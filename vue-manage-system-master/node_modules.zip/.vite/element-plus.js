import {
  Comment$1,
  Fragment,
  Teleport,
  Transition,
  TransitionGroup,
  cloneVNode,
  computed,
  createBlock,
  createCommentVNode,
  createSlots,
  createTextVNode,
  createVNode,
  defineComponent,
  getCurrentInstance,
  h,
  init_vue_runtime_esm_bundler,
  inject,
  isRef,
  isVNode,
  mergeProps,
  nextTick,
  onActivated,
  onBeforeMount,
  onBeforeUnmount,
  onBeforeUpdate,
  onDeactivated,
  onMounted,
  onUnmounted,
  onUpdated,
  openBlock,
  provide,
  reactive,
  ref,
  render,
  renderList,
  renderSlot,
  resolveComponent,
  resolveDirective,
  resolveDynamicComponent,
  shallowRef,
  toDisplayString,
  toHandlers,
  toRef,
  toRefs,
  unref,
  vModelCheckbox,
  vModelRadio,
  vModelText,
  vShow,
  watch,
  watchEffect,
  withCtx,
  withDirectives,
  withKeys,
  withModifiers
} from "./chunk-Q25HBZMS.js";
import {
  __commonJS,
  __toModule
} from "./chunk-A5ICIBVI.js";

// node_modules/lodash/isObject.js
var require_isObject = __commonJS({
  "node_modules/lodash/isObject.js"(exports, module) {
    function isObject(value) {
      var type2 = typeof value;
      return value != null && (type2 == "object" || type2 == "function");
    }
    module.exports = isObject;
  }
});

// node_modules/lodash/_freeGlobal.js
var require_freeGlobal = __commonJS({
  "node_modules/lodash/_freeGlobal.js"(exports, module) {
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    module.exports = freeGlobal;
  }
});

// node_modules/lodash/_root.js
var require_root = __commonJS({
  "node_modules/lodash/_root.js"(exports, module) {
    var freeGlobal = require_freeGlobal();
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    module.exports = root;
  }
});

// node_modules/lodash/now.js
var require_now = __commonJS({
  "node_modules/lodash/now.js"(exports, module) {
    var root = require_root();
    var now = function() {
      return root.Date.now();
    };
    module.exports = now;
  }
});

// node_modules/lodash/_trimmedEndIndex.js
var require_trimmedEndIndex = __commonJS({
  "node_modules/lodash/_trimmedEndIndex.js"(exports, module) {
    var reWhitespace = /\s/;
    function trimmedEndIndex(string2) {
      var index2 = string2.length;
      while (index2-- && reWhitespace.test(string2.charAt(index2))) {
      }
      return index2;
    }
    module.exports = trimmedEndIndex;
  }
});

// node_modules/lodash/_baseTrim.js
var require_baseTrim = __commonJS({
  "node_modules/lodash/_baseTrim.js"(exports, module) {
    var trimmedEndIndex = require_trimmedEndIndex();
    var reTrimStart = /^\s+/;
    function baseTrim(string2) {
      return string2 ? string2.slice(0, trimmedEndIndex(string2) + 1).replace(reTrimStart, "") : string2;
    }
    module.exports = baseTrim;
  }
});

// node_modules/lodash/_Symbol.js
var require_Symbol = __commonJS({
  "node_modules/lodash/_Symbol.js"(exports, module) {
    var root = require_root();
    var Symbol2 = root.Symbol;
    module.exports = Symbol2;
  }
});

// node_modules/lodash/_getRawTag.js
var require_getRawTag = __commonJS({
  "node_modules/lodash/_getRawTag.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var nativeObjectToString = objectProto.toString;
    var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
    function getRawTag(value) {
      var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
      try {
        value[symToStringTag] = void 0;
        var unmasked = true;
      } catch (e) {
      }
      var result = nativeObjectToString.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag] = tag;
        } else {
          delete value[symToStringTag];
        }
      }
      return result;
    }
    module.exports = getRawTag;
  }
});

// node_modules/lodash/_objectToString.js
var require_objectToString = __commonJS({
  "node_modules/lodash/_objectToString.js"(exports, module) {
    var objectProto = Object.prototype;
    var nativeObjectToString = objectProto.toString;
    function objectToString(value) {
      return nativeObjectToString.call(value);
    }
    module.exports = objectToString;
  }
});

// node_modules/lodash/_baseGetTag.js
var require_baseGetTag = __commonJS({
  "node_modules/lodash/_baseGetTag.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var getRawTag = require_getRawTag();
    var objectToString = require_objectToString();
    var nullTag = "[object Null]";
    var undefinedTag = "[object Undefined]";
    var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
    function baseGetTag(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag : nullTag;
      }
      return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
    }
    module.exports = baseGetTag;
  }
});

// node_modules/lodash/isObjectLike.js
var require_isObjectLike = __commonJS({
  "node_modules/lodash/isObjectLike.js"(exports, module) {
    function isObjectLike(value) {
      return value != null && typeof value == "object";
    }
    module.exports = isObjectLike;
  }
});

// node_modules/lodash/isSymbol.js
var require_isSymbol = __commonJS({
  "node_modules/lodash/isSymbol.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObjectLike = require_isObjectLike();
    var symbolTag = "[object Symbol]";
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && baseGetTag(value) == symbolTag;
    }
    module.exports = isSymbol;
  }
});

// node_modules/lodash/toNumber.js
var require_toNumber = __commonJS({
  "node_modules/lodash/toNumber.js"(exports, module) {
    var baseTrim = require_baseTrim();
    var isObject = require_isObject();
    var isSymbol = require_isSymbol();
    var NAN = 0 / 0;
    var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
    var reIsBinary = /^0b[01]+$/i;
    var reIsOctal = /^0o[0-7]+$/i;
    var freeParseInt = parseInt;
    function toNumber(value) {
      if (typeof value == "number") {
        return value;
      }
      if (isSymbol(value)) {
        return NAN;
      }
      if (isObject(value)) {
        var other = typeof value.valueOf == "function" ? value.valueOf() : value;
        value = isObject(other) ? other + "" : other;
      }
      if (typeof value != "string") {
        return value === 0 ? value : +value;
      }
      value = baseTrim(value);
      var isBinary = reIsBinary.test(value);
      return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
    }
    module.exports = toNumber;
  }
});

// node_modules/lodash/debounce.js
var require_debounce = __commonJS({
  "node_modules/lodash/debounce.js"(exports, module) {
    var isObject = require_isObject();
    var now = require_now();
    var toNumber = require_toNumber();
    var FUNC_ERROR_TEXT = "Expected a function";
    var nativeMax = Math.max;
    var nativeMin = Math.min;
    function debounce2(func, wait, options) {
      var lastArgs, lastThis, maxWait, result, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
      if (typeof func != "function") {
        throw new TypeError(FUNC_ERROR_TEXT);
      }
      wait = toNumber(wait) || 0;
      if (isObject(options)) {
        leading = !!options.leading;
        maxing = "maxWait" in options;
        maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
        trailing = "trailing" in options ? !!options.trailing : trailing;
      }
      function invokeFunc(time) {
        var args = lastArgs, thisArg = lastThis;
        lastArgs = lastThis = void 0;
        lastInvokeTime = time;
        result = func.apply(thisArg, args);
        return result;
      }
      function leadingEdge(time) {
        lastInvokeTime = time;
        timerId = setTimeout(timerExpired, wait);
        return leading ? invokeFunc(time) : result;
      }
      function remainingWait(time) {
        var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
        return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
      }
      function shouldInvoke(time) {
        var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
        return lastCallTime === void 0 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
      }
      function timerExpired() {
        var time = now();
        if (shouldInvoke(time)) {
          return trailingEdge(time);
        }
        timerId = setTimeout(timerExpired, remainingWait(time));
      }
      function trailingEdge(time) {
        timerId = void 0;
        if (trailing && lastArgs) {
          return invokeFunc(time);
        }
        lastArgs = lastThis = void 0;
        return result;
      }
      function cancel() {
        if (timerId !== void 0) {
          clearTimeout(timerId);
        }
        lastInvokeTime = 0;
        lastArgs = lastCallTime = lastThis = timerId = void 0;
      }
      function flush() {
        return timerId === void 0 ? result : trailingEdge(now());
      }
      function debounced() {
        var time = now(), isInvoking = shouldInvoke(time);
        lastArgs = arguments;
        lastThis = this;
        lastCallTime = time;
        if (isInvoking) {
          if (timerId === void 0) {
            return leadingEdge(lastCallTime);
          }
          if (maxing) {
            clearTimeout(timerId);
            timerId = setTimeout(timerExpired, wait);
            return invokeFunc(lastCallTime);
          }
        }
        if (timerId === void 0) {
          timerId = setTimeout(timerExpired, wait);
        }
        return result;
      }
      debounced.cancel = cancel;
      debounced.flush = flush;
      return debounced;
    }
    module.exports = debounce2;
  }
});

// node_modules/normalize-wheel/src/UserAgent_DEPRECATED.js
var require_UserAgent_DEPRECATED = __commonJS({
  "node_modules/normalize-wheel/src/UserAgent_DEPRECATED.js"(exports, module) {
    var _populated = false;
    var _ie;
    var _firefox;
    var _opera;
    var _webkit;
    var _chrome;
    var _ie_real_version;
    var _osx;
    var _windows;
    var _linux;
    var _android;
    var _win64;
    var _iphone;
    var _ipad;
    var _native;
    var _mobile;
    function _populate() {
      if (_populated) {
        return;
      }
      _populated = true;
      var uas = navigator.userAgent;
      var agent = /(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso|Iceweasel).(\d+\.\d+))|(?:Opera(?:.+Version.|.)(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))|(?:Trident\/\d+\.\d+.*rv:(\d+\.\d+))/.exec(uas);
      var os2 = /(Mac OS X)|(Windows)|(Linux)/.exec(uas);
      _iphone = /\b(iPhone|iP[ao]d)/.exec(uas);
      _ipad = /\b(iP[ao]d)/.exec(uas);
      _android = /Android/i.exec(uas);
      _native = /FBAN\/\w+;/i.exec(uas);
      _mobile = /Mobile/i.exec(uas);
      _win64 = !!/Win64/.exec(uas);
      if (agent) {
        _ie = agent[1] ? parseFloat(agent[1]) : agent[5] ? parseFloat(agent[5]) : NaN;
        if (_ie && document && document.documentMode) {
          _ie = document.documentMode;
        }
        var trident = /(?:Trident\/(\d+.\d+))/.exec(uas);
        _ie_real_version = trident ? parseFloat(trident[1]) + 4 : _ie;
        _firefox = agent[2] ? parseFloat(agent[2]) : NaN;
        _opera = agent[3] ? parseFloat(agent[3]) : NaN;
        _webkit = agent[4] ? parseFloat(agent[4]) : NaN;
        if (_webkit) {
          agent = /(?:Chrome\/(\d+\.\d+))/.exec(uas);
          _chrome = agent && agent[1] ? parseFloat(agent[1]) : NaN;
        } else {
          _chrome = NaN;
        }
      } else {
        _ie = _firefox = _opera = _chrome = _webkit = NaN;
      }
      if (os2) {
        if (os2[1]) {
          var ver = /(?:Mac OS X (\d+(?:[._]\d+)?))/.exec(uas);
          _osx = ver ? parseFloat(ver[1].replace("_", ".")) : true;
        } else {
          _osx = false;
        }
        _windows = !!os2[2];
        _linux = !!os2[3];
      } else {
        _osx = _windows = _linux = false;
      }
    }
    var UserAgent_DEPRECATED = {
      ie: function() {
        return _populate() || _ie;
      },
      ieCompatibilityMode: function() {
        return _populate() || _ie_real_version > _ie;
      },
      ie64: function() {
        return UserAgent_DEPRECATED.ie() && _win64;
      },
      firefox: function() {
        return _populate() || _firefox;
      },
      opera: function() {
        return _populate() || _opera;
      },
      webkit: function() {
        return _populate() || _webkit;
      },
      safari: function() {
        return UserAgent_DEPRECATED.webkit();
      },
      chrome: function() {
        return _populate() || _chrome;
      },
      windows: function() {
        return _populate() || _windows;
      },
      osx: function() {
        return _populate() || _osx;
      },
      linux: function() {
        return _populate() || _linux;
      },
      iphone: function() {
        return _populate() || _iphone;
      },
      mobile: function() {
        return _populate() || (_iphone || _ipad || _android || _mobile);
      },
      nativeApp: function() {
        return _populate() || _native;
      },
      android: function() {
        return _populate() || _android;
      },
      ipad: function() {
        return _populate() || _ipad;
      }
    };
    module.exports = UserAgent_DEPRECATED;
  }
});

// node_modules/normalize-wheel/src/ExecutionEnvironment.js
var require_ExecutionEnvironment = __commonJS({
  "node_modules/normalize-wheel/src/ExecutionEnvironment.js"(exports, module) {
    "use strict";
    var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
    var ExecutionEnvironment = {
      canUseDOM,
      canUseWorkers: typeof Worker !== "undefined",
      canUseEventListeners: canUseDOM && !!(window.addEventListener || window.attachEvent),
      canUseViewport: canUseDOM && !!window.screen,
      isInWorker: !canUseDOM
    };
    module.exports = ExecutionEnvironment;
  }
});

// node_modules/normalize-wheel/src/isEventSupported.js
var require_isEventSupported = __commonJS({
  "node_modules/normalize-wheel/src/isEventSupported.js"(exports, module) {
    "use strict";
    var ExecutionEnvironment = require_ExecutionEnvironment();
    var useHasFeature;
    if (ExecutionEnvironment.canUseDOM) {
      useHasFeature = document.implementation && document.implementation.hasFeature && document.implementation.hasFeature("", "") !== true;
    }
    function isEventSupported(eventNameSuffix, capture) {
      if (!ExecutionEnvironment.canUseDOM || capture && !("addEventListener" in document)) {
        return false;
      }
      var eventName = "on" + eventNameSuffix;
      var isSupported = eventName in document;
      if (!isSupported) {
        var element = document.createElement("div");
        element.setAttribute(eventName, "return;");
        isSupported = typeof element[eventName] === "function";
      }
      if (!isSupported && useHasFeature && eventNameSuffix === "wheel") {
        isSupported = document.implementation.hasFeature("Events.wheel", "3.0");
      }
      return isSupported;
    }
    module.exports = isEventSupported;
  }
});

// node_modules/normalize-wheel/src/normalizeWheel.js
var require_normalizeWheel = __commonJS({
  "node_modules/normalize-wheel/src/normalizeWheel.js"(exports, module) {
    "use strict";
    var UserAgent_DEPRECATED = require_UserAgent_DEPRECATED();
    var isEventSupported = require_isEventSupported();
    var PIXEL_STEP = 10;
    var LINE_HEIGHT = 40;
    var PAGE_HEIGHT = 800;
    function normalizeWheel(event2) {
      var sX = 0, sY = 0, pX = 0, pY = 0;
      if ("detail" in event2) {
        sY = event2.detail;
      }
      if ("wheelDelta" in event2) {
        sY = -event2.wheelDelta / 120;
      }
      if ("wheelDeltaY" in event2) {
        sY = -event2.wheelDeltaY / 120;
      }
      if ("wheelDeltaX" in event2) {
        sX = -event2.wheelDeltaX / 120;
      }
      if ("axis" in event2 && event2.axis === event2.HORIZONTAL_AXIS) {
        sX = sY;
        sY = 0;
      }
      pX = sX * PIXEL_STEP;
      pY = sY * PIXEL_STEP;
      if ("deltaY" in event2) {
        pY = event2.deltaY;
      }
      if ("deltaX" in event2) {
        pX = event2.deltaX;
      }
      if ((pX || pY) && event2.deltaMode) {
        if (event2.deltaMode == 1) {
          pX *= LINE_HEIGHT;
          pY *= LINE_HEIGHT;
        } else {
          pX *= PAGE_HEIGHT;
          pY *= PAGE_HEIGHT;
        }
      }
      if (pX && !sX) {
        sX = pX < 1 ? -1 : 1;
      }
      if (pY && !sY) {
        sY = pY < 1 ? -1 : 1;
      }
      return {
        spinX: sX,
        spinY: sY,
        pixelX: pX,
        pixelY: pY
      };
    }
    normalizeWheel.getEventType = function() {
      return UserAgent_DEPRECATED.firefox() ? "DOMMouseScroll" : isEventSupported("wheel") ? "wheel" : "mousewheel";
    };
    module.exports = normalizeWheel;
  }
});

// node_modules/normalize-wheel/index.js
var require_normalize_wheel = __commonJS({
  "node_modules/normalize-wheel/index.js"(exports, module) {
    module.exports = require_normalizeWheel();
  }
});

// node_modules/lodash/throttle.js
var require_throttle = __commonJS({
  "node_modules/lodash/throttle.js"(exports, module) {
    var debounce2 = require_debounce();
    var isObject = require_isObject();
    var FUNC_ERROR_TEXT = "Expected a function";
    function throttle2(func, wait, options) {
      var leading = true, trailing = true;
      if (typeof func != "function") {
        throw new TypeError(FUNC_ERROR_TEXT);
      }
      if (isObject(options)) {
        leading = "leading" in options ? !!options.leading : leading;
        trailing = "trailing" in options ? !!options.trailing : trailing;
      }
      return debounce2(func, wait, {
        "leading": leading,
        "maxWait": wait,
        "trailing": trailing
      });
    }
    module.exports = throttle2;
  }
});

// node_modules/dayjs/dayjs.min.js
var require_dayjs_min = __commonJS({
  "node_modules/dayjs/dayjs.min.js"(exports, module) {
    !function(t, e) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = e() : typeof define == "function" && define.amd ? define(e) : (t = typeof globalThis != "undefined" ? globalThis : t || self).dayjs = e();
    }(exports, function() {
      "use strict";
      var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", s = "minute", u = "hour", a = "day", o = "week", f = "month", h2 = "quarter", c = "year", d = "date", $ = "Invalid Date", l = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, M = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_") }, m = function(t2, e2, n2) {
        var r2 = String(t2);
        return !r2 || r2.length >= e2 ? t2 : "" + Array(e2 + 1 - r2.length).join(n2) + t2;
      }, g = { s: m, z: function(t2) {
        var e2 = -t2.utcOffset(), n2 = Math.abs(e2), r2 = Math.floor(n2 / 60), i2 = n2 % 60;
        return (e2 <= 0 ? "+" : "-") + m(r2, 2, "0") + ":" + m(i2, 2, "0");
      }, m: function t2(e2, n2) {
        if (e2.date() < n2.date())
          return -t2(n2, e2);
        var r2 = 12 * (n2.year() - e2.year()) + (n2.month() - e2.month()), i2 = e2.clone().add(r2, f), s2 = n2 - i2 < 0, u2 = e2.clone().add(r2 + (s2 ? -1 : 1), f);
        return +(-(r2 + (n2 - i2) / (s2 ? i2 - u2 : u2 - i2)) || 0);
      }, a: function(t2) {
        return t2 < 0 ? Math.ceil(t2) || 0 : Math.floor(t2);
      }, p: function(t2) {
        return { M: f, y: c, w: o, d: a, D: d, h: u, m: s, s: i, ms: r, Q: h2 }[t2] || String(t2 || "").toLowerCase().replace(/s$/, "");
      }, u: function(t2) {
        return t2 === void 0;
      } }, D = "en", v = {};
      v[D] = M;
      var p = function(t2) {
        return t2 instanceof _;
      }, S = function(t2, e2, n2) {
        var r2;
        if (!t2)
          return D;
        if (typeof t2 == "string")
          v[t2] && (r2 = t2), e2 && (v[t2] = e2, r2 = t2);
        else {
          var i2 = t2.name;
          v[i2] = t2, r2 = i2;
        }
        return !n2 && r2 && (D = r2), r2 || !n2 && D;
      }, w = function(t2, e2) {
        if (p(t2))
          return t2.clone();
        var n2 = typeof e2 == "object" ? e2 : {};
        return n2.date = t2, n2.args = arguments, new _(n2);
      }, O = g;
      O.l = S, O.i = p, O.w = function(t2, e2) {
        return w(t2, { locale: e2.$L, utc: e2.$u, x: e2.$x, $offset: e2.$offset });
      };
      var _ = function() {
        function M2(t2) {
          this.$L = S(t2.locale, null, true), this.parse(t2);
        }
        var m2 = M2.prototype;
        return m2.parse = function(t2) {
          this.$d = function(t3) {
            var e2 = t3.date, n2 = t3.utc;
            if (e2 === null)
              return new Date(NaN);
            if (O.u(e2))
              return new Date();
            if (e2 instanceof Date)
              return new Date(e2);
            if (typeof e2 == "string" && !/Z$/i.test(e2)) {
              var r2 = e2.match(l);
              if (r2) {
                var i2 = r2[2] - 1 || 0, s2 = (r2[7] || "0").substring(0, 3);
                return n2 ? new Date(Date.UTC(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2)) : new Date(r2[1], i2, r2[3] || 1, r2[4] || 0, r2[5] || 0, r2[6] || 0, s2);
              }
            }
            return new Date(e2);
          }(t2), this.$x = t2.x || {}, this.init();
        }, m2.init = function() {
          var t2 = this.$d;
          this.$y = t2.getFullYear(), this.$M = t2.getMonth(), this.$D = t2.getDate(), this.$W = t2.getDay(), this.$H = t2.getHours(), this.$m = t2.getMinutes(), this.$s = t2.getSeconds(), this.$ms = t2.getMilliseconds();
        }, m2.$utils = function() {
          return O;
        }, m2.isValid = function() {
          return !(this.$d.toString() === $);
        }, m2.isSame = function(t2, e2) {
          var n2 = w(t2);
          return this.startOf(e2) <= n2 && n2 <= this.endOf(e2);
        }, m2.isAfter = function(t2, e2) {
          return w(t2) < this.startOf(e2);
        }, m2.isBefore = function(t2, e2) {
          return this.endOf(e2) < w(t2);
        }, m2.$g = function(t2, e2, n2) {
          return O.u(t2) ? this[e2] : this.set(n2, t2);
        }, m2.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, m2.valueOf = function() {
          return this.$d.getTime();
        }, m2.startOf = function(t2, e2) {
          var n2 = this, r2 = !!O.u(e2) || e2, h3 = O.p(t2), $2 = function(t3, e3) {
            var i2 = O.w(n2.$u ? Date.UTC(n2.$y, e3, t3) : new Date(n2.$y, e3, t3), n2);
            return r2 ? i2 : i2.endOf(a);
          }, l2 = function(t3, e3) {
            return O.w(n2.toDate()[t3].apply(n2.toDate("s"), (r2 ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e3)), n2);
          }, y2 = this.$W, M3 = this.$M, m3 = this.$D, g2 = "set" + (this.$u ? "UTC" : "");
          switch (h3) {
            case c:
              return r2 ? $2(1, 0) : $2(31, 11);
            case f:
              return r2 ? $2(1, M3) : $2(0, M3 + 1);
            case o:
              var D2 = this.$locale().weekStart || 0, v2 = (y2 < D2 ? y2 + 7 : y2) - D2;
              return $2(r2 ? m3 - v2 : m3 + (6 - v2), M3);
            case a:
            case d:
              return l2(g2 + "Hours", 0);
            case u:
              return l2(g2 + "Minutes", 1);
            case s:
              return l2(g2 + "Seconds", 2);
            case i:
              return l2(g2 + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, m2.endOf = function(t2) {
          return this.startOf(t2, false);
        }, m2.$set = function(t2, e2) {
          var n2, o2 = O.p(t2), h3 = "set" + (this.$u ? "UTC" : ""), $2 = (n2 = {}, n2[a] = h3 + "Date", n2[d] = h3 + "Date", n2[f] = h3 + "Month", n2[c] = h3 + "FullYear", n2[u] = h3 + "Hours", n2[s] = h3 + "Minutes", n2[i] = h3 + "Seconds", n2[r] = h3 + "Milliseconds", n2)[o2], l2 = o2 === a ? this.$D + (e2 - this.$W) : e2;
          if (o2 === f || o2 === c) {
            var y2 = this.clone().set(d, 1);
            y2.$d[$2](l2), y2.init(), this.$d = y2.set(d, Math.min(this.$D, y2.daysInMonth())).$d;
          } else
            $2 && this.$d[$2](l2);
          return this.init(), this;
        }, m2.set = function(t2, e2) {
          return this.clone().$set(t2, e2);
        }, m2.get = function(t2) {
          return this[O.p(t2)]();
        }, m2.add = function(r2, h3) {
          var d2, $2 = this;
          r2 = Number(r2);
          var l2 = O.p(h3), y2 = function(t2) {
            var e2 = w($2);
            return O.w(e2.date(e2.date() + Math.round(t2 * r2)), $2);
          };
          if (l2 === f)
            return this.set(f, this.$M + r2);
          if (l2 === c)
            return this.set(c, this.$y + r2);
          if (l2 === a)
            return y2(1);
          if (l2 === o)
            return y2(7);
          var M3 = (d2 = {}, d2[s] = e, d2[u] = n, d2[i] = t, d2)[l2] || 1, m3 = this.$d.getTime() + r2 * M3;
          return O.w(m3, this);
        }, m2.subtract = function(t2, e2) {
          return this.add(-1 * t2, e2);
        }, m2.format = function(t2) {
          var e2 = this;
          if (!this.isValid())
            return $;
          var n2 = t2 || "YYYY-MM-DDTHH:mm:ssZ", r2 = O.z(this), i2 = this.$locale(), s2 = this.$H, u2 = this.$m, a2 = this.$M, o2 = i2.weekdays, f2 = i2.months, h3 = function(t3, r3, i3, s3) {
            return t3 && (t3[r3] || t3(e2, n2)) || i3[r3].substr(0, s3);
          }, c2 = function(t3) {
            return O.s(s2 % 12 || 12, t3, "0");
          }, d2 = i2.meridiem || function(t3, e3, n3) {
            var r3 = t3 < 12 ? "AM" : "PM";
            return n3 ? r3.toLowerCase() : r3;
          }, l2 = { YY: String(this.$y).slice(-2), YYYY: this.$y, M: a2 + 1, MM: O.s(a2 + 1, 2, "0"), MMM: h3(i2.monthsShort, a2, f2, 3), MMMM: h3(f2, a2), D: this.$D, DD: O.s(this.$D, 2, "0"), d: String(this.$W), dd: h3(i2.weekdaysMin, this.$W, o2, 2), ddd: h3(i2.weekdaysShort, this.$W, o2, 3), dddd: o2[this.$W], H: String(s2), HH: O.s(s2, 2, "0"), h: c2(1), hh: c2(2), a: d2(s2, u2, true), A: d2(s2, u2, false), m: String(u2), mm: O.s(u2, 2, "0"), s: String(this.$s), ss: O.s(this.$s, 2, "0"), SSS: O.s(this.$ms, 3, "0"), Z: r2 };
          return n2.replace(y, function(t3, e3) {
            return e3 || l2[t3] || r2.replace(":", "");
          });
        }, m2.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, m2.diff = function(r2, d2, $2) {
          var l2, y2 = O.p(d2), M3 = w(r2), m3 = (M3.utcOffset() - this.utcOffset()) * e, g2 = this - M3, D2 = O.m(this, M3);
          return D2 = (l2 = {}, l2[c] = D2 / 12, l2[f] = D2, l2[h2] = D2 / 3, l2[o] = (g2 - m3) / 6048e5, l2[a] = (g2 - m3) / 864e5, l2[u] = g2 / n, l2[s] = g2 / e, l2[i] = g2 / t, l2)[y2] || g2, $2 ? D2 : O.a(D2);
        }, m2.daysInMonth = function() {
          return this.endOf(f).$D;
        }, m2.$locale = function() {
          return v[this.$L];
        }, m2.locale = function(t2, e2) {
          if (!t2)
            return this.$L;
          var n2 = this.clone(), r2 = S(t2, e2, true);
          return r2 && (n2.$L = r2), n2;
        }, m2.clone = function() {
          return O.w(this.$d, this);
        }, m2.toDate = function() {
          return new Date(this.valueOf());
        }, m2.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, m2.toISOString = function() {
          return this.$d.toISOString();
        }, m2.toString = function() {
          return this.$d.toUTCString();
        }, M2;
      }(), b = _.prototype;
      return w.prototype = b, [["$ms", r], ["$s", i], ["$m", s], ["$H", u], ["$W", a], ["$M", f], ["$y", c], ["$D", d]].forEach(function(t2) {
        b[t2[1]] = function(e2) {
          return this.$g(e2, t2[0], t2[1]);
        };
      }), w.extend = function(t2, e2) {
        return t2.$i || (t2(e2, _, w), t2.$i = true), w;
      }, w.locale = S, w.isDayjs = p, w.unix = function(t2) {
        return w(1e3 * t2);
      }, w.en = v[D], w.Ls = v, w.p = {}, w;
    });
  }
});

// node_modules/dayjs/plugin/localeData.js
var require_localeData = __commonJS({
  "node_modules/dayjs/plugin/localeData.js"(exports, module) {
    !function(n, e) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = e() : typeof define == "function" && define.amd ? define(e) : (n = typeof globalThis != "undefined" ? globalThis : n || self).dayjs_plugin_localeData = e();
    }(exports, function() {
      "use strict";
      return function(n, e, t) {
        var r = e.prototype, o = function(n2) {
          return n2 && (n2.indexOf ? n2 : n2.s);
        }, u = function(n2, e2, t2, r2, u2) {
          var i2 = n2.name ? n2 : n2.$locale(), a2 = o(i2[e2]), s2 = o(i2[t2]), f = a2 || s2.map(function(n3) {
            return n3.substr(0, r2);
          });
          if (!u2)
            return f;
          var d = i2.weekStart;
          return f.map(function(n3, e3) {
            return f[(e3 + (d || 0)) % 7];
          });
        }, i = function() {
          return t.Ls[t.locale()];
        }, a = function(n2, e2) {
          return n2.formats[e2] || function(n3) {
            return n3.replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(n4, e3, t2) {
              return e3 || t2.slice(1);
            });
          }(n2.formats[e2.toUpperCase()]);
        }, s = function() {
          var n2 = this;
          return { months: function(e2) {
            return e2 ? e2.format("MMMM") : u(n2, "months");
          }, monthsShort: function(e2) {
            return e2 ? e2.format("MMM") : u(n2, "monthsShort", "months", 3);
          }, firstDayOfWeek: function() {
            return n2.$locale().weekStart || 0;
          }, weekdays: function(e2) {
            return e2 ? e2.format("dddd") : u(n2, "weekdays");
          }, weekdaysMin: function(e2) {
            return e2 ? e2.format("dd") : u(n2, "weekdaysMin", "weekdays", 2);
          }, weekdaysShort: function(e2) {
            return e2 ? e2.format("ddd") : u(n2, "weekdaysShort", "weekdays", 3);
          }, longDateFormat: function(e2) {
            return a(n2.$locale(), e2);
          }, meridiem: this.$locale().meridiem, ordinal: this.$locale().ordinal };
        };
        r.localeData = function() {
          return s.bind(this)();
        }, t.localeData = function() {
          var n2 = i();
          return { firstDayOfWeek: function() {
            return n2.weekStart || 0;
          }, weekdays: function() {
            return t.weekdays();
          }, weekdaysShort: function() {
            return t.weekdaysShort();
          }, weekdaysMin: function() {
            return t.weekdaysMin();
          }, months: function() {
            return t.months();
          }, monthsShort: function() {
            return t.monthsShort();
          }, longDateFormat: function(e2) {
            return a(n2, e2);
          }, meridiem: n2.meridiem, ordinal: n2.ordinal };
        }, t.months = function() {
          return u(i(), "months");
        }, t.monthsShort = function() {
          return u(i(), "monthsShort", "months", 3);
        }, t.weekdays = function(n2) {
          return u(i(), "weekdays", null, null, n2);
        }, t.weekdaysShort = function(n2) {
          return u(i(), "weekdaysShort", "weekdays", 3, n2);
        }, t.weekdaysMin = function(n2) {
          return u(i(), "weekdaysMin", "weekdays", 2, n2);
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/customParseFormat.js
var require_customParseFormat = __commonJS({
  "node_modules/dayjs/plugin/customParseFormat.js"(exports, module) {
    !function(t, e) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = e() : typeof define == "function" && define.amd ? define(e) : (t = typeof globalThis != "undefined" ? globalThis : t || self).dayjs_plugin_customParseFormat = e();
    }(exports, function() {
      "use strict";
      var t = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" }, e = /(\[[^[]*\])|([-:/.()\s]+)|(A|a|YYYY|YY?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g, n = /\d\d/, r = /\d\d?/, i = /\d*[^\s\d-_:/()]+/, o = {};
      var s = function(t2) {
        return function(e2) {
          this[t2] = +e2;
        };
      }, a = [/[+-]\d\d:?(\d\d)?|Z/, function(t2) {
        (this.zone || (this.zone = {})).offset = function(t3) {
          if (!t3)
            return 0;
          if (t3 === "Z")
            return 0;
          var e2 = t3.match(/([+-]|\d\d)/g), n2 = 60 * e2[1] + (+e2[2] || 0);
          return n2 === 0 ? 0 : e2[0] === "+" ? -n2 : n2;
        }(t2);
      }], f = function(t2) {
        var e2 = o[t2];
        return e2 && (e2.indexOf ? e2 : e2.s.concat(e2.f));
      }, h2 = function(t2, e2) {
        var n2, r2 = o.meridiem;
        if (r2) {
          for (var i2 = 1; i2 <= 24; i2 += 1)
            if (t2.indexOf(r2(i2, 0, e2)) > -1) {
              n2 = i2 > 12;
              break;
            }
        } else
          n2 = t2 === (e2 ? "pm" : "PM");
        return n2;
      }, u = { A: [i, function(t2) {
        this.afternoon = h2(t2, false);
      }], a: [i, function(t2) {
        this.afternoon = h2(t2, true);
      }], S: [/\d/, function(t2) {
        this.milliseconds = 100 * +t2;
      }], SS: [n, function(t2) {
        this.milliseconds = 10 * +t2;
      }], SSS: [/\d{3}/, function(t2) {
        this.milliseconds = +t2;
      }], s: [r, s("seconds")], ss: [r, s("seconds")], m: [r, s("minutes")], mm: [r, s("minutes")], H: [r, s("hours")], h: [r, s("hours")], HH: [r, s("hours")], hh: [r, s("hours")], D: [r, s("day")], DD: [n, s("day")], Do: [i, function(t2) {
        var e2 = o.ordinal, n2 = t2.match(/\d+/);
        if (this.day = n2[0], e2)
          for (var r2 = 1; r2 <= 31; r2 += 1)
            e2(r2).replace(/\[|\]/g, "") === t2 && (this.day = r2);
      }], M: [r, s("month")], MM: [n, s("month")], MMM: [i, function(t2) {
        var e2 = f("months"), n2 = (f("monthsShort") || e2.map(function(t3) {
          return t3.substr(0, 3);
        })).indexOf(t2) + 1;
        if (n2 < 1)
          throw new Error();
        this.month = n2 % 12 || n2;
      }], MMMM: [i, function(t2) {
        var e2 = f("months").indexOf(t2) + 1;
        if (e2 < 1)
          throw new Error();
        this.month = e2 % 12 || e2;
      }], Y: [/[+-]?\d+/, s("year")], YY: [n, function(t2) {
        t2 = +t2, this.year = t2 + (t2 > 68 ? 1900 : 2e3);
      }], YYYY: [/\d{4}/, s("year")], Z: a, ZZ: a };
      function d(n2) {
        var r2, i2;
        r2 = n2, i2 = o && o.formats;
        for (var s2 = (n2 = r2.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, function(e2, n3, r3) {
          var o2 = r3 && r3.toUpperCase();
          return n3 || i2[r3] || t[r3] || i2[o2].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, function(t2, e3, n4) {
            return e3 || n4.slice(1);
          });
        })).match(e), a2 = s2.length, f2 = 0; f2 < a2; f2 += 1) {
          var h3 = s2[f2], d2 = u[h3], c = d2 && d2[0], l = d2 && d2[1];
          s2[f2] = l ? { regex: c, parser: l } : h3.replace(/^\[|\]$/g, "");
        }
        return function(t2) {
          for (var e2 = {}, n3 = 0, r3 = 0; n3 < a2; n3 += 1) {
            var i3 = s2[n3];
            if (typeof i3 == "string")
              r3 += i3.length;
            else {
              var o2 = i3.regex, f3 = i3.parser, h4 = t2.substr(r3), u2 = o2.exec(h4)[0];
              f3.call(e2, u2), t2 = t2.replace(u2, "");
            }
          }
          return function(t3) {
            var e3 = t3.afternoon;
            if (e3 !== void 0) {
              var n4 = t3.hours;
              e3 ? n4 < 12 && (t3.hours += 12) : n4 === 12 && (t3.hours = 0), delete t3.afternoon;
            }
          }(e2), e2;
        };
      }
      return function(t2, e2, n2) {
        n2.p.customParseFormat = true;
        var r2 = e2.prototype, i2 = r2.parse;
        r2.parse = function(t3) {
          var e3 = t3.date, r3 = t3.utc, s2 = t3.args;
          this.$u = r3;
          var a2 = s2[1];
          if (typeof a2 == "string") {
            var f2 = s2[2] === true, h3 = s2[3] === true, u2 = f2 || h3, c = s2[2];
            h3 && (c = s2[2]), o = this.$locale(), !f2 && c && (o = n2.Ls[c]), this.$d = function(t4, e4, n3) {
              try {
                var r4 = d(e4)(t4), i3 = r4.year, o2 = r4.month, s3 = r4.day, a3 = r4.hours, f3 = r4.minutes, h4 = r4.seconds, u3 = r4.milliseconds, c2 = r4.zone, l2 = new Date(), m2 = s3 || (i3 || o2 ? 1 : l2.getDate()), M2 = i3 || l2.getFullYear(), Y = 0;
                i3 && !o2 || (Y = o2 > 0 ? o2 - 1 : l2.getMonth());
                var v = a3 || 0, p = f3 || 0, D = h4 || 0, g = u3 || 0;
                return c2 ? new Date(Date.UTC(M2, Y, m2, v, p, D, g + 60 * c2.offset * 1e3)) : n3 ? new Date(Date.UTC(M2, Y, m2, v, p, D, g)) : new Date(M2, Y, m2, v, p, D, g);
              } catch (t5) {
                return new Date("");
              }
            }(e3, a2, r3), this.init(), c && c !== true && (this.$L = this.locale(c).$L), u2 && e3 !== this.format(a2) && (this.$d = new Date("")), o = {};
          } else if (a2 instanceof Array)
            for (var l = a2.length, m = 1; m <= l; m += 1) {
              s2[1] = a2[m - 1];
              var M = n2.apply(this, s2);
              if (M.isValid()) {
                this.$d = M.$d, this.$L = M.$L, this.init();
                break;
              }
              m === l && (this.$d = new Date(""));
            }
          else
            i2.call(this, t3);
        };
      };
    });
  }
});

// node_modules/lodash/_arrayPush.js
var require_arrayPush = __commonJS({
  "node_modules/lodash/_arrayPush.js"(exports, module) {
    function arrayPush(array3, values) {
      var index2 = -1, length = values.length, offset2 = array3.length;
      while (++index2 < length) {
        array3[offset2 + index2] = values[index2];
      }
      return array3;
    }
    module.exports = arrayPush;
  }
});

// node_modules/lodash/_baseIsArguments.js
var require_baseIsArguments = __commonJS({
  "node_modules/lodash/_baseIsArguments.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObjectLike = require_isObjectLike();
    var argsTag = "[object Arguments]";
    function baseIsArguments(value) {
      return isObjectLike(value) && baseGetTag(value) == argsTag;
    }
    module.exports = baseIsArguments;
  }
});

// node_modules/lodash/isArguments.js
var require_isArguments = __commonJS({
  "node_modules/lodash/isArguments.js"(exports, module) {
    var baseIsArguments = require_baseIsArguments();
    var isObjectLike = require_isObjectLike();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var isArguments = baseIsArguments(function() {
      return arguments;
    }()) ? baseIsArguments : function(value) {
      return isObjectLike(value) && hasOwnProperty.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
    };
    module.exports = isArguments;
  }
});

// node_modules/lodash/isArray.js
var require_isArray = __commonJS({
  "node_modules/lodash/isArray.js"(exports, module) {
    var isArray = Array.isArray;
    module.exports = isArray;
  }
});

// node_modules/lodash/_isFlattenable.js
var require_isFlattenable = __commonJS({
  "node_modules/lodash/_isFlattenable.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var isArguments = require_isArguments();
    var isArray = require_isArray();
    var spreadableSymbol = Symbol2 ? Symbol2.isConcatSpreadable : void 0;
    function isFlattenable(value) {
      return isArray(value) || isArguments(value) || !!(spreadableSymbol && value && value[spreadableSymbol]);
    }
    module.exports = isFlattenable;
  }
});

// node_modules/lodash/_baseFlatten.js
var require_baseFlatten = __commonJS({
  "node_modules/lodash/_baseFlatten.js"(exports, module) {
    var arrayPush = require_arrayPush();
    var isFlattenable = require_isFlattenable();
    function baseFlatten(array3, depth, predicate, isStrict, result) {
      var index2 = -1, length = array3.length;
      predicate || (predicate = isFlattenable);
      result || (result = []);
      while (++index2 < length) {
        var value = array3[index2];
        if (depth > 0 && predicate(value)) {
          if (depth > 1) {
            baseFlatten(value, depth - 1, predicate, isStrict, result);
          } else {
            arrayPush(result, value);
          }
        } else if (!isStrict) {
          result[result.length] = value;
        }
      }
      return result;
    }
    module.exports = baseFlatten;
  }
});

// node_modules/lodash/identity.js
var require_identity = __commonJS({
  "node_modules/lodash/identity.js"(exports, module) {
    function identity(value) {
      return value;
    }
    module.exports = identity;
  }
});

// node_modules/lodash/_apply.js
var require_apply = __commonJS({
  "node_modules/lodash/_apply.js"(exports, module) {
    function apply(func, thisArg, args) {
      switch (args.length) {
        case 0:
          return func.call(thisArg);
        case 1:
          return func.call(thisArg, args[0]);
        case 2:
          return func.call(thisArg, args[0], args[1]);
        case 3:
          return func.call(thisArg, args[0], args[1], args[2]);
      }
      return func.apply(thisArg, args);
    }
    module.exports = apply;
  }
});

// node_modules/lodash/_overRest.js
var require_overRest = __commonJS({
  "node_modules/lodash/_overRest.js"(exports, module) {
    var apply = require_apply();
    var nativeMax = Math.max;
    function overRest(func, start2, transform) {
      start2 = nativeMax(start2 === void 0 ? func.length - 1 : start2, 0);
      return function() {
        var args = arguments, index2 = -1, length = nativeMax(args.length - start2, 0), array3 = Array(length);
        while (++index2 < length) {
          array3[index2] = args[start2 + index2];
        }
        index2 = -1;
        var otherArgs = Array(start2 + 1);
        while (++index2 < start2) {
          otherArgs[index2] = args[index2];
        }
        otherArgs[start2] = transform(array3);
        return apply(func, this, otherArgs);
      };
    }
    module.exports = overRest;
  }
});

// node_modules/lodash/constant.js
var require_constant = __commonJS({
  "node_modules/lodash/constant.js"(exports, module) {
    function constant(value) {
      return function() {
        return value;
      };
    }
    module.exports = constant;
  }
});

// node_modules/lodash/isFunction.js
var require_isFunction = __commonJS({
  "node_modules/lodash/isFunction.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObject = require_isObject();
    var asyncTag = "[object AsyncFunction]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var proxyTag = "[object Proxy]";
    function isFunction(value) {
      if (!isObject(value)) {
        return false;
      }
      var tag = baseGetTag(value);
      return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
    }
    module.exports = isFunction;
  }
});

// node_modules/lodash/_coreJsData.js
var require_coreJsData = __commonJS({
  "node_modules/lodash/_coreJsData.js"(exports, module) {
    var root = require_root();
    var coreJsData = root["__core-js_shared__"];
    module.exports = coreJsData;
  }
});

// node_modules/lodash/_isMasked.js
var require_isMasked = __commonJS({
  "node_modules/lodash/_isMasked.js"(exports, module) {
    var coreJsData = require_coreJsData();
    var maskSrcKey = function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    }();
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    module.exports = isMasked;
  }
});

// node_modules/lodash/_toSource.js
var require_toSource = __commonJS({
  "node_modules/lodash/_toSource.js"(exports, module) {
    var funcProto = Function.prototype;
    var funcToString = funcProto.toString;
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    module.exports = toSource;
  }
});

// node_modules/lodash/_baseIsNative.js
var require_baseIsNative = __commonJS({
  "node_modules/lodash/_baseIsNative.js"(exports, module) {
    var isFunction = require_isFunction();
    var isMasked = require_isMasked();
    var isObject = require_isObject();
    var toSource = require_toSource();
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var reIsNative = RegExp("^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern2 = isFunction(value) ? reIsNative : reIsHostCtor;
      return pattern2.test(toSource(value));
    }
    module.exports = baseIsNative;
  }
});

// node_modules/lodash/_getValue.js
var require_getValue = __commonJS({
  "node_modules/lodash/_getValue.js"(exports, module) {
    function getValue(object3, key) {
      return object3 == null ? void 0 : object3[key];
    }
    module.exports = getValue;
  }
});

// node_modules/lodash/_getNative.js
var require_getNative = __commonJS({
  "node_modules/lodash/_getNative.js"(exports, module) {
    var baseIsNative = require_baseIsNative();
    var getValue = require_getValue();
    function getNative(object3, key) {
      var value = getValue(object3, key);
      return baseIsNative(value) ? value : void 0;
    }
    module.exports = getNative;
  }
});

// node_modules/lodash/_defineProperty.js
var require_defineProperty = __commonJS({
  "node_modules/lodash/_defineProperty.js"(exports, module) {
    var getNative = require_getNative();
    var defineProperty = function() {
      try {
        var func = getNative(Object, "defineProperty");
        func({}, "", {});
        return func;
      } catch (e) {
      }
    }();
    module.exports = defineProperty;
  }
});

// node_modules/lodash/_baseSetToString.js
var require_baseSetToString = __commonJS({
  "node_modules/lodash/_baseSetToString.js"(exports, module) {
    var constant = require_constant();
    var defineProperty = require_defineProperty();
    var identity = require_identity();
    var baseSetToString = !defineProperty ? identity : function(func, string2) {
      return defineProperty(func, "toString", {
        "configurable": true,
        "enumerable": false,
        "value": constant(string2),
        "writable": true
      });
    };
    module.exports = baseSetToString;
  }
});

// node_modules/lodash/_shortOut.js
var require_shortOut = __commonJS({
  "node_modules/lodash/_shortOut.js"(exports, module) {
    var HOT_COUNT = 800;
    var HOT_SPAN = 16;
    var nativeNow = Date.now;
    function shortOut(func) {
      var count = 0, lastCalled = 0;
      return function() {
        var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
        lastCalled = stamp;
        if (remaining > 0) {
          if (++count >= HOT_COUNT) {
            return arguments[0];
          }
        } else {
          count = 0;
        }
        return func.apply(void 0, arguments);
      };
    }
    module.exports = shortOut;
  }
});

// node_modules/lodash/_setToString.js
var require_setToString = __commonJS({
  "node_modules/lodash/_setToString.js"(exports, module) {
    var baseSetToString = require_baseSetToString();
    var shortOut = require_shortOut();
    var setToString = shortOut(baseSetToString);
    module.exports = setToString;
  }
});

// node_modules/lodash/_baseRest.js
var require_baseRest = __commonJS({
  "node_modules/lodash/_baseRest.js"(exports, module) {
    var identity = require_identity();
    var overRest = require_overRest();
    var setToString = require_setToString();
    function baseRest(func, start2) {
      return setToString(overRest(func, start2, identity), func + "");
    }
    module.exports = baseRest;
  }
});

// node_modules/lodash/_nativeCreate.js
var require_nativeCreate = __commonJS({
  "node_modules/lodash/_nativeCreate.js"(exports, module) {
    var getNative = require_getNative();
    var nativeCreate = getNative(Object, "create");
    module.exports = nativeCreate;
  }
});

// node_modules/lodash/_hashClear.js
var require_hashClear = __commonJS({
  "node_modules/lodash/_hashClear.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
      this.size = 0;
    }
    module.exports = hashClear;
  }
});

// node_modules/lodash/_hashDelete.js
var require_hashDelete = __commonJS({
  "node_modules/lodash/_hashDelete.js"(exports, module) {
    function hashDelete(key) {
      var result = this.has(key) && delete this.__data__[key];
      this.size -= result ? 1 : 0;
      return result;
    }
    module.exports = hashDelete;
  }
});

// node_modules/lodash/_hashGet.js
var require_hashGet = __commonJS({
  "node_modules/lodash/_hashGet.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    module.exports = hashGet;
  }
});

// node_modules/lodash/_hashHas.js
var require_hashHas = __commonJS({
  "node_modules/lodash/_hashHas.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    module.exports = hashHas;
  }
});

// node_modules/lodash/_hashSet.js
var require_hashSet = __commonJS({
  "node_modules/lodash/_hashSet.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    function hashSet(key, value) {
      var data = this.__data__;
      this.size += this.has(key) ? 0 : 1;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    module.exports = hashSet;
  }
});

// node_modules/lodash/_Hash.js
var require_Hash = __commonJS({
  "node_modules/lodash/_Hash.js"(exports, module) {
    var hashClear = require_hashClear();
    var hashDelete = require_hashDelete();
    var hashGet = require_hashGet();
    var hashHas = require_hashHas();
    var hashSet = require_hashSet();
    function Hash(entries) {
      var index2 = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index2 < length) {
        var entry = entries[index2];
        this.set(entry[0], entry[1]);
      }
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    module.exports = Hash;
  }
});

// node_modules/lodash/_listCacheClear.js
var require_listCacheClear = __commonJS({
  "node_modules/lodash/_listCacheClear.js"(exports, module) {
    function listCacheClear() {
      this.__data__ = [];
      this.size = 0;
    }
    module.exports = listCacheClear;
  }
});

// node_modules/lodash/eq.js
var require_eq = __commonJS({
  "node_modules/lodash/eq.js"(exports, module) {
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    module.exports = eq;
  }
});

// node_modules/lodash/_assocIndexOf.js
var require_assocIndexOf = __commonJS({
  "node_modules/lodash/_assocIndexOf.js"(exports, module) {
    var eq = require_eq();
    function assocIndexOf(array3, key) {
      var length = array3.length;
      while (length--) {
        if (eq(array3[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    module.exports = assocIndexOf;
  }
});

// node_modules/lodash/_listCacheDelete.js
var require_listCacheDelete = __commonJS({
  "node_modules/lodash/_listCacheDelete.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    var arrayProto = Array.prototype;
    var splice = arrayProto.splice;
    function listCacheDelete(key) {
      var data = this.__data__, index2 = assocIndexOf(data, key);
      if (index2 < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index2 == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index2, 1);
      }
      --this.size;
      return true;
    }
    module.exports = listCacheDelete;
  }
});

// node_modules/lodash/_listCacheGet.js
var require_listCacheGet = __commonJS({
  "node_modules/lodash/_listCacheGet.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheGet(key) {
      var data = this.__data__, index2 = assocIndexOf(data, key);
      return index2 < 0 ? void 0 : data[index2][1];
    }
    module.exports = listCacheGet;
  }
});

// node_modules/lodash/_listCacheHas.js
var require_listCacheHas = __commonJS({
  "node_modules/lodash/_listCacheHas.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    module.exports = listCacheHas;
  }
});

// node_modules/lodash/_listCacheSet.js
var require_listCacheSet = __commonJS({
  "node_modules/lodash/_listCacheSet.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheSet(key, value) {
      var data = this.__data__, index2 = assocIndexOf(data, key);
      if (index2 < 0) {
        ++this.size;
        data.push([key, value]);
      } else {
        data[index2][1] = value;
      }
      return this;
    }
    module.exports = listCacheSet;
  }
});

// node_modules/lodash/_ListCache.js
var require_ListCache = __commonJS({
  "node_modules/lodash/_ListCache.js"(exports, module) {
    var listCacheClear = require_listCacheClear();
    var listCacheDelete = require_listCacheDelete();
    var listCacheGet = require_listCacheGet();
    var listCacheHas = require_listCacheHas();
    var listCacheSet = require_listCacheSet();
    function ListCache(entries) {
      var index2 = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index2 < length) {
        var entry = entries[index2];
        this.set(entry[0], entry[1]);
      }
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    module.exports = ListCache;
  }
});

// node_modules/lodash/_Map.js
var require_Map = __commonJS({
  "node_modules/lodash/_Map.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Map2 = getNative(root, "Map");
    module.exports = Map2;
  }
});

// node_modules/lodash/_mapCacheClear.js
var require_mapCacheClear = __commonJS({
  "node_modules/lodash/_mapCacheClear.js"(exports, module) {
    var Hash = require_Hash();
    var ListCache = require_ListCache();
    var Map2 = require_Map();
    function mapCacheClear() {
      this.size = 0;
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map2 || ListCache)(),
        "string": new Hash()
      };
    }
    module.exports = mapCacheClear;
  }
});

// node_modules/lodash/_isKeyable.js
var require_isKeyable = __commonJS({
  "node_modules/lodash/_isKeyable.js"(exports, module) {
    function isKeyable(value) {
      var type2 = typeof value;
      return type2 == "string" || type2 == "number" || type2 == "symbol" || type2 == "boolean" ? value !== "__proto__" : value === null;
    }
    module.exports = isKeyable;
  }
});

// node_modules/lodash/_getMapData.js
var require_getMapData = __commonJS({
  "node_modules/lodash/_getMapData.js"(exports, module) {
    var isKeyable = require_isKeyable();
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    module.exports = getMapData;
  }
});

// node_modules/lodash/_mapCacheDelete.js
var require_mapCacheDelete = __commonJS({
  "node_modules/lodash/_mapCacheDelete.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheDelete(key) {
      var result = getMapData(this, key)["delete"](key);
      this.size -= result ? 1 : 0;
      return result;
    }
    module.exports = mapCacheDelete;
  }
});

// node_modules/lodash/_mapCacheGet.js
var require_mapCacheGet = __commonJS({
  "node_modules/lodash/_mapCacheGet.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    module.exports = mapCacheGet;
  }
});

// node_modules/lodash/_mapCacheHas.js
var require_mapCacheHas = __commonJS({
  "node_modules/lodash/_mapCacheHas.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    module.exports = mapCacheHas;
  }
});

// node_modules/lodash/_mapCacheSet.js
var require_mapCacheSet = __commonJS({
  "node_modules/lodash/_mapCacheSet.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheSet(key, value) {
      var data = getMapData(this, key), size = data.size;
      data.set(key, value);
      this.size += data.size == size ? 0 : 1;
      return this;
    }
    module.exports = mapCacheSet;
  }
});

// node_modules/lodash/_MapCache.js
var require_MapCache = __commonJS({
  "node_modules/lodash/_MapCache.js"(exports, module) {
    var mapCacheClear = require_mapCacheClear();
    var mapCacheDelete = require_mapCacheDelete();
    var mapCacheGet = require_mapCacheGet();
    var mapCacheHas = require_mapCacheHas();
    var mapCacheSet = require_mapCacheSet();
    function MapCache(entries) {
      var index2 = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index2 < length) {
        var entry = entries[index2];
        this.set(entry[0], entry[1]);
      }
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    module.exports = MapCache;
  }
});

// node_modules/lodash/_setCacheAdd.js
var require_setCacheAdd = __commonJS({
  "node_modules/lodash/_setCacheAdd.js"(exports, module) {
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    function setCacheAdd(value) {
      this.__data__.set(value, HASH_UNDEFINED);
      return this;
    }
    module.exports = setCacheAdd;
  }
});

// node_modules/lodash/_setCacheHas.js
var require_setCacheHas = __commonJS({
  "node_modules/lodash/_setCacheHas.js"(exports, module) {
    function setCacheHas(value) {
      return this.__data__.has(value);
    }
    module.exports = setCacheHas;
  }
});

// node_modules/lodash/_SetCache.js
var require_SetCache = __commonJS({
  "node_modules/lodash/_SetCache.js"(exports, module) {
    var MapCache = require_MapCache();
    var setCacheAdd = require_setCacheAdd();
    var setCacheHas = require_setCacheHas();
    function SetCache(values) {
      var index2 = -1, length = values == null ? 0 : values.length;
      this.__data__ = new MapCache();
      while (++index2 < length) {
        this.add(values[index2]);
      }
    }
    SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
    SetCache.prototype.has = setCacheHas;
    module.exports = SetCache;
  }
});

// node_modules/lodash/_baseFindIndex.js
var require_baseFindIndex = __commonJS({
  "node_modules/lodash/_baseFindIndex.js"(exports, module) {
    function baseFindIndex(array3, predicate, fromIndex, fromRight) {
      var length = array3.length, index2 = fromIndex + (fromRight ? 1 : -1);
      while (fromRight ? index2-- : ++index2 < length) {
        if (predicate(array3[index2], index2, array3)) {
          return index2;
        }
      }
      return -1;
    }
    module.exports = baseFindIndex;
  }
});

// node_modules/lodash/_baseIsNaN.js
var require_baseIsNaN = __commonJS({
  "node_modules/lodash/_baseIsNaN.js"(exports, module) {
    function baseIsNaN(value) {
      return value !== value;
    }
    module.exports = baseIsNaN;
  }
});

// node_modules/lodash/_strictIndexOf.js
var require_strictIndexOf = __commonJS({
  "node_modules/lodash/_strictIndexOf.js"(exports, module) {
    function strictIndexOf(array3, value, fromIndex) {
      var index2 = fromIndex - 1, length = array3.length;
      while (++index2 < length) {
        if (array3[index2] === value) {
          return index2;
        }
      }
      return -1;
    }
    module.exports = strictIndexOf;
  }
});

// node_modules/lodash/_baseIndexOf.js
var require_baseIndexOf = __commonJS({
  "node_modules/lodash/_baseIndexOf.js"(exports, module) {
    var baseFindIndex = require_baseFindIndex();
    var baseIsNaN = require_baseIsNaN();
    var strictIndexOf = require_strictIndexOf();
    function baseIndexOf(array3, value, fromIndex) {
      return value === value ? strictIndexOf(array3, value, fromIndex) : baseFindIndex(array3, baseIsNaN, fromIndex);
    }
    module.exports = baseIndexOf;
  }
});

// node_modules/lodash/_arrayIncludes.js
var require_arrayIncludes = __commonJS({
  "node_modules/lodash/_arrayIncludes.js"(exports, module) {
    var baseIndexOf = require_baseIndexOf();
    function arrayIncludes(array3, value) {
      var length = array3 == null ? 0 : array3.length;
      return !!length && baseIndexOf(array3, value, 0) > -1;
    }
    module.exports = arrayIncludes;
  }
});

// node_modules/lodash/_arrayIncludesWith.js
var require_arrayIncludesWith = __commonJS({
  "node_modules/lodash/_arrayIncludesWith.js"(exports, module) {
    function arrayIncludesWith(array3, value, comparator) {
      var index2 = -1, length = array3 == null ? 0 : array3.length;
      while (++index2 < length) {
        if (comparator(value, array3[index2])) {
          return true;
        }
      }
      return false;
    }
    module.exports = arrayIncludesWith;
  }
});

// node_modules/lodash/_cacheHas.js
var require_cacheHas = __commonJS({
  "node_modules/lodash/_cacheHas.js"(exports, module) {
    function cacheHas(cache, key) {
      return cache.has(key);
    }
    module.exports = cacheHas;
  }
});

// node_modules/lodash/_Set.js
var require_Set = __commonJS({
  "node_modules/lodash/_Set.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Set2 = getNative(root, "Set");
    module.exports = Set2;
  }
});

// node_modules/lodash/noop.js
var require_noop = __commonJS({
  "node_modules/lodash/noop.js"(exports, module) {
    function noop() {
    }
    module.exports = noop;
  }
});

// node_modules/lodash/_setToArray.js
var require_setToArray = __commonJS({
  "node_modules/lodash/_setToArray.js"(exports, module) {
    function setToArray(set) {
      var index2 = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index2] = value;
      });
      return result;
    }
    module.exports = setToArray;
  }
});

// node_modules/lodash/_createSet.js
var require_createSet = __commonJS({
  "node_modules/lodash/_createSet.js"(exports, module) {
    var Set2 = require_Set();
    var noop = require_noop();
    var setToArray = require_setToArray();
    var INFINITY = 1 / 0;
    var createSet = !(Set2 && 1 / setToArray(new Set2([, -0]))[1] == INFINITY) ? noop : function(values) {
      return new Set2(values);
    };
    module.exports = createSet;
  }
});

// node_modules/lodash/_baseUniq.js
var require_baseUniq = __commonJS({
  "node_modules/lodash/_baseUniq.js"(exports, module) {
    var SetCache = require_SetCache();
    var arrayIncludes = require_arrayIncludes();
    var arrayIncludesWith = require_arrayIncludesWith();
    var cacheHas = require_cacheHas();
    var createSet = require_createSet();
    var setToArray = require_setToArray();
    var LARGE_ARRAY_SIZE = 200;
    function baseUniq(array3, iteratee, comparator) {
      var index2 = -1, includes = arrayIncludes, length = array3.length, isCommon = true, result = [], seen = result;
      if (comparator) {
        isCommon = false;
        includes = arrayIncludesWith;
      } else if (length >= LARGE_ARRAY_SIZE) {
        var set = iteratee ? null : createSet(array3);
        if (set) {
          return setToArray(set);
        }
        isCommon = false;
        includes = cacheHas;
        seen = new SetCache();
      } else {
        seen = iteratee ? [] : result;
      }
      outer:
        while (++index2 < length) {
          var value = array3[index2], computed2 = iteratee ? iteratee(value) : value;
          value = comparator || value !== 0 ? value : 0;
          if (isCommon && computed2 === computed2) {
            var seenIndex = seen.length;
            while (seenIndex--) {
              if (seen[seenIndex] === computed2) {
                continue outer;
              }
            }
            if (iteratee) {
              seen.push(computed2);
            }
            result.push(value);
          } else if (!includes(seen, computed2, comparator)) {
            if (seen !== result) {
              seen.push(computed2);
            }
            result.push(value);
          }
        }
      return result;
    }
    module.exports = baseUniq;
  }
});

// node_modules/lodash/isLength.js
var require_isLength = __commonJS({
  "node_modules/lodash/isLength.js"(exports, module) {
    var MAX_SAFE_INTEGER = 9007199254740991;
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    module.exports = isLength;
  }
});

// node_modules/lodash/isArrayLike.js
var require_isArrayLike = __commonJS({
  "node_modules/lodash/isArrayLike.js"(exports, module) {
    var isFunction = require_isFunction();
    var isLength = require_isLength();
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    module.exports = isArrayLike;
  }
});

// node_modules/lodash/isArrayLikeObject.js
var require_isArrayLikeObject = __commonJS({
  "node_modules/lodash/isArrayLikeObject.js"(exports, module) {
    var isArrayLike = require_isArrayLike();
    var isObjectLike = require_isObjectLike();
    function isArrayLikeObject(value) {
      return isObjectLike(value) && isArrayLike(value);
    }
    module.exports = isArrayLikeObject;
  }
});

// node_modules/lodash/union.js
var require_union = __commonJS({
  "node_modules/lodash/union.js"(exports, module) {
    var baseFlatten = require_baseFlatten();
    var baseRest = require_baseRest();
    var baseUniq = require_baseUniq();
    var isArrayLikeObject = require_isArrayLikeObject();
    var union = baseRest(function(arrays) {
      return baseUniq(baseFlatten(arrays, 1, isArrayLikeObject, true));
    });
    module.exports = union;
  }
});

// node_modules/lodash/_stackClear.js
var require_stackClear = __commonJS({
  "node_modules/lodash/_stackClear.js"(exports, module) {
    var ListCache = require_ListCache();
    function stackClear() {
      this.__data__ = new ListCache();
      this.size = 0;
    }
    module.exports = stackClear;
  }
});

// node_modules/lodash/_stackDelete.js
var require_stackDelete = __commonJS({
  "node_modules/lodash/_stackDelete.js"(exports, module) {
    function stackDelete(key) {
      var data = this.__data__, result = data["delete"](key);
      this.size = data.size;
      return result;
    }
    module.exports = stackDelete;
  }
});

// node_modules/lodash/_stackGet.js
var require_stackGet = __commonJS({
  "node_modules/lodash/_stackGet.js"(exports, module) {
    function stackGet(key) {
      return this.__data__.get(key);
    }
    module.exports = stackGet;
  }
});

// node_modules/lodash/_stackHas.js
var require_stackHas = __commonJS({
  "node_modules/lodash/_stackHas.js"(exports, module) {
    function stackHas(key) {
      return this.__data__.has(key);
    }
    module.exports = stackHas;
  }
});

// node_modules/lodash/_stackSet.js
var require_stackSet = __commonJS({
  "node_modules/lodash/_stackSet.js"(exports, module) {
    var ListCache = require_ListCache();
    var Map2 = require_Map();
    var MapCache = require_MapCache();
    var LARGE_ARRAY_SIZE = 200;
    function stackSet(key, value) {
      var data = this.__data__;
      if (data instanceof ListCache) {
        var pairs = data.__data__;
        if (!Map2 || pairs.length < LARGE_ARRAY_SIZE - 1) {
          pairs.push([key, value]);
          this.size = ++data.size;
          return this;
        }
        data = this.__data__ = new MapCache(pairs);
      }
      data.set(key, value);
      this.size = data.size;
      return this;
    }
    module.exports = stackSet;
  }
});

// node_modules/lodash/_Stack.js
var require_Stack = __commonJS({
  "node_modules/lodash/_Stack.js"(exports, module) {
    var ListCache = require_ListCache();
    var stackClear = require_stackClear();
    var stackDelete = require_stackDelete();
    var stackGet = require_stackGet();
    var stackHas = require_stackHas();
    var stackSet = require_stackSet();
    function Stack(entries) {
      var data = this.__data__ = new ListCache(entries);
      this.size = data.size;
    }
    Stack.prototype.clear = stackClear;
    Stack.prototype["delete"] = stackDelete;
    Stack.prototype.get = stackGet;
    Stack.prototype.has = stackHas;
    Stack.prototype.set = stackSet;
    module.exports = Stack;
  }
});

// node_modules/lodash/_arraySome.js
var require_arraySome = __commonJS({
  "node_modules/lodash/_arraySome.js"(exports, module) {
    function arraySome(array3, predicate) {
      var index2 = -1, length = array3 == null ? 0 : array3.length;
      while (++index2 < length) {
        if (predicate(array3[index2], index2, array3)) {
          return true;
        }
      }
      return false;
    }
    module.exports = arraySome;
  }
});

// node_modules/lodash/_equalArrays.js
var require_equalArrays = __commonJS({
  "node_modules/lodash/_equalArrays.js"(exports, module) {
    var SetCache = require_SetCache();
    var arraySome = require_arraySome();
    var cacheHas = require_cacheHas();
    var COMPARE_PARTIAL_FLAG = 1;
    var COMPARE_UNORDERED_FLAG = 2;
    function equalArrays(array3, other, bitmask, customizer, equalFunc, stack) {
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG, arrLength = array3.length, othLength = other.length;
      if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
        return false;
      }
      var arrStacked = stack.get(array3);
      var othStacked = stack.get(other);
      if (arrStacked && othStacked) {
        return arrStacked == other && othStacked == array3;
      }
      var index2 = -1, result = true, seen = bitmask & COMPARE_UNORDERED_FLAG ? new SetCache() : void 0;
      stack.set(array3, other);
      stack.set(other, array3);
      while (++index2 < arrLength) {
        var arrValue = array3[index2], othValue = other[index2];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, arrValue, index2, other, array3, stack) : customizer(arrValue, othValue, index2, array3, other, stack);
        }
        if (compared !== void 0) {
          if (compared) {
            continue;
          }
          result = false;
          break;
        }
        if (seen) {
          if (!arraySome(other, function(othValue2, othIndex) {
            if (!cacheHas(seen, othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, bitmask, customizer, stack))) {
              return seen.push(othIndex);
            }
          })) {
            result = false;
            break;
          }
        } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
          result = false;
          break;
        }
      }
      stack["delete"](array3);
      stack["delete"](other);
      return result;
    }
    module.exports = equalArrays;
  }
});

// node_modules/lodash/_Uint8Array.js
var require_Uint8Array = __commonJS({
  "node_modules/lodash/_Uint8Array.js"(exports, module) {
    var root = require_root();
    var Uint8Array = root.Uint8Array;
    module.exports = Uint8Array;
  }
});

// node_modules/lodash/_mapToArray.js
var require_mapToArray = __commonJS({
  "node_modules/lodash/_mapToArray.js"(exports, module) {
    function mapToArray(map) {
      var index2 = -1, result = Array(map.size);
      map.forEach(function(value, key) {
        result[++index2] = [key, value];
      });
      return result;
    }
    module.exports = mapToArray;
  }
});

// node_modules/lodash/_equalByTag.js
var require_equalByTag = __commonJS({
  "node_modules/lodash/_equalByTag.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var Uint8Array = require_Uint8Array();
    var eq = require_eq();
    var equalArrays = require_equalArrays();
    var mapToArray = require_mapToArray();
    var setToArray = require_setToArray();
    var COMPARE_PARTIAL_FLAG = 1;
    var COMPARE_UNORDERED_FLAG = 2;
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var symbolTag = "[object Symbol]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
    function equalByTag(object3, other, tag, bitmask, customizer, equalFunc, stack) {
      switch (tag) {
        case dataViewTag:
          if (object3.byteLength != other.byteLength || object3.byteOffset != other.byteOffset) {
            return false;
          }
          object3 = object3.buffer;
          other = other.buffer;
        case arrayBufferTag:
          if (object3.byteLength != other.byteLength || !equalFunc(new Uint8Array(object3), new Uint8Array(other))) {
            return false;
          }
          return true;
        case boolTag:
        case dateTag:
        case numberTag:
          return eq(+object3, +other);
        case errorTag:
          return object3.name == other.name && object3.message == other.message;
        case regexpTag:
        case stringTag:
          return object3 == other + "";
        case mapTag:
          var convert = mapToArray;
        case setTag:
          var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
          convert || (convert = setToArray);
          if (object3.size != other.size && !isPartial) {
            return false;
          }
          var stacked = stack.get(object3);
          if (stacked) {
            return stacked == other;
          }
          bitmask |= COMPARE_UNORDERED_FLAG;
          stack.set(object3, other);
          var result = equalArrays(convert(object3), convert(other), bitmask, customizer, equalFunc, stack);
          stack["delete"](object3);
          return result;
        case symbolTag:
          if (symbolValueOf) {
            return symbolValueOf.call(object3) == symbolValueOf.call(other);
          }
      }
      return false;
    }
    module.exports = equalByTag;
  }
});

// node_modules/lodash/_baseGetAllKeys.js
var require_baseGetAllKeys = __commonJS({
  "node_modules/lodash/_baseGetAllKeys.js"(exports, module) {
    var arrayPush = require_arrayPush();
    var isArray = require_isArray();
    function baseGetAllKeys(object3, keysFunc, symbolsFunc) {
      var result = keysFunc(object3);
      return isArray(object3) ? result : arrayPush(result, symbolsFunc(object3));
    }
    module.exports = baseGetAllKeys;
  }
});

// node_modules/lodash/_arrayFilter.js
var require_arrayFilter = __commonJS({
  "node_modules/lodash/_arrayFilter.js"(exports, module) {
    function arrayFilter(array3, predicate) {
      var index2 = -1, length = array3 == null ? 0 : array3.length, resIndex = 0, result = [];
      while (++index2 < length) {
        var value = array3[index2];
        if (predicate(value, index2, array3)) {
          result[resIndex++] = value;
        }
      }
      return result;
    }
    module.exports = arrayFilter;
  }
});

// node_modules/lodash/stubArray.js
var require_stubArray = __commonJS({
  "node_modules/lodash/stubArray.js"(exports, module) {
    function stubArray() {
      return [];
    }
    module.exports = stubArray;
  }
});

// node_modules/lodash/_getSymbols.js
var require_getSymbols = __commonJS({
  "node_modules/lodash/_getSymbols.js"(exports, module) {
    var arrayFilter = require_arrayFilter();
    var stubArray = require_stubArray();
    var objectProto = Object.prototype;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var nativeGetSymbols = Object.getOwnPropertySymbols;
    var getSymbols = !nativeGetSymbols ? stubArray : function(object3) {
      if (object3 == null) {
        return [];
      }
      object3 = Object(object3);
      return arrayFilter(nativeGetSymbols(object3), function(symbol) {
        return propertyIsEnumerable.call(object3, symbol);
      });
    };
    module.exports = getSymbols;
  }
});

// node_modules/lodash/_baseTimes.js
var require_baseTimes = __commonJS({
  "node_modules/lodash/_baseTimes.js"(exports, module) {
    function baseTimes(n, iteratee) {
      var index2 = -1, result = Array(n);
      while (++index2 < n) {
        result[index2] = iteratee(index2);
      }
      return result;
    }
    module.exports = baseTimes;
  }
});

// node_modules/lodash/stubFalse.js
var require_stubFalse = __commonJS({
  "node_modules/lodash/stubFalse.js"(exports, module) {
    function stubFalse() {
      return false;
    }
    module.exports = stubFalse;
  }
});

// node_modules/lodash/isBuffer.js
var require_isBuffer = __commonJS({
  "node_modules/lodash/isBuffer.js"(exports, module) {
    var root = require_root();
    var stubFalse = require_stubFalse();
    var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
    var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var Buffer = moduleExports ? root.Buffer : void 0;
    var nativeIsBuffer = Buffer ? Buffer.isBuffer : void 0;
    var isBuffer = nativeIsBuffer || stubFalse;
    module.exports = isBuffer;
  }
});

// node_modules/lodash/_isIndex.js
var require_isIndex = __commonJS({
  "node_modules/lodash/_isIndex.js"(exports, module) {
    var MAX_SAFE_INTEGER = 9007199254740991;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    function isIndex(value, length) {
      var type2 = typeof value;
      length = length == null ? MAX_SAFE_INTEGER : length;
      return !!length && (type2 == "number" || type2 != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    module.exports = isIndex;
  }
});

// node_modules/lodash/_baseIsTypedArray.js
var require_baseIsTypedArray = __commonJS({
  "node_modules/lodash/_baseIsTypedArray.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isLength = require_isLength();
    var isObjectLike = require_isObjectLike();
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var funcTag = "[object Function]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var objectTag = "[object Object]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var weakMapTag = "[object WeakMap]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    var typedArrayTags = {};
    typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
    typedArrayTags[argsTag] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
    function baseIsTypedArray(value) {
      return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
    }
    module.exports = baseIsTypedArray;
  }
});

// node_modules/lodash/_baseUnary.js
var require_baseUnary = __commonJS({
  "node_modules/lodash/_baseUnary.js"(exports, module) {
    function baseUnary(func) {
      return function(value) {
        return func(value);
      };
    }
    module.exports = baseUnary;
  }
});

// node_modules/lodash/_nodeUtil.js
var require_nodeUtil = __commonJS({
  "node_modules/lodash/_nodeUtil.js"(exports, module) {
    var freeGlobal = require_freeGlobal();
    var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
    var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var freeProcess = moduleExports && freeGlobal.process;
    var nodeUtil = function() {
      try {
        var types2 = freeModule && freeModule.require && freeModule.require("util").types;
        if (types2) {
          return types2;
        }
        return freeProcess && freeProcess.binding && freeProcess.binding("util");
      } catch (e) {
      }
    }();
    module.exports = nodeUtil;
  }
});

// node_modules/lodash/isTypedArray.js
var require_isTypedArray = __commonJS({
  "node_modules/lodash/isTypedArray.js"(exports, module) {
    var baseIsTypedArray = require_baseIsTypedArray();
    var baseUnary = require_baseUnary();
    var nodeUtil = require_nodeUtil();
    var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
    var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
    module.exports = isTypedArray;
  }
});

// node_modules/lodash/_arrayLikeKeys.js
var require_arrayLikeKeys = __commonJS({
  "node_modules/lodash/_arrayLikeKeys.js"(exports, module) {
    var baseTimes = require_baseTimes();
    var isArguments = require_isArguments();
    var isArray = require_isArray();
    var isBuffer = require_isBuffer();
    var isIndex = require_isIndex();
    var isTypedArray = require_isTypedArray();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function arrayLikeKeys(value, inherited) {
      var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
      for (var key in value) {
        if ((inherited || hasOwnProperty.call(value, key)) && !(skipIndexes && (key == "length" || isBuff && (key == "offset" || key == "parent") || isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || isIndex(key, length)))) {
          result.push(key);
        }
      }
      return result;
    }
    module.exports = arrayLikeKeys;
  }
});

// node_modules/lodash/_isPrototype.js
var require_isPrototype = __commonJS({
  "node_modules/lodash/_isPrototype.js"(exports, module) {
    var objectProto = Object.prototype;
    function isPrototype(value) {
      var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
      return value === proto;
    }
    module.exports = isPrototype;
  }
});

// node_modules/lodash/_overArg.js
var require_overArg = __commonJS({
  "node_modules/lodash/_overArg.js"(exports, module) {
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    module.exports = overArg;
  }
});

// node_modules/lodash/_nativeKeys.js
var require_nativeKeys = __commonJS({
  "node_modules/lodash/_nativeKeys.js"(exports, module) {
    var overArg = require_overArg();
    var nativeKeys = overArg(Object.keys, Object);
    module.exports = nativeKeys;
  }
});

// node_modules/lodash/_baseKeys.js
var require_baseKeys = __commonJS({
  "node_modules/lodash/_baseKeys.js"(exports, module) {
    var isPrototype = require_isPrototype();
    var nativeKeys = require_nativeKeys();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function baseKeys(object3) {
      if (!isPrototype(object3)) {
        return nativeKeys(object3);
      }
      var result = [];
      for (var key in Object(object3)) {
        if (hasOwnProperty.call(object3, key) && key != "constructor") {
          result.push(key);
        }
      }
      return result;
    }
    module.exports = baseKeys;
  }
});

// node_modules/lodash/keys.js
var require_keys = __commonJS({
  "node_modules/lodash/keys.js"(exports, module) {
    var arrayLikeKeys = require_arrayLikeKeys();
    var baseKeys = require_baseKeys();
    var isArrayLike = require_isArrayLike();
    function keys(object3) {
      return isArrayLike(object3) ? arrayLikeKeys(object3) : baseKeys(object3);
    }
    module.exports = keys;
  }
});

// node_modules/lodash/_getAllKeys.js
var require_getAllKeys = __commonJS({
  "node_modules/lodash/_getAllKeys.js"(exports, module) {
    var baseGetAllKeys = require_baseGetAllKeys();
    var getSymbols = require_getSymbols();
    var keys = require_keys();
    function getAllKeys(object3) {
      return baseGetAllKeys(object3, keys, getSymbols);
    }
    module.exports = getAllKeys;
  }
});

// node_modules/lodash/_equalObjects.js
var require_equalObjects = __commonJS({
  "node_modules/lodash/_equalObjects.js"(exports, module) {
    var getAllKeys = require_getAllKeys();
    var COMPARE_PARTIAL_FLAG = 1;
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function equalObjects(object3, other, bitmask, customizer, equalFunc, stack) {
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG, objProps = getAllKeys(object3), objLength = objProps.length, othProps = getAllKeys(other), othLength = othProps.length;
      if (objLength != othLength && !isPartial) {
        return false;
      }
      var index2 = objLength;
      while (index2--) {
        var key = objProps[index2];
        if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
          return false;
        }
      }
      var objStacked = stack.get(object3);
      var othStacked = stack.get(other);
      if (objStacked && othStacked) {
        return objStacked == other && othStacked == object3;
      }
      var result = true;
      stack.set(object3, other);
      stack.set(other, object3);
      var skipCtor = isPartial;
      while (++index2 < objLength) {
        key = objProps[index2];
        var objValue = object3[key], othValue = other[key];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, objValue, key, other, object3, stack) : customizer(objValue, othValue, key, object3, other, stack);
        }
        if (!(compared === void 0 ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
          result = false;
          break;
        }
        skipCtor || (skipCtor = key == "constructor");
      }
      if (result && !skipCtor) {
        var objCtor = object3.constructor, othCtor = other.constructor;
        if (objCtor != othCtor && ("constructor" in object3 && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
          result = false;
        }
      }
      stack["delete"](object3);
      stack["delete"](other);
      return result;
    }
    module.exports = equalObjects;
  }
});

// node_modules/lodash/_DataView.js
var require_DataView = __commonJS({
  "node_modules/lodash/_DataView.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var DataView = getNative(root, "DataView");
    module.exports = DataView;
  }
});

// node_modules/lodash/_Promise.js
var require_Promise = __commonJS({
  "node_modules/lodash/_Promise.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Promise2 = getNative(root, "Promise");
    module.exports = Promise2;
  }
});

// node_modules/lodash/_WeakMap.js
var require_WeakMap = __commonJS({
  "node_modules/lodash/_WeakMap.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var WeakMap2 = getNative(root, "WeakMap");
    module.exports = WeakMap2;
  }
});

// node_modules/lodash/_getTag.js
var require_getTag = __commonJS({
  "node_modules/lodash/_getTag.js"(exports, module) {
    var DataView = require_DataView();
    var Map2 = require_Map();
    var Promise2 = require_Promise();
    var Set2 = require_Set();
    var WeakMap2 = require_WeakMap();
    var baseGetTag = require_baseGetTag();
    var toSource = require_toSource();
    var mapTag = "[object Map]";
    var objectTag = "[object Object]";
    var promiseTag = "[object Promise]";
    var setTag = "[object Set]";
    var weakMapTag = "[object WeakMap]";
    var dataViewTag = "[object DataView]";
    var dataViewCtorString = toSource(DataView);
    var mapCtorString = toSource(Map2);
    var promiseCtorString = toSource(Promise2);
    var setCtorString = toSource(Set2);
    var weakMapCtorString = toSource(WeakMap2);
    var getTag = baseGetTag;
    if (DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag || Map2 && getTag(new Map2()) != mapTag || Promise2 && getTag(Promise2.resolve()) != promiseTag || Set2 && getTag(new Set2()) != setTag || WeakMap2 && getTag(new WeakMap2()) != weakMapTag) {
      getTag = function(value) {
        var result = baseGetTag(value), Ctor = result == objectTag ? value.constructor : void 0, ctorString = Ctor ? toSource(Ctor) : "";
        if (ctorString) {
          switch (ctorString) {
            case dataViewCtorString:
              return dataViewTag;
            case mapCtorString:
              return mapTag;
            case promiseCtorString:
              return promiseTag;
            case setCtorString:
              return setTag;
            case weakMapCtorString:
              return weakMapTag;
          }
        }
        return result;
      };
    }
    module.exports = getTag;
  }
});

// node_modules/lodash/_baseIsEqualDeep.js
var require_baseIsEqualDeep = __commonJS({
  "node_modules/lodash/_baseIsEqualDeep.js"(exports, module) {
    var Stack = require_Stack();
    var equalArrays = require_equalArrays();
    var equalByTag = require_equalByTag();
    var equalObjects = require_equalObjects();
    var getTag = require_getTag();
    var isArray = require_isArray();
    var isBuffer = require_isBuffer();
    var isTypedArray = require_isTypedArray();
    var COMPARE_PARTIAL_FLAG = 1;
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var objectTag = "[object Object]";
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function baseIsEqualDeep(object3, other, bitmask, customizer, equalFunc, stack) {
      var objIsArr = isArray(object3), othIsArr = isArray(other), objTag = objIsArr ? arrayTag : getTag(object3), othTag = othIsArr ? arrayTag : getTag(other);
      objTag = objTag == argsTag ? objectTag : objTag;
      othTag = othTag == argsTag ? objectTag : othTag;
      var objIsObj = objTag == objectTag, othIsObj = othTag == objectTag, isSameTag = objTag == othTag;
      if (isSameTag && isBuffer(object3)) {
        if (!isBuffer(other)) {
          return false;
        }
        objIsArr = true;
        objIsObj = false;
      }
      if (isSameTag && !objIsObj) {
        stack || (stack = new Stack());
        return objIsArr || isTypedArray(object3) ? equalArrays(object3, other, bitmask, customizer, equalFunc, stack) : equalByTag(object3, other, objTag, bitmask, customizer, equalFunc, stack);
      }
      if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
        var objIsWrapped = objIsObj && hasOwnProperty.call(object3, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty.call(other, "__wrapped__");
        if (objIsWrapped || othIsWrapped) {
          var objUnwrapped = objIsWrapped ? object3.value() : object3, othUnwrapped = othIsWrapped ? other.value() : other;
          stack || (stack = new Stack());
          return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
        }
      }
      if (!isSameTag) {
        return false;
      }
      stack || (stack = new Stack());
      return equalObjects(object3, other, bitmask, customizer, equalFunc, stack);
    }
    module.exports = baseIsEqualDeep;
  }
});

// node_modules/lodash/_baseIsEqual.js
var require_baseIsEqual = __commonJS({
  "node_modules/lodash/_baseIsEqual.js"(exports, module) {
    var baseIsEqualDeep = require_baseIsEqualDeep();
    var isObjectLike = require_isObjectLike();
    function baseIsEqual(value, other, bitmask, customizer, stack) {
      if (value === other) {
        return true;
      }
      if (value == null || other == null || !isObjectLike(value) && !isObjectLike(other)) {
        return value !== value && other !== other;
      }
      return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
    }
    module.exports = baseIsEqual;
  }
});

// node_modules/lodash/isEqual.js
var require_isEqual = __commonJS({
  "node_modules/lodash/isEqual.js"(exports, module) {
    var baseIsEqual = require_baseIsEqual();
    function isEqual(value, other) {
      return baseIsEqual(value, other);
    }
    module.exports = isEqual;
  }
});

// node_modules/dayjs/plugin/advancedFormat.js
var require_advancedFormat = __commonJS({
  "node_modules/dayjs/plugin/advancedFormat.js"(exports, module) {
    !function(e, t) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = t() : typeof define == "function" && define.amd ? define(t) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_advancedFormat = t();
    }(exports, function() {
      "use strict";
      return function(e, t, r) {
        var n = t.prototype, s = n.format;
        r.en.ordinal = function(e2) {
          var t2 = ["th", "st", "nd", "rd"], r2 = e2 % 100;
          return "[" + e2 + (t2[(r2 - 20) % 10] || t2[r2] || t2[0]) + "]";
        }, n.format = function(e2) {
          var t2 = this, r2 = this.$locale(), n2 = this.$utils(), a = (e2 || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, function(e3) {
            switch (e3) {
              case "Q":
                return Math.ceil((t2.$M + 1) / 3);
              case "Do":
                return r2.ordinal(t2.$D);
              case "gggg":
                return t2.weekYear();
              case "GGGG":
                return t2.isoWeekYear();
              case "wo":
                return r2.ordinal(t2.week(), "W");
              case "w":
              case "ww":
                return n2.s(t2.week(), e3 === "w" ? 1 : 2, "0");
              case "W":
              case "WW":
                return n2.s(t2.isoWeek(), e3 === "W" ? 1 : 2, "0");
              case "k":
              case "kk":
                return n2.s(String(t2.$H === 0 ? 24 : t2.$H), e3 === "k" ? 1 : 2, "0");
              case "X":
                return Math.floor(t2.$d.getTime() / 1e3);
              case "x":
                return t2.$d.getTime();
              case "z":
                return "[" + t2.offsetName() + "]";
              case "zzz":
                return "[" + t2.offsetName("long") + "]";
              default:
                return e3;
            }
          });
          return s.bind(this)(a);
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/weekOfYear.js
var require_weekOfYear = __commonJS({
  "node_modules/dayjs/plugin/weekOfYear.js"(exports, module) {
    !function(e, t) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = t() : typeof define == "function" && define.amd ? define(t) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_weekOfYear = t();
    }(exports, function() {
      "use strict";
      var e = "week", t = "year";
      return function(i, n, r) {
        var f = n.prototype;
        f.week = function(i2) {
          if (i2 === void 0 && (i2 = null), i2 !== null)
            return this.add(7 * (i2 - this.week()), "day");
          var n2 = this.$locale().yearStart || 1;
          if (this.month() === 11 && this.date() > 25) {
            var f2 = r(this).startOf(t).add(1, t).date(n2), s = r(this).endOf(e);
            if (f2.isBefore(s))
              return 1;
          }
          var a = r(this).startOf(t).date(n2).startOf(e).subtract(1, "millisecond"), o = this.diff(a, e, true);
          return o < 0 ? r(this).startOf("week").week() : Math.ceil(o);
        }, f.weeks = function(e2) {
          return e2 === void 0 && (e2 = null), this.week(e2);
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/weekYear.js
var require_weekYear = __commonJS({
  "node_modules/dayjs/plugin/weekYear.js"(exports, module) {
    !function(e, t) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = t() : typeof define == "function" && define.amd ? define(t) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_weekYear = t();
    }(exports, function() {
      "use strict";
      return function(e, t) {
        t.prototype.weekYear = function() {
          var e2 = this.month(), t2 = this.week(), n = this.year();
          return t2 === 1 && e2 === 11 ? n + 1 : e2 === 0 && t2 >= 52 ? n - 1 : n;
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/dayOfYear.js
var require_dayOfYear = __commonJS({
  "node_modules/dayjs/plugin/dayOfYear.js"(exports, module) {
    !function(e, t) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = t() : typeof define == "function" && define.amd ? define(t) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_dayOfYear = t();
    }(exports, function() {
      "use strict";
      return function(e, t) {
        t.prototype.dayOfYear = function(e2) {
          var t2 = Math.round((this.startOf("day") - this.startOf("year")) / 864e5) + 1;
          return e2 == null ? t2 : this.add(e2 - t2, "day");
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/isSameOrAfter.js
var require_isSameOrAfter = __commonJS({
  "node_modules/dayjs/plugin/isSameOrAfter.js"(exports, module) {
    !function(e, t) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = t() : typeof define == "function" && define.amd ? define(t) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_isSameOrAfter = t();
    }(exports, function() {
      "use strict";
      return function(e, t) {
        t.prototype.isSameOrAfter = function(e2, t2) {
          return this.isSame(e2, t2) || this.isAfter(e2, t2);
        };
      };
    });
  }
});

// node_modules/dayjs/plugin/isSameOrBefore.js
var require_isSameOrBefore = __commonJS({
  "node_modules/dayjs/plugin/isSameOrBefore.js"(exports, module) {
    !function(e, i) {
      typeof exports == "object" && typeof module != "undefined" ? module.exports = i() : typeof define == "function" && define.amd ? define(i) : (e = typeof globalThis != "undefined" ? globalThis : e || self).dayjs_plugin_isSameOrBefore = i();
    }(exports, function() {
      "use strict";
      return function(e, i) {
        i.prototype.isSameOrBefore = function(e2, i2) {
          return this.isSame(e2, i2) || this.isBefore(e2, i2);
        };
      };
    });
  }
});

// node_modules/lodash/_arrayEach.js
var require_arrayEach = __commonJS({
  "node_modules/lodash/_arrayEach.js"(exports, module) {
    function arrayEach(array3, iteratee) {
      var index2 = -1, length = array3 == null ? 0 : array3.length;
      while (++index2 < length) {
        if (iteratee(array3[index2], index2, array3) === false) {
          break;
        }
      }
      return array3;
    }
    module.exports = arrayEach;
  }
});

// node_modules/lodash/_baseAssignValue.js
var require_baseAssignValue = __commonJS({
  "node_modules/lodash/_baseAssignValue.js"(exports, module) {
    var defineProperty = require_defineProperty();
    function baseAssignValue(object3, key, value) {
      if (key == "__proto__" && defineProperty) {
        defineProperty(object3, key, {
          "configurable": true,
          "enumerable": true,
          "value": value,
          "writable": true
        });
      } else {
        object3[key] = value;
      }
    }
    module.exports = baseAssignValue;
  }
});

// node_modules/lodash/_assignValue.js
var require_assignValue = __commonJS({
  "node_modules/lodash/_assignValue.js"(exports, module) {
    var baseAssignValue = require_baseAssignValue();
    var eq = require_eq();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function assignValue(object3, key, value) {
      var objValue = object3[key];
      if (!(hasOwnProperty.call(object3, key) && eq(objValue, value)) || value === void 0 && !(key in object3)) {
        baseAssignValue(object3, key, value);
      }
    }
    module.exports = assignValue;
  }
});

// node_modules/lodash/_copyObject.js
var require_copyObject = __commonJS({
  "node_modules/lodash/_copyObject.js"(exports, module) {
    var assignValue = require_assignValue();
    var baseAssignValue = require_baseAssignValue();
    function copyObject(source, props, object3, customizer) {
      var isNew = !object3;
      object3 || (object3 = {});
      var index2 = -1, length = props.length;
      while (++index2 < length) {
        var key = props[index2];
        var newValue = customizer ? customizer(object3[key], source[key], key, object3, source) : void 0;
        if (newValue === void 0) {
          newValue = source[key];
        }
        if (isNew) {
          baseAssignValue(object3, key, newValue);
        } else {
          assignValue(object3, key, newValue);
        }
      }
      return object3;
    }
    module.exports = copyObject;
  }
});

// node_modules/lodash/_baseAssign.js
var require_baseAssign = __commonJS({
  "node_modules/lodash/_baseAssign.js"(exports, module) {
    var copyObject = require_copyObject();
    var keys = require_keys();
    function baseAssign(object3, source) {
      return object3 && copyObject(source, keys(source), object3);
    }
    module.exports = baseAssign;
  }
});

// node_modules/lodash/_nativeKeysIn.js
var require_nativeKeysIn = __commonJS({
  "node_modules/lodash/_nativeKeysIn.js"(exports, module) {
    function nativeKeysIn(object3) {
      var result = [];
      if (object3 != null) {
        for (var key in Object(object3)) {
          result.push(key);
        }
      }
      return result;
    }
    module.exports = nativeKeysIn;
  }
});

// node_modules/lodash/_baseKeysIn.js
var require_baseKeysIn = __commonJS({
  "node_modules/lodash/_baseKeysIn.js"(exports, module) {
    var isObject = require_isObject();
    var isPrototype = require_isPrototype();
    var nativeKeysIn = require_nativeKeysIn();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function baseKeysIn(object3) {
      if (!isObject(object3)) {
        return nativeKeysIn(object3);
      }
      var isProto = isPrototype(object3), result = [];
      for (var key in object3) {
        if (!(key == "constructor" && (isProto || !hasOwnProperty.call(object3, key)))) {
          result.push(key);
        }
      }
      return result;
    }
    module.exports = baseKeysIn;
  }
});

// node_modules/lodash/keysIn.js
var require_keysIn = __commonJS({
  "node_modules/lodash/keysIn.js"(exports, module) {
    var arrayLikeKeys = require_arrayLikeKeys();
    var baseKeysIn = require_baseKeysIn();
    var isArrayLike = require_isArrayLike();
    function keysIn(object3) {
      return isArrayLike(object3) ? arrayLikeKeys(object3, true) : baseKeysIn(object3);
    }
    module.exports = keysIn;
  }
});

// node_modules/lodash/_baseAssignIn.js
var require_baseAssignIn = __commonJS({
  "node_modules/lodash/_baseAssignIn.js"(exports, module) {
    var copyObject = require_copyObject();
    var keysIn = require_keysIn();
    function baseAssignIn(object3, source) {
      return object3 && copyObject(source, keysIn(source), object3);
    }
    module.exports = baseAssignIn;
  }
});

// node_modules/lodash/_cloneBuffer.js
var require_cloneBuffer = __commonJS({
  "node_modules/lodash/_cloneBuffer.js"(exports, module) {
    var root = require_root();
    var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
    var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var Buffer = moduleExports ? root.Buffer : void 0;
    var allocUnsafe = Buffer ? Buffer.allocUnsafe : void 0;
    function cloneBuffer(buffer, isDeep) {
      if (isDeep) {
        return buffer.slice();
      }
      var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
      buffer.copy(result);
      return result;
    }
    module.exports = cloneBuffer;
  }
});

// node_modules/lodash/_copyArray.js
var require_copyArray = __commonJS({
  "node_modules/lodash/_copyArray.js"(exports, module) {
    function copyArray(source, array3) {
      var index2 = -1, length = source.length;
      array3 || (array3 = Array(length));
      while (++index2 < length) {
        array3[index2] = source[index2];
      }
      return array3;
    }
    module.exports = copyArray;
  }
});

// node_modules/lodash/_copySymbols.js
var require_copySymbols = __commonJS({
  "node_modules/lodash/_copySymbols.js"(exports, module) {
    var copyObject = require_copyObject();
    var getSymbols = require_getSymbols();
    function copySymbols(source, object3) {
      return copyObject(source, getSymbols(source), object3);
    }
    module.exports = copySymbols;
  }
});

// node_modules/lodash/_getPrototype.js
var require_getPrototype = __commonJS({
  "node_modules/lodash/_getPrototype.js"(exports, module) {
    var overArg = require_overArg();
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    module.exports = getPrototype;
  }
});

// node_modules/lodash/_getSymbolsIn.js
var require_getSymbolsIn = __commonJS({
  "node_modules/lodash/_getSymbolsIn.js"(exports, module) {
    var arrayPush = require_arrayPush();
    var getPrototype = require_getPrototype();
    var getSymbols = require_getSymbols();
    var stubArray = require_stubArray();
    var nativeGetSymbols = Object.getOwnPropertySymbols;
    var getSymbolsIn = !nativeGetSymbols ? stubArray : function(object3) {
      var result = [];
      while (object3) {
        arrayPush(result, getSymbols(object3));
        object3 = getPrototype(object3);
      }
      return result;
    };
    module.exports = getSymbolsIn;
  }
});

// node_modules/lodash/_copySymbolsIn.js
var require_copySymbolsIn = __commonJS({
  "node_modules/lodash/_copySymbolsIn.js"(exports, module) {
    var copyObject = require_copyObject();
    var getSymbolsIn = require_getSymbolsIn();
    function copySymbolsIn(source, object3) {
      return copyObject(source, getSymbolsIn(source), object3);
    }
    module.exports = copySymbolsIn;
  }
});

// node_modules/lodash/_getAllKeysIn.js
var require_getAllKeysIn = __commonJS({
  "node_modules/lodash/_getAllKeysIn.js"(exports, module) {
    var baseGetAllKeys = require_baseGetAllKeys();
    var getSymbolsIn = require_getSymbolsIn();
    var keysIn = require_keysIn();
    function getAllKeysIn(object3) {
      return baseGetAllKeys(object3, keysIn, getSymbolsIn);
    }
    module.exports = getAllKeysIn;
  }
});

// node_modules/lodash/_initCloneArray.js
var require_initCloneArray = __commonJS({
  "node_modules/lodash/_initCloneArray.js"(exports, module) {
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function initCloneArray(array3) {
      var length = array3.length, result = new array3.constructor(length);
      if (length && typeof array3[0] == "string" && hasOwnProperty.call(array3, "index")) {
        result.index = array3.index;
        result.input = array3.input;
      }
      return result;
    }
    module.exports = initCloneArray;
  }
});

// node_modules/lodash/_cloneArrayBuffer.js
var require_cloneArrayBuffer = __commonJS({
  "node_modules/lodash/_cloneArrayBuffer.js"(exports, module) {
    var Uint8Array = require_Uint8Array();
    function cloneArrayBuffer(arrayBuffer) {
      var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
      new Uint8Array(result).set(new Uint8Array(arrayBuffer));
      return result;
    }
    module.exports = cloneArrayBuffer;
  }
});

// node_modules/lodash/_cloneDataView.js
var require_cloneDataView = __commonJS({
  "node_modules/lodash/_cloneDataView.js"(exports, module) {
    var cloneArrayBuffer = require_cloneArrayBuffer();
    function cloneDataView(dataView, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
      return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
    }
    module.exports = cloneDataView;
  }
});

// node_modules/lodash/_cloneRegExp.js
var require_cloneRegExp = __commonJS({
  "node_modules/lodash/_cloneRegExp.js"(exports, module) {
    var reFlags = /\w*$/;
    function cloneRegExp(regexp3) {
      var result = new regexp3.constructor(regexp3.source, reFlags.exec(regexp3));
      result.lastIndex = regexp3.lastIndex;
      return result;
    }
    module.exports = cloneRegExp;
  }
});

// node_modules/lodash/_cloneSymbol.js
var require_cloneSymbol = __commonJS({
  "node_modules/lodash/_cloneSymbol.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
    function cloneSymbol(symbol) {
      return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
    }
    module.exports = cloneSymbol;
  }
});

// node_modules/lodash/_cloneTypedArray.js
var require_cloneTypedArray = __commonJS({
  "node_modules/lodash/_cloneTypedArray.js"(exports, module) {
    var cloneArrayBuffer = require_cloneArrayBuffer();
    function cloneTypedArray(typedArray, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
      return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
    }
    module.exports = cloneTypedArray;
  }
});

// node_modules/lodash/_initCloneByTag.js
var require_initCloneByTag = __commonJS({
  "node_modules/lodash/_initCloneByTag.js"(exports, module) {
    var cloneArrayBuffer = require_cloneArrayBuffer();
    var cloneDataView = require_cloneDataView();
    var cloneRegExp = require_cloneRegExp();
    var cloneSymbol = require_cloneSymbol();
    var cloneTypedArray = require_cloneTypedArray();
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var symbolTag = "[object Symbol]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    function initCloneByTag(object3, tag, isDeep) {
      var Ctor = object3.constructor;
      switch (tag) {
        case arrayBufferTag:
          return cloneArrayBuffer(object3);
        case boolTag:
        case dateTag:
          return new Ctor(+object3);
        case dataViewTag:
          return cloneDataView(object3, isDeep);
        case float32Tag:
        case float64Tag:
        case int8Tag:
        case int16Tag:
        case int32Tag:
        case uint8Tag:
        case uint8ClampedTag:
        case uint16Tag:
        case uint32Tag:
          return cloneTypedArray(object3, isDeep);
        case mapTag:
          return new Ctor();
        case numberTag:
        case stringTag:
          return new Ctor(object3);
        case regexpTag:
          return cloneRegExp(object3);
        case setTag:
          return new Ctor();
        case symbolTag:
          return cloneSymbol(object3);
      }
    }
    module.exports = initCloneByTag;
  }
});

// node_modules/lodash/_baseCreate.js
var require_baseCreate = __commonJS({
  "node_modules/lodash/_baseCreate.js"(exports, module) {
    var isObject = require_isObject();
    var objectCreate = Object.create;
    var baseCreate = function() {
      function object3() {
      }
      return function(proto) {
        if (!isObject(proto)) {
          return {};
        }
        if (objectCreate) {
          return objectCreate(proto);
        }
        object3.prototype = proto;
        var result = new object3();
        object3.prototype = void 0;
        return result;
      };
    }();
    module.exports = baseCreate;
  }
});

// node_modules/lodash/_initCloneObject.js
var require_initCloneObject = __commonJS({
  "node_modules/lodash/_initCloneObject.js"(exports, module) {
    var baseCreate = require_baseCreate();
    var getPrototype = require_getPrototype();
    var isPrototype = require_isPrototype();
    function initCloneObject(object3) {
      return typeof object3.constructor == "function" && !isPrototype(object3) ? baseCreate(getPrototype(object3)) : {};
    }
    module.exports = initCloneObject;
  }
});

// node_modules/lodash/_baseIsMap.js
var require_baseIsMap = __commonJS({
  "node_modules/lodash/_baseIsMap.js"(exports, module) {
    var getTag = require_getTag();
    var isObjectLike = require_isObjectLike();
    var mapTag = "[object Map]";
    function baseIsMap(value) {
      return isObjectLike(value) && getTag(value) == mapTag;
    }
    module.exports = baseIsMap;
  }
});

// node_modules/lodash/isMap.js
var require_isMap = __commonJS({
  "node_modules/lodash/isMap.js"(exports, module) {
    var baseIsMap = require_baseIsMap();
    var baseUnary = require_baseUnary();
    var nodeUtil = require_nodeUtil();
    var nodeIsMap = nodeUtil && nodeUtil.isMap;
    var isMap = nodeIsMap ? baseUnary(nodeIsMap) : baseIsMap;
    module.exports = isMap;
  }
});

// node_modules/lodash/_baseIsSet.js
var require_baseIsSet = __commonJS({
  "node_modules/lodash/_baseIsSet.js"(exports, module) {
    var getTag = require_getTag();
    var isObjectLike = require_isObjectLike();
    var setTag = "[object Set]";
    function baseIsSet(value) {
      return isObjectLike(value) && getTag(value) == setTag;
    }
    module.exports = baseIsSet;
  }
});

// node_modules/lodash/isSet.js
var require_isSet = __commonJS({
  "node_modules/lodash/isSet.js"(exports, module) {
    var baseIsSet = require_baseIsSet();
    var baseUnary = require_baseUnary();
    var nodeUtil = require_nodeUtil();
    var nodeIsSet = nodeUtil && nodeUtil.isSet;
    var isSet = nodeIsSet ? baseUnary(nodeIsSet) : baseIsSet;
    module.exports = isSet;
  }
});

// node_modules/lodash/_baseClone.js
var require_baseClone = __commonJS({
  "node_modules/lodash/_baseClone.js"(exports, module) {
    var Stack = require_Stack();
    var arrayEach = require_arrayEach();
    var assignValue = require_assignValue();
    var baseAssign = require_baseAssign();
    var baseAssignIn = require_baseAssignIn();
    var cloneBuffer = require_cloneBuffer();
    var copyArray = require_copyArray();
    var copySymbols = require_copySymbols();
    var copySymbolsIn = require_copySymbolsIn();
    var getAllKeys = require_getAllKeys();
    var getAllKeysIn = require_getAllKeysIn();
    var getTag = require_getTag();
    var initCloneArray = require_initCloneArray();
    var initCloneByTag = require_initCloneByTag();
    var initCloneObject = require_initCloneObject();
    var isArray = require_isArray();
    var isBuffer = require_isBuffer();
    var isMap = require_isMap();
    var isObject = require_isObject();
    var isSet = require_isSet();
    var keys = require_keys();
    var keysIn = require_keysIn();
    var CLONE_DEEP_FLAG = 1;
    var CLONE_FLAT_FLAG = 2;
    var CLONE_SYMBOLS_FLAG = 4;
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var objectTag = "[object Object]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var symbolTag = "[object Symbol]";
    var weakMapTag = "[object WeakMap]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    var cloneableTags = {};
    cloneableTags[argsTag] = cloneableTags[arrayTag] = cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] = cloneableTags[boolTag] = cloneableTags[dateTag] = cloneableTags[float32Tag] = cloneableTags[float64Tag] = cloneableTags[int8Tag] = cloneableTags[int16Tag] = cloneableTags[int32Tag] = cloneableTags[mapTag] = cloneableTags[numberTag] = cloneableTags[objectTag] = cloneableTags[regexpTag] = cloneableTags[setTag] = cloneableTags[stringTag] = cloneableTags[symbolTag] = cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] = cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
    cloneableTags[errorTag] = cloneableTags[funcTag] = cloneableTags[weakMapTag] = false;
    function baseClone(value, bitmask, customizer, key, object3, stack) {
      var result, isDeep = bitmask & CLONE_DEEP_FLAG, isFlat = bitmask & CLONE_FLAT_FLAG, isFull = bitmask & CLONE_SYMBOLS_FLAG;
      if (customizer) {
        result = object3 ? customizer(value, key, object3, stack) : customizer(value);
      }
      if (result !== void 0) {
        return result;
      }
      if (!isObject(value)) {
        return value;
      }
      var isArr = isArray(value);
      if (isArr) {
        result = initCloneArray(value);
        if (!isDeep) {
          return copyArray(value, result);
        }
      } else {
        var tag = getTag(value), isFunc = tag == funcTag || tag == genTag;
        if (isBuffer(value)) {
          return cloneBuffer(value, isDeep);
        }
        if (tag == objectTag || tag == argsTag || isFunc && !object3) {
          result = isFlat || isFunc ? {} : initCloneObject(value);
          if (!isDeep) {
            return isFlat ? copySymbolsIn(value, baseAssignIn(result, value)) : copySymbols(value, baseAssign(result, value));
          }
        } else {
          if (!cloneableTags[tag]) {
            return object3 ? value : {};
          }
          result = initCloneByTag(value, tag, isDeep);
        }
      }
      stack || (stack = new Stack());
      var stacked = stack.get(value);
      if (stacked) {
        return stacked;
      }
      stack.set(value, result);
      if (isSet(value)) {
        value.forEach(function(subValue) {
          result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
        });
      } else if (isMap(value)) {
        value.forEach(function(subValue, key2) {
          result.set(key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
        });
      }
      var keysFunc = isFull ? isFlat ? getAllKeysIn : getAllKeys : isFlat ? keysIn : keys;
      var props = isArr ? void 0 : keysFunc(value);
      arrayEach(props || value, function(subValue, key2) {
        if (props) {
          key2 = subValue;
          subValue = value[key2];
        }
        assignValue(result, key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
      });
      return result;
    }
    module.exports = baseClone;
  }
});

// node_modules/lodash/cloneDeep.js
var require_cloneDeep = __commonJS({
  "node_modules/lodash/cloneDeep.js"(exports, module) {
    var baseClone = require_baseClone();
    var CLONE_DEEP_FLAG = 1;
    var CLONE_SYMBOLS_FLAG = 4;
    function cloneDeep(value) {
      return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG);
    }
    module.exports = cloneDeep;
  }
});

// node_modules/lodash/memoize.js
var require_memoize = __commonJS({
  "node_modules/lodash/memoize.js"(exports, module) {
    var MapCache = require_MapCache();
    var FUNC_ERROR_TEXT = "Expected a function";
    function memoize(func, resolver) {
      if (typeof func != "function" || resolver != null && typeof resolver != "function") {
        throw new TypeError(FUNC_ERROR_TEXT);
      }
      var memoized = function() {
        var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
        if (cache.has(key)) {
          return cache.get(key);
        }
        var result = func.apply(this, args);
        memoized.cache = cache.set(key, result) || cache;
        return result;
      };
      memoized.cache = new (memoize.Cache || MapCache)();
      return memoized;
    }
    memoize.Cache = MapCache;
    module.exports = memoize;
  }
});

// node_modules/element-plus/lib/index.esm.js
init_vue_runtime_esm_bundler();

// node_modules/resize-observer-polyfill/dist/ResizeObserver.es.js
var MapShim = function() {
  if (typeof Map !== "undefined") {
    return Map;
  }
  function getIndex(arr, key) {
    var result = -1;
    arr.some(function(entry, index2) {
      if (entry[0] === key) {
        result = index2;
        return true;
      }
      return false;
    });
    return result;
  }
  return function() {
    function class_1() {
      this.__entries__ = [];
    }
    Object.defineProperty(class_1.prototype, "size", {
      get: function() {
        return this.__entries__.length;
      },
      enumerable: true,
      configurable: true
    });
    class_1.prototype.get = function(key) {
      var index2 = getIndex(this.__entries__, key);
      var entry = this.__entries__[index2];
      return entry && entry[1];
    };
    class_1.prototype.set = function(key, value) {
      var index2 = getIndex(this.__entries__, key);
      if (~index2) {
        this.__entries__[index2][1] = value;
      } else {
        this.__entries__.push([key, value]);
      }
    };
    class_1.prototype.delete = function(key) {
      var entries = this.__entries__;
      var index2 = getIndex(entries, key);
      if (~index2) {
        entries.splice(index2, 1);
      }
    };
    class_1.prototype.has = function(key) {
      return !!~getIndex(this.__entries__, key);
    };
    class_1.prototype.clear = function() {
      this.__entries__.splice(0);
    };
    class_1.prototype.forEach = function(callback, ctx) {
      if (ctx === void 0) {
        ctx = null;
      }
      for (var _i2 = 0, _a2 = this.__entries__; _i2 < _a2.length; _i2++) {
        var entry = _a2[_i2];
        callback.call(ctx, entry[1], entry[0]);
      }
    };
    return class_1;
  }();
}();
var isBrowser = typeof window !== "undefined" && typeof document !== "undefined" && window.document === document;
var global$1 = function() {
  if (typeof global !== "undefined" && global.Math === Math) {
    return global;
  }
  if (typeof self !== "undefined" && self.Math === Math) {
    return self;
  }
  if (typeof window !== "undefined" && window.Math === Math) {
    return window;
  }
  return Function("return this")();
}();
var requestAnimationFrame$1 = function() {
  if (typeof requestAnimationFrame === "function") {
    return requestAnimationFrame.bind(global$1);
  }
  return function(callback) {
    return setTimeout(function() {
      return callback(Date.now());
    }, 1e3 / 60);
  };
}();
var trailingTimeout = 2;
function throttle(callback, delay) {
  var leadingCall = false, trailingCall = false, lastCallTime = 0;
  function resolvePending() {
    if (leadingCall) {
      leadingCall = false;
      callback();
    }
    if (trailingCall) {
      proxy();
    }
  }
  function timeoutCallback() {
    requestAnimationFrame$1(resolvePending);
  }
  function proxy() {
    var timeStamp = Date.now();
    if (leadingCall) {
      if (timeStamp - lastCallTime < trailingTimeout) {
        return;
      }
      trailingCall = true;
    } else {
      leadingCall = true;
      trailingCall = false;
      setTimeout(timeoutCallback, delay);
    }
    lastCallTime = timeStamp;
  }
  return proxy;
}
var REFRESH_DELAY = 20;
var transitionKeys = ["top", "right", "bottom", "left", "width", "height", "size", "weight"];
var mutationObserverSupported = typeof MutationObserver !== "undefined";
var ResizeObserverController = function() {
  function ResizeObserverController2() {
    this.connected_ = false;
    this.mutationEventsAdded_ = false;
    this.mutationsObserver_ = null;
    this.observers_ = [];
    this.onTransitionEnd_ = this.onTransitionEnd_.bind(this);
    this.refresh = throttle(this.refresh.bind(this), REFRESH_DELAY);
  }
  ResizeObserverController2.prototype.addObserver = function(observer) {
    if (!~this.observers_.indexOf(observer)) {
      this.observers_.push(observer);
    }
    if (!this.connected_) {
      this.connect_();
    }
  };
  ResizeObserverController2.prototype.removeObserver = function(observer) {
    var observers2 = this.observers_;
    var index2 = observers2.indexOf(observer);
    if (~index2) {
      observers2.splice(index2, 1);
    }
    if (!observers2.length && this.connected_) {
      this.disconnect_();
    }
  };
  ResizeObserverController2.prototype.refresh = function() {
    var changesDetected = this.updateObservers_();
    if (changesDetected) {
      this.refresh();
    }
  };
  ResizeObserverController2.prototype.updateObservers_ = function() {
    var activeObservers = this.observers_.filter(function(observer) {
      return observer.gatherActive(), observer.hasActive();
    });
    activeObservers.forEach(function(observer) {
      return observer.broadcastActive();
    });
    return activeObservers.length > 0;
  };
  ResizeObserverController2.prototype.connect_ = function() {
    if (!isBrowser || this.connected_) {
      return;
    }
    document.addEventListener("transitionend", this.onTransitionEnd_);
    window.addEventListener("resize", this.refresh);
    if (mutationObserverSupported) {
      this.mutationsObserver_ = new MutationObserver(this.refresh);
      this.mutationsObserver_.observe(document, {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true
      });
    } else {
      document.addEventListener("DOMSubtreeModified", this.refresh);
      this.mutationEventsAdded_ = true;
    }
    this.connected_ = true;
  };
  ResizeObserverController2.prototype.disconnect_ = function() {
    if (!isBrowser || !this.connected_) {
      return;
    }
    document.removeEventListener("transitionend", this.onTransitionEnd_);
    window.removeEventListener("resize", this.refresh);
    if (this.mutationsObserver_) {
      this.mutationsObserver_.disconnect();
    }
    if (this.mutationEventsAdded_) {
      document.removeEventListener("DOMSubtreeModified", this.refresh);
    }
    this.mutationsObserver_ = null;
    this.mutationEventsAdded_ = false;
    this.connected_ = false;
  };
  ResizeObserverController2.prototype.onTransitionEnd_ = function(_a2) {
    var _b = _a2.propertyName, propertyName = _b === void 0 ? "" : _b;
    var isReflowProperty = transitionKeys.some(function(key) {
      return !!~propertyName.indexOf(key);
    });
    if (isReflowProperty) {
      this.refresh();
    }
  };
  ResizeObserverController2.getInstance = function() {
    if (!this.instance_) {
      this.instance_ = new ResizeObserverController2();
    }
    return this.instance_;
  };
  ResizeObserverController2.instance_ = null;
  return ResizeObserverController2;
}();
var defineConfigurable = function(target, props) {
  for (var _i2 = 0, _a2 = Object.keys(props); _i2 < _a2.length; _i2++) {
    var key = _a2[_i2];
    Object.defineProperty(target, key, {
      value: props[key],
      enumerable: false,
      writable: false,
      configurable: true
    });
  }
  return target;
};
var getWindowOf = function(target) {
  var ownerGlobal = target && target.ownerDocument && target.ownerDocument.defaultView;
  return ownerGlobal || global$1;
};
var emptyRect = createRectInit(0, 0, 0, 0);
function toFloat(value) {
  return parseFloat(value) || 0;
}
function getBordersSize(styles) {
  var positions = [];
  for (var _i2 = 1; _i2 < arguments.length; _i2++) {
    positions[_i2 - 1] = arguments[_i2];
  }
  return positions.reduce(function(size, position) {
    var value = styles["border-" + position + "-width"];
    return size + toFloat(value);
  }, 0);
}
function getPaddings(styles) {
  var positions = ["top", "right", "bottom", "left"];
  var paddings = {};
  for (var _i2 = 0, positions_1 = positions; _i2 < positions_1.length; _i2++) {
    var position = positions_1[_i2];
    var value = styles["padding-" + position];
    paddings[position] = toFloat(value);
  }
  return paddings;
}
function getSVGContentRect(target) {
  var bbox = target.getBBox();
  return createRectInit(0, 0, bbox.width, bbox.height);
}
function getHTMLElementContentRect(target) {
  var clientWidth = target.clientWidth, clientHeight = target.clientHeight;
  if (!clientWidth && !clientHeight) {
    return emptyRect;
  }
  var styles = getWindowOf(target).getComputedStyle(target);
  var paddings = getPaddings(styles);
  var horizPad = paddings.left + paddings.right;
  var vertPad = paddings.top + paddings.bottom;
  var width = toFloat(styles.width), height = toFloat(styles.height);
  if (styles.boxSizing === "border-box") {
    if (Math.round(width + horizPad) !== clientWidth) {
      width -= getBordersSize(styles, "left", "right") + horizPad;
    }
    if (Math.round(height + vertPad) !== clientHeight) {
      height -= getBordersSize(styles, "top", "bottom") + vertPad;
    }
  }
  if (!isDocumentElement(target)) {
    var vertScrollbar = Math.round(width + horizPad) - clientWidth;
    var horizScrollbar = Math.round(height + vertPad) - clientHeight;
    if (Math.abs(vertScrollbar) !== 1) {
      width -= vertScrollbar;
    }
    if (Math.abs(horizScrollbar) !== 1) {
      height -= horizScrollbar;
    }
  }
  return createRectInit(paddings.left, paddings.top, width, height);
}
var isSVGGraphicsElement = function() {
  if (typeof SVGGraphicsElement !== "undefined") {
    return function(target) {
      return target instanceof getWindowOf(target).SVGGraphicsElement;
    };
  }
  return function(target) {
    return target instanceof getWindowOf(target).SVGElement && typeof target.getBBox === "function";
  };
}();
function isDocumentElement(target) {
  return target === getWindowOf(target).document.documentElement;
}
function getContentRect(target) {
  if (!isBrowser) {
    return emptyRect;
  }
  if (isSVGGraphicsElement(target)) {
    return getSVGContentRect(target);
  }
  return getHTMLElementContentRect(target);
}
function createReadOnlyRect(_a2) {
  var x = _a2.x, y = _a2.y, width = _a2.width, height = _a2.height;
  var Constr = typeof DOMRectReadOnly !== "undefined" ? DOMRectReadOnly : Object;
  var rect = Object.create(Constr.prototype);
  defineConfigurable(rect, {
    x,
    y,
    width,
    height,
    top: y,
    right: x + width,
    bottom: height + y,
    left: x
  });
  return rect;
}
function createRectInit(x, y, width, height) {
  return { x, y, width, height };
}
var ResizeObservation = function() {
  function ResizeObservation2(target) {
    this.broadcastWidth = 0;
    this.broadcastHeight = 0;
    this.contentRect_ = createRectInit(0, 0, 0, 0);
    this.target = target;
  }
  ResizeObservation2.prototype.isActive = function() {
    var rect = getContentRect(this.target);
    this.contentRect_ = rect;
    return rect.width !== this.broadcastWidth || rect.height !== this.broadcastHeight;
  };
  ResizeObservation2.prototype.broadcastRect = function() {
    var rect = this.contentRect_;
    this.broadcastWidth = rect.width;
    this.broadcastHeight = rect.height;
    return rect;
  };
  return ResizeObservation2;
}();
var ResizeObserverEntry = function() {
  function ResizeObserverEntry2(target, rectInit) {
    var contentRect = createReadOnlyRect(rectInit);
    defineConfigurable(this, { target, contentRect });
  }
  return ResizeObserverEntry2;
}();
var ResizeObserverSPI = function() {
  function ResizeObserverSPI2(callback, controller, callbackCtx) {
    this.activeObservations_ = [];
    this.observations_ = new MapShim();
    if (typeof callback !== "function") {
      throw new TypeError("The callback provided as parameter 1 is not a function.");
    }
    this.callback_ = callback;
    this.controller_ = controller;
    this.callbackCtx_ = callbackCtx;
  }
  ResizeObserverSPI2.prototype.observe = function(target) {
    if (!arguments.length) {
      throw new TypeError("1 argument required, but only 0 present.");
    }
    if (typeof Element === "undefined" || !(Element instanceof Object)) {
      return;
    }
    if (!(target instanceof getWindowOf(target).Element)) {
      throw new TypeError('parameter 1 is not of type "Element".');
    }
    var observations = this.observations_;
    if (observations.has(target)) {
      return;
    }
    observations.set(target, new ResizeObservation(target));
    this.controller_.addObserver(this);
    this.controller_.refresh();
  };
  ResizeObserverSPI2.prototype.unobserve = function(target) {
    if (!arguments.length) {
      throw new TypeError("1 argument required, but only 0 present.");
    }
    if (typeof Element === "undefined" || !(Element instanceof Object)) {
      return;
    }
    if (!(target instanceof getWindowOf(target).Element)) {
      throw new TypeError('parameter 1 is not of type "Element".');
    }
    var observations = this.observations_;
    if (!observations.has(target)) {
      return;
    }
    observations.delete(target);
    if (!observations.size) {
      this.controller_.removeObserver(this);
    }
  };
  ResizeObserverSPI2.prototype.disconnect = function() {
    this.clearActive();
    this.observations_.clear();
    this.controller_.removeObserver(this);
  };
  ResizeObserverSPI2.prototype.gatherActive = function() {
    var _this = this;
    this.clearActive();
    this.observations_.forEach(function(observation) {
      if (observation.isActive()) {
        _this.activeObservations_.push(observation);
      }
    });
  };
  ResizeObserverSPI2.prototype.broadcastActive = function() {
    if (!this.hasActive()) {
      return;
    }
    var ctx = this.callbackCtx_;
    var entries = this.activeObservations_.map(function(observation) {
      return new ResizeObserverEntry(observation.target, observation.broadcastRect());
    });
    this.callback_.call(ctx, entries, ctx);
    this.clearActive();
  };
  ResizeObserverSPI2.prototype.clearActive = function() {
    this.activeObservations_.splice(0);
  };
  ResizeObserverSPI2.prototype.hasActive = function() {
    return this.activeObservations_.length > 0;
  };
  return ResizeObserverSPI2;
}();
var observers = typeof WeakMap !== "undefined" ? new WeakMap() : new MapShim();
var ResizeObserver = function() {
  function ResizeObserver2(callback) {
    if (!(this instanceof ResizeObserver2)) {
      throw new TypeError("Cannot call a class as a function.");
    }
    if (!arguments.length) {
      throw new TypeError("1 argument required, but only 0 present.");
    }
    var controller = ResizeObserverController.getInstance();
    var observer = new ResizeObserverSPI(callback, controller, this);
    observers.set(this, observer);
  }
  return ResizeObserver2;
}();
[
  "observe",
  "unobserve",
  "disconnect"
].forEach(function(method3) {
  ResizeObserver.prototype[method3] = function() {
    var _a2;
    return (_a2 = observers.get(this))[method3].apply(_a2, arguments);
  };
});
var index = function() {
  if (typeof global$1.ResizeObserver !== "undefined") {
    return global$1.ResizeObserver;
  }
  return ResizeObserver;
}();
var ResizeObserver_es_default = index;

// node_modules/element-plus/lib/index.esm.js
var import_debounce2 = __toModule(require_debounce());
var import_normalize_wheel = __toModule(require_normalize_wheel());

// node_modules/mitt/dist/mitt.es.js
function mitt_es_default(n) {
  return { all: n = n || new Map(), on: function(t, e) {
    var i = n.get(t);
    i && i.push(e) || n.set(t, [e]);
  }, off: function(t, e) {
    var i = n.get(t);
    i && i.splice(i.indexOf(e) >>> 0, 1);
  }, emit: function(t, e) {
    (n.get(t) || []).slice().map(function(n2) {
      n2(e);
    }), (n.get("*") || []).slice().map(function(n2) {
      n2(t, e);
    });
  } };
}

// node_modules/@popperjs/core/lib/enums.js
var top = "top";
var bottom = "bottom";
var right = "right";
var left = "left";
var auto = "auto";
var basePlacements = [top, bottom, right, left];
var start = "start";
var end = "end";
var clippingParents = "clippingParents";
var viewport = "viewport";
var popper = "popper";
var reference = "reference";
var variationPlacements = basePlacements.reduce(function(acc, placement) {
  return acc.concat([placement + "-" + start, placement + "-" + end]);
}, []);
var placements = [].concat(basePlacements, [auto]).reduce(function(acc, placement) {
  return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
}, []);
var beforeRead = "beforeRead";
var read = "read";
var afterRead = "afterRead";
var beforeMain = "beforeMain";
var main = "main";
var afterMain = "afterMain";
var beforeWrite = "beforeWrite";
var write = "write";
var afterWrite = "afterWrite";
var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];

// node_modules/@popperjs/core/lib/dom-utils/getNodeName.js
function getNodeName(element) {
  return element ? (element.nodeName || "").toLowerCase() : null;
}

// node_modules/@popperjs/core/lib/dom-utils/getWindow.js
function getWindow(node) {
  if (node == null) {
    return window;
  }
  if (node.toString() !== "[object Window]") {
    var ownerDocument = node.ownerDocument;
    return ownerDocument ? ownerDocument.defaultView || window : window;
  }
  return node;
}

// node_modules/@popperjs/core/lib/dom-utils/instanceOf.js
function isElement(node) {
  var OwnElement = getWindow(node).Element;
  return node instanceof OwnElement || node instanceof Element;
}
function isHTMLElement(node) {
  var OwnElement = getWindow(node).HTMLElement;
  return node instanceof OwnElement || node instanceof HTMLElement;
}
function isShadowRoot(node) {
  if (typeof ShadowRoot === "undefined") {
    return false;
  }
  var OwnElement = getWindow(node).ShadowRoot;
  return node instanceof OwnElement || node instanceof ShadowRoot;
}

// node_modules/@popperjs/core/lib/modifiers/applyStyles.js
function applyStyles(_ref) {
  var state = _ref.state;
  Object.keys(state.elements).forEach(function(name) {
    var style = state.styles[name] || {};
    var attributes = state.attributes[name] || {};
    var element = state.elements[name];
    if (!isHTMLElement(element) || !getNodeName(element)) {
      return;
    }
    Object.assign(element.style, style);
    Object.keys(attributes).forEach(function(name2) {
      var value = attributes[name2];
      if (value === false) {
        element.removeAttribute(name2);
      } else {
        element.setAttribute(name2, value === true ? "" : value);
      }
    });
  });
}
function effect(_ref2) {
  var state = _ref2.state;
  var initialStyles = {
    popper: {
      position: state.options.strategy,
      left: "0",
      top: "0",
      margin: "0"
    },
    arrow: {
      position: "absolute"
    },
    reference: {}
  };
  Object.assign(state.elements.popper.style, initialStyles.popper);
  state.styles = initialStyles;
  if (state.elements.arrow) {
    Object.assign(state.elements.arrow.style, initialStyles.arrow);
  }
  return function() {
    Object.keys(state.elements).forEach(function(name) {
      var element = state.elements[name];
      var attributes = state.attributes[name] || {};
      var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]);
      var style = styleProperties.reduce(function(style2, property) {
        style2[property] = "";
        return style2;
      }, {});
      if (!isHTMLElement(element) || !getNodeName(element)) {
        return;
      }
      Object.assign(element.style, style);
      Object.keys(attributes).forEach(function(attribute) {
        element.removeAttribute(attribute);
      });
    });
  };
}
var applyStyles_default = {
  name: "applyStyles",
  enabled: true,
  phase: "write",
  fn: applyStyles,
  effect,
  requires: ["computeStyles"]
};

// node_modules/@popperjs/core/lib/utils/getBasePlacement.js
function getBasePlacement(placement) {
  return placement.split("-")[0];
}

// node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js
function getBoundingClientRect(element) {
  var rect = element.getBoundingClientRect();
  return {
    width: rect.width,
    height: rect.height,
    top: rect.top,
    right: rect.right,
    bottom: rect.bottom,
    left: rect.left,
    x: rect.left,
    y: rect.top
  };
}

// node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js
function getLayoutRect(element) {
  var clientRect = getBoundingClientRect(element);
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  if (Math.abs(clientRect.width - width) <= 1) {
    width = clientRect.width;
  }
  if (Math.abs(clientRect.height - height) <= 1) {
    height = clientRect.height;
  }
  return {
    x: element.offsetLeft,
    y: element.offsetTop,
    width,
    height
  };
}

// node_modules/@popperjs/core/lib/dom-utils/contains.js
function contains(parent2, child) {
  var rootNode = child.getRootNode && child.getRootNode();
  if (parent2.contains(child)) {
    return true;
  } else if (rootNode && isShadowRoot(rootNode)) {
    var next = child;
    do {
      if (next && parent2.isSameNode(next)) {
        return true;
      }
      next = next.parentNode || next.host;
    } while (next);
  }
  return false;
}

// node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js
function getComputedStyle2(element) {
  return getWindow(element).getComputedStyle(element);
}

// node_modules/@popperjs/core/lib/dom-utils/isTableElement.js
function isTableElement(element) {
  return ["table", "td", "th"].indexOf(getNodeName(element)) >= 0;
}

// node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js
function getDocumentElement(element) {
  return ((isElement(element) ? element.ownerDocument : element.document) || window.document).documentElement;
}

// node_modules/@popperjs/core/lib/dom-utils/getParentNode.js
function getParentNode(element) {
  if (getNodeName(element) === "html") {
    return element;
  }
  return element.assignedSlot || element.parentNode || (isShadowRoot(element) ? element.host : null) || getDocumentElement(element);
}

// node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js
function getTrueOffsetParent(element) {
  if (!isHTMLElement(element) || getComputedStyle2(element).position === "fixed") {
    return null;
  }
  return element.offsetParent;
}
function getContainingBlock(element) {
  var isFirefox = navigator.userAgent.toLowerCase().indexOf("firefox") !== -1;
  var isIE = navigator.userAgent.indexOf("Trident") !== -1;
  if (isIE && isHTMLElement(element)) {
    var elementCss = getComputedStyle2(element);
    if (elementCss.position === "fixed") {
      return null;
    }
  }
  var currentNode = getParentNode(element);
  while (isHTMLElement(currentNode) && ["html", "body"].indexOf(getNodeName(currentNode)) < 0) {
    var css = getComputedStyle2(currentNode);
    if (css.transform !== "none" || css.perspective !== "none" || css.contain === "paint" || ["transform", "perspective"].indexOf(css.willChange) !== -1 || isFirefox && css.willChange === "filter" || isFirefox && css.filter && css.filter !== "none") {
      return currentNode;
    } else {
      currentNode = currentNode.parentNode;
    }
  }
  return null;
}
function getOffsetParent(element) {
  var window2 = getWindow(element);
  var offsetParent = getTrueOffsetParent(element);
  while (offsetParent && isTableElement(offsetParent) && getComputedStyle2(offsetParent).position === "static") {
    offsetParent = getTrueOffsetParent(offsetParent);
  }
  if (offsetParent && (getNodeName(offsetParent) === "html" || getNodeName(offsetParent) === "body" && getComputedStyle2(offsetParent).position === "static")) {
    return window2;
  }
  return offsetParent || getContainingBlock(element) || window2;
}

// node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js
function getMainAxisFromPlacement(placement) {
  return ["top", "bottom"].indexOf(placement) >= 0 ? "x" : "y";
}

// node_modules/@popperjs/core/lib/utils/math.js
var max = Math.max;
var min = Math.min;
var round = Math.round;

// node_modules/@popperjs/core/lib/utils/within.js
function within(min2, value, max2) {
  return max(min2, min(value, max2));
}

// node_modules/@popperjs/core/lib/utils/getFreshSideObject.js
function getFreshSideObject() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}

// node_modules/@popperjs/core/lib/utils/mergePaddingObject.js
function mergePaddingObject(paddingObject) {
  return Object.assign({}, getFreshSideObject(), paddingObject);
}

// node_modules/@popperjs/core/lib/utils/expandToHashMap.js
function expandToHashMap(value, keys) {
  return keys.reduce(function(hashMap, key) {
    hashMap[key] = value;
    return hashMap;
  }, {});
}

// node_modules/@popperjs/core/lib/modifiers/arrow.js
var toPaddingObject = function toPaddingObject2(padding, state) {
  padding = typeof padding === "function" ? padding(Object.assign({}, state.rects, {
    placement: state.placement
  })) : padding;
  return mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
};
function arrow(_ref) {
  var _state$modifiersData$;
  var state = _ref.state, name = _ref.name, options = _ref.options;
  var arrowElement = state.elements.arrow;
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var basePlacement = getBasePlacement(state.placement);
  var axis = getMainAxisFromPlacement(basePlacement);
  var isVertical = [left, right].indexOf(basePlacement) >= 0;
  var len = isVertical ? "height" : "width";
  if (!arrowElement || !popperOffsets2) {
    return;
  }
  var paddingObject = toPaddingObject(options.padding, state);
  var arrowRect = getLayoutRect(arrowElement);
  var minProp = axis === "y" ? top : left;
  var maxProp = axis === "y" ? bottom : right;
  var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets2[axis] - state.rects.popper[len];
  var startDiff = popperOffsets2[axis] - state.rects.reference[axis];
  var arrowOffsetParent = getOffsetParent(arrowElement);
  var clientSize = arrowOffsetParent ? axis === "y" ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
  var centerToReference = endDiff / 2 - startDiff / 2;
  var min2 = paddingObject[minProp];
  var max2 = clientSize - arrowRect[len] - paddingObject[maxProp];
  var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
  var offset2 = within(min2, center, max2);
  var axisProp = axis;
  state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset2, _state$modifiersData$.centerOffset = offset2 - center, _state$modifiersData$);
}
function effect2(_ref2) {
  var state = _ref2.state, options = _ref2.options;
  var _options$element = options.element, arrowElement = _options$element === void 0 ? "[data-popper-arrow]" : _options$element;
  if (arrowElement == null) {
    return;
  }
  if (typeof arrowElement === "string") {
    arrowElement = state.elements.popper.querySelector(arrowElement);
    if (!arrowElement) {
      return;
    }
  }
  if (true) {
    if (!isHTMLElement(arrowElement)) {
      console.error(['Popper: "arrow" element must be an HTMLElement (not an SVGElement).', "To use an SVG arrow, wrap it in an HTMLElement that will be used as", "the arrow."].join(" "));
    }
  }
  if (!contains(state.elements.popper, arrowElement)) {
    if (true) {
      console.error(['Popper: "arrow" modifier\'s `element` must be a child of the popper', "element."].join(" "));
    }
    return;
  }
  state.elements.arrow = arrowElement;
}
var arrow_default = {
  name: "arrow",
  enabled: true,
  phase: "main",
  fn: arrow,
  effect: effect2,
  requires: ["popperOffsets"],
  requiresIfExists: ["preventOverflow"]
};

// node_modules/@popperjs/core/lib/modifiers/computeStyles.js
var unsetSides = {
  top: "auto",
  right: "auto",
  bottom: "auto",
  left: "auto"
};
function roundOffsetsByDPR(_ref) {
  var x = _ref.x, y = _ref.y;
  var win = window;
  var dpr = win.devicePixelRatio || 1;
  return {
    x: round(round(x * dpr) / dpr) || 0,
    y: round(round(y * dpr) / dpr) || 0
  };
}
function mapToStyles(_ref2) {
  var _Object$assign2;
  var popper2 = _ref2.popper, popperRect = _ref2.popperRect, placement = _ref2.placement, offsets = _ref2.offsets, position = _ref2.position, gpuAcceleration = _ref2.gpuAcceleration, adaptive = _ref2.adaptive, roundOffsets = _ref2.roundOffsets;
  var _ref3 = roundOffsets === true ? roundOffsetsByDPR(offsets) : typeof roundOffsets === "function" ? roundOffsets(offsets) : offsets, _ref3$x = _ref3.x, x = _ref3$x === void 0 ? 0 : _ref3$x, _ref3$y = _ref3.y, y = _ref3$y === void 0 ? 0 : _ref3$y;
  var hasX = offsets.hasOwnProperty("x");
  var hasY = offsets.hasOwnProperty("y");
  var sideX = left;
  var sideY = top;
  var win = window;
  if (adaptive) {
    var offsetParent = getOffsetParent(popper2);
    var heightProp = "clientHeight";
    var widthProp = "clientWidth";
    if (offsetParent === getWindow(popper2)) {
      offsetParent = getDocumentElement(popper2);
      if (getComputedStyle2(offsetParent).position !== "static") {
        heightProp = "scrollHeight";
        widthProp = "scrollWidth";
      }
    }
    offsetParent = offsetParent;
    if (placement === top) {
      sideY = bottom;
      y -= offsetParent[heightProp] - popperRect.height;
      y *= gpuAcceleration ? 1 : -1;
    }
    if (placement === left) {
      sideX = right;
      x -= offsetParent[widthProp] - popperRect.width;
      x *= gpuAcceleration ? 1 : -1;
    }
  }
  var commonStyles = Object.assign({
    position
  }, adaptive && unsetSides);
  if (gpuAcceleration) {
    var _Object$assign;
    return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? "0" : "", _Object$assign[sideX] = hasX ? "0" : "", _Object$assign.transform = (win.devicePixelRatio || 1) < 2 ? "translate(" + x + "px, " + y + "px)" : "translate3d(" + x + "px, " + y + "px, 0)", _Object$assign));
  }
  return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y + "px" : "", _Object$assign2[sideX] = hasX ? x + "px" : "", _Object$assign2.transform = "", _Object$assign2));
}
function computeStyles(_ref4) {
  var state = _ref4.state, options = _ref4.options;
  var _options$gpuAccelerat = options.gpuAcceleration, gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat, _options$adaptive = options.adaptive, adaptive = _options$adaptive === void 0 ? true : _options$adaptive, _options$roundOffsets = options.roundOffsets, roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
  if (true) {
    var transitionProperty = getComputedStyle2(state.elements.popper).transitionProperty || "";
    if (adaptive && ["transform", "top", "right", "bottom", "left"].some(function(property) {
      return transitionProperty.indexOf(property) >= 0;
    })) {
      console.warn(["Popper: Detected CSS transitions on at least one of the following", 'CSS properties: "transform", "top", "right", "bottom", "left".', "\n\n", 'Disable the "computeStyles" modifier\'s `adaptive` option to allow', "for smooth transitions, or remove these properties from the CSS", "transition declaration on the popper element if only transitioning", "opacity or background-color for example.", "\n\n", "We recommend using the popper element as a wrapper around an inner", "element that can have any CSS property transitioned for animations."].join(" "));
    }
  }
  var commonStyles = {
    placement: getBasePlacement(state.placement),
    popper: state.elements.popper,
    popperRect: state.rects.popper,
    gpuAcceleration
  };
  if (state.modifiersData.popperOffsets != null) {
    state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.popperOffsets,
      position: state.options.strategy,
      adaptive,
      roundOffsets
    })));
  }
  if (state.modifiersData.arrow != null) {
    state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.arrow,
      position: "absolute",
      adaptive: false,
      roundOffsets
    })));
  }
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-placement": state.placement
  });
}
var computeStyles_default = {
  name: "computeStyles",
  enabled: true,
  phase: "beforeWrite",
  fn: computeStyles,
  data: {}
};

// node_modules/@popperjs/core/lib/modifiers/eventListeners.js
var passive = {
  passive: true
};
function effect3(_ref) {
  var state = _ref.state, instance = _ref.instance, options = _ref.options;
  var _options$scroll = options.scroll, scroll = _options$scroll === void 0 ? true : _options$scroll, _options$resize = options.resize, resize = _options$resize === void 0 ? true : _options$resize;
  var window2 = getWindow(state.elements.popper);
  var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);
  if (scroll) {
    scrollParents.forEach(function(scrollParent) {
      scrollParent.addEventListener("scroll", instance.update, passive);
    });
  }
  if (resize) {
    window2.addEventListener("resize", instance.update, passive);
  }
  return function() {
    if (scroll) {
      scrollParents.forEach(function(scrollParent) {
        scrollParent.removeEventListener("scroll", instance.update, passive);
      });
    }
    if (resize) {
      window2.removeEventListener("resize", instance.update, passive);
    }
  };
}
var eventListeners_default = {
  name: "eventListeners",
  enabled: true,
  phase: "write",
  fn: function fn() {
  },
  effect: effect3,
  data: {}
};

// node_modules/@popperjs/core/lib/utils/getOppositePlacement.js
var hash = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, function(matched) {
    return hash[matched];
  });
}

// node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js
var hash2 = {
  start: "end",
  end: "start"
};
function getOppositeVariationPlacement(placement) {
  return placement.replace(/start|end/g, function(matched) {
    return hash2[matched];
  });
}

// node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js
function getWindowScroll(node) {
  var win = getWindow(node);
  var scrollLeft = win.pageXOffset;
  var scrollTop = win.pageYOffset;
  return {
    scrollLeft,
    scrollTop
  };
}

// node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js
function getWindowScrollBarX(element) {
  return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
}

// node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js
function getViewportRect(element) {
  var win = getWindow(element);
  var html = getDocumentElement(element);
  var visualViewport = win.visualViewport;
  var width = html.clientWidth;
  var height = html.clientHeight;
  var x = 0;
  var y = 0;
  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    if (!/^((?!chrome|android).)*safari/i.test(navigator.userAgent)) {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }
  return {
    width,
    height,
    x: x + getWindowScrollBarX(element),
    y
  };
}

// node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js
function getDocumentRect(element) {
  var _element$ownerDocumen;
  var html = getDocumentElement(element);
  var winScroll = getWindowScroll(element);
  var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
  var width = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
  var height = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
  var x = -winScroll.scrollLeft + getWindowScrollBarX(element);
  var y = -winScroll.scrollTop;
  if (getComputedStyle2(body || html).direction === "rtl") {
    x += max(html.clientWidth, body ? body.clientWidth : 0) - width;
  }
  return {
    width,
    height,
    x,
    y
  };
}

// node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js
function isScrollParent(element) {
  var _getComputedStyle = getComputedStyle2(element), overflow = _getComputedStyle.overflow, overflowX = _getComputedStyle.overflowX, overflowY = _getComputedStyle.overflowY;
  return /auto|scroll|overlay|hidden/.test(overflow + overflowY + overflowX);
}

// node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js
function getScrollParent(node) {
  if (["html", "body", "#document"].indexOf(getNodeName(node)) >= 0) {
    return node.ownerDocument.body;
  }
  if (isHTMLElement(node) && isScrollParent(node)) {
    return node;
  }
  return getScrollParent(getParentNode(node));
}

// node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js
function listScrollParents(element, list) {
  var _element$ownerDocumen;
  if (list === void 0) {
    list = [];
  }
  var scrollParent = getScrollParent(element);
  var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
  var win = getWindow(scrollParent);
  var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
  var updatedList = list.concat(target);
  return isBody ? updatedList : updatedList.concat(listScrollParents(getParentNode(target)));
}

// node_modules/@popperjs/core/lib/utils/rectToClientRect.js
function rectToClientRect(rect) {
  return Object.assign({}, rect, {
    left: rect.x,
    top: rect.y,
    right: rect.x + rect.width,
    bottom: rect.y + rect.height
  });
}

// node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js
function getInnerBoundingClientRect(element) {
  var rect = getBoundingClientRect(element);
  rect.top = rect.top + element.clientTop;
  rect.left = rect.left + element.clientLeft;
  rect.bottom = rect.top + element.clientHeight;
  rect.right = rect.left + element.clientWidth;
  rect.width = element.clientWidth;
  rect.height = element.clientHeight;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}
function getClientRectFromMixedType(element, clippingParent) {
  return clippingParent === viewport ? rectToClientRect(getViewportRect(element)) : isHTMLElement(clippingParent) ? getInnerBoundingClientRect(clippingParent) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
}
function getClippingParents(element) {
  var clippingParents2 = listScrollParents(getParentNode(element));
  var canEscapeClipping = ["absolute", "fixed"].indexOf(getComputedStyle2(element).position) >= 0;
  var clipperElement = canEscapeClipping && isHTMLElement(element) ? getOffsetParent(element) : element;
  if (!isElement(clipperElement)) {
    return [];
  }
  return clippingParents2.filter(function(clippingParent) {
    return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== "body";
  });
}
function getClippingRect(element, boundary, rootBoundary) {
  var mainClippingParents = boundary === "clippingParents" ? getClippingParents(element) : [].concat(boundary);
  var clippingParents2 = [].concat(mainClippingParents, [rootBoundary]);
  var firstClippingParent = clippingParents2[0];
  var clippingRect = clippingParents2.reduce(function(accRect, clippingParent) {
    var rect = getClientRectFromMixedType(element, clippingParent);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromMixedType(element, firstClippingParent));
  clippingRect.width = clippingRect.right - clippingRect.left;
  clippingRect.height = clippingRect.bottom - clippingRect.top;
  clippingRect.x = clippingRect.left;
  clippingRect.y = clippingRect.top;
  return clippingRect;
}

// node_modules/@popperjs/core/lib/utils/getVariation.js
function getVariation(placement) {
  return placement.split("-")[1];
}

// node_modules/@popperjs/core/lib/utils/computeOffsets.js
function computeOffsets(_ref) {
  var reference2 = _ref.reference, element = _ref.element, placement = _ref.placement;
  var basePlacement = placement ? getBasePlacement(placement) : null;
  var variation = placement ? getVariation(placement) : null;
  var commonX = reference2.x + reference2.width / 2 - element.width / 2;
  var commonY = reference2.y + reference2.height / 2 - element.height / 2;
  var offsets;
  switch (basePlacement) {
    case top:
      offsets = {
        x: commonX,
        y: reference2.y - element.height
      };
      break;
    case bottom:
      offsets = {
        x: commonX,
        y: reference2.y + reference2.height
      };
      break;
    case right:
      offsets = {
        x: reference2.x + reference2.width,
        y: commonY
      };
      break;
    case left:
      offsets = {
        x: reference2.x - element.width,
        y: commonY
      };
      break;
    default:
      offsets = {
        x: reference2.x,
        y: reference2.y
      };
  }
  var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;
  if (mainAxis != null) {
    var len = mainAxis === "y" ? "height" : "width";
    switch (variation) {
      case start:
        offsets[mainAxis] = offsets[mainAxis] - (reference2[len] / 2 - element[len] / 2);
        break;
      case end:
        offsets[mainAxis] = offsets[mainAxis] + (reference2[len] / 2 - element[len] / 2);
        break;
      default:
    }
  }
  return offsets;
}

// node_modules/@popperjs/core/lib/utils/detectOverflow.js
function detectOverflow(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, _options$placement = _options.placement, placement = _options$placement === void 0 ? state.placement : _options$placement, _options$boundary = _options.boundary, boundary = _options$boundary === void 0 ? clippingParents : _options$boundary, _options$rootBoundary = _options.rootBoundary, rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary, _options$elementConte = _options.elementContext, elementContext = _options$elementConte === void 0 ? popper : _options$elementConte, _options$altBoundary = _options.altBoundary, altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary, _options$padding = _options.padding, padding = _options$padding === void 0 ? 0 : _options$padding;
  var paddingObject = mergePaddingObject(typeof padding !== "number" ? padding : expandToHashMap(padding, basePlacements));
  var altContext = elementContext === popper ? reference : popper;
  var referenceElement = state.elements.reference;
  var popperRect = state.rects.popper;
  var element = state.elements[altBoundary ? altContext : elementContext];
  var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary);
  var referenceClientRect = getBoundingClientRect(referenceElement);
  var popperOffsets2 = computeOffsets({
    reference: referenceClientRect,
    element: popperRect,
    strategy: "absolute",
    placement
  });
  var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets2));
  var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect;
  var overflowOffsets = {
    top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
    bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
    left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
    right: elementClientRect.right - clippingClientRect.right + paddingObject.right
  };
  var offsetData = state.modifiersData.offset;
  if (elementContext === popper && offsetData) {
    var offset2 = offsetData[placement];
    Object.keys(overflowOffsets).forEach(function(key) {
      var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
      var axis = [top, bottom].indexOf(key) >= 0 ? "y" : "x";
      overflowOffsets[key] += offset2[axis] * multiply;
    });
  }
  return overflowOffsets;
}

// node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js
function computeAutoPlacement(state, options) {
  if (options === void 0) {
    options = {};
  }
  var _options = options, placement = _options.placement, boundary = _options.boundary, rootBoundary = _options.rootBoundary, padding = _options.padding, flipVariations = _options.flipVariations, _options$allowedAutoP = _options.allowedAutoPlacements, allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
  var variation = getVariation(placement);
  var placements2 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function(placement2) {
    return getVariation(placement2) === variation;
  }) : basePlacements;
  var allowedPlacements = placements2.filter(function(placement2) {
    return allowedAutoPlacements.indexOf(placement2) >= 0;
  });
  if (allowedPlacements.length === 0) {
    allowedPlacements = placements2;
    if (true) {
      console.error(["Popper: The `allowedAutoPlacements` option did not allow any", "placements. Ensure the `placement` option matches the variation", "of the allowed placements.", 'For example, "auto" cannot be used to allow "bottom-start".', 'Use "auto-start" instead.'].join(" "));
    }
  }
  var overflows = allowedPlacements.reduce(function(acc, placement2) {
    acc[placement2] = detectOverflow(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding
    })[getBasePlacement(placement2)];
    return acc;
  }, {});
  return Object.keys(overflows).sort(function(a, b) {
    return overflows[a] - overflows[b];
  });
}

// node_modules/@popperjs/core/lib/modifiers/flip.js
function getExpandedFallbackPlacements(placement) {
  if (getBasePlacement(placement) === auto) {
    return [];
  }
  var oppositePlacement = getOppositePlacement(placement);
  return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
}
function flip(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  if (state.modifiersData[name]._skip) {
    return;
  }
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis, specifiedFallbackPlacements = options.fallbackPlacements, padding = options.padding, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, _options$flipVariatio = options.flipVariations, flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio, allowedAutoPlacements = options.allowedAutoPlacements;
  var preferredPlacement = state.options.placement;
  var basePlacement = getBasePlacement(preferredPlacement);
  var isBasePlacement = basePlacement === preferredPlacement;
  var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
  var placements2 = [preferredPlacement].concat(fallbackPlacements).reduce(function(acc, placement2) {
    return acc.concat(getBasePlacement(placement2) === auto ? computeAutoPlacement(state, {
      placement: placement2,
      boundary,
      rootBoundary,
      padding,
      flipVariations,
      allowedAutoPlacements
    }) : placement2);
  }, []);
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var checksMap = new Map();
  var makeFallbackChecks = true;
  var firstFittingPlacement = placements2[0];
  for (var i = 0; i < placements2.length; i++) {
    var placement = placements2[i];
    var _basePlacement = getBasePlacement(placement);
    var isStartVariation = getVariation(placement) === start;
    var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
    var len = isVertical ? "width" : "height";
    var overflow = detectOverflow(state, {
      placement,
      boundary,
      rootBoundary,
      altBoundary,
      padding
    });
    var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;
    if (referenceRect[len] > popperRect[len]) {
      mainVariationSide = getOppositePlacement(mainVariationSide);
    }
    var altVariationSide = getOppositePlacement(mainVariationSide);
    var checks = [];
    if (checkMainAxis) {
      checks.push(overflow[_basePlacement] <= 0);
    }
    if (checkAltAxis) {
      checks.push(overflow[mainVariationSide] <= 0, overflow[altVariationSide] <= 0);
    }
    if (checks.every(function(check) {
      return check;
    })) {
      firstFittingPlacement = placement;
      makeFallbackChecks = false;
      break;
    }
    checksMap.set(placement, checks);
  }
  if (makeFallbackChecks) {
    var numberOfChecks = flipVariations ? 3 : 1;
    var _loop = function _loop2(_i3) {
      var fittingPlacement = placements2.find(function(placement2) {
        var checks2 = checksMap.get(placement2);
        if (checks2) {
          return checks2.slice(0, _i3).every(function(check) {
            return check;
          });
        }
      });
      if (fittingPlacement) {
        firstFittingPlacement = fittingPlacement;
        return "break";
      }
    };
    for (var _i2 = numberOfChecks; _i2 > 0; _i2--) {
      var _ret = _loop(_i2);
      if (_ret === "break")
        break;
    }
  }
  if (state.placement !== firstFittingPlacement) {
    state.modifiersData[name]._skip = true;
    state.placement = firstFittingPlacement;
    state.reset = true;
  }
}
var flip_default = {
  name: "flip",
  enabled: true,
  phase: "main",
  fn: flip,
  requiresIfExists: ["offset"],
  data: {
    _skip: false
  }
};

// node_modules/@popperjs/core/lib/modifiers/hide.js
function getSideOffsets(overflow, rect, preventedOffsets) {
  if (preventedOffsets === void 0) {
    preventedOffsets = {
      x: 0,
      y: 0
    };
  }
  return {
    top: overflow.top - rect.height - preventedOffsets.y,
    right: overflow.right - rect.width + preventedOffsets.x,
    bottom: overflow.bottom - rect.height + preventedOffsets.y,
    left: overflow.left - rect.width - preventedOffsets.x
  };
}
function isAnySideFullyClipped(overflow) {
  return [top, right, bottom, left].some(function(side) {
    return overflow[side] >= 0;
  });
}
function hide(_ref) {
  var state = _ref.state, name = _ref.name;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var preventedOffsets = state.modifiersData.preventOverflow;
  var referenceOverflow = detectOverflow(state, {
    elementContext: "reference"
  });
  var popperAltOverflow = detectOverflow(state, {
    altBoundary: true
  });
  var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
  var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
  var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
  var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
  state.modifiersData[name] = {
    referenceClippingOffsets,
    popperEscapeOffsets,
    isReferenceHidden,
    hasPopperEscaped
  };
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    "data-popper-reference-hidden": isReferenceHidden,
    "data-popper-escaped": hasPopperEscaped
  });
}
var hide_default = {
  name: "hide",
  enabled: true,
  phase: "main",
  requiresIfExists: ["preventOverflow"],
  fn: hide
};

// node_modules/@popperjs/core/lib/modifiers/offset.js
function distanceAndSkiddingToXY(placement, rects, offset2) {
  var basePlacement = getBasePlacement(placement);
  var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;
  var _ref = typeof offset2 === "function" ? offset2(Object.assign({}, rects, {
    placement
  })) : offset2, skidding = _ref[0], distance = _ref[1];
  skidding = skidding || 0;
  distance = (distance || 0) * invertDistance;
  return [left, right].indexOf(basePlacement) >= 0 ? {
    x: distance,
    y: skidding
  } : {
    x: skidding,
    y: distance
  };
}
function offset(_ref2) {
  var state = _ref2.state, options = _ref2.options, name = _ref2.name;
  var _options$offset = options.offset, offset2 = _options$offset === void 0 ? [0, 0] : _options$offset;
  var data = placements.reduce(function(acc, placement) {
    acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset2);
    return acc;
  }, {});
  var _data$state$placement = data[state.placement], x = _data$state$placement.x, y = _data$state$placement.y;
  if (state.modifiersData.popperOffsets != null) {
    state.modifiersData.popperOffsets.x += x;
    state.modifiersData.popperOffsets.y += y;
  }
  state.modifiersData[name] = data;
}
var offset_default = {
  name: "offset",
  enabled: true,
  phase: "main",
  requires: ["popperOffsets"],
  fn: offset
};

// node_modules/@popperjs/core/lib/modifiers/popperOffsets.js
function popperOffsets(_ref) {
  var state = _ref.state, name = _ref.name;
  state.modifiersData[name] = computeOffsets({
    reference: state.rects.reference,
    element: state.rects.popper,
    strategy: "absolute",
    placement: state.placement
  });
}
var popperOffsets_default = {
  name: "popperOffsets",
  enabled: true,
  phase: "read",
  fn: popperOffsets,
  data: {}
};

// node_modules/@popperjs/core/lib/utils/getAltAxis.js
function getAltAxis(axis) {
  return axis === "x" ? "y" : "x";
}

// node_modules/@popperjs/core/lib/modifiers/preventOverflow.js
function preventOverflow(_ref) {
  var state = _ref.state, options = _ref.options, name = _ref.name;
  var _options$mainAxis = options.mainAxis, checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis, _options$altAxis = options.altAxis, checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis, boundary = options.boundary, rootBoundary = options.rootBoundary, altBoundary = options.altBoundary, padding = options.padding, _options$tether = options.tether, tether = _options$tether === void 0 ? true : _options$tether, _options$tetherOffset = options.tetherOffset, tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
  var overflow = detectOverflow(state, {
    boundary,
    rootBoundary,
    padding,
    altBoundary
  });
  var basePlacement = getBasePlacement(state.placement);
  var variation = getVariation(state.placement);
  var isBasePlacement = !variation;
  var mainAxis = getMainAxisFromPlacement(basePlacement);
  var altAxis = getAltAxis(mainAxis);
  var popperOffsets2 = state.modifiersData.popperOffsets;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var tetherOffsetValue = typeof tetherOffset === "function" ? tetherOffset(Object.assign({}, state.rects, {
    placement: state.placement
  })) : tetherOffset;
  var data = {
    x: 0,
    y: 0
  };
  if (!popperOffsets2) {
    return;
  }
  if (checkMainAxis || checkAltAxis) {
    var mainSide = mainAxis === "y" ? top : left;
    var altSide = mainAxis === "y" ? bottom : right;
    var len = mainAxis === "y" ? "height" : "width";
    var offset2 = popperOffsets2[mainAxis];
    var min2 = popperOffsets2[mainAxis] + overflow[mainSide];
    var max2 = popperOffsets2[mainAxis] - overflow[altSide];
    var additive = tether ? -popperRect[len] / 2 : 0;
    var minLen = variation === start ? referenceRect[len] : popperRect[len];
    var maxLen = variation === start ? -popperRect[len] : -referenceRect[len];
    var arrowElement = state.elements.arrow;
    var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
      width: 0,
      height: 0
    };
    var arrowPaddingObject = state.modifiersData["arrow#persistent"] ? state.modifiersData["arrow#persistent"].padding : getFreshSideObject();
    var arrowPaddingMin = arrowPaddingObject[mainSide];
    var arrowPaddingMax = arrowPaddingObject[altSide];
    var arrowLen = within(0, referenceRect[len], arrowRect[len]);
    var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - tetherOffsetValue : minLen - arrowLen - arrowPaddingMin - tetherOffsetValue;
    var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + tetherOffsetValue : maxLen + arrowLen + arrowPaddingMax + tetherOffsetValue;
    var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
    var clientOffset = arrowOffsetParent ? mainAxis === "y" ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
    var offsetModifierValue = state.modifiersData.offset ? state.modifiersData.offset[state.placement][mainAxis] : 0;
    var tetherMin = popperOffsets2[mainAxis] + minOffset - offsetModifierValue - clientOffset;
    var tetherMax = popperOffsets2[mainAxis] + maxOffset - offsetModifierValue;
    if (checkMainAxis) {
      var preventedOffset = within(tether ? min(min2, tetherMin) : min2, offset2, tether ? max(max2, tetherMax) : max2);
      popperOffsets2[mainAxis] = preventedOffset;
      data[mainAxis] = preventedOffset - offset2;
    }
    if (checkAltAxis) {
      var _mainSide = mainAxis === "x" ? top : left;
      var _altSide = mainAxis === "x" ? bottom : right;
      var _offset = popperOffsets2[altAxis];
      var _min = _offset + overflow[_mainSide];
      var _max = _offset - overflow[_altSide];
      var _preventedOffset = within(tether ? min(_min, tetherMin) : _min, _offset, tether ? max(_max, tetherMax) : _max);
      popperOffsets2[altAxis] = _preventedOffset;
      data[altAxis] = _preventedOffset - _offset;
    }
  }
  state.modifiersData[name] = data;
}
var preventOverflow_default = {
  name: "preventOverflow",
  enabled: true,
  phase: "main",
  fn: preventOverflow,
  requiresIfExists: ["offset"]
};

// node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js
function getHTMLElementScroll(element) {
  return {
    scrollLeft: element.scrollLeft,
    scrollTop: element.scrollTop
  };
}

// node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js
function getNodeScroll(node) {
  if (node === getWindow(node) || !isHTMLElement(node)) {
    return getWindowScroll(node);
  } else {
    return getHTMLElementScroll(node);
  }
}

// node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js
function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
  if (isFixed === void 0) {
    isFixed = false;
  }
  var documentElement = getDocumentElement(offsetParent);
  var rect = getBoundingClientRect(elementOrVirtualElement);
  var isOffsetParentAnElement = isHTMLElement(offsetParent);
  var scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  var offsets = {
    x: 0,
    y: 0
  };
  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== "body" || isScrollParent(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }
    if (isHTMLElement(offsetParent)) {
      offsets = getBoundingClientRect(offsetParent);
      offsets.x += offsetParent.clientLeft;
      offsets.y += offsetParent.clientTop;
    } else if (documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
  }
  return {
    x: rect.left + scroll.scrollLeft - offsets.x,
    y: rect.top + scroll.scrollTop - offsets.y,
    width: rect.width,
    height: rect.height
  };
}

// node_modules/@popperjs/core/lib/utils/orderModifiers.js
function order(modifiers) {
  var map = new Map();
  var visited = new Set();
  var result = [];
  modifiers.forEach(function(modifier) {
    map.set(modifier.name, modifier);
  });
  function sort(modifier) {
    visited.add(modifier.name);
    var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
    requires.forEach(function(dep) {
      if (!visited.has(dep)) {
        var depModifier = map.get(dep);
        if (depModifier) {
          sort(depModifier);
        }
      }
    });
    result.push(modifier);
  }
  modifiers.forEach(function(modifier) {
    if (!visited.has(modifier.name)) {
      sort(modifier);
    }
  });
  return result;
}
function orderModifiers(modifiers) {
  var orderedModifiers = order(modifiers);
  return modifierPhases.reduce(function(acc, phase) {
    return acc.concat(orderedModifiers.filter(function(modifier) {
      return modifier.phase === phase;
    }));
  }, []);
}

// node_modules/@popperjs/core/lib/utils/debounce.js
function debounce(fn3) {
  var pending;
  return function() {
    if (!pending) {
      pending = new Promise(function(resolve) {
        Promise.resolve().then(function() {
          pending = void 0;
          resolve(fn3());
        });
      });
    }
    return pending;
  };
}

// node_modules/@popperjs/core/lib/utils/format.js
function format(str) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  return [].concat(args).reduce(function(p, c) {
    return p.replace(/%s/, c);
  }, str);
}

// node_modules/@popperjs/core/lib/utils/validateModifiers.js
var INVALID_MODIFIER_ERROR = 'Popper: modifier "%s" provided an invalid %s property, expected %s but got %s';
var MISSING_DEPENDENCY_ERROR = 'Popper: modifier "%s" requires "%s", but "%s" modifier is not available';
var VALID_PROPERTIES = ["name", "enabled", "phase", "fn", "effect", "requires", "options"];
function validateModifiers(modifiers) {
  modifiers.forEach(function(modifier) {
    Object.keys(modifier).forEach(function(key) {
      switch (key) {
        case "name":
          if (typeof modifier.name !== "string") {
            console.error(format(INVALID_MODIFIER_ERROR, String(modifier.name), '"name"', '"string"', '"' + String(modifier.name) + '"'));
          }
          break;
        case "enabled":
          if (typeof modifier.enabled !== "boolean") {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"enabled"', '"boolean"', '"' + String(modifier.enabled) + '"'));
          }
        case "phase":
          if (modifierPhases.indexOf(modifier.phase) < 0) {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"phase"', "either " + modifierPhases.join(", "), '"' + String(modifier.phase) + '"'));
          }
          break;
        case "fn":
          if (typeof modifier.fn !== "function") {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"fn"', '"function"', '"' + String(modifier.fn) + '"'));
          }
          break;
        case "effect":
          if (typeof modifier.effect !== "function") {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"effect"', '"function"', '"' + String(modifier.fn) + '"'));
          }
          break;
        case "requires":
          if (!Array.isArray(modifier.requires)) {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"requires"', '"array"', '"' + String(modifier.requires) + '"'));
          }
          break;
        case "requiresIfExists":
          if (!Array.isArray(modifier.requiresIfExists)) {
            console.error(format(INVALID_MODIFIER_ERROR, modifier.name, '"requiresIfExists"', '"array"', '"' + String(modifier.requiresIfExists) + '"'));
          }
          break;
        case "options":
        case "data":
          break;
        default:
          console.error('PopperJS: an invalid property has been provided to the "' + modifier.name + '" modifier, valid properties are ' + VALID_PROPERTIES.map(function(s) {
            return '"' + s + '"';
          }).join(", ") + '; but "' + key + '" was provided.');
      }
      modifier.requires && modifier.requires.forEach(function(requirement) {
        if (modifiers.find(function(mod) {
          return mod.name === requirement;
        }) == null) {
          console.error(format(MISSING_DEPENDENCY_ERROR, String(modifier.name), requirement, requirement));
        }
      });
    });
  });
}

// node_modules/@popperjs/core/lib/utils/uniqueBy.js
function uniqueBy(arr, fn3) {
  var identifiers = new Set();
  return arr.filter(function(item) {
    var identifier = fn3(item);
    if (!identifiers.has(identifier)) {
      identifiers.add(identifier);
      return true;
    }
  });
}

// node_modules/@popperjs/core/lib/utils/mergeByName.js
function mergeByName(modifiers) {
  var merged = modifiers.reduce(function(merged2, current) {
    var existing = merged2[current.name];
    merged2[current.name] = existing ? Object.assign({}, existing, current, {
      options: Object.assign({}, existing.options, current.options),
      data: Object.assign({}, existing.data, current.data)
    }) : current;
    return merged2;
  }, {});
  return Object.keys(merged).map(function(key) {
    return merged[key];
  });
}

// node_modules/@popperjs/core/lib/createPopper.js
var INVALID_ELEMENT_ERROR = "Popper: Invalid reference or popper argument provided. They must be either a DOM element or virtual element.";
var INFINITE_LOOP_ERROR = "Popper: An infinite loop in the modifiers cycle has been detected! The cycle has been interrupted to prevent a browser crash.";
var DEFAULT_OPTIONS = {
  placement: "bottom",
  modifiers: [],
  strategy: "absolute"
};
function areValidElements() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  return !args.some(function(element) {
    return !(element && typeof element.getBoundingClientRect === "function");
  });
}
function popperGenerator(generatorOptions) {
  if (generatorOptions === void 0) {
    generatorOptions = {};
  }
  var _generatorOptions = generatorOptions, _generatorOptions$def = _generatorOptions.defaultModifiers, defaultModifiers3 = _generatorOptions$def === void 0 ? [] : _generatorOptions$def, _generatorOptions$def2 = _generatorOptions.defaultOptions, defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
  return function createPopper4(reference2, popper2, options) {
    if (options === void 0) {
      options = defaultOptions;
    }
    var state = {
      placement: "bottom",
      orderedModifiers: [],
      options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
      modifiersData: {},
      elements: {
        reference: reference2,
        popper: popper2
      },
      attributes: {},
      styles: {}
    };
    var effectCleanupFns = [];
    var isDestroyed = false;
    var instance = {
      state,
      setOptions: function setOptions(options2) {
        cleanupModifierEffects();
        state.options = Object.assign({}, defaultOptions, state.options, options2);
        state.scrollParents = {
          reference: isElement(reference2) ? listScrollParents(reference2) : reference2.contextElement ? listScrollParents(reference2.contextElement) : [],
          popper: listScrollParents(popper2)
        };
        var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers3, state.options.modifiers)));
        state.orderedModifiers = orderedModifiers.filter(function(m) {
          return m.enabled;
        });
        if (true) {
          var modifiers = uniqueBy([].concat(orderedModifiers, state.options.modifiers), function(_ref) {
            var name = _ref.name;
            return name;
          });
          validateModifiers(modifiers);
          if (getBasePlacement(state.options.placement) === auto) {
            var flipModifier = state.orderedModifiers.find(function(_ref2) {
              var name = _ref2.name;
              return name === "flip";
            });
            if (!flipModifier) {
              console.error(['Popper: "auto" placements require the "flip" modifier be', "present and enabled to work."].join(" "));
            }
          }
          var _getComputedStyle = getComputedStyle2(popper2), marginTop = _getComputedStyle.marginTop, marginRight = _getComputedStyle.marginRight, marginBottom = _getComputedStyle.marginBottom, marginLeft = _getComputedStyle.marginLeft;
          if ([marginTop, marginRight, marginBottom, marginLeft].some(function(margin) {
            return parseFloat(margin);
          })) {
            console.warn(['Popper: CSS "margin" styles cannot be used to apply padding', "between the popper and its reference element or boundary.", "To replicate margin, use the `offset` modifier, as well as", "the `padding` option in the `preventOverflow` and `flip`", "modifiers."].join(" "));
          }
        }
        runModifierEffects();
        return instance.update();
      },
      forceUpdate: function forceUpdate() {
        if (isDestroyed) {
          return;
        }
        var _state$elements = state.elements, reference3 = _state$elements.reference, popper3 = _state$elements.popper;
        if (!areValidElements(reference3, popper3)) {
          if (true) {
            console.error(INVALID_ELEMENT_ERROR);
          }
          return;
        }
        state.rects = {
          reference: getCompositeRect(reference3, getOffsetParent(popper3), state.options.strategy === "fixed"),
          popper: getLayoutRect(popper3)
        };
        state.reset = false;
        state.placement = state.options.placement;
        state.orderedModifiers.forEach(function(modifier) {
          return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
        });
        var __debug_loops__ = 0;
        for (var index2 = 0; index2 < state.orderedModifiers.length; index2++) {
          if (true) {
            __debug_loops__ += 1;
            if (__debug_loops__ > 100) {
              console.error(INFINITE_LOOP_ERROR);
              break;
            }
          }
          if (state.reset === true) {
            state.reset = false;
            index2 = -1;
            continue;
          }
          var _state$orderedModifie = state.orderedModifiers[index2], fn3 = _state$orderedModifie.fn, _state$orderedModifie2 = _state$orderedModifie.options, _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2, name = _state$orderedModifie.name;
          if (typeof fn3 === "function") {
            state = fn3({
              state,
              options: _options,
              name,
              instance
            }) || state;
          }
        }
      },
      update: debounce(function() {
        return new Promise(function(resolve) {
          instance.forceUpdate();
          resolve(state);
        });
      }),
      destroy: function destroy() {
        cleanupModifierEffects();
        isDestroyed = true;
      }
    };
    if (!areValidElements(reference2, popper2)) {
      if (true) {
        console.error(INVALID_ELEMENT_ERROR);
      }
      return instance;
    }
    instance.setOptions(options).then(function(state2) {
      if (!isDestroyed && options.onFirstUpdate) {
        options.onFirstUpdate(state2);
      }
    });
    function runModifierEffects() {
      state.orderedModifiers.forEach(function(_ref3) {
        var name = _ref3.name, _ref3$options = _ref3.options, options2 = _ref3$options === void 0 ? {} : _ref3$options, effect4 = _ref3.effect;
        if (typeof effect4 === "function") {
          var cleanupFn = effect4({
            state,
            name,
            instance,
            options: options2
          });
          var noopFn = function noopFn2() {
          };
          effectCleanupFns.push(cleanupFn || noopFn);
        }
      });
    }
    function cleanupModifierEffects() {
      effectCleanupFns.forEach(function(fn3) {
        return fn3();
      });
      effectCleanupFns = [];
    }
    return instance;
  };
}
var createPopper = popperGenerator();

// node_modules/@popperjs/core/lib/popper-lite.js
var defaultModifiers = [eventListeners_default, popperOffsets_default, computeStyles_default, applyStyles_default];
var createPopper2 = popperGenerator({
  defaultModifiers
});

// node_modules/@popperjs/core/lib/popper.js
var defaultModifiers2 = [eventListeners_default, popperOffsets_default, computeStyles_default, applyStyles_default, offset_default, flip_default, preventOverflow_default, arrow_default, hide_default];
var createPopper3 = popperGenerator({
  defaultModifiers: defaultModifiers2
});

// node_modules/element-plus/lib/index.esm.js
var import_throttle = __toModule(require_throttle());
var import_dayjs = __toModule(require_dayjs_min());
var import_localeData = __toModule(require_localeData());
var import_customParseFormat = __toModule(require_customParseFormat());
var import_union = __toModule(require_union());
var import_isEqual = __toModule(require_isEqual());
var import_advancedFormat = __toModule(require_advancedFormat());
var import_weekOfYear = __toModule(require_weekOfYear());
var import_weekYear = __toModule(require_weekYear());
var import_dayOfYear = __toModule(require_dayOfYear());
var import_isSameOrAfter = __toModule(require_isSameOrAfter());
var import_isSameOrBefore = __toModule(require_isSameOrBefore());

// node_modules/async-validator/dist-web/index.js
function _extends() {
  _extends = Object.assign || function(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;
  _setPrototypeOf(subClass, superClass);
}
function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf2(o2) {
    return o2.__proto__ || Object.getPrototypeOf(o2);
  };
  return _getPrototypeOf(o);
}
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf2(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
}
function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
}
function _construct(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct2(Parent2, args2, Class2) {
      var a = [null];
      a.push.apply(a, args2);
      var Constructor = Function.bind.apply(Parent2, a);
      var instance = new Constructor();
      if (Class2)
        _setPrototypeOf(instance, Class2.prototype);
      return instance;
    };
  }
  return _construct.apply(null, arguments);
}
function _isNativeFunction(fn3) {
  return Function.toString.call(fn3).indexOf("[native code]") !== -1;
}
function _wrapNativeSuper(Class) {
  var _cache = typeof Map === "function" ? new Map() : void 0;
  _wrapNativeSuper = function _wrapNativeSuper2(Class2) {
    if (Class2 === null || !_isNativeFunction(Class2))
      return Class2;
    if (typeof Class2 !== "function") {
      throw new TypeError("Super expression must either be null or a function");
    }
    if (typeof _cache !== "undefined") {
      if (_cache.has(Class2))
        return _cache.get(Class2);
      _cache.set(Class2, Wrapper);
    }
    function Wrapper() {
      return _construct(Class2, arguments, _getPrototypeOf(this).constructor);
    }
    Wrapper.prototype = Object.create(Class2.prototype, {
      constructor: {
        value: Wrapper,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    return _setPrototypeOf(Wrapper, Class2);
  };
  return _wrapNativeSuper(Class);
}
var formatRegExp = /%[sdj%]/g;
var warning = function warning2() {
};
if (typeof process !== "undefined" && process.env && true && typeof window !== "undefined" && typeof document !== "undefined") {
  warning = function warning3(type2, errors) {
    if (typeof console !== "undefined" && console.warn) {
      if (errors.every(function(e) {
        return typeof e === "string";
      })) {
        console.warn(type2, errors);
      }
    }
  };
}
function convertFieldsError(errors) {
  if (!errors || !errors.length)
    return null;
  var fields = {};
  errors.forEach(function(error) {
    var field = error.field;
    fields[field] = fields[field] || [];
    fields[field].push(error);
  });
  return fields;
}
function format2() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  var i = 1;
  var f = args[0];
  var len = args.length;
  if (typeof f === "function") {
    return f.apply(null, args.slice(1));
  }
  if (typeof f === "string") {
    var str = String(f).replace(formatRegExp, function(x) {
      if (x === "%%") {
        return "%";
      }
      if (i >= len) {
        return x;
      }
      switch (x) {
        case "%s":
          return String(args[i++]);
        case "%d":
          return Number(args[i++]);
        case "%j":
          try {
            return JSON.stringify(args[i++]);
          } catch (_) {
            return "[Circular]";
          }
          break;
        default:
          return x;
      }
    });
    return str;
  }
  return f;
}
function isNativeStringType(type2) {
  return type2 === "string" || type2 === "url" || type2 === "hex" || type2 === "email" || type2 === "date" || type2 === "pattern";
}
function isEmptyValue(value, type2) {
  if (value === void 0 || value === null) {
    return true;
  }
  if (type2 === "array" && Array.isArray(value) && !value.length) {
    return true;
  }
  if (isNativeStringType(type2) && typeof value === "string" && !value) {
    return true;
  }
  return false;
}
function asyncParallelArray(arr, func, callback) {
  var results = [];
  var total = 0;
  var arrLength = arr.length;
  function count(errors) {
    results.push.apply(results, errors);
    total++;
    if (total === arrLength) {
      callback(results);
    }
  }
  arr.forEach(function(a) {
    func(a, count);
  });
}
function asyncSerialArray(arr, func, callback) {
  var index2 = 0;
  var arrLength = arr.length;
  function next(errors) {
    if (errors && errors.length) {
      callback(errors);
      return;
    }
    var original = index2;
    index2 = index2 + 1;
    if (original < arrLength) {
      func(arr[original], next);
    } else {
      callback([]);
    }
  }
  next([]);
}
function flattenObjArr(objArr) {
  var ret = [];
  Object.keys(objArr).forEach(function(k) {
    ret.push.apply(ret, objArr[k]);
  });
  return ret;
}
var AsyncValidationError = function(_Error) {
  _inheritsLoose(AsyncValidationError2, _Error);
  function AsyncValidationError2(errors, fields) {
    var _this;
    _this = _Error.call(this, "Async Validation Error") || this;
    _this.errors = errors;
    _this.fields = fields;
    return _this;
  }
  return AsyncValidationError2;
}(_wrapNativeSuper(Error));
function asyncMap(objArr, option, func, callback) {
  if (option.first) {
    var _pending = new Promise(function(resolve, reject) {
      var next = function next2(errors) {
        callback(errors);
        return errors.length ? reject(new AsyncValidationError(errors, convertFieldsError(errors))) : resolve();
      };
      var flattenArr = flattenObjArr(objArr);
      asyncSerialArray(flattenArr, func, next);
    });
    _pending["catch"](function(e) {
      return e;
    });
    return _pending;
  }
  var firstFields = option.firstFields || [];
  if (firstFields === true) {
    firstFields = Object.keys(objArr);
  }
  var objArrKeys = Object.keys(objArr);
  var objArrLength = objArrKeys.length;
  var total = 0;
  var results = [];
  var pending = new Promise(function(resolve, reject) {
    var next = function next2(errors) {
      results.push.apply(results, errors);
      total++;
      if (total === objArrLength) {
        callback(results);
        return results.length ? reject(new AsyncValidationError(results, convertFieldsError(results))) : resolve();
      }
    };
    if (!objArrKeys.length) {
      callback(results);
      resolve();
    }
    objArrKeys.forEach(function(key) {
      var arr = objArr[key];
      if (firstFields.indexOf(key) !== -1) {
        asyncSerialArray(arr, func, next);
      } else {
        asyncParallelArray(arr, func, next);
      }
    });
  });
  pending["catch"](function(e) {
    return e;
  });
  return pending;
}
function complementError(rule) {
  return function(oe2) {
    if (oe2 && oe2.message) {
      oe2.field = oe2.field || rule.fullField;
      return oe2;
    }
    return {
      message: typeof oe2 === "function" ? oe2() : oe2,
      field: oe2.field || rule.fullField
    };
  };
}
function deepMerge(target, source) {
  if (source) {
    for (var s in source) {
      if (source.hasOwnProperty(s)) {
        var value = source[s];
        if (typeof value === "object" && typeof target[s] === "object") {
          target[s] = _extends({}, target[s], value);
        } else {
          target[s] = value;
        }
      }
    }
  }
  return target;
}
function required(rule, value, source, errors, options, type2) {
  if (rule.required && (!source.hasOwnProperty(rule.field) || isEmptyValue(value, type2 || rule.type))) {
    errors.push(format2(options.messages.required, rule.fullField));
  }
}
function whitespace(rule, value, source, errors, options) {
  if (/^\s+$/.test(value) || value === "") {
    errors.push(format2(options.messages.whitespace, rule.fullField));
  }
}
var pattern = {
  email: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  url: new RegExp("^(?!mailto:)(?:(?:http|https|ftp)://|//)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$", "i"),
  hex: /^#?([a-f0-9]{6}|[a-f0-9]{3})$/i
};
var types = {
  integer: function integer(value) {
    return types.number(value) && parseInt(value, 10) === value;
  },
  "float": function float(value) {
    return types.number(value) && !types.integer(value);
  },
  array: function array(value) {
    return Array.isArray(value);
  },
  regexp: function regexp(value) {
    if (value instanceof RegExp) {
      return true;
    }
    try {
      return !!new RegExp(value);
    } catch (e) {
      return false;
    }
  },
  date: function date(value) {
    return typeof value.getTime === "function" && typeof value.getMonth === "function" && typeof value.getYear === "function" && !isNaN(value.getTime());
  },
  number: function number(value) {
    if (isNaN(value)) {
      return false;
    }
    return typeof value === "number";
  },
  object: function object(value) {
    return typeof value === "object" && !types.array(value);
  },
  method: function method(value) {
    return typeof value === "function";
  },
  email: function email(value) {
    return typeof value === "string" && !!value.match(pattern.email) && value.length < 255;
  },
  url: function url(value) {
    return typeof value === "string" && !!value.match(pattern.url);
  },
  hex: function hex(value) {
    return typeof value === "string" && !!value.match(pattern.hex);
  }
};
function type(rule, value, source, errors, options) {
  if (rule.required && value === void 0) {
    required(rule, value, source, errors, options);
    return;
  }
  var custom = ["integer", "float", "array", "regexp", "object", "method", "email", "number", "date", "url", "hex"];
  var ruleType = rule.type;
  if (custom.indexOf(ruleType) > -1) {
    if (!types[ruleType](value)) {
      errors.push(format2(options.messages.types[ruleType], rule.fullField, rule.type));
    }
  } else if (ruleType && typeof value !== rule.type) {
    errors.push(format2(options.messages.types[ruleType], rule.fullField, rule.type));
  }
}
function range(rule, value, source, errors, options) {
  var len = typeof rule.len === "number";
  var min2 = typeof rule.min === "number";
  var max2 = typeof rule.max === "number";
  var spRegexp = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g;
  var val = value;
  var key = null;
  var num = typeof value === "number";
  var str = typeof value === "string";
  var arr = Array.isArray(value);
  if (num) {
    key = "number";
  } else if (str) {
    key = "string";
  } else if (arr) {
    key = "array";
  }
  if (!key) {
    return false;
  }
  if (arr) {
    val = value.length;
  }
  if (str) {
    val = value.replace(spRegexp, "_").length;
  }
  if (len) {
    if (val !== rule.len) {
      errors.push(format2(options.messages[key].len, rule.fullField, rule.len));
    }
  } else if (min2 && !max2 && val < rule.min) {
    errors.push(format2(options.messages[key].min, rule.fullField, rule.min));
  } else if (max2 && !min2 && val > rule.max) {
    errors.push(format2(options.messages[key].max, rule.fullField, rule.max));
  } else if (min2 && max2 && (val < rule.min || val > rule.max)) {
    errors.push(format2(options.messages[key].range, rule.fullField, rule.min, rule.max));
  }
}
var ENUM = "enum";
function enumerable(rule, value, source, errors, options) {
  rule[ENUM] = Array.isArray(rule[ENUM]) ? rule[ENUM] : [];
  if (rule[ENUM].indexOf(value) === -1) {
    errors.push(format2(options.messages[ENUM], rule.fullField, rule[ENUM].join(", ")));
  }
}
function pattern$1(rule, value, source, errors, options) {
  if (rule.pattern) {
    if (rule.pattern instanceof RegExp) {
      rule.pattern.lastIndex = 0;
      if (!rule.pattern.test(value)) {
        errors.push(format2(options.messages.pattern.mismatch, rule.fullField, value, rule.pattern));
      }
    } else if (typeof rule.pattern === "string") {
      var _pattern = new RegExp(rule.pattern);
      if (!_pattern.test(value)) {
        errors.push(format2(options.messages.pattern.mismatch, rule.fullField, value, rule.pattern));
      }
    }
  }
}
var rules = {
  required,
  whitespace,
  type,
  range,
  "enum": enumerable,
  pattern: pattern$1
};
function string(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value, "string") && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options, "string");
    if (!isEmptyValue(value, "string")) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
      rules.pattern(rule, value, source, errors, options);
      if (rule.whitespace === true) {
        rules.whitespace(rule, value, source, errors, options);
      }
    }
  }
  callback(errors);
}
function method2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function number2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (value === "") {
      value = void 0;
    }
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function _boolean(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function regexp2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (!isEmptyValue(value)) {
      rules.type(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function integer2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function floatFn(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function array2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if ((value === void 0 || value === null) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options, "array");
    if (value !== void 0 && value !== null) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function object2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules.type(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
var ENUM$1 = "enum";
function enumerable$1(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (value !== void 0) {
      rules[ENUM$1](rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function pattern$2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value, "string") && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (!isEmptyValue(value, "string")) {
      rules.pattern(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function date2(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value, "date") && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
    if (!isEmptyValue(value, "date")) {
      var dateObject;
      if (value instanceof Date) {
        dateObject = value;
      } else {
        dateObject = new Date(value);
      }
      rules.type(rule, dateObject, source, errors, options);
      if (dateObject) {
        rules.range(rule, dateObject.getTime(), source, errors, options);
      }
    }
  }
  callback(errors);
}
function required$1(rule, value, callback, source, options) {
  var errors = [];
  var type2 = Array.isArray(value) ? "array" : typeof value;
  rules.required(rule, value, source, errors, options, type2);
  callback(errors);
}
function type$1(rule, value, callback, source, options) {
  var ruleType = rule.type;
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value, ruleType) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options, ruleType);
    if (!isEmptyValue(value, ruleType)) {
      rules.type(rule, value, source, errors, options);
    }
  }
  callback(errors);
}
function any(rule, value, callback, source, options) {
  var errors = [];
  var validate2 = rule.required || !rule.required && source.hasOwnProperty(rule.field);
  if (validate2) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }
    rules.required(rule, value, source, errors, options);
  }
  callback(errors);
}
var validators = {
  string,
  method: method2,
  number: number2,
  "boolean": _boolean,
  regexp: regexp2,
  integer: integer2,
  "float": floatFn,
  array: array2,
  object: object2,
  "enum": enumerable$1,
  pattern: pattern$2,
  date: date2,
  url: type$1,
  hex: type$1,
  email: type$1,
  required: required$1,
  any
};
function newMessages() {
  return {
    "default": "Validation error on field %s",
    required: "%s is required",
    "enum": "%s must be one of %s",
    whitespace: "%s cannot be empty",
    date: {
      format: "%s date %s is invalid for format %s",
      parse: "%s date could not be parsed, %s is invalid ",
      invalid: "%s date %s is invalid"
    },
    types: {
      string: "%s is not a %s",
      method: "%s is not a %s (function)",
      array: "%s is not an %s",
      object: "%s is not an %s",
      number: "%s is not a %s",
      date: "%s is not a %s",
      "boolean": "%s is not a %s",
      integer: "%s is not an %s",
      "float": "%s is not a %s",
      regexp: "%s is not a valid %s",
      email: "%s is not a valid %s",
      url: "%s is not a valid %s",
      hex: "%s is not a valid %s"
    },
    string: {
      len: "%s must be exactly %s characters",
      min: "%s must be at least %s characters",
      max: "%s cannot be longer than %s characters",
      range: "%s must be between %s and %s characters"
    },
    number: {
      len: "%s must equal %s",
      min: "%s cannot be less than %s",
      max: "%s cannot be greater than %s",
      range: "%s must be between %s and %s"
    },
    array: {
      len: "%s must be exactly %s in length",
      min: "%s cannot be less than %s in length",
      max: "%s cannot be greater than %s in length",
      range: "%s must be between %s and %s in length"
    },
    pattern: {
      mismatch: "%s value %s does not match pattern %s"
    },
    clone: function clone() {
      var cloned = JSON.parse(JSON.stringify(this));
      cloned.clone = this.clone;
      return cloned;
    }
  };
}
var messages = newMessages();
function Schema(descriptor) {
  this.rules = null;
  this._messages = messages;
  this.define(descriptor);
}
Schema.prototype = {
  messages: function messages2(_messages) {
    if (_messages) {
      this._messages = deepMerge(newMessages(), _messages);
    }
    return this._messages;
  },
  define: function define2(rules2) {
    if (!rules2) {
      throw new Error("Cannot configure a schema with no rules");
    }
    if (typeof rules2 !== "object" || Array.isArray(rules2)) {
      throw new Error("Rules must be an object");
    }
    this.rules = {};
    var z;
    var item;
    for (z in rules2) {
      if (rules2.hasOwnProperty(z)) {
        item = rules2[z];
        this.rules[z] = Array.isArray(item) ? item : [item];
      }
    }
  },
  validate: function validate(source_, o, oc2) {
    var _this = this;
    if (o === void 0) {
      o = {};
    }
    if (oc2 === void 0) {
      oc2 = function oc3() {
      };
    }
    var source = source_;
    var options = o;
    var callback = oc2;
    if (typeof options === "function") {
      callback = options;
      options = {};
    }
    if (!this.rules || Object.keys(this.rules).length === 0) {
      if (callback) {
        callback();
      }
      return Promise.resolve();
    }
    function complete(results) {
      var i;
      var errors = [];
      var fields = {};
      function add(e) {
        if (Array.isArray(e)) {
          var _errors;
          errors = (_errors = errors).concat.apply(_errors, e);
        } else {
          errors.push(e);
        }
      }
      for (i = 0; i < results.length; i++) {
        add(results[i]);
      }
      if (!errors.length) {
        errors = null;
        fields = null;
      } else {
        fields = convertFieldsError(errors);
      }
      callback(errors, fields);
    }
    if (options.messages) {
      var messages$1 = this.messages();
      if (messages$1 === messages) {
        messages$1 = newMessages();
      }
      deepMerge(messages$1, options.messages);
      options.messages = messages$1;
    } else {
      options.messages = this.messages();
    }
    var arr;
    var value;
    var series = {};
    var keys = options.keys || Object.keys(this.rules);
    keys.forEach(function(z) {
      arr = _this.rules[z];
      value = source[z];
      arr.forEach(function(r) {
        var rule = r;
        if (typeof rule.transform === "function") {
          if (source === source_) {
            source = _extends({}, source);
          }
          value = source[z] = rule.transform(value);
        }
        if (typeof rule === "function") {
          rule = {
            validator: rule
          };
        } else {
          rule = _extends({}, rule);
        }
        rule.validator = _this.getValidationMethod(rule);
        rule.field = z;
        rule.fullField = rule.fullField || z;
        rule.type = _this.getType(rule);
        if (!rule.validator) {
          return;
        }
        series[z] = series[z] || [];
        series[z].push({
          rule,
          value,
          source,
          field: z
        });
      });
    });
    var errorFields = {};
    return asyncMap(series, options, function(data, doIt) {
      var rule = data.rule;
      var deep = (rule.type === "object" || rule.type === "array") && (typeof rule.fields === "object" || typeof rule.defaultField === "object");
      deep = deep && (rule.required || !rule.required && data.value);
      rule.field = data.field;
      function addFullfield(key, schema) {
        return _extends({}, schema, {
          fullField: rule.fullField + "." + key
        });
      }
      function cb(e) {
        if (e === void 0) {
          e = [];
        }
        var errors = e;
        if (!Array.isArray(errors)) {
          errors = [errors];
        }
        if (!options.suppressWarning && errors.length) {
          Schema.warning("async-validator:", errors);
        }
        if (errors.length && rule.message !== void 0) {
          errors = [].concat(rule.message);
        }
        errors = errors.map(complementError(rule));
        if (options.first && errors.length) {
          errorFields[rule.field] = 1;
          return doIt(errors);
        }
        if (!deep) {
          doIt(errors);
        } else {
          if (rule.required && !data.value) {
            if (rule.message !== void 0) {
              errors = [].concat(rule.message).map(complementError(rule));
            } else if (options.error) {
              errors = [options.error(rule, format2(options.messages.required, rule.field))];
            }
            return doIt(errors);
          }
          var fieldsSchema = {};
          if (rule.defaultField) {
            for (var k in data.value) {
              if (data.value.hasOwnProperty(k)) {
                fieldsSchema[k] = rule.defaultField;
              }
            }
          }
          fieldsSchema = _extends({}, fieldsSchema, data.rule.fields);
          for (var f in fieldsSchema) {
            if (fieldsSchema.hasOwnProperty(f)) {
              var fieldSchema = Array.isArray(fieldsSchema[f]) ? fieldsSchema[f] : [fieldsSchema[f]];
              fieldsSchema[f] = fieldSchema.map(addFullfield.bind(null, f));
            }
          }
          var schema = new Schema(fieldsSchema);
          schema.messages(options.messages);
          if (data.rule.options) {
            data.rule.options.messages = options.messages;
            data.rule.options.error = options.error;
          }
          schema.validate(data.value, data.rule.options || options, function(errs) {
            var finalErrors = [];
            if (errors && errors.length) {
              finalErrors.push.apply(finalErrors, errors);
            }
            if (errs && errs.length) {
              finalErrors.push.apply(finalErrors, errs);
            }
            doIt(finalErrors.length ? finalErrors : null);
          });
        }
      }
      var res;
      if (rule.asyncValidator) {
        res = rule.asyncValidator(rule, data.value, cb, data.source, options);
      } else if (rule.validator) {
        res = rule.validator(rule, data.value, cb, data.source, options);
        if (res === true) {
          cb();
        } else if (res === false) {
          cb(rule.message || rule.field + " fails");
        } else if (res instanceof Array) {
          cb(res);
        } else if (res instanceof Error) {
          cb(res.message);
        }
      }
      if (res && res.then) {
        res.then(function() {
          return cb();
        }, function(e) {
          return cb(e);
        });
      }
    }, function(results) {
      complete(results);
    });
  },
  getType: function getType(rule) {
    if (rule.type === void 0 && rule.pattern instanceof RegExp) {
      rule.type = "pattern";
    }
    if (typeof rule.validator !== "function" && rule.type && !validators.hasOwnProperty(rule.type)) {
      throw new Error(format2("Unknown rule type %s", rule.type));
    }
    return rule.type || "string";
  },
  getValidationMethod: function getValidationMethod(rule) {
    if (typeof rule.validator === "function") {
      return rule.validator;
    }
    var keys = Object.keys(rule);
    var messageIndex = keys.indexOf("message");
    if (messageIndex !== -1) {
      keys.splice(messageIndex, 1);
    }
    if (keys.length === 1 && keys[0] === "required") {
      return validators.required;
    }
    return validators[this.getType(rule)] || false;
  }
};
Schema.register = function register(type2, validator) {
  if (typeof validator !== "function") {
    throw new Error("Cannot register a validator by type, validator is not a function");
  }
  validators[type2] = validator;
};
Schema.warning = warning;
Schema.messages = messages;
Schema.validators = validators;
var dist_web_default = Schema;

// node_modules/element-plus/lib/index.esm.js
var import_cloneDeep = __toModule(require_cloneDeep());
var import_memoize = __toModule(require_memoize());
var ke = typeof window == "undefined";
Object.freeze({}), Object.freeze([]);
var xe = () => {
};
var Ce = Object.assign;
var we = Object.prototype.hasOwnProperty;
var Se = (e, t) => we.call(e, t);
var _e = Array.isArray;
var Ee = (e) => typeof e == "function";
var Me = (e) => typeof e == "string";
var Te = (e) => e !== null && typeof e == "object";
var Ie = (e) => Te(e) && Ee(e.then) && Ee(e.catch);
var Oe = Object.prototype.toString;
var Ne = (e) => Oe.call(e);
var De = (e) => Ne(e).slice(8, -1);
var Ve = (e) => {
  const t = Object.create(null);
  return (l) => t[l] || (t[l] = e(l));
};
var Be = /-(\w)/g;
var Pe = Ve((e) => e.replace(Be, (e2, t) => t ? t.toUpperCase() : ""));
var Ae = Ve((e) => e.charAt(0).toUpperCase() + e.slice(1));
var ze = class extends Error {
  constructor(e) {
    super(e), this.name = "ElementPlusError";
  }
};
var Le = (e, t) => {
  throw new ze(`[${e}] ${t}`);
};
function Fe(e, t) {
  console.warn(new ze(`[${e}] ${t}`));
}
var Re = (e, t = "") => {
  let l = e;
  return t.split(".").map((e2) => {
    l = l == null ? void 0 : l[e2];
  }), l;
};
function $e(e, t, l) {
  let a = e;
  const n = (t = (t = t.replace(/\[(\w+)\]/g, ".$1")).replace(/^\./, "")).split(".");
  let o = 0;
  for (; o < n.length - 1 && (a || l); o++) {
    const e2 = n[o];
    if (!(e2 in a)) {
      if (l)
        throw new Error("please transfer a valid prop path to form item!");
      break;
    }
    a = a[e2];
  }
  return { o: a, k: n[o], v: a == null ? void 0 : a[n[o]] };
}
var He = () => Math.floor(1e4 * Math.random());
var We = (e) => e || e === 0 ? Array.isArray(e) ? e : [e] : [];
var je = (e) => typeof e == "boolean";
var Ke = (e) => typeof e == "number";
function Ye(e) {
  let t = false;
  return function(...l) {
    t || (t = true, window.requestAnimationFrame(() => {
      e.apply(this, l), t = false;
    }));
  };
}
var qe = (e) => {
  clearTimeout(e.value), e.value = null;
};
function Ue(e) {
  return Object.keys(e).map((t) => [t, e[t]]);
}
function Ge(e) {
  return e === void 0;
}
function Xe() {
  const t = getCurrentInstance();
  return "$ELEMENT" in t.proxy ? t.proxy.$ELEMENT : {};
}
var Ze = function(e, t) {
  return e.find(t);
};
function Qe(e) {
  return !!(!e && e !== 0 || _e(e) && !e.length || Te(e) && !Object.keys(e).length);
}
function Je(e) {
  return e.reduce((e2, t) => {
    const l = Array.isArray(t) ? Je(t) : t;
    return e2.concat(l);
  }, []);
}
function et(e) {
  return Array.from(new Set(e));
}
function tt(e) {
  return e.value;
}
function lt(e) {
  return Me(e) ? e : Ke(e) ? e + "px" : (Fe("Util", "binding value must be a string or number"), "");
}
var at = function(e, t, l, a = false) {
  e && t && l && e.addEventListener(t, l, a);
};
var nt = function(e, t, l, a = false) {
  e && t && l && e.removeEventListener(t, l, a);
};
function ot(e, t) {
  if (!e || !t)
    return false;
  if (t.indexOf(" ") !== -1)
    throw new Error("className should not contain space.");
  return e.classList ? e.classList.contains(t) : (" " + e.className + " ").indexOf(" " + t + " ") > -1;
}
function it(e, t) {
  if (!e)
    return;
  let l = e.className;
  const a = (t || "").split(" ");
  for (let t2 = 0, n = a.length; t2 < n; t2++) {
    const n2 = a[t2];
    n2 && (e.classList ? e.classList.add(n2) : ot(e, n2) || (l += " " + n2));
  }
  e.classList || (e.className = l);
}
function rt(e, t) {
  if (!e || !t)
    return;
  const l = t.split(" ");
  let a = " " + e.className + " ";
  for (let t2 = 0, n = l.length; t2 < n; t2++) {
    const n2 = l[t2];
    n2 && (e.classList ? e.classList.remove(n2) : ot(e, n2) && (a = a.replace(" " + n2 + " ", " ")));
  }
  e.classList || (e.className = (a || "").replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g, ""));
}
var st = function(e, t) {
  if (!ke) {
    if (!e || !t)
      return null;
    (t = Pe(t)) === "float" && (t = "cssFloat");
    try {
      const l = e.style[t];
      if (l)
        return l;
      const a = document.defaultView.getComputedStyle(e, "");
      return a ? a[t] : "";
    } catch (l) {
      return e.style[t];
    }
  }
};
var ut = (e, t) => {
  if (ke)
    return;
  return st(e, t == null ? "overflow" : t ? "overflow-y" : "overflow-x").match(/(scroll|auto)/);
};
var dt = (e, t) => {
  if (ke)
    return;
  let l = e;
  for (; l; ) {
    if ([window, document, document.documentElement].includes(l))
      return window;
    if (ut(l, t))
      return l;
    l = l.parentNode;
  }
  return l;
};
var ct = (e) => {
  let t = 0, l = e;
  for (; l; )
    t += l.offsetTop, l = l.offsetParent;
  return t;
};
var pt = (e) => e.stopPropagation();
var ht = function(e) {
  for (const t of e) {
    const e2 = t.target.__resizeListeners__ || [];
    e2.length && e2.forEach((e3) => {
      e3();
    });
  }
};
var vt = function(e, t) {
  !ke && e && (e.__resizeListeners__ || (e.__resizeListeners__ = [], e.__ro__ = new ResizeObserver_es_default(ht), e.__ro__.observe(e)), e.__resizeListeners__.push(t));
};
var mt = function(e, t) {
  e && e.__resizeListeners__ && (e.__resizeListeners__.splice(e.__resizeListeners__.indexOf(t), 1), e.__resizeListeners__.length || e.__ro__.disconnect());
};
var ft = defineComponent({ name: "ElAffix", props: { zIndex: { type: Number, default: 100 }, target: { type: String, default: "" }, offset: { type: Number, default: 0 }, position: { type: String, default: "top" } }, emits: ["scroll", "change"], setup(e, { emit: t }) {
  const s = ref(null), u = ref(null), d = ref(null), c = reactive({ fixed: false, height: 0, width: 0, scrollTop: 0, clientHeight: 0, transform: 0 }), p = computed(() => ({ height: c.fixed ? c.height + "px" : "", width: c.fixed ? c.width + "px" : "" })), h2 = computed(() => {
    if (!c.fixed)
      return;
    const t2 = e.offset ? e.offset + "px" : 0, l = c.transform ? `translateY(${c.transform}px)` : "";
    return { height: c.height + "px", width: c.width + "px", top: e.position === "top" ? t2 : "", bottom: e.position === "bottom" ? t2 : "", transform: l, zIndex: e.zIndex };
  }), v = () => {
    const t2 = u.value.getBoundingClientRect(), l = s.value.getBoundingClientRect();
    if (c.height = t2.height, c.width = t2.width, c.scrollTop = d.value === window ? document.documentElement.scrollTop : d.value.scrollTop, c.clientHeight = document.documentElement.clientHeight, e.position === "top")
      if (e.target) {
        const a = l.bottom - e.offset - c.height;
        c.fixed = e.offset > t2.top && l.bottom > 0, c.transform = a < 0 ? a : 0;
      } else
        c.fixed = e.offset > t2.top;
    else if (e.target) {
      const a = c.clientHeight - l.top - e.offset - c.height;
      c.fixed = c.clientHeight - e.offset < t2.bottom && c.clientHeight > l.top, c.transform = a < 0 ? -a : 0;
    } else
      c.fixed = c.clientHeight - e.offset < t2.bottom;
  }, m = () => {
    v(), t("scroll", { scrollTop: c.scrollTop, fixed: c.fixed });
  };
  return watch(() => c.fixed, () => {
    t("change", c.fixed);
  }), onMounted(() => {
    if (e.target) {
      if (s.value = document.querySelector(e.target), !s.value)
        throw new Error("target is not existed: " + e.target);
    } else
      s.value = document.documentElement;
    d.value = dt(u.value), at(d.value, "scroll", m), vt(u.value, v);
  }), onBeforeUnmount(() => {
    nt(d.value, "scroll", m), mt(u.value, v);
  }), { root: u, state: c, rootStyle: p, affixStyle: h2 };
} });
ft.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { ref: "root", class: "el-affix", style: e.rootStyle }, [createVNode("div", { class: { "el-affix--fixed": e.state.fixed }, style: e.affixStyle }, [renderSlot(e.$slots, "default")], 6)], 4);
}, ft.__file = "packages/affix/src/index.vue", ft.install = (e) => {
  e.component(ft.name, ft);
};
var gt = ft;
var bt = { success: "el-icon-success", warning: "el-icon-warning", error: "el-icon-error" };
var yt = defineComponent({ name: "ElAlert", props: { title: { type: String, default: "" }, description: { type: String, default: "" }, type: { type: String, default: "info" }, closable: { type: Boolean, default: true }, closeText: { type: String, default: "" }, showIcon: Boolean, center: Boolean, effect: { type: String, default: "light", validator: (e) => ["light", "dark"].indexOf(e) > -1 } }, emits: ["close"], setup(e, t) {
  const a = ref(true), o = computed(() => "el-alert--" + e.type), i = computed(() => bt[e.type] || "el-icon-info"), r = computed(() => e.description || t.slots.default ? "is-big" : ""), s = computed(() => e.description || t.slots.default ? "is-bold" : "");
  return { visible: a, typeClass: o, iconClass: i, isBigIcon: r, isBoldTitle: s, close: (e2) => {
    a.value = false, t.emit("close", e2);
  } };
} });
var kt = { class: "el-alert__content" };
var xt = { key: 1, class: "el-alert__description" };
yt.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "el-alert-fade" }, { default: withCtx(() => [withDirectives(createVNode("div", { class: ["el-alert", [e.typeClass, e.center ? "is-center" : "", "is-" + e.effect]], role: "alert" }, [e.showIcon ? (openBlock(), createBlock("i", { key: 0, class: ["el-alert__icon", [e.iconClass, e.isBigIcon]] }, null, 2)) : createCommentVNode("v-if", true), createVNode("div", kt, [e.title || e.$slots.title ? (openBlock(), createBlock("span", { key: 0, class: ["el-alert__title", [e.isBoldTitle]] }, [renderSlot(e.$slots, "title", {}, () => [createTextVNode(toDisplayString(e.title), 1)])], 2)) : createCommentVNode("v-if", true), e.$slots.default || e.description ? (openBlock(), createBlock("p", xt, [renderSlot(e.$slots, "default", {}, () => [createTextVNode(toDisplayString(e.description), 1)])])) : createCommentVNode("v-if", true), e.closable ? (openBlock(), createBlock("i", { key: 2, class: ["el-alert__closebtn", { "is-customed": e.closeText !== "", "el-icon-close": e.closeText === "" }], onClick: t[1] || (t[1] = (...t2) => e.close && e.close(...t2)) }, toDisplayString(e.closeText), 3)) : createCommentVNode("v-if", true)])], 2), [[vShow, e.visible]])]), _: 3 });
}, yt.__file = "packages/alert/src/index.vue", yt.install = (e) => {
  e.component(yt.name, yt);
};
var Ct = yt;
var wt = defineComponent({ name: "ElAside", props: { width: { type: String, default: "300px" } } });
wt.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("aside", { class: "el-aside", style: { width: e.width } }, [renderSlot(e.$slots, "default")], 4);
}, wt.__file = "packages/container/src/aside.vue", wt.install = (e) => {
  e.component(wt.name, wt);
};
var St = wt;
var _t = ["class", "style"];
var Et = /^on[A-Z]/;
var Mt = (t = {}) => {
  const { excludeListeners: l = false, excludeKeys: n = [] } = t, o = getCurrentInstance(), i = shallowRef({}), r = n.concat(_t);
  return o.attrs = reactive(o.attrs), watchEffect(() => {
    const e = Ue(o.attrs).reduce((e2, [t2, a]) => (r.includes(t2) || l && Et.test(t2) || (e2[t2] = a), e2), {});
    i.value = e;
  }), i;
};
var Tt;
function It() {
  if (ke)
    return 0;
  if (Tt !== void 0)
    return Tt;
  const e = document.createElement("div");
  e.className = "el-scrollbar__wrap", e.style.visibility = "hidden", e.style.width = "100px", e.style.position = "absolute", e.style.top = "-9999px", document.body.appendChild(e);
  const t = e.offsetWidth;
  e.style.overflow = "scroll";
  const l = document.createElement("div");
  l.style.width = "100%", e.appendChild(l);
  const a = l.offsetWidth;
  return e.parentNode.removeChild(e), Tt = t - a, Tt;
}
var Ot = (e) => {
  isRef(e) || Le("[useLockScreen]", "You need to pass a ref param to this function");
  let t = 0, l = false, a = "0", n = 0;
  onUnmounted(() => {
    i();
  });
  const i = () => {
    rt(document.body, "el-popup-parent--hidden"), l && (document.body.style.paddingRight = a);
  };
  watch(e, (e2) => {
    if (e2) {
      l = !ot(document.body, "el-popup-parent--hidden"), l && (a = document.body.style.paddingRight, n = parseInt(st(document.body, "paddingRight"), 10)), t = It();
      const e3 = document.documentElement.clientHeight < document.body.scrollHeight, o = st(document.body, "overflowY");
      t > 0 && (e3 || o === "scroll") && l && (document.body.style.paddingRight = n + t + "px"), it(document.body, "el-popup-parent--hidden");
    } else
      i();
  });
};
var Nt = (e, t) => {
  let l;
  watch(() => e.value, (e2) => {
    var a, n;
    e2 ? (l = document.activeElement, isRef(t) && ((n = (a = t.value).focus) === null || n === void 0 || n.call(a))) : false ? l.focus.call(l) : l.focus();
  });
};
var Dt = { tab: "Tab", enter: "Enter", space: "Space", left: "ArrowLeft", up: "ArrowUp", right: "ArrowRight", down: "ArrowDown", esc: "Escape", delete: "Delete", backspace: "Backspace" };
var Vt = (e) => {
  if (false)
    return true;
  return getComputedStyle(e).position !== "fixed" && e.offsetParent !== null;
};
var Bt = (e) => Array.from(e.querySelectorAll('a[href],button:not([disabled]),button:not([hidden]),:not([tabindex="-1"]),input:not([disabled]),input:not([type="hidden"]),select:not([disabled]),textarea:not([disabled])')).filter(Pt).filter(Vt);
var Pt = (e) => {
  if (e.tabIndex > 0 || e.tabIndex === 0 && e.getAttribute("tabIndex") !== null)
    return true;
  if (e.disabled)
    return false;
  switch (e.nodeName) {
    case "A":
      return !!e.href && e.rel !== "ignore";
    case "INPUT":
      return !(e.type === "hidden" || e.type === "file");
    case "BUTTON":
    case "SELECT":
    case "TEXTAREA":
      return true;
    default:
      return false;
  }
};
var At = function(e, t, ...l) {
  let a;
  a = t.includes("mouse") || t.includes("click") ? "MouseEvents" : t.includes("key") ? "KeyboardEvent" : "HTMLEvents";
  const n = document.createEvent(a);
  return n.initEvent(t, ...l), e.dispatchEvent(n), e;
};
var zt = [];
var Lt = (e, t) => {
  watch(() => t.value, (t2) => {
    t2 ? zt.push(e) : zt.splice(zt.findIndex((t3) => t3 === e), 1);
  });
};
ke || at(document, "keydown", (e) => {
  if (zt.length !== 0 && e.code === Dt.esc) {
    e.stopPropagation();
    zt[zt.length - 1].handleClose();
  }
});
var Ft = new Map();
var Rt;
function $t(e, t) {
  let l = [];
  return Array.isArray(t.arg) ? l = t.arg : l.push(t.arg), function(a, n) {
    const o = t.instance.popperRef, i = a.target, r = n == null ? void 0 : n.target, s = !t || !t.instance, u = !i || !r, d = e.contains(i) || e.contains(r), c = e === i, p = l.length && l.some((e2) => e2 == null ? void 0 : e2.contains(i)) || l.length && l.includes(r), h2 = o && (o.contains(i) || o.contains(r));
    s || u || d || c || p || h2 || t.value(a, n);
  };
}
ke || (at(document, "mousedown", (e) => Rt = e), at(document, "mouseup", (e) => {
  for (const { documentHandler: t } of Ft.values())
    t(e, Rt);
}));
var Ht = { beforeMount(e, t) {
  Ft.set(e, { documentHandler: $t(e, t), bindingFn: t.value });
}, updated(e, t) {
  Ft.set(e, { documentHandler: $t(e, t), bindingFn: t.value });
}, unmounted(e) {
  Ft.delete(e);
} };
var Wt = { beforeMount(e, t) {
  let l, a = null;
  const n = () => t.value && t.value(), o = () => {
    Date.now() - l < 100 && n(), clearInterval(a), a = null;
  };
  at(e, "mousedown", (e2) => {
    e2.button === 0 && (l = Date.now(), function(e3, t2, l2) {
      const a2 = function(...n2) {
        l2 && l2.apply(this, n2), nt(e3, t2, a2);
      };
      at(e3, t2, a2);
    }(document, "mouseup", o), clearInterval(a), a = setInterval(n, 100));
  });
} };
var jt = [];
var Kt = (e) => {
  var t;
  if (jt.length === 0)
    return;
  const l = jt[jt.length - 1]["_trap-focus-children"];
  if (l.length > 0 && e.code === Dt.tab) {
    if (l.length === 1)
      return e.preventDefault(), void (document.activeElement !== l[0] && l[0].focus());
    const a = e.shiftKey, n = e.target === l[0], o = e.target === l[l.length - 1];
    if (n && a && (e.preventDefault(), l[l.length - 1].focus()), o && !a && (e.preventDefault(), l[0].focus()), false) {
      const n2 = l.findIndex((t2) => t2 === e.target);
      n2 !== -1 && ((t = l[a ? n2 - 1 : n2 + 1]) === null || t === void 0 || t.focus());
    }
  }
};
var Yt = { beforeMount(e) {
  e["_trap-focus-children"] = Bt(e), jt.push(e), jt.length <= 1 && at(document, "keydown", Kt);
}, updated(e) {
  nextTick(() => {
    e["_trap-focus-children"] = Bt(e);
  });
}, unmounted() {
  jt.shift(), jt.length === 0 && nt(document, "keydown", Kt);
} };
var qt = typeof navigator != "undefined" && navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
var Ut = { beforeMount(e, t) {
  !function(e2, t2) {
    if (e2 && e2.addEventListener) {
      const l = function(e3) {
        const l2 = (0, import_normalize_wheel.default)(e3);
        t2 && t2.apply(this, [e3, l2]);
      };
      qt ? e2.addEventListener("DOMMouseScroll", l) : e2.onmousewheel = l;
    }
  }(e, t.value);
} };
var Gt = "update:modelValue";
var Xt = { validating: "el-icon-loading", success: "el-icon-circle-check", error: "el-icon-circle-close" };
function Zt(e) {
  return /([(\uAC00-\uD7AF)|(\u3130-\u318F)])+/gi.test(e);
}
var Qt = (e) => ["", "large", "medium", "small", "mini"].includes(e);
var Jt = (e) => ["year", "month", "date", "dates", "week", "datetime", "datetimerange", "daterange", "monthrange"].includes(e);
var el = "el.form.addField";
var tl = "el.form.removeField";
var ll = defineComponent({ name: "ElForm", props: { model: Object, rules: Object, labelPosition: String, labelWidth: String, labelSuffix: { type: String, default: "" }, inline: Boolean, inlineMessage: Boolean, statusIcon: Boolean, showMessage: { type: Boolean, default: true }, size: String, disabled: Boolean, validateOnRuleChange: { type: Boolean, default: true }, hideRequiredAsterisk: { type: Boolean, default: false } }, emits: ["validate"], setup(e, { emit: t }) {
  const i = mitt_es_default(), r = [];
  watch(() => e.rules, () => {
    r.forEach((e2) => {
      e2.removeValidateEvents(), e2.addValidateEvents();
    }), e.validateOnRuleChange && d(() => ({}));
  }), i.on(el, (e2) => {
    e2 && r.push(e2);
  }), i.on(tl, (e2) => {
    e2.prop && r.splice(r.indexOf(e2), 1);
  });
  const s = () => {
    e.model ? r.forEach((e2) => {
      e2.resetField();
    }) : console.warn("[Element Warn][Form]model is required for resetFields to work.");
  }, u = (e2 = []) => {
    (e2.length ? typeof e2 == "string" ? r.filter((t2) => e2 === t2.prop) : r.filter((t2) => e2.indexOf(t2.prop) > -1) : r).forEach((e3) => {
      e3.clearValidate();
    });
  }, d = (t2) => {
    if (!e.model)
      return void console.warn("[Element Warn][Form]model is required for validate to work!");
    let l;
    typeof t2 != "function" && (l = new Promise((e2, l2) => {
      t2 = function(t3, a2) {
        t3 ? e2(true) : l2(a2);
      };
    })), r.length === 0 && t2(true);
    let a = true, n = 0, o = {};
    for (const e2 of r)
      e2.validate("", (e3, l2) => {
        e3 && (a = false), o = Object.assign(Object.assign({}, o), l2), ++n === r.length && t2(a, o);
      });
    return l;
  }, c = (e2, t2) => {
    e2 = [].concat(e2);
    const l = r.filter((t3) => e2.indexOf(t3.prop) !== -1);
    r.length ? l.forEach((e3) => {
      e3.validate("", t2);
    }) : console.warn("[Element Warn]please pass correct props!");
  }, p = reactive(Object.assign(Object.assign(Object.assign({ formMitt: i }, toRefs(e)), { resetFields: s, clearValidate: u, validateField: c, emit: t }), function() {
    const e2 = ref([]);
    function t2(t3) {
      const l = e2.value.indexOf(t3);
      return l === -1 && console.warn("[Element Warn][ElementForm]unexpected width " + t3), l;
    }
    return { autoLabelWidth: computed(() => {
      if (!e2.value.length)
        return "0";
      const t3 = Math.max(...e2.value);
      return t3 ? t3 + "px" : "";
    }), registerLabelWidth: function(l, a) {
      if (l && a) {
        const n = t2(a);
        e2.value.splice(n, 1, l);
      } else
        l && e2.value.push(l);
    }, deregisterLabelWidth: function(l) {
      const a = t2(l);
      a > -1 && e2.value.splice(a, 1);
    } };
  }()));
  return provide("elForm", p), { validate: d, resetFields: s, clearValidate: u, validateField: c };
} });
ll.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("form", { class: ["el-form", [e.labelPosition ? "el-form--label-" + e.labelPosition : "", { "el-form--inline": e.inline }]] }, [renderSlot(e.$slots, "default")], 2);
}, ll.__file = "packages/form/src/form.vue", ll.install = (e) => {
  e.component(ll.name, ll);
};
var al = ll;
var nl;
var ol = ["letter-spacing", "line-height", "padding-top", "padding-bottom", "font-family", "font-weight", "font-size", "text-rendering", "text-transform", "width", "text-indent", "padding-left", "padding-right", "border-width", "box-sizing"];
function il(e, t = 1, l = null) {
  var a;
  nl || (nl = document.createElement("textarea"), document.body.appendChild(nl));
  const { paddingSize: n, borderSize: o, boxSizing: i, contextStyle: r } = function(e2) {
    const t2 = window.getComputedStyle(e2), l2 = t2.getPropertyValue("box-sizing"), a2 = parseFloat(t2.getPropertyValue("padding-bottom")) + parseFloat(t2.getPropertyValue("padding-top")), n2 = parseFloat(t2.getPropertyValue("border-bottom-width")) + parseFloat(t2.getPropertyValue("border-top-width"));
    return { contextStyle: ol.map((e3) => `${e3}:${t2.getPropertyValue(e3)}`).join(";"), paddingSize: a2, borderSize: n2, boxSizing: l2 };
  }(e);
  nl.setAttribute("style", r + ";\n  height:0 !important;\n  visibility:hidden !important;\n  overflow:hidden !important;\n  position:absolute !important;\n  z-index:-1000 !important;\n  top:0 !important;\n  right:0 !important;\n"), nl.value = e.value || e.placeholder || "";
  let s = nl.scrollHeight;
  const u = {};
  i === "border-box" ? s += o : i === "content-box" && (s -= n), nl.value = "";
  const d = nl.scrollHeight - n;
  if (t !== null) {
    let e2 = d * t;
    i === "border-box" && (e2 = e2 + n + o), s = Math.max(e2, s), u.minHeight = e2 + "px";
  }
  if (l !== null) {
    let e2 = d * l;
    i === "border-box" && (e2 = e2 + n + o), s = Math.min(e2, s);
  }
  return u.height = s + "px", (a = nl.parentNode) === null || a === void 0 || a.removeChild(nl), nl = null, u;
}
var rl = { suffix: "append", prefix: "prepend" };
var sl = defineComponent({ name: "ElInput", inheritAttrs: false, props: { modelValue: { type: [String, Number], default: "" }, type: { type: String, default: "text" }, size: { type: String, validator: Qt }, resize: { type: String, validator: (e) => ["none", "both", "horizontal", "vertical"].includes(e) }, autosize: { type: [Boolean, Object], default: false }, autocomplete: { type: String, default: "off", validator: (e) => ["on", "off"].includes(e) }, placeholder: { type: String }, form: { type: String, default: "" }, disabled: { type: Boolean, default: false }, readonly: { type: Boolean, default: false }, clearable: { type: Boolean, default: false }, showPassword: { type: Boolean, default: false }, showWordLimit: { type: Boolean, default: false }, suffixIcon: { type: String, default: "" }, prefixIcon: { type: String, default: "" }, label: { type: String }, tabindex: { type: [Number, String] }, validateEvent: { type: Boolean, default: true }, inputStyle: { type: Object, default: () => ({}) } }, emits: [Gt, "input", "change", "focus", "blur", "clear", "mouseleave", "mouseenter", "keydown"], setup(t, a) {
  const r = getCurrentInstance(), s = Mt(), u = Xe(), d = inject("elForm", {}), c = inject("elFormItem", {}), p = ref(null), h2 = ref(null), v = ref(false), m = ref(false), f = ref(false), g = ref(false), b = shallowRef(t.inputStyle), k = computed(() => p.value || h2.value), x = computed(() => t.size || c.size || u.size), C = computed(() => d.statusIcon), S = computed(() => c.validateState || ""), _ = computed(() => Xt[S.value]), T = computed(() => Object.assign(Object.assign({}, b.value), { resize: t.resize })), I = computed(() => t.disabled || d.disabled), O = computed(() => t.modelValue === null || t.modelValue === void 0 ? "" : String(t.modelValue)), N = computed(() => a.attrs.maxlength), D = computed(() => t.clearable && !I.value && !t.readonly && O.value && (v.value || m.value)), V = computed(() => t.showPassword && !I.value && !t.readonly && (!!O.value || v.value)), B = computed(() => t.showWordLimit && a.attrs.maxlength && (t.type === "text" || t.type === "textarea") && !I.value && !t.readonly && !t.showPassword), P = computed(() => typeof t.modelValue == "number" ? String(t.modelValue).length : (t.modelValue || "").length), A = computed(() => B.value && P.value > N.value), z = () => {
    const { type: e, autosize: l } = t;
    if (!ke && e === "textarea")
      if (l) {
        const e2 = Te(l) ? l.minRows : void 0, a2 = Te(l) ? l.maxRows : void 0;
        b.value = Object.assign(Object.assign({}, t.inputStyle), il(h2.value, e2, a2));
      } else
        b.value = Object.assign(Object.assign({}, t.inputStyle), { minHeight: il(h2.value).minHeight });
  }, L = () => {
    const e = k.value;
    e && e.value !== O.value && (e.value = O.value);
  }, F = (e) => {
    const { el: t2 } = r.vnode, l = Array.from(t2.querySelectorAll(".el-input__" + e)).find((e2) => e2.parentNode === t2);
    if (!l)
      return;
    const n = rl[e];
    a.slots[n] ? l.style.transform = `translateX(${e === "suffix" ? "-" : ""}${t2.querySelector(".el-input-group__" + n).offsetWidth}px)` : l.removeAttribute("style");
  }, R = () => {
    F("prefix"), F("suffix");
  }, $ = (e) => {
    const { value: t2 } = e.target;
    f.value || t2 !== O.value && (a.emit(Gt, t2), a.emit("input", t2), nextTick(L));
  }, H = () => {
    nextTick(() => {
      k.value.focus();
    });
  };
  watch(() => t.modelValue, (e) => {
    var l;
    nextTick(z), t.validateEvent && ((l = c.formItemMitt) === null || l === void 0 || l.emit("el.form.change", [e]));
  }), watch(O, () => {
    L();
  }), watch(() => t.type, () => {
    nextTick(() => {
      L(), z(), R();
    });
  }), onMounted(() => {
    L(), R(), nextTick(z);
  }), onUpdated(() => {
    nextTick(R);
  });
  return { input: p, textarea: h2, attrs: s, inputSize: x, validateState: S, validateIcon: _, computedTextareaStyle: T, resizeTextarea: z, inputDisabled: I, showClear: D, showPwdVisible: V, isWordLimitVisible: B, upperLimit: N, textLength: P, hovering: m, inputExceed: A, passwordVisible: g, inputOrTextarea: k, handleInput: $, handleChange: (e) => {
    a.emit("change", e.target.value);
  }, handleFocus: (e) => {
    v.value = true, a.emit("focus", e);
  }, handleBlur: (e) => {
    var l;
    v.value = false, a.emit("blur", e), t.validateEvent && ((l = c.formItemMitt) === null || l === void 0 || l.emit("el.form.blur", [t.modelValue]));
  }, handleCompositionStart: () => {
    f.value = true;
  }, handleCompositionUpdate: (e) => {
    const t2 = e.target.value, l = t2[t2.length - 1] || "";
    f.value = !Zt(l);
  }, handleCompositionEnd: (e) => {
    f.value && (f.value = false, $(e));
  }, handlePasswordVisible: () => {
    g.value = !g.value, H();
  }, clear: () => {
    a.emit(Gt, ""), a.emit("change", ""), a.emit("clear");
  }, select: () => {
    k.value.select();
  }, focus: H, blur: () => {
    k.value.blur();
  }, getSuffixVisible: () => a.slots.suffix || t.suffixIcon || D.value || t.showPassword || B.value || S.value && C.value, onMouseLeave: (e) => {
    m.value = false, a.emit("mouseleave", e);
  }, onMouseEnter: (e) => {
    m.value = true, a.emit("mouseenter", e);
  }, handleKeydown: (e) => {
    a.emit("keydown", e);
  } };
} });
var ul = { key: 0, class: "el-input-group__prepend" };
var dl = { key: 2, class: "el-input__prefix" };
var cl = { key: 3, class: "el-input__suffix" };
var pl = { class: "el-input__suffix-inner" };
var hl = { key: 3, class: "el-input__count" };
var vl = { class: "el-input__count-inner" };
var ml = { key: 4, class: "el-input-group__append" };
var fl = { key: 2, class: "el-input__count" };
sl.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: [e.type === "textarea" ? "el-textarea" : "el-input", e.inputSize ? "el-input--" + e.inputSize : "", { "is-disabled": e.inputDisabled, "is-exceed": e.inputExceed, "el-input-group": e.$slots.prepend || e.$slots.append, "el-input-group--append": e.$slots.append, "el-input-group--prepend": e.$slots.prepend, "el-input--prefix": e.$slots.prefix || e.prefixIcon, "el-input--suffix": e.$slots.suffix || e.suffixIcon || e.clearable || e.showPassword, "el-input--suffix--password-clear": e.clearable && e.showPassword }, e.$attrs.class], style: e.$attrs.style, onMouseenter: t[20] || (t[20] = (...t2) => e.onMouseEnter && e.onMouseEnter(...t2)), onMouseleave: t[21] || (t[21] = (...t2) => e.onMouseLeave && e.onMouseLeave(...t2)) }, [e.type !== "textarea" ? (openBlock(), createBlock(Fragment, { key: 0 }, [createCommentVNode(" \u524D\u7F6E\u5143\u7D20 "), e.$slots.prepend ? (openBlock(), createBlock("div", ul, [renderSlot(e.$slots, "prepend")])) : createCommentVNode("v-if", true), e.type !== "textarea" ? (openBlock(), createBlock("input", mergeProps({ key: 1, ref: "input", class: "el-input__inner" }, e.attrs, { type: e.showPassword ? e.passwordVisible ? "text" : "password" : e.type, disabled: e.inputDisabled, readonly: e.readonly, autocomplete: e.autocomplete, tabindex: e.tabindex, "aria-label": e.label, placeholder: e.placeholder, style: e.inputStyle, onCompositionstart: t[1] || (t[1] = (...t2) => e.handleCompositionStart && e.handleCompositionStart(...t2)), onCompositionupdate: t[2] || (t[2] = (...t2) => e.handleCompositionUpdate && e.handleCompositionUpdate(...t2)), onCompositionend: t[3] || (t[3] = (...t2) => e.handleCompositionEnd && e.handleCompositionEnd(...t2)), onInput: t[4] || (t[4] = (...t2) => e.handleInput && e.handleInput(...t2)), onFocus: t[5] || (t[5] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onBlur: t[6] || (t[6] = (...t2) => e.handleBlur && e.handleBlur(...t2)), onChange: t[7] || (t[7] = (...t2) => e.handleChange && e.handleChange(...t2)), onKeydown: t[8] || (t[8] = (...t2) => e.handleKeydown && e.handleKeydown(...t2)) }), null, 16, ["type", "disabled", "readonly", "autocomplete", "tabindex", "aria-label", "placeholder"])) : createCommentVNode("v-if", true), createCommentVNode(" \u524D\u7F6E\u5185\u5BB9 "), e.$slots.prefix || e.prefixIcon ? (openBlock(), createBlock("span", dl, [renderSlot(e.$slots, "prefix"), e.prefixIcon ? (openBlock(), createBlock("i", { key: 0, class: ["el-input__icon", e.prefixIcon] }, null, 2)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createCommentVNode(" \u540E\u7F6E\u5185\u5BB9 "), e.getSuffixVisible() ? (openBlock(), createBlock("span", cl, [createVNode("span", pl, [e.showClear && e.showPwdVisible && e.isWordLimitVisible ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Fragment, { key: 0 }, [renderSlot(e.$slots, "suffix"), e.suffixIcon ? (openBlock(), createBlock("i", { key: 0, class: ["el-input__icon", e.suffixIcon] }, null, 2)) : createCommentVNode("v-if", true)], 64)), e.showClear ? (openBlock(), createBlock("i", { key: 1, class: "el-input__icon el-icon-circle-close el-input__clear", onMousedown: t[9] || (t[9] = withModifiers(() => {
  }, ["prevent"])), onClick: t[10] || (t[10] = (...t2) => e.clear && e.clear(...t2)) }, null, 32)) : createCommentVNode("v-if", true), e.showPwdVisible ? (openBlock(), createBlock("i", { key: 2, class: "el-input__icon el-icon-view el-input__clear", onClick: t[11] || (t[11] = (...t2) => e.handlePasswordVisible && e.handlePasswordVisible(...t2)) })) : createCommentVNode("v-if", true), e.isWordLimitVisible ? (openBlock(), createBlock("span", hl, [createVNode("span", vl, toDisplayString(e.textLength) + "/" + toDisplayString(e.upperLimit), 1)])) : createCommentVNode("v-if", true)]), e.validateState ? (openBlock(), createBlock("i", { key: 0, class: ["el-input__icon", "el-input__validateIcon", e.validateIcon] }, null, 2)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createCommentVNode(" \u540E\u7F6E\u5143\u7D20 "), e.$slots.append ? (openBlock(), createBlock("div", ml, [renderSlot(e.$slots, "append")])) : createCommentVNode("v-if", true)], 64)) : (openBlock(), createBlock("textarea", mergeProps({ key: 1, ref: "textarea", class: "el-textarea__inner" }, e.attrs, { tabindex: e.tabindex, disabled: e.inputDisabled, readonly: e.readonly, autocomplete: e.autocomplete, style: e.computedTextareaStyle, "aria-label": e.label, placeholder: e.placeholder, onCompositionstart: t[12] || (t[12] = (...t2) => e.handleCompositionStart && e.handleCompositionStart(...t2)), onCompositionupdate: t[13] || (t[13] = (...t2) => e.handleCompositionUpdate && e.handleCompositionUpdate(...t2)), onCompositionend: t[14] || (t[14] = (...t2) => e.handleCompositionEnd && e.handleCompositionEnd(...t2)), onInput: t[15] || (t[15] = (...t2) => e.handleInput && e.handleInput(...t2)), onFocus: t[16] || (t[16] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onBlur: t[17] || (t[17] = (...t2) => e.handleBlur && e.handleBlur(...t2)), onChange: t[18] || (t[18] = (...t2) => e.handleChange && e.handleChange(...t2)), onKeydown: t[19] || (t[19] = (...t2) => e.handleKeydown && e.handleKeydown(...t2)) }), "\n    ", 16, ["tabindex", "disabled", "readonly", "autocomplete", "aria-label", "placeholder"])), e.isWordLimitVisible && e.type === "textarea" ? (openBlock(), createBlock("span", fl, toDisplayString(e.textLength) + "/" + toDisplayString(e.upperLimit), 1)) : createCommentVNode("v-if", true)], 38);
}, sl.__file = "packages/input/src/index.vue", sl.install = (e) => {
  e.component(sl.name, sl);
};
var gl = sl;
var bl = { vertical: { offset: "offsetHeight", scroll: "scrollTop", scrollSize: "scrollHeight", size: "height", key: "vertical", axis: "Y", client: "clientY", direction: "top" }, horizontal: { offset: "offsetWidth", scroll: "scrollLeft", scrollSize: "scrollWidth", size: "width", key: "horizontal", axis: "X", client: "clientX", direction: "left" } };
var yl = defineComponent({ name: "Bar", props: { vertical: Boolean, size: String, move: Number }, setup(e) {
  const t = ref(null), a = ref(null), o = inject("scrollbar", {}), s = inject("scrollbar-wrap", {}), u = computed(() => bl[e.vertical ? "vertical" : "horizontal"]), d = ref({}), c = ref(null), p = ref(null), h2 = ref(false);
  let v = null;
  const m = (e2) => {
    e2.stopImmediatePropagation(), c.value = true, at(document, "mousemove", f), at(document, "mouseup", g), v = document.onselectstart, document.onselectstart = () => false;
  }, f = (e2) => {
    if (c.value === false)
      return;
    const l = d.value[u.value.axis];
    if (!l)
      return;
    const n = 100 * (-1 * (t.value.getBoundingClientRect()[u.value.direction] - e2[u.value.client]) - (a.value[u.value.offset] - l)) / t.value[u.value.offset];
    s.value[u.value.scroll] = n * s.value[u.value.scrollSize] / 100;
  }, g = () => {
    c.value = false, d.value[u.value.axis] = 0, nt(document, "mousemove", f), document.onselectstart = v, p.value && (h2.value = false);
  }, b = computed(() => function({ move: e2, size: t2, bar: l }) {
    const a2 = {}, n = `translate${l.axis}(${e2}%)`;
    return a2[l.size] = t2, a2.transform = n, a2.msTransform = n, a2.webkitTransform = n, a2;
  }({ size: e.size, move: e.move, bar: u.value })), y = () => {
    p.value = false, h2.value = !!e.size;
  }, k = () => {
    p.value = true, h2.value = c.value;
  };
  return onMounted(() => {
    at(o.value, "mousemove", y), at(o.value, "mouseleave", k);
  }), onBeforeUnmount(() => {
    nt(document, "mouseup", g), nt(o.value, "mousemove", y), nt(o.value, "mouseleave", k);
  }), { instance: t, thumb: a, bar: u, clickTrackHandler: (e2) => {
    const l = 100 * (Math.abs(e2.target.getBoundingClientRect()[u.value.direction] - e2[u.value.client]) - a.value[u.value.offset] / 2) / t.value[u.value.offset];
    s.value[u.value.scroll] = l * s.value[u.value.scrollSize] / 100;
  }, clickThumbHandler: (e2) => {
    e2.stopPropagation(), e2.ctrlKey || [1, 2].includes(e2.button) || (window.getSelection().removeAllRanges(), m(e2), d.value[u.value.axis] = e2.currentTarget[u.value.offset] - (e2[u.value.client] - e2.currentTarget.getBoundingClientRect()[u.value.direction]));
  }, thumbStyle: b, visible: h2 };
} });
yl.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "el-scrollbar-fade" }, { default: withCtx(() => [withDirectives(createVNode("div", { ref: "instance", class: ["el-scrollbar__bar", "is-" + e.bar.key], onMousedown: t[2] || (t[2] = (...t2) => e.clickTrackHandler && e.clickTrackHandler(...t2)) }, [createVNode("div", { ref: "thumb", class: "el-scrollbar__thumb", style: e.thumbStyle, onMousedown: t[1] || (t[1] = (...t2) => e.clickThumbHandler && e.clickThumbHandler(...t2)) }, null, 36)], 34), [[vShow, e.visible]])]), _: 1 });
}, yl.__file = "packages/scrollbar/src/bar.vue";
var kl = defineComponent({ name: "ElScrollbar", components: { Bar: yl }, props: { height: { type: [String, Number], default: "" }, maxHeight: { type: [String, Number], default: "" }, native: { type: Boolean, default: false }, wrapStyle: { type: [String, Array], default: "" }, wrapClass: { type: [String, Array], default: "" }, viewClass: { type: [String, Array], default: "" }, viewStyle: { type: [String, Array], default: "" }, noresize: Boolean, tag: { type: String, default: "div" } }, emits: ["scroll"], setup(e, { emit: t }) {
  const a = ref("0"), o = ref("0"), s = ref(0), u = ref(0), d = ref(null), c = ref(null), p = ref(null);
  provide("scrollbar", d), provide("scrollbar-wrap", c);
  const h2 = () => {
    if (!c.value)
      return;
    const e2 = 100 * c.value.clientHeight / c.value.scrollHeight, t2 = 100 * c.value.clientWidth / c.value.scrollWidth;
    o.value = e2 < 100 ? e2 + "%" : "", a.value = t2 < 100 ? t2 + "%" : "";
  }, v = computed(() => {
    let t2 = e.wrapStyle;
    return _e(t2) ? (t2 = function(e2) {
      const t3 = {};
      for (let l = 0; l < e2.length; l++)
        e2[l] && Ce(t3, e2[l]);
      return t3;
    }(t2), t2.height = lt(e.height), t2.maxHeight = lt(e.maxHeight)) : Me(t2) && (t2 += lt(e.height) ? `height: ${lt(e.height)};` : "", t2 += lt(e.maxHeight) ? `max-height: ${lt(e.maxHeight)};` : ""), t2;
  });
  return onMounted(() => {
    e.native || nextTick(h2), e.noresize || (vt(p.value, h2), addEventListener("resize", h2));
  }), onBeforeUnmount(() => {
    e.noresize || (mt(p.value, h2), removeEventListener("resize", h2));
  }), { moveX: s, moveY: u, sizeWidth: a, sizeHeight: o, style: v, scrollbar: d, wrap: c, resize: p, update: h2, handleScroll: () => {
    c.value && (u.value = 100 * c.value.scrollTop / c.value.clientHeight, s.value = 100 * c.value.scrollLeft / c.value.clientWidth, t("scroll", { scrollLeft: s.value, scrollTop: u.value }));
  } };
} });
var xl = { ref: "scrollbar", class: "el-scrollbar" };
kl.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("bar");
  return openBlock(), createBlock("div", xl, [createVNode("div", { ref: "wrap", class: [e.wrapClass, "el-scrollbar__wrap", e.native ? "" : "el-scrollbar__wrap--hidden-default"], style: e.style, onScroll: t[1] || (t[1] = (...t2) => e.handleScroll && e.handleScroll(...t2)) }, [(openBlock(), createBlock(resolveDynamicComponent(e.tag), { ref: "resize", class: ["el-scrollbar__view", e.viewClass], style: e.viewStyle }, { default: withCtx(() => [renderSlot(e.$slots, "default")]), _: 3 }, 8, ["class", "style"]))], 38), e.native ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Fragment, { key: 0 }, [createVNode(i, { move: e.moveX, size: e.sizeWidth }, null, 8, ["move", "size"]), createVNode(i, { vertical: "", move: e.moveY, size: e.sizeHeight }, null, 8, ["move", "size"])], 64))], 512);
}, kl.__file = "packages/scrollbar/src/index.vue", kl.install = (e) => {
  e.component(kl.name, kl);
};
var Cl = kl;
var wl = {};
var Sl = (e) => {
  e.preventDefault(), e.stopPropagation();
};
var _l = () => {
  Ol == null || Ol.doOnModalClick();
};
var El;
var Ml = false;
var Tl = function() {
  if (ke)
    return;
  let e = Ol.modalDom;
  return e ? Ml = true : (Ml = false, e = document.createElement("div"), Ol.modalDom = e, at(e, "touchmove", Sl), at(e, "click", _l)), e;
};
var Il = {};
var Ol = { modalFade: true, modalDom: void 0, zIndex: El, getInstance: function(e) {
  return Il[e];
}, register: function(e, t) {
  e && t && (Il[e] = t);
}, deregister: function(e) {
  e && (Il[e] = null, delete Il[e]);
}, nextZIndex: function() {
  return ++Ol.zIndex;
}, modalStack: [], doOnModalClick: function() {
  const e = Ol.modalStack[Ol.modalStack.length - 1];
  if (!e)
    return;
  const t = Ol.getInstance(e.id);
  t && t.closeOnClickModal.value && t.close();
}, openModal: function(e, t, l, a, n) {
  if (ke)
    return;
  if (!e || t === void 0)
    return;
  this.modalFade = n;
  const o = this.modalStack;
  for (let t2 = 0, l2 = o.length; t2 < l2; t2++) {
    if (o[t2].id === e)
      return;
  }
  const i = Tl();
  if (it(i, "v-modal"), this.modalFade && !Ml && it(i, "v-modal-enter"), a) {
    a.trim().split(/\s+/).forEach((e2) => it(i, e2));
  }
  setTimeout(() => {
    rt(i, "v-modal-enter");
  }, 200), l && l.parentNode && l.parentNode.nodeType !== 11 ? l.parentNode.appendChild(i) : document.body.appendChild(i), t && (i.style.zIndex = String(t)), i.tabIndex = 0, i.style.display = "", this.modalStack.push({ id: e, zIndex: t, modalClass: a });
}, closeModal: function(e) {
  const t = this.modalStack, l = Tl();
  if (t.length > 0) {
    const a = t[t.length - 1];
    if (a.id === e) {
      if (a.modalClass) {
        a.modalClass.trim().split(/\s+/).forEach((e2) => rt(l, e2));
      }
      t.pop(), t.length > 0 && (l.style.zIndex = t[t.length - 1].zIndex);
    } else
      for (let l2 = t.length - 1; l2 >= 0; l2--)
        if (t[l2].id === e) {
          t.splice(l2, 1);
          break;
        }
  }
  t.length === 0 && (this.modalFade && it(l, "v-modal-leave"), setTimeout(() => {
    t.length === 0 && (l.parentNode && l.parentNode.removeChild(l), l.style.display = "none", Ol.modalDom = void 0), rt(l, "v-modal-leave");
  }, 200));
} };
Object.defineProperty(Ol, "zIndex", { configurable: true, get: () => (El === void 0 && (El = wl["zIndex"] || 2e3), El), set(e) {
  El = e;
} });
function Nl(e, t = []) {
  const { arrow: l, arrowOffset: a, offset: n, gpuAcceleration: o, fallbackPlacements: i } = e, r = [{ name: "offset", options: { offset: [0, n != null ? n : 12] } }, { name: "preventOverflow", options: { padding: { top: 2, bottom: 2, left: 5, right: 5 } } }, { name: "flip", options: { padding: 5, fallbackPlacements: i != null ? i : [] } }, { name: "computeStyles", options: { gpuAcceleration: o, adaptive: o } }];
  return l && r.push({ name: "arrow", options: { element: l, padding: a != null ? a : 5 } }), r.push(...t), r;
}
var Dl;
ke || at(window, "keydown", function(e) {
  if (e.code === Dt.esc) {
    const e2 = function() {
      if (!ke && Ol.modalStack.length > 0) {
        const e3 = Ol.modalStack[Ol.modalStack.length - 1];
        if (!e3)
          return;
        return Ol.getInstance(e3.id);
      }
    }();
    e2 && e2.closeOnPressEscape.value && (e2.handleClose ? e2.handleClose() : e2.handleAction ? e2.handleAction("cancel") : e2.close());
  }
}), function(e) {
  e.DARK = "dark", e.LIGHT = "light";
}(Dl || (Dl = {}));
var Vl = { arrowOffset: { type: Number, default: 5 }, appendToBody: { type: Boolean, default: true }, autoClose: { type: Number, default: 0 }, boundariesPadding: { type: Number, default: 0 }, content: { type: String, default: "" }, class: { type: String, default: "" }, style: Object, hideAfter: { type: Number, default: 200 }, cutoff: { type: Boolean, default: false }, disabled: { type: Boolean, default: false }, effect: { type: String, default: Dl.DARK }, enterable: { type: Boolean, default: true }, manualMode: { type: Boolean, default: false }, showAfter: { type: Number, default: 0 }, offset: { type: Number, default: 12 }, placement: { type: String, default: "bottom" }, popperClass: { type: String, default: "" }, pure: { type: Boolean, default: false }, popperOptions: { type: Object, default: () => null }, showArrow: { type: Boolean, default: true }, strategy: { type: String, default: "fixed" }, transition: { type: String, default: "el-fade-in-linear" }, trigger: { type: [String, Array], default: "hover" }, visible: { type: Boolean, default: void 0 }, stopPopperMouseEvent: { type: Boolean, default: true }, gpuAcceleration: { type: Boolean, default: true }, fallbackPlacements: { type: Array, default: [] } };
function Bl(e, { emit: t }) {
  const i = ref(null), r = ref(null), s = ref(null), u = "el-popper-" + He();
  let d = null, c = null, p = null, h2 = false;
  const v = () => e.manualMode || e.trigger === "manual", m = ref({ zIndex: Ol.nextZIndex() }), f = function(e2, t2) {
    return computed(() => {
      var l;
      return Object.assign(Object.assign({ placement: e2.placement }, e2.popperOptions), { modifiers: Nl({ arrow: t2.arrow.value, arrowOffset: e2.arrowOffset, offset: e2.offset, gpuAcceleration: e2.gpuAcceleration, fallbackPlacements: e2.fallbackPlacements }, (l = e2.popperOptions) === null || l === void 0 ? void 0 : l.modifiers) });
    });
  }(e, { arrow: i }), g = reactive({ visible: !!e.visible }), b = computed({ get: () => !e.disabled && (je(e.visible) ? e.visible : g.visible), set(l) {
    v() || (je(e.visible) ? t("update:visible", l) : g.visible = l);
  } });
  function y() {
    e.autoClose > 0 && (p = window.setTimeout(() => {
      k();
    }, e.autoClose)), b.value = true;
  }
  function k() {
    b.value = false;
  }
  function x() {
    clearTimeout(c), clearTimeout(p);
  }
  const C = () => {
    v() || e.disabled || (x(), e.showAfter === 0 ? y() : c = window.setTimeout(() => {
      y();
    }, e.showAfter));
  }, w = () => {
    v() || (x(), e.hideAfter > 0 ? p = window.setTimeout(() => {
      S();
    }, e.hideAfter) : S());
  }, S = () => {
    k(), e.disabled && E(true);
  };
  function _() {
    if (!tt(b))
      return;
    const e2 = tt(r), t2 = De(e2).startsWith("HTML") ? e2 : e2.$el;
    d = createPopper3(t2, tt(s), tt(f)), d.update();
  }
  function E(e2) {
    !d || tt(b) && !e2 || M();
  }
  function M() {
    var e2;
    (e2 = d == null ? void 0 : d.destroy) === null || e2 === void 0 || e2.call(d), d = null;
  }
  const T = {};
  if (!v()) {
    const t2 = () => {
      tt(b) ? w() : C();
    }, l = (e2) => {
      switch (e2.stopPropagation(), e2.type) {
        case "click":
          h2 ? h2 = false : t2();
          break;
        case "mouseenter":
          C();
          break;
        case "mouseleave":
          w();
          break;
        case "focus":
          h2 = true, C();
          break;
        case "blur":
          h2 = false, w();
      }
    }, a = { click: ["onClick"], hover: ["onMouseenter", "onMouseleave"], focus: ["onFocus", "onBlur"] }, n = (e2) => {
      a[e2].forEach((e3) => {
        T[e3] = l;
      });
    };
    _e(e.trigger) ? Object.values(e.trigger).forEach(n) : n(e.trigger);
  }
  return watch(f, (e2) => {
    d && (d.setOptions(e2), d.update());
  }), watch(b, function(e2) {
    e2 && (m.value.zIndex = Ol.nextZIndex(), _());
  }), { update: function() {
    tt(b) && (d ? d.update() : _());
  }, doDestroy: E, show: C, hide: w, onPopperMouseEnter: function() {
    e.enterable && e.trigger !== "click" && clearTimeout(p);
  }, onPopperMouseLeave: function() {
    const { trigger: t2 } = e;
    Me(t2) && (t2 === "click" || t2 === "focus") || t2.length === 1 && (t2[0] === "click" || t2[0] === "focus") || w();
  }, onAfterEnter: () => {
    t("after-enter");
  }, onAfterLeave: () => {
    M(), t("after-leave");
  }, onBeforeEnter: () => {
    t("before-enter");
  }, onBeforeLeave: () => {
    t("before-leave");
  }, initializePopper: _, isManualMode: v, arrowRef: i, events: T, popperId: u, popperInstance: d, popperRef: s, popperStyle: m, triggerRef: r, visibility: b };
}
function Pl(e, t) {
  const { effect: l, name: a, stopPopperMouseEvent: n, popperClass: o, popperStyle: i, popperRef: r, pure: s, popperId: u, visibility: d, onMouseenter: c, onMouseleave: m, onAfterEnter: f, onAfterLeave: g, onBeforeEnter: y, onBeforeLeave: k } = e, x = [o, "el-popper", "is-" + l, s ? "is-pure" : ""], C = n ? pt : xe;
  return h(Transition, { name: a, onAfterEnter: f, onAfterLeave: g, onBeforeEnter: y, onBeforeLeave: k }, { default: withCtx(() => [withDirectives(h("div", { "aria-hidden": String(!d), class: x, style: i != null ? i : {}, id: u, ref: r != null ? r : "popperRef", role: "tooltip", onMouseenter: c, onMouseleave: m, onClick: pt, onMousedown: C, onMouseup: C }, t), [[vShow, d]])]) });
}
var Al;
!function(e) {
  e[e.TEXT = 1] = "TEXT", e[e.CLASS = 2] = "CLASS", e[e.STYLE = 4] = "STYLE", e[e.PROPS = 8] = "PROPS", e[e.FULL_PROPS = 16] = "FULL_PROPS", e[e.HYDRATE_EVENTS = 32] = "HYDRATE_EVENTS", e[e.STABLE_FRAGMENT = 64] = "STABLE_FRAGMENT", e[e.KEYED_FRAGMENT = 128] = "KEYED_FRAGMENT", e[e.UNKEYED_FRAGMENT = 256] = "UNKEYED_FRAGMENT", e[e.NEED_PATCH = 512] = "NEED_PATCH", e[e.DYNAMIC_SLOTS = 1024] = "DYNAMIC_SLOTS", e[e.HOISTED = -1] = "HOISTED", e[e.BAIL = -2] = "BAIL";
}(Al || (Al = {}));
var zl = (e) => e.type === Fragment;
var Ll = (e) => e.type === Comment$1;
function Fl(e, t) {
  if (!Ll(e))
    return zl(e) || ((e2) => e2.type === "template")(e) ? t > 0 ? Rl(e.children, t - 1) : void 0 : e;
}
var Rl = (e, t = 3) => Array.isArray(e) ? Fl(e[0], t) : Fl(e, t);
function $l(e, t, l, a, n, o) {
  return e ? function(e2, t2, l2, a2, n2) {
    return openBlock(), createBlock(e2, t2, l2, a2, n2);
  }(t, l, a, n, o) : createCommentVNode("v-if", true);
}
function Hl(e, t) {
  const l = Rl(e, 1);
  return l || Le("renderTrigger", "trigger expects single rooted node"), cloneVNode(l, t, true);
}
function Wl(e) {
  return e ? h("div", { ref: "arrowRef", class: "el-popper__arrow", "data-popper-arrow": "" }, null) : h(Comment$1, null, "");
}
var jl = defineComponent({ name: "ElPopper", props: Vl, emits: ["update:visible", "after-enter", "after-leave", "before-enter", "before-leave"], setup(e, t) {
  t.slots.trigger || Le("ElPopper", "Trigger must be provided");
  const l = Bl(e, t), a = () => l.doDestroy(true);
  return onMounted(l.initializePopper), onBeforeUnmount(a), onActivated(l.initializePopper), onDeactivated(a), l;
}, render() {
  var e;
  const { $slots: t, appendToBody: l, class: a, style: n, effect: o, hide: i, onPopperMouseEnter: r, onPopperMouseLeave: s, onAfterEnter: u, onAfterLeave: d, onBeforeEnter: p, onBeforeLeave: h2, popperClass: m, popperId: f, popperStyle: b, pure: y, showArrow: k, transition: x, visibility: C, stopPopperMouseEvent: w } = this, S = this.isManualMode(), _ = Wl(k), E = Pl({ effect: o, name: x, popperClass: m, popperId: f, popperStyle: b, pure: y, stopPopperMouseEvent: w, onMouseenter: r, onMouseleave: s, onAfterEnter: u, onAfterLeave: d, onBeforeEnter: p, onBeforeLeave: h2, visibility: C }, [renderSlot(t, "default", {}, () => [toDisplayString(this.content)]), _]), M = (e = t.trigger) === null || e === void 0 ? void 0 : e.call(t), I = Object.assign({ "aria-describedby": f, class: a, style: n, ref: "triggerRef" }, this.events), O = S ? Hl(M, I) : withDirectives(Hl(M, I), [[Ht, i]]);
  return h(Fragment, null, [O, h(Teleport, { to: "body", disabled: !l }, [E])]);
} });
jl.__file = "packages/popper/src/index.vue", jl.install = (e) => {
  e.component(jl.name, jl);
};
var Kl = jl;
var Yl = defineComponent({ name: "ElAutocomplete", components: { ElPopper: Kl, ElInput: gl, ElScrollbar: Cl }, directives: { clickoutside: Ht }, inheritAttrs: false, props: { valueKey: { type: String, default: "value" }, modelValue: { type: [String, Number], default: "" }, debounce: { type: Number, default: 300 }, placement: { type: String, validator: (e) => ["top", "top-start", "top-end", "bottom", "bottom-start", "bottom-end"].includes(e), default: "bottom-start" }, fetchSuggestions: { type: Function, default: xe }, popperClass: { type: String, default: "" }, triggerOnFocus: { type: Boolean, default: true }, selectWhenUnmatched: { type: Boolean, default: false }, hideLoading: { type: Boolean, default: false }, popperAppendToBody: { type: Boolean, default: true }, highlightFirstItem: { type: Boolean, default: false } }, emits: [Gt, "input", "change", "focus", "blur", "clear", "select"], setup(e, t) {
  const a = Mt(), r = ref([]), s = ref(-1), u = ref(""), d = ref(false), c = ref(false), p = ref(false), h2 = ref(null), v = ref(null), m = ref(null), f = computed(() => "el-autocomplete-" + He()), g = computed(() => (_e(r.value) && r.value.length > 0 || p.value) && d.value), b = computed(() => !e.hideLoading && p.value), y = () => {
    nextTick(m.value.update);
  };
  watch(g, () => {
    u.value = h2.value.$el.offsetWidth + "px";
  }), onMounted(() => {
    h2.value.inputOrTextarea.setAttribute("role", "textbox"), h2.value.inputOrTextarea.setAttribute("aria-autocomplete", "list"), h2.value.inputOrTextarea.setAttribute("aria-controls", "id"), h2.value.inputOrTextarea.setAttribute("aria-activedescendant", `${f.value}-item-${s.value}`);
    const e2 = v.value.querySelector(".el-autocomplete-suggestion__list");
    e2.setAttribute("role", "listbox"), e2.setAttribute("id", f.value);
  }), onUpdated(y);
  const k = (t2) => {
    c.value || (p.value = true, y(), e.fetchSuggestions(t2, (t3) => {
      p.value = false, c.value || (_e(t3) ? (r.value = t3, s.value = e.highlightFirstItem ? 0 : -1) : Le("ElAutocomplete", "autocomplete suggestions must be an array"));
    }));
  }, x = (0, import_debounce2.default)(k, e.debounce), C = (l) => {
    t.emit("input", l[e.valueKey]), t.emit(Gt, l[e.valueKey]), t.emit("select", l), nextTick(() => {
      r.value = [], s.value = -1;
    });
  };
  return { attrs: a, suggestions: r, highlightedIndex: s, dropdownWidth: u, activated: d, suggestionDisabled: c, loading: p, inputRef: h2, regionRef: v, popper: m, id: f, suggestionVisible: g, suggestionLoading: b, getData: k, handleInput: (l) => {
    if (t.emit("input", l), t.emit(Gt, l), c.value = false, !e.triggerOnFocus && !l)
      return c.value = true, void (r.value = []);
    x(l);
  }, handleChange: (e2) => {
    t.emit("change", e2);
  }, handleFocus: (l) => {
    d.value = true, t.emit("focus", l), e.triggerOnFocus && x(e.modelValue);
  }, handleBlur: (e2) => {
    t.emit("blur", e2);
  }, handleClear: () => {
    d.value = false, t.emit(Gt, ""), t.emit("clear");
  }, handleKeyEnter: () => {
    g.value && s.value >= 0 && s.value < r.value.length ? C(r.value[s.value]) : e.selectWhenUnmatched && (t.emit("select", { value: e.modelValue }), nextTick(() => {
      r.value = [], s.value = -1;
    }));
  }, close: () => {
    d.value = false;
  }, focus: () => {
    h2.value.focus();
  }, select: C, highlight: (e2) => {
    if (!g.value || p.value)
      return;
    if (e2 < 0)
      return void (s.value = -1);
    e2 >= r.value.length && (e2 = r.value.length - 1);
    const t2 = v.value.querySelector(".el-autocomplete-suggestion__wrap"), l = t2.querySelectorAll(".el-autocomplete-suggestion__list li")[e2], a2 = t2.scrollTop, n = l.offsetTop;
    n + l.scrollHeight > a2 + t2.clientHeight && (t2.scrollTop += l.scrollHeight), n < a2 && (t2.scrollTop -= l.scrollHeight), s.value = e2, h2.value.inputOrTextarea.setAttribute("aria-activedescendant", `${f.value}-item-${s.value}`);
  } };
} });
var ql = { key: 0 };
var Ul = createVNode("i", { class: "el-icon-loading" }, null, -1);
Yl.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("el-scrollbar"), p = resolveComponent("el-popper"), m = resolveDirective("clickoutside");
  return openBlock(), createBlock(p, { ref: "popper", visible: e.suggestionVisible, "onUpdate:visible": t[3] || (t[3] = (t2) => e.suggestionVisible = t2), placement: e.placement, "popper-class": "el-autocomplete__popper " + e.popperClass, "append-to-body": e.popperAppendToBody, pure: "", "manual-mode": "", effect: "light", trigger: "click", transition: "el-zoom-in-top", "gpu-acceleration": false }, { trigger: withCtx(() => [withDirectives(createVNode("div", { class: ["el-autocomplete", e.$attrs.class], style: e.$attrs.style, role: "combobox", "aria-haspopup": "listbox", "aria-expanded": e.suggestionVisible, "aria-owns": e.id }, [createVNode(i, mergeProps({ ref: "inputRef" }, e.attrs, { "model-value": e.modelValue, onInput: e.handleInput, onChange: e.handleChange, onFocus: e.handleFocus, onBlur: e.handleBlur, onClear: e.handleClear, onKeydown: [t[1] || (t[1] = withKeys(withModifiers((t2) => e.highlight(e.highlightedIndex - 1), ["prevent"]), ["up"])), t[2] || (t[2] = withKeys(withModifiers((t2) => e.highlight(e.highlightedIndex + 1), ["prevent"]), ["down"])), withKeys(e.handleKeyEnter, ["enter"]), withKeys(e.close, ["tab"])] }), createSlots({ _: 2 }, [e.$slots.prepend ? { name: "prepend", fn: withCtx(() => [renderSlot(e.$slots, "prepend")]) } : void 0, e.$slots.append ? { name: "append", fn: withCtx(() => [renderSlot(e.$slots, "append")]) } : void 0, e.$slots.prefix ? { name: "prefix", fn: withCtx(() => [renderSlot(e.$slots, "prefix")]) } : void 0, e.$slots.suffix ? { name: "suffix", fn: withCtx(() => [renderSlot(e.$slots, "suffix")]) } : void 0]), 1040, ["model-value", "onInput", "onChange", "onFocus", "onBlur", "onClear", "onKeydown"])], 14, ["aria-expanded", "aria-owns"]), [[m, e.close]])]), default: withCtx(() => [createVNode("div", { ref: "regionRef", class: ["el-autocomplete-suggestion", e.suggestionLoading && "is-loading"], style: { width: e.dropdownWidth, outline: "none" }, role: "region" }, [createVNode(r, { tag: "ul", "wrap-class": "el-autocomplete-suggestion__wrap", "view-class": "el-autocomplete-suggestion__list" }, { default: withCtx(() => [e.suggestionLoading ? (openBlock(), createBlock("li", ql, [Ul])) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(e.suggestions, (t2, l2) => (openBlock(), createBlock("li", { id: `${e.id}-item-${l2}`, key: l2, class: { highlighted: e.highlightedIndex === l2 }, role: "option", "aria-selected": e.highlightedIndex === l2, onClick: (l3) => e.select(t2) }, [renderSlot(e.$slots, "default", { item: t2 }, () => [createTextVNode(toDisplayString(t2[e.valueKey]), 1)])], 10, ["id", "aria-selected", "onClick"]))), 128))]), _: 3 })], 6)]), _: 1 }, 8, ["visible", "placement", "popper-class", "append-to-body"]);
}, Yl.__file = "packages/autocomplete/src/index.vue", Yl.install = (e) => {
  e.component(Yl.name, Yl);
};
var Gl = Yl;
var Xl = defineComponent({ name: "ElAvatar", props: { size: { type: [Number, String], validator: (e) => typeof e == "string" ? ["large", "medium", "small"].includes(e) : typeof e == "number", default: "large" }, shape: { type: String, default: "circle", validator: (e) => ["circle", "square"].includes(e) }, icon: String, src: { type: String, default: "" }, alt: String, srcSet: String, fit: { type: String, default: "cover" } }, emits: ["error"], setup(e, { emit: t }) {
  const a = ref(false), i = toRef(e, "src");
  watch(i, () => {
    a.value = false;
  });
  const r = computed(() => {
    const { size: t2, icon: l, shape: a2 } = e;
    let n = ["el-avatar"];
    return t2 && typeof t2 == "string" && n.push("el-avatar--" + t2), l && n.push("el-avatar--icon"), a2 && n.push("el-avatar--" + a2), n;
  }), s = computed(() => {
    const { size: t2 } = e;
    return typeof t2 == "number" ? { height: t2 + "px", width: t2 + "px", lineHeight: t2 + "px" } : {};
  }), u = computed(() => ({ objectFit: e.fit }));
  return { hasLoadError: a, avatarClass: r, sizeStyle: s, handleError: function(e2) {
    a.value = true, t("error", e2);
  }, fitStyle: u };
} });
Xl.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("span", { class: e.avatarClass, style: e.sizeStyle }, [!e.src && !e.srcSet || e.hasLoadError ? e.icon ? (openBlock(), createBlock("i", { key: 1, class: e.icon }, null, 2)) : renderSlot(e.$slots, "default", { key: 2 }) : (openBlock(), createBlock("img", { key: 0, src: e.src, alt: e.alt, srcset: e.srcSet, style: e.fitStyle, onError: t[1] || (t[1] = (...t2) => e.handleError && e.handleError(...t2)) }, null, 44, ["src", "alt", "srcset"]))], 6);
}, Xl.__file = "packages/avatar/src/index.vue", Xl.install = (e) => {
  e.component(Xl.name, Xl);
};
var Zl = Xl;
var Ql = (e) => Math.pow(e, 3);
var Jl = defineComponent({ name: "ElBacktop", props: { visibilityHeight: { type: Number, default: 200 }, target: { type: String, default: "" }, right: { type: Number, default: 40 }, bottom: { type: Number, default: 40 } }, emits: ["click"], setup(e, t) {
  const a = ref(null), o = ref(null), s = ref(false), u = computed(() => e.bottom + "px"), d = computed(() => e.right + "px"), c = () => {
    const e2 = Date.now(), t2 = a.value.scrollTop, l = window.requestAnimationFrame || ((e3) => setTimeout(e3, 16)), n = () => {
      const o2 = (Date.now() - e2) / 500;
      var i;
      o2 < 1 ? (a.value.scrollTop = t2 * (1 - ((i = o2) < 0.5 ? Ql(2 * i) / 2 : 1 - Ql(2 * (1 - i)) / 2)), l(n)) : a.value.scrollTop = 0;
    };
    l(n);
  }, p = (0, import_throttle.default)(() => {
    s.value = a.value.scrollTop >= e.visibilityHeight;
  }, 300);
  return onMounted(() => {
    o.value = document, a.value = document.documentElement, e.target && (a.value = document.querySelector(e.target), a.value || Le("ElBackTop", "target is not existed: " + e.target), o.value = a.value), at(o.value, "scroll", p);
  }), onBeforeUnmount(() => {
    nt(o.value, "scroll", p);
  }), { el: a, container: o, visible: s, styleBottom: u, styleRight: d, handleClick: (e2) => {
    c(), t.emit("click", e2);
  } };
} });
var ea = createVNode("i", { class: "el-icon-caret-top" }, null, -1);
Jl.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "el-fade-in" }, { default: withCtx(() => [e.visible ? (openBlock(), createBlock("div", { key: 0, style: { right: e.styleRight, bottom: e.styleBottom }, class: "el-backtop", onClick: t[1] || (t[1] = withModifiers((...t2) => e.handleClick && e.handleClick(...t2), ["stop"])) }, [renderSlot(e.$slots, "default", {}, () => [ea])], 4)) : createCommentVNode("v-if", true)]), _: 3 });
}, Jl.__file = "packages/backtop/src/index.vue", Jl.install = (e) => {
  e.component(Jl.name, Jl);
};
var ta = Jl;
var la = defineComponent({ name: "ElBadge", props: { value: { type: [String, Number], default: "" }, max: { type: Number, default: 99 }, isDot: Boolean, hidden: Boolean, type: { type: String, default: "primary", validator: (e) => ["primary", "success", "warning", "info", "danger"].includes(e) } }, setup: (e) => ({ content: computed(() => {
  if (!e.isDot)
    return typeof e.value == "number" && typeof e.max == "number" && e.max < e.value ? e.max + "+" : e.value;
}) }) });
var aa = { class: "el-badge" };
la.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", aa, [renderSlot(e.$slots, "default"), createVNode(Transition, { name: "el-zoom-in-center" }, { default: withCtx(() => [withDirectives(createVNode("sup", { class: ["el-badge__content", ["el-badge__content--" + e.type, { "is-fixed": e.$slots.default, "is-dot": e.isDot }]], textContent: toDisplayString(e.content) }, null, 10, ["textContent"]), [[vShow, !e.hidden && (e.content || e.content === 0 || e.isDot)]])]), _: 1 })]);
}, la.__file = "packages/badge/src/index.vue", la.install = (e) => {
  e.component(la.name, la);
};
var na = la;
var oa = defineComponent({ name: "ElBreadcrumb", props: { separator: { type: String, default: "/" }, separatorClass: { type: String, default: "" } }, setup(e) {
  const t = ref(null);
  return provide("breadcrumb", e), onMounted(() => {
    const e2 = t.value.querySelectorAll(".el-breadcrumb__item");
    e2.length && e2[e2.length - 1].setAttribute("aria-current", "page");
  }), { breadcrumb: t };
} });
var ia = { ref: "breadcrumb", class: "el-breadcrumb", "aria-label": "Breadcrumb", role: "navigation" };
oa.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", ia, [renderSlot(e.$slots, "default")], 512);
}, oa.__file = "packages/breadcrumb/src/index.vue", oa.install = (e) => {
  e.component(oa.name, oa);
};
var ra = oa;
var sa = defineComponent({ name: "ElBreadcrumbItem", props: { to: { type: [String, Object], default: "" }, replace: { type: Boolean, default: false } }, setup(t) {
  const a = ref(null), n = inject("breadcrumb"), o = getCurrentInstance().appContext.config.globalProperties.$router;
  return onMounted(() => {
    a.value.setAttribute("role", "link"), a.value.addEventListener("click", () => {
      t.to && o && (t.replace ? o.replace(t.to) : o.push(t.to));
    });
  }), { link: a, separator: n == null ? void 0 : n.separator, separatorClass: n == null ? void 0 : n.separatorClass };
} });
var ua = { class: "el-breadcrumb__item" };
var da = { key: 1, class: "el-breadcrumb__separator", role: "presentation" };
sa.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("span", ua, [createVNode("span", { ref: "link", class: ["el-breadcrumb__inner", e.to ? "is-link" : ""], role: "link" }, [renderSlot(e.$slots, "default")], 2), e.separatorClass ? (openBlock(), createBlock("i", { key: 0, class: ["el-breadcrumb__separator", e.separatorClass] }, null, 2)) : (openBlock(), createBlock("span", da, toDisplayString(e.separator), 1))]);
}, sa.__file = "packages/breadcrumb/src/item.vue", sa.install = (e) => {
  e.component(sa.name, sa);
};
var ca = sa;
var pa = defineComponent({ name: "ElButton", props: { type: { type: String, default: "default", validator: (e) => ["default", "primary", "success", "warning", "info", "danger", "text"].includes(e) }, size: { type: String, validator: Qt }, icon: { type: String, default: "" }, nativeType: { type: String, default: "button", validator: (e) => ["button", "submit", "reset"].includes(e) }, loading: Boolean, disabled: Boolean, plain: Boolean, autofocus: Boolean, round: Boolean, circle: Boolean }, emits: ["click"], setup(e, { emit: t }) {
  const l = Xe(), a = inject("elForm", {}), o = inject("elFormItem", {});
  return { buttonSize: computed(() => e.size || o.size || l.size), buttonDisabled: computed(() => e.disabled || a.disabled), handleClick: (e2) => {
    t("click", e2);
  } };
} });
var ha = { key: 0, class: "el-icon-loading" };
var va = { key: 2 };
pa.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("button", { class: ["el-button", e.type ? "el-button--" + e.type : "", e.buttonSize ? "el-button--" + e.buttonSize : "", { "is-disabled": e.buttonDisabled, "is-loading": e.loading, "is-plain": e.plain, "is-round": e.round, "is-circle": e.circle }], disabled: e.buttonDisabled || e.loading, autofocus: e.autofocus, type: e.nativeType, onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [e.loading ? (openBlock(), createBlock("i", ha)) : createCommentVNode("v-if", true), e.icon && !e.loading ? (openBlock(), createBlock("i", { key: 1, class: e.icon }, null, 2)) : createCommentVNode("v-if", true), e.$slots.default ? (openBlock(), createBlock("span", va, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true)], 10, ["disabled", "autofocus", "type"]);
}, pa.__file = "packages/button/src/button.vue", pa.install = (e) => {
  e.component(pa.name, pa);
};
var ma = pa;
var fa = defineComponent({ name: "ElButtonGroup" });
var ga = { class: "el-button-group" };
fa.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", ga, [renderSlot(e.$slots, "default")]);
}, fa.__file = "packages/button/src/button-group.vue", fa.install = (e) => {
  e.component(fa.name, fa);
};
var ba = fa;
var ya = { name: "en", el: { colorpicker: { confirm: "OK", clear: "Clear" }, datepicker: { now: "Now", today: "Today", cancel: "Cancel", clear: "Clear", confirm: "OK", selectDate: "Select date", selectTime: "Select time", startDate: "Start Date", startTime: "Start Time", endDate: "End Date", endTime: "End Time", prevYear: "Previous Year", nextYear: "Next Year", prevMonth: "Previous Month", nextMonth: "Next Month", year: "", month1: "January", month2: "February", month3: "March", month4: "April", month5: "May", month6: "June", month7: "July", month8: "August", month9: "September", month10: "October", month11: "November", month12: "December", week: "week", weeks: { sun: "Sun", mon: "Mon", tue: "Tue", wed: "Wed", thu: "Thu", fri: "Fri", sat: "Sat" }, months: { jan: "Jan", feb: "Feb", mar: "Mar", apr: "Apr", may: "May", jun: "Jun", jul: "Jul", aug: "Aug", sep: "Sep", oct: "Oct", nov: "Nov", dec: "Dec" } }, select: { loading: "Loading", noMatch: "No matching data", noData: "No data", placeholder: "Select" }, cascader: { noMatch: "No matching data", loading: "Loading", placeholder: "Select", noData: "No data" }, pagination: { goto: "Go to", pagesize: "/page", total: "Total {total}", pageClassifier: "" }, messagebox: { title: "Message", confirm: "OK", cancel: "Cancel", error: "Illegal input" }, upload: { deleteTip: "press delete to remove", delete: "Delete", preview: "Preview", continue: "Continue" }, table: { emptyText: "No Data", confirmFilter: "Confirm", resetFilter: "Reset", clearFilter: "All", sumText: "Sum" }, tree: { emptyText: "No Data" }, transfer: { noMatch: "No matching data", noData: "No data", titles: ["List 1", "List 2"], filterPlaceholder: "Enter keyword", noCheckedFormat: "{total} items", hasCheckedFormat: "{checked}/{total} checked" }, image: { error: "FAILED" }, pageHeader: { title: "Back" }, popconfirm: { confirmButtonText: "Yes", cancelButtonText: "No" } } };
var ka = null;
function xa(e, t) {
  return e && t ? e.replace(/\{(\w+)\}/g, (e2, l) => t[l]) : e;
}
var Ca = (...e) => {
  if (ka)
    return ka(...e);
  const [t, l] = e;
  let a;
  const n = t.split(".");
  let o = ya;
  for (let e2 = 0, t2 = n.length; e2 < t2; e2++) {
    if (a = o[n[e2]], e2 === t2 - 1)
      return xa(a, l);
    if (!a)
      return "";
    o = a;
  }
  return "";
};
var wa = { date: "YYYY-MM-DD", week: "gggg[w]ww", year: "YYYY", month: "YYYY-MM", datetime: "YYYY-MM-DD HH:mm:ss", monthrange: "YYYY-MM", daterange: "YYYY-MM-DD", datetimerange: "YYYY-MM-DD HH:mm:ss" };
var Sa = { name: { type: [Array, String], default: "" }, popperClass: { type: String, default: "" }, format: { type: String }, valueFormat: { type: String }, type: { type: String, default: "" }, clearable: { type: Boolean, default: true }, clearIcon: { type: String, default: "el-icon-circle-close" }, editable: { type: Boolean, default: true }, prefixIcon: { type: String, default: "" }, size: { type: String, validator: Qt }, readonly: { type: Boolean, default: false }, disabled: { type: Boolean, default: false }, placeholder: { type: String, default: "" }, popperOptions: { type: Object, default: () => ({}) }, modelValue: { type: [Date, Array, String], default: "" }, rangeSeparator: { type: String, default: "-" }, startPlaceholder: String, endPlaceholder: String, defaultValue: { type: [Date, Array] }, defaultTime: { type: [Date, Array] }, isRange: { type: Boolean, default: false }, disabledHours: { type: Function }, disabledMinutes: { type: Function }, disabledSeconds: { type: Function }, disabledDate: { type: Function }, cellClassName: { type: Function }, shortcuts: { type: Array, default: () => [] }, arrowControl: { type: Boolean, default: false }, validateEvent: { type: Boolean, default: true }, unlinkPanels: Boolean };
var _a = function(e, t) {
  const l = e instanceof Date, a = t instanceof Date;
  return l && a ? e.getTime() === t.getTime() : !l && !a && e === t;
};
var Ea = function(e, t) {
  const l = e instanceof Array, a = t instanceof Array;
  return l && a ? e.length === t.length && e.every((e2, l2) => _a(e2, t[l2])) : !l && !a && _a(e, t);
};
var Ma = function(e, t) {
  const l = Qe(t) ? (0, import_dayjs.default)(e) : (0, import_dayjs.default)(e, t);
  return l.isValid() ? l : void 0;
};
var Ta = function(e, t) {
  return Qe(t) ? e : (0, import_dayjs.default)(e).format(t);
};
var Ia = defineComponent({ name: "Picker", components: { ElInput: gl, ElPopper: Kl }, directives: { clickoutside: Ht }, props: Sa, emits: ["update:modelValue", "change", "focus", "blur"], setup(e, t) {
  const a = Xe(), i = inject("elForm", {}), r = inject("elFormItem", {}), s = inject("ElPopperOptions", {}), u = ref(null), d = ref(false), c = ref(false), p = ref(null);
  watch(d, (l) => {
    var a2;
    l ? p.value = e.modelValue : (N.value = null, nextTick(() => {
      h2(e.modelValue);
    }), t.emit("blur"), V(), e.validateEvent && ((a2 = r.formItemMitt) === null || a2 === void 0 || a2.emit("el.form.blur")));
  });
  const h2 = (l, a2) => {
    var n;
    !a2 && Ea(l, p.value) || (t.emit("change", l), e.validateEvent && ((n = r.formItemMitt) === null || n === void 0 || n.emit("el.form.change", l)));
  }, v = (l) => {
    if (!Ea(e.modelValue, l)) {
      let a2;
      Array.isArray(l) ? a2 = l.map((t2) => Ta(t2, e.valueFormat)) : l && (a2 = Ta(l, e.valueFormat)), t.emit("update:modelValue", l ? a2 : l);
    }
  }, m = computed(() => {
    if (u.value.triggerRef) {
      const e2 = T.value ? u.value.triggerRef : u.value.triggerRef.$el;
      return [].slice.call(e2.querySelectorAll("input"));
    }
    return [];
  }), f = computed(() => e.disabled || i.disabled), g = computed(() => {
    let t2;
    return M.value ? z.value.getDefaultValue && (t2 = z.value.getDefaultValue()) : t2 = Array.isArray(e.modelValue) ? e.modelValue.map((t3) => Ma(t3, e.valueFormat)) : Ma(e.modelValue, e.valueFormat), z.value.getRangeAvaliableTime && (t2 = z.value.getRangeAvaliableTime(t2)), Array.isArray(t2) && t2.some((e2) => !e2) && (t2 = []), t2;
  }), b = computed(() => {
    if (!z.value.panelReady)
      return;
    const e2 = P(g.value);
    return Array.isArray(N.value) ? [N.value[0] || e2 && e2[0] || "", N.value[1] || e2 && e2[1] || ""] : N.value !== null ? N.value : !k.value && M.value || !d.value && M.value ? void 0 : e2 ? x.value ? e2.join(", ") : e2 : "";
  }), y = computed(() => e.type.indexOf("time") !== -1), k = computed(() => e.type.indexOf("time") === 0), x = computed(() => e.type === "dates"), C = computed(() => e.prefixIcon || (y.value ? "el-icon-time" : "el-icon-date")), S = ref(false), M = computed(() => !e.modelValue || Array.isArray(e.modelValue) && !e.modelValue.length), T = computed(() => e.type.indexOf("range") > -1), I = computed(() => e.size || r.size || a.size), O = computed(() => {
    var e2;
    return (e2 = u.value) === null || e2 === void 0 ? void 0 : e2.popperRef;
  }), N = ref(null), D = () => {
    if (N.value) {
      const e2 = B(b.value);
      e2 && A(e2) && (v(Array.isArray(e2) ? e2.map((e3) => e3.toDate()) : e2.toDate()), N.value = null);
    }
    N.value === "" && (v(null), h2(null), N.value = null);
  }, V = () => {
    m.value.forEach((e2) => e2.blur());
  }, B = (e2) => e2 ? z.value.parseUserInput(e2) : null, P = (e2) => e2 ? z.value.formatToString(e2) : null, A = (e2) => z.value.isValidValue(e2), z = ref({});
  return provide("EP_PICKER_BASE", { props: e }), { elPopperOptions: s, isDatesPicker: x, handleEndChange: () => {
    const e2 = B(N.value && N.value[1]);
    if (e2 && e2.isValid()) {
      N.value = [b.value[0], P(e2)];
      const t2 = [g.value && g.value[0], e2];
      A(t2) && (v(t2), N.value = null);
    }
  }, handleStartChange: () => {
    const e2 = B(N.value && N.value[0]);
    if (e2 && e2.isValid()) {
      N.value = [P(e2), b.value[1]];
      const t2 = [e2, g.value && g.value[1]];
      A(t2) && (v(t2), N.value = null);
    }
  }, handleStartInput: (e2) => {
    N.value ? N.value = [e2.target.value, N.value[1]] : N.value = [e2.target.value, null];
  }, handleEndInput: (e2) => {
    N.value ? N.value = [N.value[0], e2.target.value] : N.value = [null, e2.target.value];
  }, onUserInput: (e2) => {
    N.value = e2;
  }, handleChange: D, handleKeydown: (e2) => {
    const t2 = e2.code;
    return t2 === Dt.esc ? (d.value = false, void e2.stopPropagation()) : t2 !== Dt.tab ? t2 === Dt.enter ? ((N.value === "" || A(B(b.value))) && (D(), d.value = false), void e2.stopPropagation()) : void (N.value ? e2.stopPropagation() : z.value.handleKeydown && z.value.handleKeydown(e2)) : void (T.value ? setTimeout(() => {
      m.value.indexOf(document.activeElement) === -1 && (d.value = false, V());
    }, 0) : (D(), d.value = false, e2.stopPropagation()));
  }, popperPaneRef: O, onClickOutside: () => {
    d.value && (d.value = false);
  }, pickerSize: I, isRangeInput: T, onMouseLeave: () => {
    S.value = false;
  }, onMouseEnter: () => {
    e.readonly || f.value || !M.value && e.clearable && (S.value = true);
  }, onClearIconClick: (t2) => {
    e.readonly || f.value || S.value && (t2.stopPropagation(), v(null), h2(null, true), S.value = false, d.value = false, z.value.handleClear && z.value.handleClear());
  }, showClose: S, triggerClass: C, onPick: (e2 = "", t2 = false) => {
    let l;
    d.value = t2, l = Array.isArray(e2) ? e2.map((e3) => e3.toDate()) : e2 ? e2.toDate() : e2, N.value = null, v(l);
  }, handleFocus: (l) => {
    e.readonly || f.value || (d.value = true, t.emit("focus", l));
  }, pickerVisible: d, pickerActualVisible: c, displayValue: b, parsedValue: g, setSelectionRange: (e2, t2, l) => {
    const a2 = m.value;
    a2.length && (l && l !== "min" ? l === "max" && (a2[1].setSelectionRange(e2, t2), a2[1].focus()) : (a2[0].setSelectionRange(e2, t2), a2[0].focus()));
  }, refPopper: u, pickerDisabled: f, onSetPickerOption: (e2) => {
    z.value[e2[0]] = e2[1], z.value.panelReady = true;
  } };
} });
var Oa = { class: "el-range-separator" };
Ia.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("el-popper"), p = resolveDirective("clickoutside");
  return openBlock(), createBlock(r, mergeProps({ ref: "refPopper", visible: e.pickerVisible, "onUpdate:visible": t[18] || (t[18] = (t2) => e.pickerVisible = t2), "manual-mode": "", effect: "light", pure: "", trigger: "click" }, e.$attrs, { "popper-class": "el-picker__popper " + e.popperClass, "popper-options": e.elPopperOptions, "fallback-placements": ["bottom", "top", "right", "left"], transition: "el-zoom-in-top", "gpu-acceleration": false, "stop-popper-mouse-event": false, "append-to-body": "", onBeforeEnter: t[19] || (t[19] = (t2) => e.pickerActualVisible = true), onAfterLeave: t[20] || (t[20] = (t2) => e.pickerActualVisible = false) }), { trigger: withCtx(() => [e.isRangeInput ? withDirectives((openBlock(), createBlock("div", { key: 1, class: ["el-date-editor el-range-editor el-input__inner", ["el-date-editor--" + e.type, e.pickerSize ? "el-range-editor--" + e.pickerSize : "", e.pickerDisabled ? "is-disabled" : "", e.pickerVisible ? "is-active" : ""]], onClick: t[10] || (t[10] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onMouseenter: t[11] || (t[11] = (...t2) => e.onMouseEnter && e.onMouseEnter(...t2)), onMouseleave: t[12] || (t[12] = (...t2) => e.onMouseLeave && e.onMouseLeave(...t2)), onKeydown: t[13] || (t[13] = (...t2) => e.handleKeydown && e.handleKeydown(...t2)) }, [createVNode("i", { class: ["el-input__icon", "el-range__icon", e.triggerClass] }, null, 2), createVNode("input", { autocomplete: "off", name: e.name && e.name[0], placeholder: e.startPlaceholder, value: e.displayValue && e.displayValue[0], disabled: e.pickerDisabled, readonly: !e.editable || e.readonly, class: "el-range-input", onInput: t[3] || (t[3] = (...t2) => e.handleStartInput && e.handleStartInput(...t2)), onChange: t[4] || (t[4] = (...t2) => e.handleStartChange && e.handleStartChange(...t2)), onFocus: t[5] || (t[5] = (...t2) => e.handleFocus && e.handleFocus(...t2)) }, null, 40, ["name", "placeholder", "value", "disabled", "readonly"]), renderSlot(e.$slots, "range-separator", {}, () => [createVNode("span", Oa, toDisplayString(e.rangeSeparator), 1)]), createVNode("input", { autocomplete: "off", name: e.name && e.name[1], placeholder: e.endPlaceholder, value: e.displayValue && e.displayValue[1], disabled: e.pickerDisabled, readonly: !e.editable || e.readonly, class: "el-range-input", onFocus: t[6] || (t[6] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onInput: t[7] || (t[7] = (...t2) => e.handleEndInput && e.handleEndInput(...t2)), onChange: t[8] || (t[8] = (...t2) => e.handleEndChange && e.handleEndChange(...t2)) }, null, 40, ["name", "placeholder", "value", "disabled", "readonly"]), createVNode("i", { class: [[e.showClose ? "" + e.clearIcon : ""], "el-input__icon el-range__close-icon"], onClick: t[9] || (t[9] = (...t2) => e.onClearIconClick && e.onClearIconClick(...t2)) }, null, 2)], 34)), [[p, e.onClickOutside, e.popperPaneRef]]) : withDirectives((openBlock(), createBlock(i, { key: 0, "model-value": e.displayValue, name: e.name, size: e.pickerSize, disabled: e.pickerDisabled, placeholder: e.placeholder, class: ["el-date-editor", "el-date-editor--" + e.type], readonly: !e.editable || e.readonly || e.isDatesPicker || e.type === "week", onInput: e.onUserInput, onFocus: e.handleFocus, onKeydown: e.handleKeydown, onChange: e.handleChange, onMouseenter: e.onMouseEnter, onMouseleave: e.onMouseLeave }, { prefix: withCtx(() => [createVNode("i", { class: ["el-input__icon", e.triggerClass], onClick: t[1] || (t[1] = (...t2) => e.handleFocus && e.handleFocus(...t2)) }, null, 2)]), suffix: withCtx(() => [createVNode("i", { class: ["el-input__icon", [e.showClose ? "" + e.clearIcon : ""]], onClick: t[2] || (t[2] = (...t2) => e.onClearIconClick && e.onClearIconClick(...t2)) }, null, 2)]), _: 1 }, 8, ["model-value", "name", "size", "disabled", "placeholder", "class", "readonly", "onInput", "onFocus", "onKeydown", "onChange", "onMouseenter", "onMouseleave"])), [[p, e.onClickOutside, e.popperPaneRef]])]), default: withCtx(() => [renderSlot(e.$slots, "default", { visible: e.pickerVisible, actualVisible: e.pickerActualVisible, parsedValue: e.parsedValue, format: e.format, unlinkPanels: e.unlinkPanels, type: e.type, defaultValue: e.defaultValue, onPick: t[14] || (t[14] = (...t2) => e.onPick && e.onPick(...t2)), onSelectRange: t[15] || (t[15] = (...t2) => e.setSelectionRange && e.setSelectionRange(...t2)), onSetPickerOption: t[16] || (t[16] = (...t2) => e.onSetPickerOption && e.onSetPickerOption(...t2)), onMousedown: t[17] || (t[17] = withModifiers(() => {
  }, ["stop"])) })]), _: 1 }, 16, ["visible", "popper-class", "popper-options"]);
}, Ia.__file = "packages/time-picker/src/common/picker.vue";
var Na = (e, t, l) => {
  const a = [], n = t && l();
  for (let t2 = 0; t2 < e; t2++)
    a[t2] = !!n && n.includes(t2);
  return a;
};
var Da = (e) => e.map((e2, t) => e2 || t).filter((e2) => e2 !== true);
var Va = (e, t, l) => ({ getHoursList: (t2, l2) => Na(24, e, () => e(t2, l2)), getMinutesList: (e2, l2, a) => Na(60, t, () => t(e2, l2, a)), getSecondsList: (e2, t2, a, n) => Na(60, l, () => l(e2, t2, a, n)) });
var Ba = (e, t, l) => {
  const { getHoursList: a, getMinutesList: n, getSecondsList: o } = Va(e, t, l);
  return { getAvaliableHours: (e2, t2) => Da(a(e2, t2)), getAvaliableMinutes: (e2, t2, l2) => Da(n(e2, t2, l2)), getAvaliableSeconds: (e2, t2, l2, a2) => Da(o(e2, t2, l2, a2)) };
};
var Pa = (e) => {
  const t = ref(e.parsedValue);
  return watch(() => e.visible, (l) => {
    l || (t.value = e.parsedValue);
  }), t;
};
var Aa = defineComponent({ directives: { repeatClick: Wt }, components: { ElScrollbar: Cl }, props: { role: { type: String, required: true }, spinnerDate: { type: Object, required: true }, showSeconds: { type: Boolean, default: true }, arrowControl: Boolean, amPmMode: { type: String, default: "" }, disabledHours: { type: Function }, disabledMinutes: { type: Function }, disabledSeconds: { type: Function } }, emits: ["change", "select-range", "set-option"], setup(e, t) {
  let a = false;
  const r = (0, import_debounce2.default)((e2) => {
    a = false, T(e2);
  }, 200), s = ref(null), u = ref(null), d = ref(null), c = ref(null), p = { hours: u, minutes: d, seconds: c }, h2 = computed(() => {
    const t2 = ["hours", "minutes", "seconds"];
    return e.showSeconds ? t2 : t2.slice(0, 2);
  }), v = computed(() => e.spinnerDate.hour()), m = computed(() => e.spinnerDate.minute()), f = computed(() => e.spinnerDate.second()), g = computed(() => ({ hours: v, minutes: m, seconds: f })), b = computed(() => A(e.role)), y = computed(() => z(v.value, e.role)), k = computed(() => L(v.value, m.value, e.role)), x = computed(() => ({ hours: b, minutes: y, seconds: k })), C = computed(() => {
    const e2 = v.value;
    return [e2 > 0 ? e2 - 1 : void 0, e2, e2 < 23 ? e2 + 1 : void 0];
  }), S = computed(() => {
    const e2 = m.value;
    return [e2 > 0 ? e2 - 1 : void 0, e2, e2 < 59 ? e2 + 1 : void 0];
  }), _ = computed(() => {
    const e2 = f.value;
    return [e2 > 0 ? e2 - 1 : void 0, e2, e2 < 59 ? e2 + 1 : void 0];
  }), E = computed(() => ({ hours: C, minutes: S, seconds: _ })), M = (e2) => {
    e2 === "hours" ? t.emit("select-range", 0, 2) : e2 === "minutes" ? t.emit("select-range", 3, 5) : e2 === "seconds" && t.emit("select-range", 6, 8), s.value = e2;
  }, T = (e2) => {
    O(e2, g.value[e2].value);
  }, I = () => {
    T("hours"), T("minutes"), T("seconds");
  }, O = (t2, l) => {
    if (e.arrowControl)
      return;
    const a2 = p[t2];
    a2.value && (a2.value.$el.querySelector(".el-scrollbar__wrap").scrollTop = Math.max(0, l * N(t2)));
  }, N = (e2) => p[e2].value.$el.querySelector("li").offsetHeight, D = (e2) => {
    s.value || M("hours");
    const t2 = s.value;
    let l = g.value[t2].value;
    const a2 = s.value === "hours" ? 24 : 60;
    l = (l + e2 + a2) % a2, V(t2, l), O(t2, l), nextTick(() => M(s.value));
  }, V = (l, a2) => {
    if (!x.value[l].value[a2])
      switch (l) {
        case "hours":
          t.emit("change", e.spinnerDate.hour(a2).minute(m.value).second(f.value));
          break;
        case "minutes":
          t.emit("change", e.spinnerDate.hour(v.value).minute(a2).second(f.value));
          break;
        case "seconds":
          t.emit("change", e.spinnerDate.hour(v.value).minute(m.value).second(a2));
      }
  }, B = (e2) => p[e2].value.$el.offsetHeight, P = () => {
    const e2 = (e3) => {
      p[e3].value && (p[e3].value.$el.querySelector(".el-scrollbar__wrap").onscroll = () => {
        ((e4) => {
          a = true, r(e4);
          const t2 = Math.min(Math.round((p[e4].value.$el.querySelector(".el-scrollbar__wrap").scrollTop - (0.5 * B(e4) - 10) / N(e4) + 3) / N(e4)), e4 === "hours" ? 23 : 59);
          V(e4, t2);
        })(e3);
      });
    };
    e2("hours"), e2("minutes"), e2("seconds");
  };
  onMounted(() => {
    nextTick(() => {
      !e.arrowControl && P(), I(), e.role === "start" && M("hours");
    });
  });
  t.emit("set-option", [e.role + "_scrollDown", D]), t.emit("set-option", [e.role + "_emitSelectRange", M]);
  const { getHoursList: A, getMinutesList: z, getSecondsList: L } = Va(e.disabledHours, e.disabledMinutes, e.disabledSeconds);
  return watch(() => e.spinnerDate, () => {
    a || I();
  }), { getRefId: (e2) => `list${e2.charAt(0).toUpperCase() + e2.slice(1)}Ref`, spinnerItems: h2, currentScrollbar: s, hours: v, minutes: m, seconds: f, hoursList: b, minutesList: y, arrowHourList: C, arrowMinuteList: S, arrowSecondList: _, getAmPmFlag: (t2) => {
    if (!!!e.amPmMode)
      return "";
    let l = t2 < 12 ? " am" : " pm";
    return e.amPmMode === "A" && (l = l.toUpperCase()), l;
  }, emitSelectRange: M, adjustCurrentSpinner: T, typeItemHeight: N, listHoursRef: u, listMinutesRef: d, listSecondsRef: c, onIncreaseClick: () => {
    D(1);
  }, onDecreaseClick: () => {
    D(-1);
  }, handleClick: (e2, { value: t2, disabled: l }) => {
    l || (V(e2, t2), M(e2), O(e2, t2));
  }, secondsList: k, timePartsMap: g, arrowListMap: E, listMap: x };
} });
var za = { class: "el-time-spinner__arrow el-icon-arrow-up" };
var La = { class: "el-time-spinner__arrow el-icon-arrow-down" };
var Fa = { class: "el-time-spinner__list" };
Aa.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-scrollbar"), r = resolveDirective("repeat-click");
  return openBlock(), createBlock("div", { class: ["el-time-spinner", { "has-seconds": e.showSeconds }] }, [e.arrowControl ? createCommentVNode("v-if", true) : (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(e.spinnerItems, (t2) => (openBlock(), createBlock(i, { key: t2, ref: e.getRefId(t2), class: "el-time-spinner__wrapper", "wrap-style": "max-height: inherit;", "view-class": "el-time-spinner__list", noresize: "", tag: "ul", onMouseenter: (l2) => e.emitSelectRange(t2), onMousemove: (l2) => e.adjustCurrentSpinner(t2) }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.listMap[t2].value, (l2, a2) => (openBlock(), createBlock("li", { key: a2, class: ["el-time-spinner__item", { active: a2 === e.timePartsMap[t2].value, disabled: l2 }], onClick: (n2) => e.handleClick(t2, { value: a2, disabled: l2 }) }, [t2 === "hours" ? (openBlock(), createBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(("0" + (e.amPmMode ? a2 % 12 || 12 : a2)).slice(-2)) + toDisplayString(e.getAmPmFlag(a2)), 1)], 2112)) : (openBlock(), createBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(("0" + a2).slice(-2)), 1)], 2112))], 10, ["onClick"]))), 128))]), _: 2 }, 1032, ["onMouseenter", "onMousemove"]))), 128)), e.arrowControl ? (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(e.spinnerItems, (t2) => (openBlock(), createBlock("div", { key: t2, class: "el-time-spinner__wrapper is-arrow", onMouseenter: (l2) => e.emitSelectRange(t2) }, [withDirectives(createVNode("i", za, null, 512), [[r, e.onDecreaseClick]]), withDirectives(createVNode("i", La, null, 512), [[r, e.onIncreaseClick]]), createVNode("ul", Fa, [(openBlock(true), createBlock(Fragment, null, renderList(e.arrowListMap[t2].value, (l2, a2) => (openBlock(), createBlock("li", { key: a2, class: ["el-time-spinner__item", { active: l2 === e.timePartsMap[t2].value, disabled: e.listMap[t2].value[l2] }] }, toDisplayString(l2 === void 0 ? "" : ("0" + (e.amPmMode ? l2 % 12 || 12 : l2)).slice(-2) + e.getAmPmFlag(l2)), 3))), 128))])], 40, ["onMouseenter"]))), 128)) : createCommentVNode("v-if", true)], 2);
}, Aa.__file = "packages/time-picker/src/time-picker-com/basic-time-spinner.vue";
var Ra = defineComponent({ components: { TimeSpinner: Aa }, props: { visible: Boolean, actualVisible: { type: Boolean, default: void 0 }, datetimeRole: { type: String }, parsedValue: { type: [Object, String] }, format: { type: String, default: "" } }, emits: ["pick", "select-range", "set-picker-option"], setup(e, t) {
  const a = ref([0, 2]), o = Pa(e), i = computed(() => e.actualVisible === void 0 ? "el-zoom-in-top" : ""), r = computed(() => e.format.includes("ss")), s = computed(() => e.format.includes("A") ? "A" : e.format.includes("a") ? "a" : ""), u = (t2) => {
    const l = { hour: g, minute: b, second: y };
    let a2 = t2;
    return ["hour", "minute", "second"].forEach((t3) => {
      if (l[t3]) {
        let n;
        const o2 = l[t3];
        n = t3 === "minute" ? o2(a2.hour(), e.datetimeRole) : t3 === "second" ? o2(a2.hour(), a2.minute(), e.datetimeRole) : o2(e.datetimeRole), n && n.length && !n.includes(a2[t3]()) && (a2 = a2[t3](n[0]));
      }
    }), a2;
  };
  t.emit("set-picker-option", ["isValidValue", (e2) => {
    const t2 = (0, import_dayjs.default)(e2), l = u(t2);
    return t2.isSame(l);
  }]), t.emit("set-picker-option", ["formatToString", (t2) => t2 ? t2.format(e.format) : null]), t.emit("set-picker-option", ["parseUserInput", (t2) => t2 ? (0, import_dayjs.default)(t2, e.format) : null]), t.emit("set-picker-option", ["handleKeydown", (e2) => {
    const t2 = e2.code;
    if (t2 === Dt.left || t2 === Dt.right) {
      return ((e3) => {
        const t3 = [0, 3].concat(r.value ? [6] : []), l = ["hours", "minutes"].concat(r.value ? ["seconds"] : []), n = (t3.indexOf(a.value[0]) + e3 + t3.length) % t3.length;
        d.start_emitSelectRange(l[n]);
      })(t2 === Dt.left ? -1 : 1), void e2.preventDefault();
    }
    if (t2 === Dt.up || t2 === Dt.down) {
      const l = t2 === Dt.up ? -1 : 1;
      return d.start_scrollDown(l), void e2.preventDefault();
    }
  }]), t.emit("set-picker-option", ["getRangeAvaliableTime", u]), t.emit("set-picker-option", ["getDefaultValue", () => (0, import_dayjs.default)(f)]);
  const d = {}, c = inject("EP_PICKER_BASE"), { arrowControl: p, disabledHours: h2, disabledMinutes: v, disabledSeconds: m, defaultValue: f } = c.props, { getAvaliableHours: g, getAvaliableMinutes: b, getAvaliableSeconds: y } = Ba(h2, v, m);
  return { transitionName: i, arrowControl: p, onSetOption: (e2) => {
    d[e2[0]] = e2[1];
  }, t: Ca, handleConfirm: (l = false, a2) => {
    a2 || t.emit("pick", e.parsedValue, l);
  }, handleChange: (l) => {
    if (!e.visible)
      return;
    const a2 = u(l).millisecond(0);
    t.emit("pick", a2, true);
  }, setSelectionRange: (e2, l) => {
    t.emit("select-range", e2, l), a.value = [e2, l];
  }, amPmMode: s, showSeconds: r, handleCancel: () => {
    t.emit("pick", o.value, false);
  }, disabledHours: h2, disabledMinutes: v, disabledSeconds: m };
} });
var $a = { key: 0, class: "el-time-panel" };
var Ha = { class: "el-time-panel__footer" };
Ra.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("time-spinner");
  return openBlock(), createBlock(Transition, { name: e.transitionName }, { default: withCtx(() => [e.actualVisible || e.visible ? (openBlock(), createBlock("div", $a, [createVNode("div", { class: ["el-time-panel__content", { "has-seconds": e.showSeconds }] }, [createVNode(i, { ref: "spinner", role: e.datetimeRole || "start", "arrow-control": e.arrowControl, "show-seconds": e.showSeconds, "am-pm-mode": e.amPmMode, "spinner-date": e.parsedValue, "disabled-hours": e.disabledHours, "disabled-minutes": e.disabledMinutes, "disabled-seconds": e.disabledSeconds, onChange: e.handleChange, onSetOption: e.onSetOption, onSelectRange: e.setSelectionRange }, null, 8, ["role", "arrow-control", "show-seconds", "am-pm-mode", "spinner-date", "disabled-hours", "disabled-minutes", "disabled-seconds", "onChange", "onSetOption", "onSelectRange"])], 2), createVNode("div", Ha, [createVNode("button", { type: "button", class: "el-time-panel__btn cancel", onClick: t[1] || (t[1] = (...t2) => e.handleCancel && e.handleCancel(...t2)) }, toDisplayString(e.t("el.datepicker.cancel")), 1), createVNode("button", { type: "button", class: "el-time-panel__btn confirm", onClick: t[2] || (t[2] = (t2) => e.handleConfirm()) }, toDisplayString(e.t("el.datepicker.confirm")), 1)])])) : createCommentVNode("v-if", true)]), _: 1 }, 8, ["name"]);
}, Ra.__file = "packages/time-picker/src/time-picker-com/panel-time-pick.vue";
var Wa = (e, t) => {
  const l = [];
  for (let a = e; a <= t; a++)
    l.push(a);
  return l;
};
var ja = defineComponent({ components: { TimeSpinner: Aa }, props: { visible: Boolean, actualVisible: Boolean, parsedValue: { type: [Array, String] }, format: { type: String, default: "" } }, emits: ["pick", "select-range", "set-picker-option"], setup(e, t) {
  const a = computed(() => e.parsedValue[0]), o = computed(() => e.parsedValue[1]), i = Pa(e), r = computed(() => e.format.includes("ss")), s = computed(() => e.format.includes("A") ? "A" : e.format.includes("a") ? "a" : ""), u = ref([]), d = ref([]), c = (e2, l) => {
    t.emit("pick", [e2, l], true);
  }, p = computed(() => a.value > o.value), h2 = ref([0, 2]), v = computed(() => r.value ? 11 : 8), m = (e2, t2) => {
    const l = M ? M(e2) : [], n = e2 === "start", i2 = (t2 || (n ? o.value : a.value)).hour(), r2 = n ? Wa(i2 + 1, 23) : Wa(0, i2 - 1);
    return (0, import_union.default)(l, r2);
  }, f = (e2, t2, l) => {
    const n = T ? T(e2, t2) : [], i2 = t2 === "start", r2 = l || (i2 ? o.value : a.value);
    if (e2 !== r2.hour())
      return n;
    const s2 = r2.minute(), u2 = i2 ? Wa(s2 + 1, 59) : Wa(0, s2 - 1);
    return (0, import_union.default)(n, u2);
  }, g = (e2, t2, l, n) => {
    const i2 = I ? I(e2, t2, l) : [], r2 = l === "start", s2 = n || (r2 ? o.value : a.value), u2 = s2.hour(), d2 = s2.minute();
    if (e2 !== u2 || t2 !== d2)
      return i2;
    const c2 = s2.second(), p2 = r2 ? Wa(c2 + 1, 59) : Wa(0, c2 - 1);
    return (0, import_union.default)(i2, p2);
  }, b = (e2) => e2.map((t2, l) => C(e2[0], e2[1], l === 0 ? "start" : "end")), { getAvaliableHours: y, getAvaliableMinutes: k, getAvaliableSeconds: x } = Ba(m, f, g), C = (e2, t2, l) => {
    const a2 = { hour: y, minute: k, second: x }, n = l === "start";
    let o2 = n ? e2 : t2;
    const i2 = n ? t2 : e2;
    return ["hour", "minute", "second"].forEach((e3) => {
      if (a2[e3]) {
        let t3;
        const r2 = a2[e3];
        if (t3 = e3 === "minute" ? r2(o2.hour(), l, i2) : e3 === "second" ? r2(o2.hour(), o2.minute(), l, i2) : r2(l, i2), t3 && t3.length && !t3.includes(o2[e3]())) {
          const l2 = n ? 0 : t3.length - 1;
          o2 = o2[e3](t3[l2]);
        }
      }
    }), o2;
  };
  t.emit("set-picker-option", ["formatToString", (t2) => t2 ? Array.isArray(t2) ? t2.map((t3) => t3.format(e.format)) : t2.format(e.format) : null]), t.emit("set-picker-option", ["parseUserInput", (t2) => t2 ? Array.isArray(t2) ? t2.map((t3) => (0, import_dayjs.default)(t3, e.format)) : (0, import_dayjs.default)(t2, e.format) : null]), t.emit("set-picker-option", ["isValidValue", (e2) => {
    const t2 = e2.map((e3) => (0, import_dayjs.default)(e3)), l = b(t2);
    return t2[0].isSame(l[0]) && t2[1].isSame(l[1]);
  }]), t.emit("set-picker-option", ["handleKeydown", (e2) => {
    const t2 = e2.code;
    if (t2 === Dt.left || t2 === Dt.right) {
      return ((e3) => {
        const t3 = r.value ? [0, 3, 6, 11, 14, 17] : [0, 3, 8, 11], l = ["hours", "minutes"].concat(r.value ? ["seconds"] : []), a2 = (t3.indexOf(h2.value[0]) + e3 + t3.length) % t3.length, n = t3.length / 2;
        a2 < n ? w.start_emitSelectRange(l[a2]) : w.end_emitSelectRange(l[a2 - n]);
      })(t2 === Dt.left ? -1 : 1), void e2.preventDefault();
    }
    if (t2 === Dt.up || t2 === Dt.down) {
      const l = t2 === Dt.up ? -1 : 1, a2 = h2.value[0] < v.value ? "start" : "end";
      return w[a2 + "_scrollDown"](l), void e2.preventDefault();
    }
  }]), t.emit("set-picker-option", ["getDefaultValue", () => Array.isArray(O) ? O.map((e2) => (0, import_dayjs.default)(e2)) : [(0, import_dayjs.default)(O), (0, import_dayjs.default)(O).add(60, "m")]]), t.emit("set-picker-option", ["getRangeAvaliableTime", b]);
  const w = {}, S = inject("EP_PICKER_BASE"), { arrowControl: _, disabledHours: M, disabledMinutes: T, disabledSeconds: I, defaultValue: O } = S.props;
  return { arrowControl: _, onSetOption: (e2) => {
    w[e2[0]] = e2[1];
  }, setMaxSelectionRange: (e2, l) => {
    t.emit("select-range", e2, l, "max"), h2.value = [e2 + v.value, l + v.value];
  }, setMinSelectionRange: (e2, l) => {
    t.emit("select-range", e2, l, "min"), h2.value = [e2, l];
  }, btnConfirmDisabled: p, handleCancel: () => {
    t.emit("pick", i.value, null);
  }, handleConfirm: (e2 = false) => {
    t.emit("pick", [a.value, o.value], e2);
  }, t: Ca, showSeconds: r, minDate: a, maxDate: o, amPmMode: s, handleMinChange: (e2) => {
    c(e2.millisecond(0), o.value);
  }, handleMaxChange: (e2) => {
    c(a.value, e2.millisecond(0));
  }, minSelectableRange: u, maxSelectableRange: d, disabledHours_: m, disabledMinutes_: f, disabledSeconds_: g };
} });
var Ka = { key: 0, class: "el-time-range-picker el-picker-panel" };
var Ya = { class: "el-time-range-picker__content" };
var qa = { class: "el-time-range-picker__cell" };
var Ua = { class: "el-time-range-picker__header" };
var Ga = { class: "el-time-range-picker__cell" };
var Xa = { class: "el-time-range-picker__header" };
var Za = { class: "el-time-panel__footer" };
ja.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("time-spinner");
  return e.actualVisible ? (openBlock(), createBlock("div", Ka, [createVNode("div", Ya, [createVNode("div", qa, [createVNode("div", Ua, toDisplayString(e.t("el.datepicker.startTime")), 1), createVNode("div", { class: [{ "has-seconds": e.showSeconds, "is-arrow": e.arrowControl }, "el-time-range-picker__body el-time-panel__content"] }, [createVNode(i, { ref: "minSpinner", role: "start", "show-seconds": e.showSeconds, "am-pm-mode": e.amPmMode, "arrow-control": e.arrowControl, "spinner-date": e.minDate, "disabled-hours": e.disabledHours_, "disabled-minutes": e.disabledMinutes_, "disabled-seconds": e.disabledSeconds_, onChange: e.handleMinChange, onSetOption: e.onSetOption, onSelectRange: e.setMinSelectionRange }, null, 8, ["show-seconds", "am-pm-mode", "arrow-control", "spinner-date", "disabled-hours", "disabled-minutes", "disabled-seconds", "onChange", "onSetOption", "onSelectRange"])], 2)]), createVNode("div", Ga, [createVNode("div", Xa, toDisplayString(e.t("el.datepicker.endTime")), 1), createVNode("div", { class: [{ "has-seconds": e.showSeconds, "is-arrow": e.arrowControl }, "el-time-range-picker__body el-time-panel__content"] }, [createVNode(i, { ref: "maxSpinner", role: "end", "show-seconds": e.showSeconds, "am-pm-mode": e.amPmMode, "arrow-control": e.arrowControl, "spinner-date": e.maxDate, "disabled-hours": e.disabledHours_, "disabled-minutes": e.disabledMinutes_, "disabled-seconds": e.disabledSeconds_, onChange: e.handleMaxChange, onSetOption: e.onSetOption, onSelectRange: e.setMaxSelectionRange }, null, 8, ["show-seconds", "am-pm-mode", "arrow-control", "spinner-date", "disabled-hours", "disabled-minutes", "disabled-seconds", "onChange", "onSetOption", "onSelectRange"])], 2)])]), createVNode("div", Za, [createVNode("button", { type: "button", class: "el-time-panel__btn cancel", onClick: t[1] || (t[1] = (t2) => e.handleCancel()) }, toDisplayString(e.t("el.datepicker.cancel")), 1), createVNode("button", { type: "button", class: "el-time-panel__btn confirm", disabled: e.btnConfirmDisabled, onClick: t[2] || (t[2] = (t2) => e.handleConfirm()) }, toDisplayString(e.t("el.datepicker.confirm")), 9, ["disabled"])])])) : createCommentVNode("v-if", true);
}, ja.__file = "packages/time-picker/src/time-picker-com/panel-time-range.vue", import_dayjs.default.extend(import_customParseFormat.default);
var Qa = defineComponent({ name: "ElTimePicker", install: null, props: Object.assign(Object.assign({}, Sa), { isRange: { type: Boolean, default: false } }), emits: ["update:modelValue"], setup(e, t) {
  const a = ref(null), n = e.isRange ? "timerange" : "time", o = e.isRange ? ja : Ra, i = Object.assign(Object.assign({}, e), { focus: () => {
    var e2;
    (e2 = a.value) === null || e2 === void 0 || e2.handleFocus();
  } });
  return provide("ElPopperOptions", e.popperOptions), t.expose(i), () => {
    var l;
    const i2 = (l = e.format) !== null && l !== void 0 ? l : "HH:mm:ss";
    return h(Ia, Object.assign(Object.assign({}, e), { format: i2, type: n, ref: a, "onUpdate:modelValue": (e2) => t.emit("update:modelValue", e2) }), { default: (e2) => h(o, e2) });
  };
} });
var Ja = (e) => Array.from(Array(e).keys());
var en = (e) => e.replace(/\W?m{1,2}|\W?ZZ/g, "").replace(/\W?h{1,2}|\W?s{1,3}|\W?a/gi, "").trim();
var tn = (e) => e.replace(/\W?D{1,2}|\W?Do|\W?d{1,4}|\W?M{1,4}|\W?Y{2,4}/g, "").trim();
var ln = Qa;
ln.install = (e) => {
  e.component(ln.name, ln);
}, import_dayjs.default.extend(import_localeData.default);
var an = defineComponent({ props: { selectedDay: { type: Object }, range: { type: Array }, date: { type: Object }, hideHeader: { type: Boolean } }, emits: ["pick"], setup(e, t) {
  const a = ref((0, import_dayjs.default)().localeData().weekdaysShort()), o = (0, import_dayjs.default)(), i = o.$locale().weekStart || 0, r = (t2, l) => {
    let a2;
    return a2 = l === "prev" ? e.date.startOf("month").subtract(1, "month").date(t2) : l === "next" ? e.date.startOf("month").add(1, "month").date(t2) : e.date.date(t2), a2;
  }, s = computed(() => e.range && e.range.length), u = computed(() => {
    let t2 = [];
    if (s.value) {
      const [l, a2] = e.range, n = Ja(a2.date() - l.date() + 1).map((e2, t3) => ({ text: l.date() + t3, type: "current" }));
      let o2 = n.length % 7;
      o2 = o2 === 0 ? 0 : 7 - o2;
      const i2 = Ja(o2).map((e2, t3) => ({ text: t3 + 1, type: "next" }));
      t2 = n.concat(i2);
    } else {
      const l = e.date.startOf("month").day() || 7;
      t2 = [...((e2, t3) => {
        const l2 = e2.subtract(1, "month").endOf("month").date();
        return Ja(t3).map((e3, a3) => l2 - (t3 - a3 - 1));
      })(e.date, l - i).map((e2) => ({ text: e2, type: "prev" })), ...((e2) => {
        const t3 = e2.daysInMonth();
        return Ja(t3).map((e3, t4) => t4 + 1);
      })(e.date).map((e2) => ({ text: e2, type: "current" }))];
      const a2 = Ja(42 - t2.length).map((e2, t3) => ({ text: t3 + 1, type: "next" }));
      t2 = t2.concat(a2);
    }
    return ((e2) => Ja(e2.length / 7).map((t3, l) => {
      const a2 = 7 * l;
      return e2.slice(a2, a2 + 7);
    }))(t2);
  }), d = computed(() => {
    const e2 = i;
    return e2 === 0 ? a.value : a.value.slice(e2).concat(a.value.slice(0, e2));
  });
  return { isInRange: s, weekDays: d, rows: u, getCellClass: ({ text: t2, type: l }) => {
    const a2 = [l];
    if (l === "current") {
      const n = r(t2, l);
      n.isSame(e.selectedDay, "day") && a2.push("is-selected"), n.isSame(o, "day") && a2.push("is-today");
    }
    return a2;
  }, pickDay: ({ text: e2, type: l }) => {
    const a2 = r(e2, l);
    t.emit("pick", a2);
  }, getSlotData: ({ text: t2, type: l }) => {
    const a2 = r(t2, l);
    return { isSelected: a2.isSame(e.selectedDay), type: l + "-month", day: a2.format("YYYY-MM-DD"), date: a2.toDate() };
  } };
} });
var nn = { key: 0 };
var on = { class: "el-calendar-day" };
an.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("table", { class: { "el-calendar-table": true, "is-range": e.isInRange }, cellspacing: "0", cellpadding: "0" }, [e.hideHeader ? createCommentVNode("v-if", true) : (openBlock(), createBlock("thead", nn, [(openBlock(true), createBlock(Fragment, null, renderList(e.weekDays, (e2) => (openBlock(), createBlock("th", { key: e2 }, toDisplayString(e2), 1))), 128))])), createVNode("tbody", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.rows, (t2, l2) => (openBlock(), createBlock("tr", { key: l2, class: { "el-calendar-table__row": true, "el-calendar-table__row--hide-border": l2 === 0 && e.hideHeader } }, [(openBlock(true), createBlock(Fragment, null, renderList(t2, (t3, l3) => (openBlock(), createBlock("td", { key: l3, class: e.getCellClass(t3), onClick: (l4) => e.pickDay(t3) }, [createVNode("div", on, [renderSlot(e.$slots, "dateCell", { data: e.getSlotData(t3) }, () => [createVNode("span", null, toDisplayString(t3.text), 1)])])], 10, ["onClick"]))), 128))], 2))), 128))])], 2);
}, an.__file = "packages/calendar/src/date-table.vue";
var rn = defineComponent({ name: "ElCalendar", components: { DateTable: an, ElButton: ma, ElButtonGroup: ba }, props: { modelValue: { type: Date }, range: { type: Array, validator: (e) => !!Array.isArray(e) && (e.length === 2 && e.every((e2) => e2 instanceof Date)) } }, emits: ["input", "update:modelValue"], setup(e, t) {
  const a = ref(null), o = (0, import_dayjs.default)(), i = computed(() => c.value.subtract(1, "month")), r = computed(() => (0, import_dayjs.default)(c.value).format("YYYY-MM")), s = computed(() => c.value.add(1, "month")), u = computed(() => {
    const e2 = "el.datepicker.month" + c.value.format("M");
    return `${c.value.year()} ${Ca("el.datepicker.year")} ${Ca(e2)}`;
  }), d = computed({ get: () => e.modelValue ? c.value : a.value, set(e2) {
    a.value = e2;
    const l = e2.toDate();
    t.emit("input", l), t.emit("update:modelValue", l);
  } }), c = computed(() => e.modelValue ? (0, import_dayjs.default)(e.modelValue) : d.value ? d.value : p.value.length ? p.value[0][0] : o), p = computed(() => {
    if (!e.range)
      return [];
    const t2 = e.range.map((e2) => (0, import_dayjs.default)(e2)), [l, a2] = t2;
    if (l.isAfter(a2))
      return console.warn("[ElementCalendar]end time should be greater than start time"), [];
    if (l.isSame(a2, "month"))
      return [[l.startOf("week"), a2.endOf("week")]];
    {
      if (l.add(1, "month").month() !== a2.month())
        return console.warn("[ElementCalendar]start time and end time interval must not exceed two months"), [];
      const e2 = a2.startOf("month"), t3 = e2.startOf("week");
      let n = e2;
      return e2.isSame(t3, "month") || (n = e2.endOf("week").add(1, "day")), [[l.startOf("week"), l.endOf("month")], [n, a2.endOf("week")]];
    }
  }), h2 = (e2) => {
    d.value = e2;
  };
  return { selectedDay: a, curMonthDatePrefix: r, i18nDate: u, realSelectedDay: d, date: c, validatedRange: p, pickDay: h2, selectDate: (e2) => {
    let t2;
    t2 = e2 === "prev-month" ? i.value : e2 === "next-month" ? s.value : o, t2.isSame(c.value, "day") || h2(t2);
  }, t: Ca };
} });
var sn = { class: "el-calendar" };
var un = { class: "el-calendar__header" };
var dn = { class: "el-calendar__title" };
var cn = { key: 0, class: "el-calendar__button-group" };
var pn = { key: 0, class: "el-calendar__body" };
var hn = { key: 1, class: "el-calendar__body" };
rn.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-button"), r = resolveComponent("el-button-group"), p = resolveComponent("date-table");
  return openBlock(), createBlock("div", sn, [createVNode("div", un, [createVNode("div", dn, toDisplayString(e.i18nDate), 1), e.validatedRange.length === 0 ? (openBlock(), createBlock("div", cn, [createVNode(r, null, { default: withCtx(() => [createVNode(i, { size: "mini", onClick: t[1] || (t[1] = (t2) => e.selectDate("prev-month")) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.prevMonth")), 1)]), _: 1 }), createVNode(i, { size: "mini", onClick: t[2] || (t[2] = (t2) => e.selectDate("today")) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.today")), 1)]), _: 1 }), createVNode(i, { size: "mini", onClick: t[3] || (t[3] = (t2) => e.selectDate("next-month")) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.nextMonth")), 1)]), _: 1 })]), _: 1 })])) : createCommentVNode("v-if", true)]), e.validatedRange.length === 0 ? (openBlock(), createBlock("div", pn, [createVNode(p, { date: e.date, "selected-day": e.realSelectedDay, onPick: e.pickDay }, createSlots({ _: 2 }, [e.$slots.dateCell ? { name: "dateCell", fn: withCtx((t2) => [renderSlot(e.$slots, "dateCell", t2)]) } : void 0]), 1032, ["date", "selected-day", "onPick"])])) : (openBlock(), createBlock("div", hn, [(openBlock(true), createBlock(Fragment, null, renderList(e.validatedRange, (t2, l2) => (openBlock(), createBlock(p, { key: l2, date: t2[0], "selected-day": e.realSelectedDay, range: t2, "hide-header": l2 !== 0, onPick: e.pickDay }, createSlots({ _: 2 }, [e.$slots.dateCell ? { name: "dateCell", fn: withCtx((t3) => [renderSlot(e.$slots, "dateCell", t3)]) } : void 0]), 1032, ["date", "selected-day", "range", "hide-header", "onPick"]))), 128))]))]);
}, rn.__file = "packages/calendar/src/index.vue", rn.install = (e) => {
  e.component(rn.name, rn);
};
var vn = rn;
var mn = defineComponent({ name: "ElCard", props: { header: { type: String, default: "" }, bodyStyle: { type: [String, Object, Array], default: "" }, shadow: { type: String, default: "" } } });
var fn2 = { key: 0, class: "el-card__header" };
mn.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-card", e.shadow ? "is-" + e.shadow + "-shadow" : "is-always-shadow"] }, [e.$slots.header || e.header ? (openBlock(), createBlock("div", fn2, [renderSlot(e.$slots, "header", {}, () => [createTextVNode(toDisplayString(e.header), 1)])])) : createCommentVNode("v-if", true), createVNode("div", { class: "el-card__body", style: e.bodyStyle }, [renderSlot(e.$slots, "default")], 4)], 2);
}, mn.__file = "packages/card/src/index.vue", mn.install = (e) => {
  e.component(mn.name, mn);
};
var gn = mn;
var bn = defineComponent({ name: "ElCarousel", props: { initialIndex: { type: Number, default: 0 }, height: { type: String, default: "" }, trigger: { type: String, default: "hover" }, autoplay: { type: Boolean, default: true }, interval: { type: Number, default: 3e3 }, indicatorPosition: { type: String, default: "" }, indicator: { type: Boolean, default: true }, arrow: { type: String, default: "hover" }, type: { type: String, default: "" }, loop: { type: Boolean, default: true }, direction: { type: String, default: "horizontal", validator: (e) => ["horizontal", "vertical"].includes(e) }, pauseOnHover: { type: Boolean, default: true } }, emits: ["change"], setup(e, { emit: t }) {
  const s = reactive({ activeIndex: -1, containerWidth: 0, timer: null, hover: false }), u = ref(null), d = ref([]), c = ref(0), p = ref(0), h2 = computed(() => e.arrow !== "never" && e.direction !== "vertical"), v = computed(() => d.value.some((e2) => e2.label.toString().length > 0)), m = computed(() => {
    const t2 = ["el-carousel", "el-carousel--" + e.direction];
    return e.type === "card" && t2.push("el-carousel--card"), t2;
  }), f = computed(() => {
    const t2 = ["el-carousel__indicators", "el-carousel__indicators--" + e.direction];
    return v.value && t2.push("el-carousel__indicators--labels"), e.indicatorPosition !== "outside" && e.type !== "card" || t2.push("el-carousel__indicators--outside"), t2;
  }), g = (0, import_throttle.default)((e2) => {
    C(e2);
  }, 300, { trailing: true }), b = (0, import_throttle.default)((t2) => {
    !function(t3) {
      e.trigger === "hover" && t3 !== s.activeIndex && (s.activeIndex = t3);
    }(t2);
  }, 300);
  function y() {
    s.timer && (clearInterval(s.timer), s.timer = null);
  }
  function k() {
    e.interval <= 0 || !e.autoplay || s.timer || (s.timer = setInterval(() => x(), e.interval));
  }
  const x = () => {
    s.activeIndex < d.value.length - 1 ? s.activeIndex = s.activeIndex + 1 : e.loop && (s.activeIndex = 0);
  };
  function C(t2) {
    if (typeof t2 == "string") {
      const e2 = d.value.filter((e3) => e3.name === t2);
      e2.length > 0 && (t2 = d.value.indexOf(e2[0]));
    }
    if (t2 = Number(t2), isNaN(t2) || t2 !== Math.floor(t2))
      return void console.warn("[Element Warn][Carousel]index must be an integer.");
    let l = d.value.length;
    const a = s.activeIndex;
    s.activeIndex = t2 < 0 ? e.loop ? l - 1 : 0 : t2 >= l ? e.loop ? 0 : l - 1 : t2, a === s.activeIndex && S(a);
  }
  function S(e2) {
    d.value.forEach((t2, l) => {
      t2.translateItem(l, s.activeIndex, e2);
    });
  }
  function E() {
    C(s.activeIndex + 1);
  }
  return watch(() => s.activeIndex, (e2, l) => {
    S(l), l > -1 && t("change", e2, l);
  }), watch(() => e.autoplay, (e2) => {
    e2 ? k() : y();
  }), watch(() => e.loop, () => {
    C(s.activeIndex);
  }), onMounted(() => {
    nextTick(() => {
      vt(u.value, S), u.value && (c.value = u.value.offsetWidth, p.value = u.value.offsetHeight), e.initialIndex < d.value.length && e.initialIndex >= 0 && (s.activeIndex = e.initialIndex), k();
    });
  }), onBeforeUnmount(() => {
    u.value && mt(u.value, S), y();
  }), provide("injectCarouselScope", { direction: e.direction, offsetWidth: c, offsetHeight: p, type: e.type, items: d, loop: e.loop, addItem: function(e2) {
    d.value.push(e2);
  }, removeItem: function(e2) {
    const t2 = d.value.findIndex((t3) => t3.uid === e2);
    t2 !== -1 && (d.value.splice(t2, 1), s.activeIndex === t2 && E());
  }, setActiveItem: C }), { data: s, props: e, items: d, arrowDisplay: h2, carouselClasses: m, indicatorsClasses: f, hasLabel: v, handleMouseEnter: function() {
    s.hover = true, e.pauseOnHover && y();
  }, handleMouseLeave: function() {
    s.hover = false, k();
  }, handleIndicatorClick: function(e2) {
    s.activeIndex = e2;
  }, throttledArrowClick: g, throttledIndicatorHover: b, handleButtonEnter: function(t2) {
    e.direction !== "vertical" && d.value.forEach((e2, l) => {
      t2 === function(e3, t3) {
        const l2 = d.value.length;
        return t3 === l2 - 1 && e3.inStage && d.value[0].active || e3.inStage && d.value[t3 + 1] && d.value[t3 + 1].active ? "left" : !!(t3 === 0 && e3.inStage && d.value[l2 - 1].active || e3.inStage && d.value[t3 - 1] && d.value[t3 - 1].active) && "right";
      }(e2, l) && (e2.hover = true);
    });
  }, handleButtonLeave: function() {
    e.direction !== "vertical" && d.value.forEach((e2) => {
      e2.hover = false;
    });
  }, prev: function() {
    C(s.activeIndex - 1);
  }, next: E, setActiveItem: C, root: u };
} });
var yn = createVNode("i", { class: "el-icon-arrow-left" }, null, -1);
var kn = createVNode("i", { class: "el-icon-arrow-right" }, null, -1);
var xn = { class: "el-carousel__button" };
var Cn = { key: 0 };
bn.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { ref: "root", class: e.carouselClasses, onMouseenter: t[7] || (t[7] = withModifiers((...t2) => e.handleMouseEnter && e.handleMouseEnter(...t2), ["stop"])), onMouseleave: t[8] || (t[8] = withModifiers((...t2) => e.handleMouseLeave && e.handleMouseLeave(...t2), ["stop"])) }, [createVNode("div", { class: "el-carousel__container", style: { height: e.height } }, [e.arrowDisplay ? (openBlock(), createBlock(Transition, { key: 0, name: "carousel-arrow-left" }, { default: withCtx(() => [withDirectives(createVNode("button", { type: "button", class: "el-carousel__arrow el-carousel__arrow--left", onMouseenter: t[1] || (t[1] = (t2) => e.handleButtonEnter("left")), onMouseleave: t[2] || (t[2] = (...t2) => e.handleButtonLeave && e.handleButtonLeave(...t2)), onClick: t[3] || (t[3] = withModifiers((t2) => e.throttledArrowClick(e.data.activeIndex - 1), ["stop"])) }, [yn], 544), [[vShow, (e.arrow === "always" || e.data.hover) && (e.props.loop || e.data.activeIndex > 0)]])]), _: 1 })) : createCommentVNode("v-if", true), e.arrowDisplay ? (openBlock(), createBlock(Transition, { key: 1, name: "carousel-arrow-right" }, { default: withCtx(() => [withDirectives(createVNode("button", { type: "button", class: "el-carousel__arrow el-carousel__arrow--right", onMouseenter: t[4] || (t[4] = (t2) => e.handleButtonEnter("right")), onMouseleave: t[5] || (t[5] = (...t2) => e.handleButtonLeave && e.handleButtonLeave(...t2)), onClick: t[6] || (t[6] = withModifiers((t2) => e.throttledArrowClick(e.data.activeIndex + 1), ["stop"])) }, [kn], 544), [[vShow, (e.arrow === "always" || e.data.hover) && (e.props.loop || e.data.activeIndex < e.items.length - 1)]])]), _: 1 })) : createCommentVNode("v-if", true), renderSlot(e.$slots, "default")], 4), e.indicatorPosition !== "none" ? (openBlock(), createBlock("ul", { key: 0, class: e.indicatorsClasses }, [(openBlock(true), createBlock(Fragment, null, renderList(e.items, (t2, l2) => (openBlock(), createBlock("li", { key: l2, class: ["el-carousel__indicator", "el-carousel__indicator--" + e.direction, { "is-active": l2 === e.data.activeIndex }], onMouseenter: (t3) => e.throttledIndicatorHover(l2), onClick: withModifiers((t3) => e.handleIndicatorClick(l2), ["stop"]) }, [createVNode("button", xn, [e.hasLabel ? (openBlock(), createBlock("span", Cn, toDisplayString(t2.label), 1)) : createCommentVNode("v-if", true)])], 42, ["onMouseenter", "onClick"]))), 128))], 2)) : createCommentVNode("v-if", true)], 34);
}, bn.__file = "packages/carousel/src/main.vue", bn.install = (e) => {
  e.component(bn.name, bn);
};
var wn = bn;
var Sn = defineComponent({ name: "ElCarouselItem", props: { name: { type: String, default: "" }, label: { type: [String, Number], default: "" } }, setup(t) {
  const l = getCurrentInstance();
  l.uid;
  const o = reactive({ hover: false, translate: 0, scale: 1, active: false, ready: false, inStage: false, animating: false }), r = inject("injectCarouselScope"), s = computed(() => r.direction), u = computed(() => function(e) {
    const t2 = ["ms-", "webkit-"];
    return ["transform", "transition", "animation"].forEach((l2) => {
      const a = e[l2];
      l2 && a && t2.forEach((t3) => {
        e[t3 + l2] = a;
      });
    }), e;
  }({ transform: `${s.value === "vertical" ? "translateY" : "translateX"}(${o.translate}px) scale(${o.scale})` }));
  const d = (e, t2, l2) => {
    const a = r.type, n = r.items.value.length;
    if (a !== "card" && l2 !== void 0 && (o.animating = e === t2 || e === l2), e !== t2 && n > 2 && r.loop && (e = function(e2, t3, l3) {
      return t3 === 0 && e2 === l3 - 1 ? -1 : t3 === l3 - 1 && e2 === 0 ? l3 : e2 < t3 - 1 && t3 - e2 >= l3 / 2 ? l3 + 1 : e2 > t3 + 1 && e2 - t3 >= l3 / 2 ? -2 : e2;
    }(e, t2, n)), a === "card")
      s.value === "vertical" && console.warn("[Element Warn][Carousel]vertical direction is not supported in card mode"), o.inStage = Math.round(Math.abs(e - t2)) <= 1, o.active = e === t2, o.translate = function(e2, t3) {
        const l3 = r.offsetWidth.value;
        return o.inStage ? l3 * (1.17 * (e2 - t3) + 1) / 4 : e2 < t3 ? -1.83 * l3 / 4 : 3.83 * l3 / 4;
      }(e, t2), o.scale = o.active ? 1 : 0.83;
    else {
      o.active = e === t2;
      const l3 = s.value === "vertical";
      o.translate = function(e2, t3, l4) {
        return r[l4 ? "offsetHeight" : "offsetWidth"].value * (e2 - t3);
      }(e, t2, l3);
    }
    o.ready = true;
  };
  return onMounted(() => {
    r.addItem && r.addItem(Object.assign(Object.assign(Object.assign({ uid: l.uid }, t), toRefs(o)), { translateItem: d }));
  }), onUnmounted(() => {
    r.removeItem && r.removeItem(l.uid);
  }), { data: o, itemStyle: u, translateItem: d, type: r.type, handleItemClick: function() {
    if (r && r.type === "card") {
      const e = r.items.value.map((e2) => e2.uid).indexOf(l.uid);
      r.setActiveItem(e);
    }
  } };
} });
var _n = { key: 0, class: "el-carousel__mask" };
Sn.render = function(e, t, l, a, n, o) {
  return withDirectives((openBlock(), createBlock("div", { class: ["el-carousel__item", { "is-active": e.data.active, "el-carousel__item--card": e.type === "card", "is-in-stage": e.data.inStage, "is-hover": e.data.hover, "is-animating": e.data.animating }], style: e.itemStyle, onClick: t[1] || (t[1] = (...t2) => e.handleItemClick && e.handleItemClick(...t2)) }, [e.type === "card" ? withDirectives((openBlock(), createBlock("div", _n, null, 512)), [[vShow, !e.data.active]]) : createCommentVNode("v-if", true), renderSlot(e.$slots, "default")], 6)), [[vShow, e.data.ready]]);
}, Sn.__file = "packages/carousel/src/item.vue", Sn.install = (e) => {
  e.component(Sn.name, Sn);
};
var En = Sn;
var Mn = () => {
  const e = Xe(), t = inject("elForm", {}), l = inject("elFormItem", {}), a = inject("CheckboxGroup", {}), o = computed(() => a && (a == null ? void 0 : a.name) === "ElCheckboxGroup"), i = computed(() => l.size);
  return { isGroup: o, checkboxGroup: a, elForm: t, ELEMENT: e, elFormItemSize: i, elFormItem: l };
};
var Tn = (t) => {
  const { model: a, isLimitExceeded: i } = ((t2) => {
    const a2 = ref(false), { emit: o } = getCurrentInstance(), { isGroup: i2, checkboxGroup: r2 } = Mn(), s2 = ref(false), u2 = computed(() => {
      var e;
      return r2 ? (e = r2.modelValue) === null || e === void 0 ? void 0 : e.value : t2.modelValue;
    });
    return { model: computed({ get() {
      var e;
      return i2.value ? u2.value : (e = t2.modelValue) !== null && e !== void 0 ? e : a2.value;
    }, set(e) {
      var t3;
      i2.value && Array.isArray(e) ? (s2.value = false, r2.min !== void 0 && e.length < r2.min.value && (s2.value = true), r2.max !== void 0 && e.length > r2.max.value && (s2.value = true), s2.value === false && ((t3 = r2 == null ? void 0 : r2.changeEvent) === null || t3 === void 0 || t3.call(r2, e))) : (o(Gt, e), a2.value = e);
    } }), isLimitExceeded: s2 };
  })(t), { focus: r, size: s, isChecked: u, checkboxSize: d } = ((e, { model: t2 }) => {
    const { isGroup: a2, checkboxGroup: o, elFormItemSize: i2, ELEMENT: r2 } = Mn(), s2 = ref(false), u2 = computed(() => {
      var e2;
      return ((e2 = o == null ? void 0 : o.checkboxGroupSize) === null || e2 === void 0 ? void 0 : e2.value) || i2.value || r2.size;
    });
    return { isChecked: computed(() => {
      const l = t2.value;
      return Ne(l) === "[object Boolean]" ? l : Array.isArray(l) ? l.includes(e.label) : l != null ? l === e.trueLabel : void 0;
    }), focus: s2, size: u2, checkboxSize: computed(() => {
      var t3;
      const l = e.size || i2.value || r2.size;
      return a2.value && ((t3 = o == null ? void 0 : o.checkboxGroupSize) === null || t3 === void 0 ? void 0 : t3.value) || l;
    }) };
  })(t, { model: a }), { isDisabled: c } = ((e, { model: t2, isChecked: l }) => {
    const { elForm: a2, isGroup: o, checkboxGroup: i2 } = Mn(), r2 = computed(() => {
      var e2, a3;
      const n = (e2 = i2.max) === null || e2 === void 0 ? void 0 : e2.value, o2 = (a3 = i2.min) === null || a3 === void 0 ? void 0 : a3.value;
      return !(!n && !o2) && t2.value.length >= n && !l.value || t2.value.length <= o2 && l.value;
    });
    return { isDisabled: computed(() => {
      var t3;
      const l2 = e.disabled || a2.disabled;
      return o.value ? ((t3 = i2.disabled) === null || t3 === void 0 ? void 0 : t3.value) || l2 || r2.value : e.disabled || a2.disabled;
    }), isLimitDisabled: r2 };
  })(t, { model: a, isChecked: u }), { handleChange: p } = ((t2, { isLimitExceeded: l }) => {
    const { elFormItem: a2 } = Mn(), { emit: n } = getCurrentInstance();
    return watch(() => t2.modelValue, (e) => {
      var t3;
      (t3 = a2.formItemMitt) === null || t3 === void 0 || t3.emit("el.form.change", [e]);
    }), { handleChange: function(e) {
      var a3, o;
      if (l.value)
        return;
      const i2 = e.target.checked ? (a3 = t2.trueLabel) === null || a3 === void 0 || a3 : (o = t2.falseLabel) !== null && o !== void 0 && o;
      n("change", i2, e);
    } };
  })(t, { isLimitExceeded: i });
  return ((e, { model: t2 }) => {
    e.checked && (Array.isArray(t2.value) && !t2.value.includes(e.label) ? t2.value.push(e.label) : t2.value = e.trueLabel || true);
  })(t, { model: a }), { isChecked: u, isDisabled: c, checkboxSize: d, model: a, handleChange: p, focus: r, size: s };
};
var In = defineComponent({ name: "ElCheckbox", props: { modelValue: { type: [Boolean, Number, String], default: () => {
} }, label: { type: [Boolean, Number, String] }, indeterminate: Boolean, disabled: Boolean, checked: Boolean, name: { type: String, default: void 0 }, trueLabel: { type: [String, Number], default: void 0 }, falseLabel: { type: [String, Number], default: void 0 }, id: { type: String, default: void 0 }, controls: { type: String, default: void 0 }, border: Boolean, size: { type: String, validator: Qt } }, emits: [Gt, "change"], setup: (e) => Tn(e) });
var On = createVNode("span", { class: "el-checkbox__inner" }, null, -1);
var Nn = { key: 0, class: "el-checkbox__label" };
In.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("label", { id: e.id, class: ["el-checkbox", [e.border && e.checkboxSize ? "el-checkbox--" + e.checkboxSize : "", { "is-disabled": e.isDisabled }, { "is-bordered": e.border }, { "is-checked": e.isChecked }]], "aria-controls": e.indeterminate ? e.controls : null }, [createVNode("span", { class: ["el-checkbox__input", { "is-disabled": e.isDisabled, "is-checked": e.isChecked, "is-indeterminate": e.indeterminate, "is-focus": e.focus }], tabindex: !!e.indeterminate && 0, role: !!e.indeterminate && "checkbox", "aria-checked": !!e.indeterminate && "mixed" }, [On, e.trueLabel || e.falseLabel ? withDirectives((openBlock(), createBlock("input", { key: 0, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.model = t2), checked: e.isChecked, class: "el-checkbox__original", type: "checkbox", "aria-hidden": e.indeterminate ? "true" : "false", name: e.name, disabled: e.isDisabled, "true-value": e.trueLabel, "false-value": e.falseLabel, onChange: t[2] || (t[2] = (...t2) => e.handleChange && e.handleChange(...t2)), onFocus: t[3] || (t[3] = (t2) => e.focus = true), onBlur: t[4] || (t[4] = (t2) => e.focus = false) }, null, 40, ["checked", "aria-hidden", "name", "disabled", "true-value", "false-value"])), [[vModelCheckbox, e.model]]) : withDirectives((openBlock(), createBlock("input", { key: 1, "onUpdate:modelValue": t[5] || (t[5] = (t2) => e.model = t2), class: "el-checkbox__original", type: "checkbox", "aria-hidden": e.indeterminate ? "true" : "false", disabled: e.isDisabled, value: e.label, name: e.name, onChange: t[6] || (t[6] = (...t2) => e.handleChange && e.handleChange(...t2)), onFocus: t[7] || (t[7] = (t2) => e.focus = true), onBlur: t[8] || (t[8] = (t2) => e.focus = false) }, null, 40, ["aria-hidden", "disabled", "value", "name"])), [[vModelCheckbox, e.model]])], 10, ["tabindex", "role", "aria-checked"]), e.$slots.default || e.label ? (openBlock(), createBlock("span", Nn, [renderSlot(e.$slots, "default"), e.$slots.default ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(e.label), 1)], 2112))])) : createCommentVNode("v-if", true)], 10, ["id", "aria-controls"]);
}, In.__file = "packages/checkbox/src/checkbox.vue", In.install = (e) => {
  e.component(In.name, In);
};
var Dn = In;
var Vn = () => {
  const e = Xe(), t = inject("elForm", {}), a = inject("elFormItem", {}), o = inject("RadioGroup", {}), i = ref(false), r = computed(() => (o == null ? void 0 : o.name) === "ElRadioGroup"), s = computed(() => a.size || e.size);
  return { isGroup: r, focus: i, radioGroup: o, elForm: t, ELEMENT: e, elFormItemSize: s };
};
var Bn = (e, { isGroup: t, radioGroup: l, elForm: a, model: o }) => {
  const i = computed(() => t.value ? l.disabled || e.disabled || a.disabled : e.disabled || a.disabled), r = computed(() => i.value || t.value && o.value !== e.label ? -1 : 0);
  return { isDisabled: i, tabIndex: r };
};
var Pn = defineComponent({ name: "ElRadio", componentName: "ElRadio", props: { modelValue: { type: [String, Number, Boolean], default: "" }, label: { type: [String, Number, Boolean], default: "" }, disabled: Boolean, name: { type: String, default: "" }, border: Boolean, size: { type: String, validator: Qt } }, emits: [Gt, "change"], setup(e, t) {
  const { isGroup: a, radioGroup: o, elFormItemSize: i, ELEMENT: r, focus: s, elForm: u } = Vn(), d = ref(), c = computed({ get: () => a.value ? o.modelValue : e.modelValue, set(l) {
    a.value ? o.changeEvent(l) : t.emit(Gt, l), d.value.checked = e.modelValue === e.label;
  } }), { tabIndex: p, isDisabled: h2 } = Bn(e, { isGroup: a, radioGroup: o, elForm: u, model: c }), v = computed(() => {
    const t2 = e.size || i.value || r.size;
    return a.value && o.radioGroupSize || t2;
  });
  return { focus: s, isGroup: a, isDisabled: h2, model: c, tabIndex: p, radioSize: v, handleChange: function() {
    nextTick(() => {
      t.emit("change", c.value);
    });
  }, radioRef: d };
} });
var An = createVNode("span", { class: "el-radio__inner" }, null, -1);
Pn.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("label", { class: ["el-radio", { ["el-radio--" + (e.radioSize || "")]: e.border && e.radioSize, "is-disabled": e.isDisabled, "is-focus": e.focus, "is-bordered": e.border, "is-checked": e.model === e.label }], role: "radio", "aria-checked": e.model === e.label, "aria-disabled": e.isDisabled, tabindex: e.tabIndex, onKeydown: t[6] || (t[6] = withKeys(withModifiers((t2) => e.model = e.isDisabled ? e.model : e.label, ["stop", "prevent"]), ["space"])) }, [createVNode("span", { class: ["el-radio__input", { "is-disabled": e.isDisabled, "is-checked": e.model === e.label }] }, [An, withDirectives(createVNode("input", { ref: "radioRef", "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.model = t2), class: "el-radio__original", value: e.label, type: "radio", "aria-hidden": "true", name: e.name, disabled: e.isDisabled, tabindex: "-1", onFocus: t[2] || (t[2] = (t2) => e.focus = true), onBlur: t[3] || (t[3] = (t2) => e.focus = false), onChange: t[4] || (t[4] = (...t2) => e.handleChange && e.handleChange(...t2)) }, null, 40, ["value", "name", "disabled"]), [[vModelRadio, e.model]])], 2), createVNode("span", { class: "el-radio__label", onKeydown: t[5] || (t[5] = withModifiers(() => {
  }, ["stop"])) }, [renderSlot(e.$slots, "default", {}, () => [createTextVNode(toDisplayString(e.label), 1)])], 32)], 42, ["aria-checked", "aria-disabled", "tabindex"]);
}, Pn.__file = "packages/radio/src/radio.vue", Pn.install = (e) => {
  e.component(Pn.name, Pn);
};
var zn = Pn;
var Ln;
!function(e) {
  e.CLICK = "click", e.HOVER = "hover";
}(Ln || (Ln = {}));
var Fn = Symbol();
var Rn = defineComponent({ name: "ElCascaderNode", components: { ElCheckbox: Dn, ElRadio: zn, NodeContent: { render() {
  const { node: e, panel: t } = this.$parent, { data: l, label: a } = e, { renderLabelFn: n } = t;
  return h("span", { class: "el-cascader-node__label" }, n ? n({ node: e, data: l }) : a);
} } }, props: { node: { type: Object, required: true }, menuId: String }, emits: ["expand"], setup(e, { emit: t }) {
  const l = inject(Fn), a = computed(() => l.isHoverMenu), o = computed(() => l.config.multiple), i = computed(() => l.config.checkStrictly), r = computed(() => {
    var e2;
    return (e2 = l.checkedNodes[0]) === null || e2 === void 0 ? void 0 : e2.uid;
  }), s = computed(() => e.node.isDisabled), u = computed(() => e.node.isLeaf), d = computed(() => i.value && !u.value || !s.value), c = computed(() => h2(l.expandingNode)), p = computed(() => i.value && l.checkedNodes.some(h2)), h2 = (t2) => {
    var l2;
    const { level: a2, uid: n } = e.node;
    return ((l2 = t2 == null ? void 0 : t2.pathNodes[a2 - 1]) === null || l2 === void 0 ? void 0 : l2.uid) === n;
  }, v = () => {
    c.value || l.expandNode(e.node);
  }, m = () => {
    l.lazyLoad(e.node, () => {
      u.value || v();
    });
  }, f = () => {
    const { node: t2 } = e;
    d.value && !t2.loading && (t2.loaded ? v() : m());
  }, g = (t2) => {
    e.node.loaded ? (((t3) => {
      const { node: a2 } = e;
      t3 !== a2.checked && l.handleCheckChange(a2, t3);
    })(t2), !i.value && v()) : m();
  };
  return { panel: l, isHoverMenu: a, multiple: o, checkStrictly: i, checkedNodeId: r, isDisabled: s, isLeaf: u, expandable: d, inExpandingPath: c, inCheckedPath: p, handleHoverExpand: (e2) => {
    a.value && (f(), !u.value && t("expand", e2));
  }, handleExpand: f, handleClick: () => {
    a.value && !u.value || (!u.value || s.value || i.value || o.value ? f() : g(true));
  }, handleCheck: g };
} });
var $n = createVNode("span", null, null, -1);
var Hn = { key: 2, class: "el-icon-check el-cascader-node__prefix" };
var Wn = { key: 0, class: "el-icon-loading el-cascader-node__postfix" };
var jn = { key: 1, class: "el-icon-arrow-right el-cascader-node__postfix" };
Rn.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-checkbox"), r = resolveComponent("el-radio"), c = resolveComponent("node-content");
  return openBlock(), createBlock("li", { id: `${e.menuId}-${e.node.uid}`, role: "menuitem", "aria-haspopup": !e.isLeaf, "aria-owns": e.isLeaf ? null : e.menuId, "aria-expanded": e.inExpandingPath, tabindex: e.expandable ? -1 : null, class: ["el-cascader-node", e.checkStrictly && "is-selectable", e.inExpandingPath && "in-active-path", e.inCheckedPath && "in-checked-path", e.node.checked && "is-active", !e.expandable && "is-disabled"], onMouseenter: t[3] || (t[3] = (...t2) => e.handleHoverExpand && e.handleHoverExpand(...t2)), onFocus: t[4] || (t[4] = (...t2) => e.handleHoverExpand && e.handleHoverExpand(...t2)), onClick: t[5] || (t[5] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [createCommentVNode(" prefix "), e.multiple ? (openBlock(), createBlock(i, { key: 0, "model-value": e.node.checked, indeterminate: e.node.indeterminate, disabled: e.isDisabled, onClick: t[1] || (t[1] = withModifiers(() => {
  }, ["stop"])), "onUpdate:modelValue": e.handleCheck }, null, 8, ["model-value", "indeterminate", "disabled", "onUpdate:modelValue"])) : e.checkStrictly ? (openBlock(), createBlock(r, { key: 1, "model-value": e.checkedNodeId, label: e.node.uid, disabled: e.isDisabled, "onUpdate:modelValue": e.handleCheck, onClick: t[2] || (t[2] = withModifiers(() => {
  }, ["stop"])) }, { default: withCtx(() => [createCommentVNode("\n        Add an empty element to avoid render label,\n        do not use empty fragment here for https://github.com/vuejs/vue-next/pull/2485\n      "), $n]), _: 1 }, 8, ["model-value", "label", "disabled", "onUpdate:modelValue"])) : e.isLeaf && e.node.checked ? (openBlock(), createBlock("i", Hn)) : createCommentVNode("v-if", true), createCommentVNode(" content "), createVNode(c), createCommentVNode(" postfix "), e.isLeaf ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Fragment, { key: 3 }, [e.node.loading ? (openBlock(), createBlock("i", Wn)) : (openBlock(), createBlock("i", jn))], 2112))], 42, ["id", "aria-haspopup", "aria-owns", "aria-expanded", "tabindex"]);
}, Rn.__file = "packages/cascader-panel/src/node.vue";
var Kn = defineComponent({ name: "ElCascaderMenu", components: { ElScrollbar: Cl, ElCascaderNode: Rn }, props: { nodes: { type: Array, required: true }, index: { type: Number, required: true } }, setup(t) {
  const a = getCurrentInstance(), o = He();
  let i = null, r = null;
  const s = inject(Fn), u = ref(null), d = computed(() => !t.nodes.length), c = computed(() => `cascader-menu-${o}-${t.index}`), p = () => {
    r && (clearTimeout(r), r = null);
  }, h2 = () => {
    u.value && (u.value.innerHTML = "", p());
  };
  return { panel: s, hoverZone: u, isEmpty: d, menuId: c, t: Ca, handleExpand: (e) => {
    i = e.target;
  }, handleMouseMove: (e) => {
    if (s.isHoverMenu && i && u.value)
      if (i.contains(e.target)) {
        p();
        const t2 = a.vnode.el, { left: l } = t2.getBoundingClientRect(), { offsetWidth: n, offsetHeight: o2 } = t2, r2 = e.clientX - l, s2 = i.offsetTop, d2 = s2 + i.offsetHeight;
        u.value.innerHTML = `
          <path style="pointer-events: auto;" fill="transparent" d="M${r2} ${s2} L${n} 0 V${s2} Z" />
          <path style="pointer-events: auto;" fill="transparent" d="M${r2} ${d2} L${n} ${o2} V${d2} Z" />
        `;
      } else
        r || (r = window.setTimeout(h2, s.config.hoverThreshold));
  }, clearHoverZone: h2 };
} });
var Yn = { key: 0, class: "el-cascader-menu__empty-text" };
var qn = { key: 1, ref: "hoverZone", class: "el-cascader-menu__hover-zone" };
Kn.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-cascader-node"), r = resolveComponent("el-scrollbar");
  return openBlock(), createBlock(r, { id: e.menuId, tag: "ul", role: "menu", class: "el-cascader-menu", "wrap-class": "el-cascader-menu__wrap", "view-class": ["el-cascader-menu__list", e.isEmpty && "is-empty"], onMousemove: e.handleMouseMove, onMouseleave: e.clearHoverZone }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.nodes, (t2) => (openBlock(), createBlock(i, { key: t2.uid, node: t2, "menu-id": e.menuId, onExpand: e.handleExpand }, null, 8, ["node", "menu-id", "onExpand"]))), 128)), e.isEmpty ? (openBlock(), createBlock("div", Yn, toDisplayString(e.t("el.cascader.noData")), 1)) : e.panel.isHoverMenu ? (openBlock(), createBlock("svg", qn, null, 512)) : createCommentVNode("v-if", true)]), _: 1 }, 8, ["id", "view-class", "onMousemove", "onMouseleave"]);
}, Kn.__file = "packages/cascader-panel/src/menu.vue";
var Un = 0;
var Gn = class {
  constructor(e, t, l, a = false) {
    this.data = e, this.config = t, this.parent = l, this.root = a, this.uid = Un++, this.checked = false, this.indeterminate = false, this.loading = false;
    const { value: n, label: o, children: i } = t, r = e[i], s = ((e2) => {
      const t2 = [e2];
      let { parent: l2 } = e2;
      for (; l2; )
        t2.unshift(l2), l2 = l2.parent;
      return t2;
    })(this);
    this.level = a ? 0 : l ? l.level + 1 : 1, this.value = e[n], this.label = e[o], this.pathNodes = s, this.pathValues = s.map((e2) => e2.value), this.pathLabels = s.map((e2) => e2.label), this.childrenData = r, this.children = (r || []).map((e2) => new Gn(e2, t, this)), this.loaded = !t.lazy || this.isLeaf || !Qe(r);
  }
  get isDisabled() {
    const { data: e, parent: t, config: l } = this, { disabled: a, checkStrictly: n } = l;
    return (Ee(a) ? a(e, this) : !!e[a]) || !n && (t == null ? void 0 : t.isDisabled);
  }
  get isLeaf() {
    const { data: e, config: t, childrenData: l, loaded: a } = this, { lazy: n, leaf: o } = t, i = Ee(o) ? o(e, this) : e[o];
    return Ge(i) ? !(n && !a) && !Array.isArray(l) : !!i;
  }
  get valueByOption() {
    return this.config.emitPath ? this.pathValues : this.value;
  }
  appendChild(e) {
    const { childrenData: t, children: l } = this, a = new Gn(e, this.config, this);
    return Array.isArray(t) ? t.push(e) : this.childrenData = [e], l.push(a), a;
  }
  calcText(e, t) {
    const l = e ? this.pathLabels.join(t) : this.label;
    return this.text = l, l;
  }
  broadcast(e, ...t) {
    const l = "onParent" + Ae(e);
    this.children.forEach((a) => {
      a && (a.broadcast(e, ...t), a[l] && a[l](...t));
    });
  }
  emit(e, ...t) {
    const { parent: l } = this, a = "onChild" + Ae(e);
    l && (l[a] && l[a](...t), l.emit(e, ...t));
  }
  onParentCheck(e) {
    this.isDisabled || this.setCheckState(e);
  }
  onChildCheck() {
    const { children: e } = this, t = e.filter((e2) => !e2.isDisabled), l = !!t.length && t.every((e2) => e2.checked);
    this.setCheckState(l);
  }
  setCheckState(e) {
    const t = this.children.length, l = this.children.reduce((e2, t2) => e2 + (t2.checked ? 1 : t2.indeterminate ? 0.5 : 0), 0);
    this.checked = this.loaded && this.children.every((e2) => e2.loaded && e2.checked) && e, this.indeterminate = this.loaded && l !== t && l > 0;
  }
  doCheck(e) {
    if (this.checked === e)
      return;
    const { checkStrictly: t, multiple: l } = this.config;
    t || !l ? this.checked = e : (this.broadcast("check", e), this.setCheckState(e), this.emit("check"));
  }
};
var Xn = (e, t) => e.reduce((e2, l) => (l.isLeaf ? e2.push(l) : (!t && e2.push(l), e2 = e2.concat(Xn(l.children, t))), e2), []);
var Zn = class {
  constructor(e, t) {
    this.config = t;
    const l = (e || []).map((e2) => new Gn(e2, this.config));
    this.nodes = l, this.allNodes = Xn(l, false), this.leafNodes = Xn(l, true);
  }
  getNodes() {
    return this.nodes;
  }
  getFlattedNodes(e) {
    return e ? this.leafNodes : this.allNodes;
  }
  appendNode(e, t) {
    const l = t ? t.appendChild(e) : new Gn(e, this.config);
    t || this.nodes.push(l), this.allNodes.push(l), l.isLeaf && this.leafNodes.push(l);
  }
  appendNodes(e, t) {
    e.forEach((e2) => this.appendNode(e2, t));
  }
  getNodeByValue(e, t = false) {
    if (!e && e !== 0)
      return null;
    return this.getFlattedNodes(t).filter((t2) => t2.value === e || (0, import_isEqual.default)(t2.pathValues, e))[0] || null;
  }
  getSameNode(e) {
    if (!e)
      return null;
    return this.getFlattedNodes(false).filter(({ value: t, level: l }) => e.value === t && e.level === l)[0] || null;
  }
};
function Qn(e, t) {
  if (ke)
    return;
  if (!t)
    return void (e.scrollTop = 0);
  const l = [];
  let a = t.offsetParent;
  for (; a !== null && e !== a && e.contains(a); )
    l.push(a), a = a.offsetParent;
  const n = t.offsetTop + l.reduce((e2, t2) => e2 + t2.offsetTop, 0), o = n + t.offsetHeight, i = e.scrollTop, r = i + e.clientHeight;
  n < i ? e.scrollTop = n : o > r && (e.scrollTop = o - e.clientHeight);
}
var Jn = { modelValue: [Number, String, Array], options: { type: Array, default: () => [] }, props: { type: Object, default: () => ({}) } };
var eo = { expandTrigger: Ln.CLICK, multiple: false, checkStrictly: false, emitPath: true, lazy: false, lazyLoad: xe, value: "value", label: "label", children: "children", leaf: "leaf", disabled: "disabled", hoverThreshold: 500 };
var to = (e) => !e.getAttribute("aria-owns");
var lo = (e) => {
  if (!e)
    return 0;
  const t = e.id.split("-");
  return Number(t[t.length - 2]);
};
var ao = (e) => {
  e && (e.focus(), !to(e) && e.click());
};
var no = defineComponent({ name: "ElCascaderPanel", components: { ElCascaderMenu: Kn }, props: Object.assign(Object.assign({}, Jn), { border: { type: Boolean, default: true }, renderLabel: Function }), emits: [Gt, "change", "close", "expand-change"], setup(e, { emit: t, slots: r }) {
  let s = true, u = false;
  const d = ((e2) => computed(() => Object.assign(Object.assign({}, eo), e2.props)))(e), c = ref(null), p = ref([]), h2 = ref(null), v = ref([]), m = ref(null), f = ref([]), g = computed(() => d.value.expandTrigger === Ln.HOVER), b = computed(() => e.renderLabel || r.default), y = (e2, t2) => {
    const l = d.value;
    (e2 = e2 || new Gn({}, l, null, true)).loading = true;
    l.lazyLoad(e2, (l2) => {
      const a = e2.root ? null : e2;
      l2 && c.value.appendNodes(l2, a), e2.loading = false, e2.loaded = true, t2 && t2(l2);
    });
  }, k = (e2, l) => {
    var a;
    const { level: n } = e2, o = v.value.slice(0, n);
    let i;
    e2.isLeaf ? i = e2.pathNodes[n - 2] : (i = e2, o.push(e2.children)), ((a = m.value) === null || a === void 0 ? void 0 : a.uid) !== (i == null ? void 0 : i.uid) && (m.value = e2, v.value = o, !l && t("expand-change", (e2 == null ? void 0 : e2.pathValues) || []));
  }, x = (e2, l, a = true) => {
    const { checkStrictly: n, multiple: o } = d.value, i = f.value[0];
    u = true, !o && (i == null || i.doCheck(false)), e2.doCheck(l), E(), a && !o && !n && t("close");
  }, C = (e2) => c.value.getFlattedNodes(e2), S = (e2) => C(e2).filter((e3) => e3.checked !== false), E = () => {
    var e2;
    const { checkStrictly: t2, multiple: l } = d.value, a = ((e3, t3) => {
      const l2 = t3.slice(0), a2 = l2.map((e4) => e4.uid), n2 = e3.reduce((e4, t4) => {
        const n3 = a2.indexOf(t4.uid);
        return n3 > -1 && (e4.push(t4), l2.splice(n3, 1), a2.splice(n3, 1)), e4;
      }, []);
      return n2.push(...l2), n2;
    })(f.value, S(!t2)), n = a.map((e3) => e3.valueByOption);
    f.value = a, h2.value = l ? n : (e2 = n[0]) !== null && e2 !== void 0 ? e2 : null;
  }, M = (t2 = false, l = false) => {
    const { modelValue: a } = e, { lazy: n, multiple: o, checkStrictly: i } = d.value, r2 = !i;
    if (s && !u && (l || !(0, import_isEqual.default)(a, h2.value)))
      if (n && !t2) {
        const e2 = et(Je(We(a))).map((e3) => c.value.getNodeByValue(e3)).filter((e3) => !!e3 && !e3.loaded && !e3.loading);
        e2.length ? e2.forEach((e3) => {
          y(e3, () => M(false, l));
        }) : M(true, l);
      } else {
        const e2 = et((o ? We(a) : [a]).map((e3) => c.value.getNodeByValue(e3, r2)));
        T(e2, false), h2.value = a;
      }
  }, T = (e2, t2 = true) => {
    const { checkStrictly: l } = d.value, a = f.value, n = e2.filter((e3) => !!e3 && (l || e3.isLeaf)), o = c.value.getSameNode(m.value), i = t2 && o || n[0];
    i ? i.pathNodes.forEach((e3) => k(e3, true)) : m.value = null, a.forEach((e3) => e3.doCheck(false)), n.forEach((e3) => e3.doCheck(true)), f.value = n, nextTick(I);
  }, I = () => {
    ke || p.value.forEach((e2) => {
      const t2 = e2 == null ? void 0 : e2.$el;
      if (t2) {
        Qn(t2.querySelector(".el-scrollbar__wrap"), t2.querySelector(".el-cascader-node.is-active") || t2.querySelector(".el-cascader-node.in-active-path"));
      }
    });
  };
  return provide(Fn, reactive({ config: d, expandingNode: m, checkedNodes: f, isHoverMenu: g, renderLabelFn: b, lazyLoad: y, expandNode: k, handleCheckChange: x })), watch([d, () => e.options], () => {
    const { options: t2 } = e, l = d.value;
    u = false, c.value = new Zn(t2, l), v.value = [c.value.getNodes()], l.lazy && Qe(e.options) ? (s = false, y(null, () => {
      s = true, M(false, true);
    })) : M(false, true);
  }, { deep: true, immediate: true }), watch(() => e.modelValue, () => {
    u = false, M();
  }), watch(h2, (l) => {
    (0, import_isEqual.default)(l, e.modelValue) || (t(Gt, l), t("change", l));
  }), onBeforeUpdate(() => p.value = []), onMounted(() => !Qe(e.modelValue) && M()), { menuList: p, menus: v, checkedNodes: f, handleKeyDown: (e2) => {
    const l = e2.target, { code: a } = e2;
    switch (a) {
      case Dt.up:
      case Dt.down:
        const e3 = a === Dt.up ? -1 : 1;
        ao(((e4, t2) => {
          const { parentNode: l2 } = e4;
          if (!l2)
            return null;
          const a2 = l2.querySelectorAll('.el-cascader-node[tabindex="-1"]');
          return a2[Array.prototype.indexOf.call(a2, e4) + t2] || null;
        })(l, e3));
        break;
      case Dt.left:
        const n = p.value[lo(l) - 1], o = n == null ? void 0 : n.$el.querySelector('.el-cascader-node[aria-expanded="true"]');
        ao(o);
        break;
      case Dt.right:
        const i = p.value[lo(l) + 1], r2 = i == null ? void 0 : i.$el.querySelector('.el-cascader-node[tabindex="-1"]');
        ao(r2);
        break;
      case Dt.enter:
        ((e4) => {
          if (!e4)
            return;
          const t2 = e4.querySelector("input");
          t2 ? t2.click() : to(e4) && e4.click();
        })(l);
        break;
      case Dt.esc:
      case Dt.tab:
        t("close");
    }
  }, handleCheckChange: x, getFlattedNodes: C, getCheckedNodes: S, clearCheckedNodes: () => {
    f.value.forEach((e2) => e2.doCheck(false)), E();
  }, calculateCheckedValue: E, scrollToExpandingNode: I };
} });
no.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-cascader-menu");
  return openBlock(), createBlock("div", { class: ["el-cascader-panel", e.border && "is-bordered"], onKeydown: t[1] || (t[1] = (...t2) => e.handleKeyDown && e.handleKeyDown(...t2)) }, [(openBlock(true), createBlock(Fragment, null, renderList(e.menus, (t2, l2) => (openBlock(), createBlock(i, { key: l2, ref: (t3) => e.menuList[l2] = t3, index: l2, nodes: t2 }, null, 8, ["index", "nodes"]))), 128))], 34);
}, no.__file = "packages/cascader-panel/src/index.vue", no.install = (e) => {
  e.component(no.name, no);
};
var oo = no;
var io = defineComponent({ name: "ElTag", props: { closable: Boolean, type: { type: String, default: "" }, hit: Boolean, disableTransitions: Boolean, color: { type: String, default: "" }, size: { type: String, validator: Qt }, effect: { type: String, default: "light", validator: (e) => ["dark", "light", "plain"].indexOf(e) !== -1 } }, emits: ["close", "click"], setup(e, t) {
  const l = Xe(), a = computed(() => e.size || l.size), o = computed(() => {
    const { type: t2, hit: l2, effect: n } = e;
    return ["el-tag", t2 ? "el-tag--" + t2 : "", a.value ? "el-tag--" + a.value : "", n ? "el-tag--" + n : "", l2 && "is-hit"];
  });
  return { tagSize: a, classes: o, handleClose: (e2) => {
    e2.stopPropagation(), t.emit("close", e2);
  }, handleClick: (e2) => {
    t.emit("click", e2);
  } };
} });
io.render = function(e, t, l, a, n, o) {
  return e.disableTransitions ? (openBlock(), createBlock(Transition, { key: 1, name: "el-zoom-in-center" }, { default: withCtx(() => [createVNode("span", { class: e.classes, style: { backgroundColor: e.color }, onClick: t[4] || (t[4] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [renderSlot(e.$slots, "default"), e.closable ? (openBlock(), createBlock("i", { key: 0, class: "el-tag__close el-icon-close", onClick: t[3] || (t[3] = (...t2) => e.handleClose && e.handleClose(...t2)) })) : createCommentVNode("v-if", true)], 6)]), _: 3 })) : (openBlock(), createBlock("span", { key: 0, class: e.classes, style: { backgroundColor: e.color }, onClick: t[2] || (t[2] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [renderSlot(e.$slots, "default"), e.closable ? (openBlock(), createBlock("i", { key: 0, class: "el-tag__close el-icon-close", onClick: t[1] || (t[1] = (...t2) => e.handleClose && e.handleClose(...t2)) })) : createCommentVNode("v-if", true)], 6));
}, io.__file = "packages/tag/src/index.vue", io.install = (e) => {
  e.component(io.name, io);
};
var ro = io;
var so = { medium: 36, small: 32, mini: 28 };
var uo = { modifiers: [{ name: "arrowPosition", enabled: true, phase: "main", fn: ({ state: e }) => {
  const { modifiersData: t, elements: l, placement: a } = e;
  if (["right", "left"].includes(a))
    return;
  const { reference: n, arrow: o } = l;
  t.arrow.x = t.arrow.x - (n.clientWidth - o.clientWidth) / 2 + 35;
}, requires: ["arrow"] }] };
var co = defineComponent({ name: "ElCascader", components: { ElCascaderPanel: oo, ElInput: gl, ElPopper: Kl, ElScrollbar: Cl, ElTag: ro }, directives: { Clickoutside: Ht }, props: Object.assign(Object.assign({}, Jn), { size: { type: String, validator: Qt }, placeholder: { type: String, default: () => Ca("el.cascader.placeholder") }, disabled: Boolean, clearable: Boolean, filterable: Boolean, filterMethod: { type: Function, default: (e, t) => e.text.includes(t) }, separator: { type: String, default: " / " }, showAllLevels: { type: Boolean, default: true }, collapseTags: Boolean, debounce: { type: Number, default: 300 }, beforeFilter: { type: Function, default: () => true }, popperClass: { type: String, default: "" } }), emits: [Gt, "change", "focus", "blur", "visible-change", "expand-change", "remove-tag"], setup(e, { emit: t }) {
  let a = 0, s = 0;
  const u = Xe(), d = inject("elForm", {}), c = inject("elFormItem", {}), p = ref(null), h2 = ref(null), v = ref(null), m = ref(null), f = ref(null), g = ref(false), b = ref(false), y = ref(false), k = ref(""), x = ref(""), C = ref([]), S = ref([]), _ = computed(() => e.disabled || d.disabled), M = computed(() => e.size || c.size || u.size), T = computed(() => ["small", "mini"].includes(M.value) ? "mini" : "small"), I = computed(() => !!e.props.multiple), O = computed(() => !e.filterable || I.value), N = computed(() => I.value ? x.value : k.value), D = computed(() => {
    var e2;
    return ((e2 = m.value) === null || e2 === void 0 ? void 0 : e2.checkedNodes) || [];
  }), V = computed(() => !(!e.clearable || _.value || y.value || !b.value) && !!D.value.length), B = computed(() => {
    const { showAllLevels: t2, separator: l } = e, a2 = D.value;
    return a2.length ? I.value ? " " : a2[0].calcText(t2, l) : "";
  }), P = computed({ get: () => e.modelValue, set(e2) {
    var l;
    t(Gt, e2), t("change", e2), (l = c.formItemMitt) === null || l === void 0 || l.emit("el.form.change", [e2]);
  } }), A = computed(() => {
    var e2;
    return (e2 = p.value) === null || e2 === void 0 ? void 0 : e2.popperRef;
  }), z = (l) => {
    if (!_.value && (l = l != null ? l : !g.value) !== g.value) {
      if (g.value = l, h2.value.input.setAttribute("aria-expanded", l), l)
        L(), nextTick(m.value.scrollToExpandingNode);
      else if (e.filterable) {
        const { value: e2 } = B;
        k.value = e2, x.value = e2;
      }
      t("visible-change", l);
    }
  }, L = () => {
    nextTick(p.value.update);
  }, F = () => {
    y.value = false;
  }, R = (t2) => {
    const { showAllLevels: l, separator: a2 } = e;
    return { node: t2, key: t2.uid, text: t2.calcText(l, a2), hitState: false, closable: !_.value && !t2.isDisabled };
  }, $ = (e2) => {
    const { node: l } = e2;
    l.doCheck(false), m.value.calculateCheckedValue(), t("remove-tag", l.valueByOption);
  }, H = () => {
    const { filterMethod: t2, showAllLevels: l, separator: a2 } = e, n = m.value.getFlattedNodes(!e.props.checkStrictly).filter((e2) => !e2.isDisabled && (e2.calcText(l, a2), t2(e2, N.value)));
    I.value && C.value.forEach((e2) => {
      e2.hitState = false;
    }), y.value = true, S.value = n, L();
  }, W = () => {
    var e2;
    let t2 = null;
    t2 = y.value && f.value ? f.value.$el.querySelector(".el-cascader__suggestion-item") : (e2 = m.value) === null || e2 === void 0 ? void 0 : e2.$el.querySelector('.el-cascader-node[tabindex="-1"]'), t2 && (t2.focus(), !y.value && t2.click());
  }, j = () => {
    var e2;
    const t2 = h2.value.input, l = v.value, n = (e2 = f.value) === null || e2 === void 0 ? void 0 : e2.$el;
    if (!ke && t2) {
      if (n) {
        n.querySelector(".el-cascader__suggestion-list").style.minWidth = t2.offsetWidth + "px";
      }
      if (l) {
        const { offsetHeight: e3 } = l, n2 = C.value.length > 0 ? Math.max(e3 + 6, a) + "px" : a + "px";
        t2.style.height = n2, L();
      }
    }
  }, K = (0, import_debounce2.default)(() => {
    const { value: t2 } = N;
    if (!t2)
      return;
    const l = e.beforeFilter(t2);
    Ie(l) ? l.then(H).catch(() => {
    }) : l !== false ? H() : F();
  }, e.debounce);
  return watch(y, L), watch([D, _], () => {
    if (!I.value)
      return;
    const t2 = D.value, l = [];
    if (t2.length) {
      const [a2, ...n] = t2, o = n.length;
      l.push(R(a2)), o && (e.collapseTags ? l.push({ key: -1, text: "+ " + o, closable: false }) : n.forEach((e2) => l.push(R(e2))));
    }
    C.value = l;
  }), watch(C, () => nextTick(j)), watch(B, (e2) => k.value = e2, { immediate: true }), onMounted(() => {
    const e2 = h2.value.$el;
    a = (e2 == null ? void 0 : e2.offsetHeight) || so[M.value] || 40, vt(e2, j);
  }), onBeforeUnmount(() => {
    mt(h2.value.$el, j);
  }), { popperOptions: uo, popper: p, popperPaneRef: A, input: h2, tagWrapper: v, panel: m, suggestionPanel: f, popperVisible: g, inputHover: b, filtering: y, presentText: B, checkedValue: P, inputValue: k, searchInputValue: x, presentTags: C, suggestions: S, isDisabled: _, realSize: M, tagSize: T, multiple: I, readonly: O, clearBtnVisible: V, t: Ca, togglePopperVisible: z, hideSuggestionPanel: F, deleteTag: $, focusFirstNode: W, getCheckedNodes: (e2) => m.value.getCheckedNodes(e2), handleExpandChange: (e2) => {
    L(), t("expand-change", e2);
  }, handleKeyDown: (e2) => {
    switch (e2.code) {
      case Dt.enter:
        z();
        break;
      case Dt.down:
        z(true), nextTick(W), event.preventDefault();
        break;
      case Dt.esc:
      case Dt.tab:
        z(false);
    }
  }, handleClear: () => {
    m.value.clearCheckedNodes(), z(false);
  }, handleSuggestionClick: (e2) => {
    const { checked: t2 } = e2;
    I.value ? m.value.handleCheckChange(e2, !t2, false) : (!t2 && m.value.handleCheckChange(e2, true, false), z(false));
  }, handleDelete: () => {
    const e2 = C.value, t2 = e2[e2.length - 1];
    s = x.value ? 0 : s + 1, t2 && s && (t2.hitState ? $(t2) : t2.hitState = true);
  }, handleInput: (e2, t2) => {
    !g.value && z(true), (t2 == null ? void 0 : t2.isComposing) || (e2 ? K() : F());
  } };
} });
var po = { key: 0, ref: "tagWrapper", class: "el-cascader__tags" };
var ho = { key: 0, class: "el-icon-check" };
var vo = { class: "el-cascader__empty-text" };
co.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("el-tag"), p = resolveComponent("el-cascader-panel"), f = resolveComponent("el-scrollbar"), y = resolveComponent("el-popper"), k = resolveDirective("clickoutside");
  return openBlock(), createBlock(y, { ref: "popper", visible: e.popperVisible, "onUpdate:visible": t[16] || (t[16] = (t2) => e.popperVisible = t2), "manual-mode": "", placement: "bottom-start", "popper-class": "el-cascader__dropdown " + e.popperClass, "popper-options": e.popperOptions, "fallback-placements": ["bottom-start", "top-start", "right", "left"], "stop-popper-mouse-event": false, transition: "el-zoom-in-top", "gpu-acceleration": false, effect: "light", pure: "", onAfterLeave: e.hideSuggestionPanel }, { trigger: withCtx(() => [withDirectives(createVNode("div", { class: ["el-cascader", e.realSize && "el-cascader--" + e.realSize, { "is-disabled": e.isDisabled }], onClick: t[10] || (t[10] = () => e.togglePopperVisible(!e.readonly || void 0)), onKeydown: t[11] || (t[11] = (...t2) => e.handleKeyDown && e.handleKeyDown(...t2)), onMouseenter: t[12] || (t[12] = (t2) => e.inputHover = true), onMouseleave: t[13] || (t[13] = (t2) => e.inputHover = false) }, [createVNode(i, { ref: "input", modelValue: e.inputValue, "onUpdate:modelValue": t[3] || (t[3] = (t2) => e.inputValue = t2), modelModifiers: { trim: true }, placeholder: e.placeholder, readonly: e.readonly, disabled: e.isDisabled, "validate-event": false, size: e.realSize, class: { "is-focus": e.popperVisible }, onFocus: t[4] || (t[4] = (t2) => e.$emit("focus", t2)), onBlur: t[5] || (t[5] = (t2) => e.$emit("blur", t2)), onInput: e.handleInput }, { suffix: withCtx(() => [e.clearBtnVisible ? (openBlock(), createBlock("i", { key: "clear", class: "el-input__icon el-icon-circle-close", onClick: t[1] || (t[1] = withModifiers((...t2) => e.handleClear && e.handleClear(...t2), ["stop"])) })) : (openBlock(), createBlock("i", { key: "arrow-down", class: ["el-input__icon", "el-icon-arrow-down", e.popperVisible && "is-reverse"], onClick: t[2] || (t[2] = withModifiers((t2) => e.togglePopperVisible(), ["stop"])) }, null, 2))]), _: 1 }, 8, ["modelValue", "placeholder", "readonly", "disabled", "size", "class", "onInput"]), e.multiple ? (openBlock(), createBlock("div", po, [(openBlock(true), createBlock(Fragment, null, renderList(e.presentTags, (t2) => (openBlock(), createBlock(r, { key: t2.key, type: "info", size: e.tagSize, hit: t2.hitState, closable: t2.closable, "disable-transitions": "", onClose: (l2) => e.deleteTag(t2) }, { default: withCtx(() => [createVNode("span", null, toDisplayString(t2.text), 1)]), _: 2 }, 1032, ["size", "hit", "closable", "onClose"]))), 128)), e.filterable && !e.isDisabled ? withDirectives((openBlock(), createBlock("input", { key: 0, "onUpdate:modelValue": t[6] || (t[6] = (t2) => e.searchInputValue = t2), type: "text", class: "el-cascader__search-input", placeholder: e.presentText ? "" : e.placeholder, onInput: t[7] || (t[7] = (t2) => e.handleInput(e.searchInputValue, t2)), onClick: t[8] || (t[8] = withModifiers((t2) => e.togglePopperVisible(true), ["stop"])), onKeydown: t[9] || (t[9] = withKeys((...t2) => e.handleDelete && e.handleDelete(...t2), ["delete"])) }, null, 40, ["placeholder"])), [[vModelText, e.searchInputValue, void 0, { trim: true }]]) : createCommentVNode("v-if", true)], 512)) : createCommentVNode("v-if", true)], 34), [[k, () => e.togglePopperVisible(false), e.popperPaneRef]])]), default: withCtx(() => [withDirectives(createVNode(p, { ref: "panel", modelValue: e.checkedValue, "onUpdate:modelValue": t[14] || (t[14] = (t2) => e.checkedValue = t2), options: e.options, props: e.props, border: false, "render-label": e.$slots.default, onExpandChange: e.handleExpandChange, onClose: t[15] || (t[15] = (t2) => e.togglePopperVisible(false)) }, null, 8, ["modelValue", "options", "props", "render-label", "onExpandChange"]), [[vShow, !e.filtering]]), e.filterable ? withDirectives((openBlock(), createBlock(f, { key: 0, ref: "suggestionPanel", tag: "ul", class: "el-cascader__suggestion-panel", "view-class": "el-cascader__suggestion-list" }, { default: withCtx(() => [e.suggestions.length ? (openBlock(true), createBlock(Fragment, { key: 0 }, renderList(e.suggestions, (t2) => (openBlock(), createBlock("li", { key: t2.uid, class: ["el-cascader__suggestion-item", t2.checked && "is-checked"], tabindex: -1, onClick: (l2) => e.handleSuggestionClick(t2) }, [createVNode("span", null, toDisplayString(t2.text), 1), t2.checked ? (openBlock(), createBlock("i", ho)) : createCommentVNode("v-if", true)], 10, ["onClick"]))), 128)) : renderSlot(e.$slots, "empty", { key: 1 }, () => [createVNode("li", vo, toDisplayString(e.t("el.cascader.noMatch")), 1)])]), _: 3 }, 512)), [[vShow, e.filtering]]) : createCommentVNode("v-if", true)]), _: 1 }, 8, ["visible", "popper-class", "popper-options", "onAfterLeave"]);
}, co.__file = "packages/cascader/src/index.vue", co.install = (e) => {
  e.component(co.name, co);
};
var mo = co;
var fo = defineComponent({ name: "ElCheckboxButton", props: { modelValue: { type: [Boolean, Number, String], default: () => {
} }, label: { type: [Boolean, Number, String] }, indeterminate: Boolean, disabled: Boolean, checked: Boolean, name: { type: String, default: void 0 }, trueLabel: { type: [String, Number], default: void 0 }, falseLabel: { type: [String, Number], default: void 0 } }, emits: [Gt, "change"], setup(e) {
  const { focus: t, isChecked: l, isDisabled: a, size: o, model: i, handleChange: r } = Tn(e), { checkboxGroup: s } = Mn();
  return { focus: t, isChecked: l, isDisabled: a, model: i, handleChange: r, activeStyle: computed(() => {
    var e2, t2, l2, a2;
    const n = (t2 = (e2 = s == null ? void 0 : s.fill) === null || e2 === void 0 ? void 0 : e2.value) !== null && t2 !== void 0 ? t2 : "";
    return { backgroundColor: n, borderColor: n, color: (a2 = (l2 = s == null ? void 0 : s.textColor) === null || l2 === void 0 ? void 0 : l2.value) !== null && a2 !== void 0 ? a2 : "", boxShadow: n ? "-1px 0 0 0 " + n : null };
  }), size: o };
} });
fo.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("label", { class: ["el-checkbox-button", [e.size ? "el-checkbox-button--" + e.size : "", { "is-disabled": e.isDisabled }, { "is-checked": e.isChecked }, { "is-focus": e.focus }]], role: "checkbox", "aria-checked": e.isChecked, "aria-disabled": e.isDisabled }, [e.trueLabel || e.falseLabel ? withDirectives((openBlock(), createBlock("input", { key: 0, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.model = t2), checked: e.isChecked, class: "el-checkbox-button__original", type: "checkbox", name: e.name, disabled: e.isDisabled, "true-value": e.trueLabel, "false-value": e.falseLabel, onChange: t[2] || (t[2] = (...t2) => e.handleChange && e.handleChange(...t2)), onFocus: t[3] || (t[3] = (t2) => e.focus = true), onBlur: t[4] || (t[4] = (t2) => e.focus = false) }, null, 40, ["checked", "name", "disabled", "true-value", "false-value"])), [[vModelCheckbox, e.model]]) : withDirectives((openBlock(), createBlock("input", { key: 1, "onUpdate:modelValue": t[5] || (t[5] = (t2) => e.model = t2), class: "el-checkbox-button__original", type: "checkbox", name: e.name, disabled: e.isDisabled, value: e.label, onChange: t[6] || (t[6] = (...t2) => e.handleChange && e.handleChange(...t2)), onFocus: t[7] || (t[7] = (t2) => e.focus = true), onBlur: t[8] || (t[8] = (t2) => e.focus = false) }, null, 40, ["name", "disabled", "value"])), [[vModelCheckbox, e.model]]), e.$slots.default || e.label ? (openBlock(), createBlock("span", { key: 2, class: "el-checkbox-button__inner", style: e.isChecked ? e.activeStyle : null }, [renderSlot(e.$slots, "default", {}, () => [createTextVNode(toDisplayString(e.label), 1)])], 4)) : createCommentVNode("v-if", true)], 10, ["aria-checked", "aria-disabled"]);
}, fo.__file = "packages/checkbox/src/checkbox-button.vue", fo.install = (e) => {
  e.component(fo.name, fo);
};
var go = fo;
var bo = defineComponent({ name: "ElCheckboxGroup", props: { modelValue: { type: [Object, Boolean, Array], default: () => {
} }, disabled: Boolean, min: { type: Number, default: void 0 }, max: { type: Number, default: void 0 }, size: { type: String, validator: Qt }, fill: { type: String, default: void 0 }, textColor: { type: String, default: void 0 } }, emits: [Gt, "change"], setup(e, t) {
  const { elFormItem: l, elFormItemSize: a, ELEMENT: i } = Mn(), r = computed(() => e.size || a.value || i.size), s = (e2) => {
    t.emit(Gt, e2), nextTick(() => {
      t.emit("change", e2);
    });
  }, u = computed({ get: () => e.modelValue, set(e2) {
    s(e2);
  } });
  provide("CheckboxGroup", Object.assign(Object.assign({ name: "ElCheckboxGroup", modelValue: u }, toRefs(e)), { checkboxGroupSize: r, changeEvent: s })), watch(() => e.modelValue, (e2) => {
    var t2;
    (t2 = l.formItemMitt) === null || t2 === void 0 || t2.emit("el.form.change", [e2]);
  });
} });
var yo = { class: "el-checkbox-group", role: "group", "aria-label": "checkbox-group" };
bo.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", yo, [renderSlot(e.$slots, "default")]);
}, bo.__file = "packages/checkbox/src/checkbox-group.vue", bo.install = (e) => {
  e.component(bo.name, bo);
};
var ko = bo;
var xo = defineComponent({ name: "ElCol", props: { tag: { type: String, default: "div" }, span: { type: Number, default: 24 }, offset: { type: Number, default: 0 }, pull: { type: Number, default: 0 }, push: { type: Number, default: 0 }, xs: { type: [Number, Object], default: () => ({}) }, sm: { type: [Number, Object], default: () => ({}) }, md: { type: [Number, Object], default: () => ({}) }, lg: { type: [Number, Object], default: () => ({}) }, xl: { type: [Number, Object], default: () => ({}) } }, setup(e, { slots: t }) {
  const { gutter: l } = inject("ElRow", { gutter: { value: 0 } }), a = computed(() => l.value ? { paddingLeft: l.value / 2 + "px", paddingRight: l.value / 2 + "px" } : {}), o = computed(() => {
    const t2 = [];
    ["span", "offset", "pull", "push"].forEach((l2) => {
      const a2 = e[l2];
      typeof a2 == "number" && (l2 === "span" ? t2.push("el-col-" + e[l2]) : a2 > 0 && t2.push(`el-col-${l2}-${e[l2]}`));
    });
    return ["xs", "sm", "md", "lg", "xl"].forEach((l2) => {
      if (typeof e[l2] == "number")
        t2.push(`el-col-${l2}-${e[l2]}`);
      else if (typeof e[l2] == "object") {
        const a2 = e[l2];
        Object.keys(a2).forEach((e2) => {
          t2.push(e2 !== "span" ? `el-col-${l2}-${e2}-${a2[e2]}` : `el-col-${l2}-${a2[e2]}`);
        });
      }
    }), l.value && t2.push("is-guttered"), t2;
  });
  return () => {
    var l2;
    return h(e.tag, { class: ["el-col", o.value], style: a.value }, (l2 = t.default) === null || l2 === void 0 ? void 0 : l2.call(t));
  };
} });
xo.install = (e) => {
  e.component(xo.name, xo);
};
var Co = defineComponent({ name: "ElCollapse", props: { accordion: Boolean, modelValue: { type: [Array, String, Number], default: () => [] } }, emits: [Gt, "change"], setup(e, { emit: t }) {
  const a = ref([].concat(e.modelValue)), n = mitt_es_default(), i = (l) => {
    a.value = [].concat(l);
    const n2 = e.accordion ? a.value[0] : a.value;
    t(Gt, n2), t("change", n2);
  }, r = (t2) => {
    if (e.accordion)
      i(!a.value[0] && a.value[0] !== 0 || a.value[0] !== t2 ? t2 : "");
    else {
      let e2 = a.value.slice(0);
      const l = e2.indexOf(t2);
      l > -1 ? e2.splice(l, 1) : e2.push(t2), i(e2);
    }
  };
  return watch(() => e.modelValue, () => {
    a.value = [].concat(e.modelValue);
  }), n.on("item-click", r), onUnmounted(() => {
    n.all.clear();
  }), provide("collapse", { activeNames: a, collapseMitt: n }), { activeNames: a, setActiveNames: i, handleItemClick: r };
} });
var wo = { class: "el-collapse", role: "tablist", "aria-multiselectable": "true" };
Co.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", wo, [renderSlot(e.$slots, "default")]);
}, Co.__file = "packages/collapse/src/collapse.vue", Co.install = (e) => {
  e.component(Co.name, Co);
};
var So = Co;
var _o = defineComponent({ name: "ElCollapseTransition", setup: () => ({ on: { beforeEnter(e) {
  it(e, "collapse-transition"), e.dataset || (e.dataset = {}), e.dataset.oldPaddingTop = e.style.paddingTop, e.dataset.oldPaddingBottom = e.style.paddingBottom, e.style.height = "0", e.style.paddingTop = 0, e.style.paddingBottom = 0;
}, enter(e) {
  e.dataset.oldOverflow = e.style.overflow, e.scrollHeight !== 0 ? (e.style.height = e.scrollHeight + "px", e.style.paddingTop = e.dataset.oldPaddingTop, e.style.paddingBottom = e.dataset.oldPaddingBottom) : (e.style.height = "", e.style.paddingTop = e.dataset.oldPaddingTop, e.style.paddingBottom = e.dataset.oldPaddingBottom), e.style.overflow = "hidden";
}, afterEnter(e) {
  rt(e, "collapse-transition"), e.style.height = "", e.style.overflow = e.dataset.oldOverflow;
}, beforeLeave(e) {
  e.dataset || (e.dataset = {}), e.dataset.oldPaddingTop = e.style.paddingTop, e.dataset.oldPaddingBottom = e.style.paddingBottom, e.dataset.oldOverflow = e.style.overflow, e.style.height = e.scrollHeight + "px", e.style.overflow = "hidden";
}, leave(e) {
  e.scrollHeight !== 0 && (it(e, "collapse-transition"), e.style.transitionProperty = "height", e.style.height = 0, e.style.paddingTop = 0, e.style.paddingBottom = 0);
}, afterLeave(e) {
  rt(e, "collapse-transition"), e.style.height = "", e.style.overflow = e.dataset.oldOverflow, e.style.paddingTop = e.dataset.oldPaddingTop, e.style.paddingBottom = e.dataset.oldPaddingBottom;
} } }) });
_o.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, toHandlers(e.on), { default: withCtx(() => [renderSlot(e.$slots, "default")]), _: 3 }, 16);
}, _o.__file = "packages/transition/collapse-transition/index.vue", _o.install = (e) => {
  e.component(_o.name, _o);
};
var Eo = _o;
var Mo = defineComponent({ name: "ElCollapseItem", components: { ElCollapseTransition: Eo }, props: { title: { type: String, default: "" }, name: { type: [String, Number], default: () => He() }, disabled: Boolean }, setup(e) {
  const t = inject("collapse"), a = t == null ? void 0 : t.collapseMitt, o = ref({ height: "auto", display: "block" }), i = ref(0), r = ref(false), s = ref(false), u = ref(He());
  return { isActive: computed(() => (t == null ? void 0 : t.activeNames.value.indexOf(e.name)) > -1), contentWrapStyle: o, contentHeight: i, focusing: r, isClick: s, id: u, handleFocus: () => {
    setTimeout(() => {
      s.value ? s.value = false : r.value = true;
    }, 50);
  }, handleHeaderClick: () => {
    e.disabled || (a == null || a.emit("item-click", e.name), r.value = false, s.value = true);
  }, handleEnterClick: () => {
    a == null || a.emit("item-click", e.name);
  }, collapse: t };
} });
var To = { class: "el-collapse-item__content" };
Mo.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-collapse-transition");
  return openBlock(), createBlock("div", { class: ["el-collapse-item", { "is-active": e.isActive, "is-disabled": e.disabled }] }, [createVNode("div", { role: "tab", "aria-expanded": e.isActive, "aria-controls": "el-collapse-content-" + e.id, "aria-describedby": "el-collapse-content-" + e.id }, [createVNode("div", { id: "el-collapse-head-" + e.id, class: ["el-collapse-item__header", { focusing: e.focusing, "is-active": e.isActive }], role: "button", tabindex: e.disabled ? -1 : 0, onClick: t[1] || (t[1] = (...t2) => e.handleHeaderClick && e.handleHeaderClick(...t2)), onKeyup: t[2] || (t[2] = withKeys(withModifiers((...t2) => e.handleEnterClick && e.handleEnterClick(...t2), ["stop"]), ["space", "enter"])), onFocus: t[3] || (t[3] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onBlur: t[4] || (t[4] = (t2) => e.focusing = false) }, [renderSlot(e.$slots, "title", {}, () => [createTextVNode(toDisplayString(e.title), 1)]), createVNode("i", { class: ["el-collapse-item__arrow el-icon-arrow-right", { "is-active": e.isActive }] }, null, 2)], 42, ["id", "tabindex"])], 8, ["aria-expanded", "aria-controls", "aria-describedby"]), createVNode(i, null, { default: withCtx(() => [withDirectives(createVNode("div", { id: "el-collapse-content-" + e.id, class: "el-collapse-item__wrap", role: "tabpanel", "aria-hidden": !e.isActive, "aria-labelledby": "el-collapse-head-" + e.id }, [createVNode("div", To, [renderSlot(e.$slots, "default")])], 8, ["id", "aria-hidden", "aria-labelledby"]), [[vShow, e.isActive]])]), _: 3 })], 2);
}, Mo.__file = "packages/collapse/src/collapse-item.vue", Mo.install = (e) => {
  e.component(Mo.name, Mo);
};
var Io = Mo;
var Oo = function(e, t, l) {
  return [e, t * l / ((e = (2 - t) * l) < 1 ? e : 2 - e) || 0, e / 2];
};
var No = function(e, t) {
  var l;
  typeof (l = e) == "string" && l.indexOf(".") !== -1 && parseFloat(l) === 1 && (e = "100%");
  const a = function(e2) {
    return typeof e2 == "string" && e2.indexOf("%") !== -1;
  }(e);
  return e = Math.min(t, Math.max(0, parseFloat(e + ""))), a && (e = parseInt(e * t + "", 10) / 100), Math.abs(e - t) < 1e-6 ? 1 : e % t / parseFloat(t);
};
var Do = { 10: "A", 11: "B", 12: "C", 13: "D", 14: "E", 15: "F" };
var Vo = { A: 10, B: 11, C: 12, D: 13, E: 14, F: 15 };
var Bo = function(e) {
  return e.length === 2 ? 16 * (Vo[e[0].toUpperCase()] || +e[0]) + (Vo[e[1].toUpperCase()] || +e[1]) : Vo[e[1].toUpperCase()] || +e[1];
};
var Po = function(e, t, l) {
  e = No(e, 255), t = No(t, 255), l = No(l, 255);
  const a = Math.max(e, t, l), n = Math.min(e, t, l);
  let o;
  const i = a, r = a - n, s = a === 0 ? 0 : r / a;
  if (a === n)
    o = 0;
  else {
    switch (a) {
      case e:
        o = (t - l) / r + (t < l ? 6 : 0);
        break;
      case t:
        o = (l - e) / r + 2;
        break;
      case l:
        o = (e - t) / r + 4;
    }
    o /= 6;
  }
  return { h: 360 * o, s: 100 * s, v: 100 * i };
};
var Ao = function(e, t, l) {
  e = 6 * No(e, 360), t = No(t, 100), l = No(l, 100);
  const a = Math.floor(e), n = e - a, o = l * (1 - t), i = l * (1 - n * t), r = l * (1 - (1 - n) * t), s = a % 6, u = [l, i, o, o, r, l][s], d = [r, l, l, i, o, o][s], c = [o, o, r, l, l, i][s];
  return { r: Math.round(255 * u), g: Math.round(255 * d), b: Math.round(255 * c) };
};
var zo = class {
  constructor(e) {
    this._hue = 0, this._saturation = 100, this._value = 100, this._alpha = 100, this.enableAlpha = false, this.format = "hex", this.value = "", e = e || {};
    for (const t in e)
      Se(e, t) && (this[t] = e[t]);
    this.doOnChange();
  }
  set(e, t) {
    if (arguments.length !== 1 || typeof e != "object")
      this["_" + e] = t, this.doOnChange();
    else
      for (const t2 in e)
        Se(e, t2) && this.set(t2, e[t2]);
  }
  get(e) {
    return this["_" + e];
  }
  toRgb() {
    return Ao(this._hue, this._saturation, this._value);
  }
  fromString(e) {
    if (!e)
      return this._hue = 0, this._saturation = 100, this._value = 100, void this.doOnChange();
    const t = (e2, t2, l) => {
      this._hue = Math.max(0, Math.min(360, e2)), this._saturation = Math.max(0, Math.min(100, t2)), this._value = Math.max(0, Math.min(100, l)), this.doOnChange();
    };
    if (e.indexOf("hsl") !== -1) {
      const l = e.replace(/hsla|hsl|\(|\)/gm, "").split(/\s|,/g).filter((e2) => e2 !== "").map((e2, t2) => t2 > 2 ? parseFloat(e2) : parseInt(e2, 10));
      if (l.length === 4 ? this._alpha = Math.floor(100 * parseFloat(l[3])) : l.length === 3 && (this._alpha = 100), l.length >= 3) {
        const { h: e2, s: a, v: n } = function(e3, t2, l2) {
          l2 /= 100;
          let a2 = t2 /= 100;
          const n2 = Math.max(l2, 0.01);
          return t2 *= (l2 *= 2) <= 1 ? l2 : 2 - l2, a2 *= n2 <= 1 ? n2 : 2 - n2, { h: e3, s: 100 * (l2 === 0 ? 2 * a2 / (n2 + a2) : 2 * t2 / (l2 + t2)), v: (l2 + t2) / 2 * 100 };
        }(l[0], l[1], l[2]);
        t(e2, a, n);
      }
    } else if (e.indexOf("hsv") !== -1) {
      const l = e.replace(/hsva|hsv|\(|\)/gm, "").split(/\s|,/g).filter((e2) => e2 !== "").map((e2, t2) => t2 > 2 ? parseFloat(e2) : parseInt(e2, 10));
      l.length === 4 ? this._alpha = Math.floor(100 * parseFloat(l[3])) : l.length === 3 && (this._alpha = 100), l.length >= 3 && t(l[0], l[1], l[2]);
    } else if (e.indexOf("rgb") !== -1) {
      const l = e.replace(/rgba|rgb|\(|\)/gm, "").split(/\s|,/g).filter((e2) => e2 !== "").map((e2, t2) => t2 > 2 ? parseFloat(e2) : parseInt(e2, 10));
      if (l.length === 4 ? this._alpha = Math.floor(100 * parseFloat(l[3])) : l.length === 3 && (this._alpha = 100), l.length >= 3) {
        const { h: e2, s: a, v: n } = Po(l[0], l[1], l[2]);
        t(e2, a, n);
      }
    } else if (e.indexOf("#") !== -1) {
      const l = e.replace("#", "").trim();
      if (!/^[0-9a-fA-F]{3}$|^[0-9a-fA-F]{6}$|^[0-9a-fA-F]{8}$/.test(l))
        return;
      let a, n, o;
      l.length === 3 ? (a = Bo(l[0] + l[0]), n = Bo(l[1] + l[1]), o = Bo(l[2] + l[2])) : l.length !== 6 && l.length !== 8 || (a = Bo(l.substring(0, 2)), n = Bo(l.substring(2, 4)), o = Bo(l.substring(4, 6))), l.length === 8 ? this._alpha = Math.floor(Bo(l.substring(6)) / 255 * 100) : l.length !== 3 && l.length !== 6 || (this._alpha = 100);
      const { h: i, s: r, v: s } = Po(a, n, o);
      t(i, r, s);
    }
  }
  compare(e) {
    return Math.abs(e._hue - this._hue) < 2 && Math.abs(e._saturation - this._saturation) < 1 && Math.abs(e._value - this._value) < 1 && Math.abs(e._alpha - this._alpha) < 1;
  }
  doOnChange() {
    const { _hue: e, _saturation: t, _value: l, _alpha: a, format: n } = this;
    if (this.enableAlpha)
      switch (n) {
        case "hsl": {
          const n2 = Oo(e, t / 100, l / 100);
          this.value = `hsla(${e}, ${Math.round(100 * n2[1])}%, ${Math.round(100 * n2[2])}%, ${a / 100})`;
          break;
        }
        case "hsv":
          this.value = `hsva(${e}, ${Math.round(t)}%, ${Math.round(l)}%, ${a / 100})`;
          break;
        default: {
          const { r: n2, g: o, b: i } = Ao(e, t, l);
          this.value = `rgba(${n2}, ${o}, ${i}, ${a / 100})`;
        }
      }
    else
      switch (n) {
        case "hsl": {
          const a2 = Oo(e, t / 100, l / 100);
          this.value = `hsl(${e}, ${Math.round(100 * a2[1])}%, ${Math.round(100 * a2[2])}%)`;
          break;
        }
        case "hsv":
          this.value = `hsv(${e}, ${Math.round(t)}%, ${Math.round(l)}%)`;
          break;
        case "rgb": {
          const { r: a2, g: n2, b: o } = Ao(e, t, l);
          this.value = `rgb(${a2}, ${n2}, ${o})`;
          break;
        }
        default:
          this.value = function({ r: e2, g: t2, b: l2 }) {
            const a2 = function(e3) {
              e3 = Math.min(Math.round(e3), 255);
              const t3 = Math.floor(e3 / 16), l3 = e3 % 16;
              return "" + (Do[t3] || t3) + (Do[l3] || l3);
            };
            return isNaN(e2) || isNaN(t2) || isNaN(l2) ? "" : "#" + a2(e2) + a2(t2) + a2(l2);
          }(Ao(e, t, l));
      }
  }
};
var Lo = false;
function Fo(e, t) {
  if (ke)
    return;
  const l = function(e2) {
    var l2;
    (l2 = t.drag) === null || l2 === void 0 || l2.call(t, e2);
  }, a = function(e2) {
    var n;
    nt(document, "mousemove", l), nt(document, "mouseup", a), document.onselectstart = null, document.ondragstart = null, Lo = false, (n = t.end) === null || n === void 0 || n.call(t, e2);
  };
  at(e, "mousedown", function(e2) {
    var n;
    Lo || (document.onselectstart = () => false, document.ondragstart = () => false, at(document, "mousemove", l), at(document, "mouseup", a), Lo = true, (n = t.start) === null || n === void 0 || n.call(t, e2));
  });
}
var Ro = defineComponent({ name: "ElSlPanel", props: { color: { type: Object, required: true } }, setup(t) {
  const a = getCurrentInstance(), r = ref(0), s = ref(0), u = ref("hsl(0, 100%, 50%)"), d = computed(() => ({ hue: t.color.get("hue"), value: t.color.get("value") }));
  function c() {
    const e = t.color.get("saturation"), l = t.color.get("value"), n = a.vnode.el;
    let { clientWidth: o, clientHeight: i } = n;
    s.value = e * o / 100, r.value = (100 - l) * i / 100, u.value = "hsl(" + t.color.get("hue") + ", 100%, 50%)";
  }
  function p(e) {
    const l = a.vnode.el.getBoundingClientRect();
    let n = e.clientX - l.left, o = e.clientY - l.top;
    n = Math.max(0, n), n = Math.min(n, l.width), o = Math.max(0, o), o = Math.min(o, l.height), s.value = n, r.value = o, t.color.set({ saturation: n / l.width * 100, value: 100 - o / l.height * 100 });
  }
  return watch(() => d.value, () => {
    c();
  }), onMounted(() => {
    Fo(a.vnode.el, { drag: (e) => {
      p(e);
    }, end: (e) => {
      p(e);
    } }), c();
  }), { cursorTop: r, cursorLeft: s, background: u, colorValue: d, handleDrag: p, update: c };
} });
var $o = createVNode("div", { class: "el-color-svpanel__white" }, null, -1);
var Ho = createVNode("div", { class: "el-color-svpanel__black" }, null, -1);
var Wo = createVNode("div", null, null, -1);
Ro.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: "el-color-svpanel", style: { backgroundColor: e.background } }, [$o, Ho, createVNode("div", { class: "el-color-svpanel__cursor", style: { top: e.cursorTop + "px", left: e.cursorLeft + "px" } }, [Wo], 4)], 4);
}, Ro.__file = "packages/color-picker/src/components/sv-panel.vue";
var jo = defineComponent({ name: "ElColorHueSlider", props: { color: { type: Object, required: true }, vertical: Boolean }, setup(t) {
  const a = getCurrentInstance(), r = ref(null), s = ref(null), u = ref(0), d = ref(0), c = computed(() => t.color.get("hue"));
  function p(e) {
    const l = a.vnode.el.getBoundingClientRect();
    let n;
    if (t.vertical) {
      let t2 = e.clientY - l.top;
      t2 = Math.min(t2, l.height - r.value.offsetHeight / 2), t2 = Math.max(r.value.offsetHeight / 2, t2), n = Math.round((t2 - r.value.offsetHeight / 2) / (l.height - r.value.offsetHeight) * 360);
    } else {
      let t2 = e.clientX - l.left;
      t2 = Math.min(t2, l.width - r.value.offsetWidth / 2), t2 = Math.max(r.value.offsetWidth / 2, t2), n = Math.round((t2 - r.value.offsetWidth / 2) / (l.width - r.value.offsetWidth) * 360);
    }
    t.color.set("hue", n);
  }
  function h2() {
    u.value = function() {
      const e = a.vnode.el;
      if (t.vertical)
        return 0;
      const l = t.color.get("hue");
      return e ? Math.round(l * (e.offsetWidth - r.value.offsetWidth / 2) / 360) : 0;
    }(), d.value = function() {
      const e = a.vnode.el;
      if (!t.vertical)
        return 0;
      const l = t.color.get("hue");
      return e ? Math.round(l * (e.offsetHeight - r.value.offsetHeight / 2) / 360) : 0;
    }();
  }
  return watch(() => c.value, () => {
    h2();
  }), onMounted(() => {
    const e = { drag: (e2) => {
      p(e2);
    }, end: (e2) => {
      p(e2);
    } };
    Fo(s.value, e), Fo(r.value, e), h2();
  }), { bar: s, thumb: r, thumbLeft: u, thumbTop: d, hueValue: c, handleClick: function(e) {
    e.target !== r.value && p(e);
  }, update: h2 };
} });
jo.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-color-hue-slider", { "is-vertical": e.vertical }] }, [createVNode("div", { ref: "bar", class: "el-color-hue-slider__bar", onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, null, 512), createVNode("div", { ref: "thumb", class: "el-color-hue-slider__thumb", style: { left: e.thumbLeft + "px", top: e.thumbTop + "px" } }, null, 4)], 2);
}, jo.__file = "packages/color-picker/src/components/hue-slider.vue";
var Ko = defineComponent({ name: "ElColorAlphaSlider", props: { color: { type: Object, required: true }, vertical: { type: Boolean, default: false } }, setup(t) {
  const a = getCurrentInstance(), n = ref(null), r = ref(null), s = ref(0), u = ref(0), d = ref(null);
  function c(e) {
    const l = a.vnode.el.getBoundingClientRect();
    if (t.vertical) {
      let a2 = e.clientY - l.top;
      a2 = Math.max(n.value.offsetHeight / 2, a2), a2 = Math.min(a2, l.height - n.value.offsetHeight / 2), t.color.set("alpha", Math.round((a2 - n.value.offsetHeight / 2) / (l.height - n.value.offsetHeight) * 100));
    } else {
      let a2 = e.clientX - l.left;
      a2 = Math.max(n.value.offsetWidth / 2, a2), a2 = Math.min(a2, l.width - n.value.offsetWidth / 2), t.color.set("alpha", Math.round((a2 - n.value.offsetWidth / 2) / (l.width - n.value.offsetWidth) * 100));
    }
  }
  function p() {
    s.value = function() {
      if (t.vertical)
        return 0;
      const e = a.vnode.el, l = t.color.get("alpha");
      return e ? Math.round(l * (e.offsetWidth - n.value.offsetWidth / 2) / 100) : 0;
    }(), u.value = function() {
      const e = a.vnode.el;
      if (!t.vertical)
        return 0;
      const l = t.color.get("alpha");
      return e ? Math.round(l * (e.offsetHeight - n.value.offsetHeight / 2) / 100) : 0;
    }(), d.value = function() {
      if (t.color && t.color.value) {
        const { r: e, g: l, b: a2 } = t.color.toRgb();
        return `linear-gradient(to right, rgba(${e}, ${l}, ${a2}, 0) 0%, rgba(${e}, ${l}, ${a2}, 1) 100%)`;
      }
      return null;
    }();
  }
  return watch(() => t.color.get("alpha"), () => {
    p();
  }), watch(() => t.color.value, () => {
    p();
  }), onMounted(() => {
    const e = { drag: (e2) => {
      c(e2);
    }, end: (e2) => {
      c(e2);
    } };
    Fo(r.value, e), Fo(n.value, e), p();
  }), { thumb: n, bar: r, thumbLeft: s, thumbTop: u, background: d, handleClick: function(e) {
    e.target !== n.value && c(e);
  }, update: p };
} });
Ko.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-color-alpha-slider", { "is-vertical": e.vertical }] }, [createVNode("div", { ref: "bar", class: "el-color-alpha-slider__bar", style: { background: e.background }, onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, null, 4), createVNode("div", { ref: "thumb", class: "el-color-alpha-slider__thumb", style: { left: e.thumbLeft + "px", top: e.thumbTop + "px" } }, null, 4)], 2);
}, Ko.__file = "packages/color-picker/src/components/alpha-slider.vue";
var Yo = defineComponent({ props: { colors: { type: Array, required: true }, color: { type: Object, required: true } }, setup(e) {
  const { currentColor: t } = Xo(), a = ref(n(e.colors, e.color));
  function n(e2, t2) {
    return e2.map((e3) => {
      const l = new zo();
      return l.enableAlpha = true, l.format = "rgba", l.fromString(e3), l.selected = l.value === t2.value, l;
    });
  }
  return watch(() => t.value, (e2) => {
    const t2 = new zo();
    t2.fromString(e2), a.value.forEach((e3) => {
      e3.selected = t2.compare(e3);
    });
  }), watchEffect(() => {
    a.value = n(e.colors, e.color);
  }), { rgbaColors: a, handleSelect: function(t2) {
    e.color.fromString(e.colors[t2]);
  } };
} });
var qo = { class: "el-color-predefine" };
var Uo = { class: "el-color-predefine__colors" };
Yo.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", qo, [createVNode("div", Uo, [(openBlock(true), createBlock(Fragment, null, renderList(e.rgbaColors, (t2, l2) => (openBlock(), createBlock("div", { key: e.colors[l2], class: ["el-color-predefine__color-selector", { selected: t2.selected, "is-alpha": t2._alpha < 100 }], onClick: (t3) => e.handleSelect(l2) }, [createVNode("div", { style: { "background-color": t2.value } }, null, 4)], 10, ["onClick"]))), 128))])]);
}, Yo.__file = "packages/color-picker/src/components/predefine.vue";
var Go = Symbol();
var Xo = () => inject(Go);
var Zo = defineComponent({ name: "ElColorPicker", components: { ElPopper: Kl, ElInput: gl, SvPanel: Ro, HueSlider: jo, AlphaSlider: Ko, ElButton: ma, Predefine: Yo }, directives: { ClickOutside: Ht }, props: { modelValue: String, showAlpha: Boolean, colorFormat: String, disabled: Boolean, size: { type: String, validator: Qt }, popperClass: String, predefine: Array }, emits: ["change", "active-change", Gt], setup(e, { emit: t }) {
  const r = Xe(), s = inject("elForm", {}), u = inject("elFormItem", {}), d = ref(null), c = ref(null), p = ref(null), h2 = ref(null), v = reactive(new zo({ enableAlpha: e.showAlpha, format: e.colorFormat })), m = ref(false), f = ref(false), g = ref(""), b = computed(() => e.modelValue || f.value ? function(e2, t2) {
    if (!(e2 instanceof zo))
      throw Error("color should be instance of _color Class");
    const { r: l, g: a, b: n } = e2.toRgb();
    return t2 ? `rgba(${l}, ${a}, ${n}, ${e2.get("alpha") / 100})` : `rgb(${l}, ${a}, ${n})`;
  }(v, e.showAlpha) : "transparent"), y = computed(() => e.size || u.size || r.size), k = computed(() => e.disabled || s.disabled), x = computed(() => e.modelValue || f.value ? v.value : "");
  watch(() => e.modelValue, (e2) => {
    e2 ? e2 && e2 !== v.value && v.fromString(e2) : f.value = false;
  }), watch(() => x.value, (e2) => {
    g.value = e2, t("active-change", e2);
  }), watch(() => v.value, () => {
    e.modelValue || f.value || (f.value = true);
  });
  const C = (0, import_debounce2.default)(function(e2) {
    m.value = e2;
  }, 100);
  function S() {
    nextTick(() => {
      e.modelValue ? v.fromString(e.modelValue) : f.value = false;
    });
  }
  return onMounted(() => {
    e.modelValue && (v.fromString(e.modelValue), g.value = x.value);
  }), watch(() => m.value, () => {
    nextTick(() => {
      var e2, t2, l;
      (e2 = d.value) === null || e2 === void 0 || e2.update(), (t2 = c.value) === null || t2 === void 0 || t2.update(), (l = p.value) === null || l === void 0 || l.update();
    });
  }), provide(Go, { currentColor: x }), { color: v, colorDisabled: k, colorSize: y, displayedColor: b, showPanelColor: f, showPicker: m, customInput: g, handleConfirm: function() {
    v.fromString(g.value);
  }, hide: function() {
    C(false), S();
  }, handleTrigger: function() {
    k.value || C(!m.value);
  }, clear: function() {
    var l;
    C(false), t(Gt, null), t("change", null), e.modelValue !== null && ((l = u.formItemMitt) === null || l === void 0 || l.emit("el.form.change", null)), S();
  }, confirmValue: function() {
    var l;
    const a = v.value;
    t(Gt, a), t("change", a), (l = u.formItemMitt) === null || l === void 0 || l.emit("el.form.change", a), C(false), nextTick(() => {
      const t2 = new zo({ enableAlpha: e.showAlpha, format: e.colorFormat });
      t2.fromString(e.modelValue), v.compare(t2) || S();
    });
  }, t: Ca, hue: d, svPanel: c, alpha: p, popper: h2 };
} });
var Qo = { class: "el-color-dropdown__main-wrapper" };
var Jo = { class: "el-color-dropdown__btns" };
var ei = { class: "el-color-dropdown__value" };
var ti = { key: 0, class: "el-color-picker__mask" };
var li = { key: 0, class: "el-color-picker__empty el-icon-close" };
var ai = { class: "el-color-picker__icon el-icon-arrow-down" };
Zo.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("hue-slider"), r = resolveComponent("sv-panel"), c = resolveComponent("alpha-slider"), p = resolveComponent("predefine"), y = resolveComponent("el-input"), k = resolveComponent("el-button"), x = resolveComponent("el-popper"), C = resolveDirective("click-outside");
  return openBlock(), createBlock(x, { ref: "popper", visible: e.showPicker, "onUpdate:visible": t[3] || (t[3] = (t2) => e.showPicker = t2), effect: "light", "manual-mode": "", trigger: "click", "show-arrow": false, "fallback-placements": ["bottom", "top", "right", "left"], offset: 0, transition: "el-zoom-in-top", "gpu-acceleration": false, "popper-class": "el-color-picker__panel el-color-dropdown " + e.popperClass, "stop-popper-mouse-event": false }, { default: withCtx(() => [withDirectives(createVNode("div", null, [createVNode("div", Qo, [createVNode(i, { ref: "hue", class: "hue-slider", color: e.color, vertical: "" }, null, 8, ["color"]), createVNode(r, { ref: "svPanel", color: e.color }, null, 8, ["color"])]), e.showAlpha ? (openBlock(), createBlock(c, { key: 0, ref: "alpha", color: e.color }, null, 8, ["color"])) : createCommentVNode("v-if", true), e.predefine ? (openBlock(), createBlock(p, { key: 1, ref: "predefine", color: e.color, colors: e.predefine }, null, 8, ["color", "colors"])) : createCommentVNode("v-if", true), createVNode("div", Jo, [createVNode("span", ei, [createVNode(y, { modelValue: e.customInput, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.customInput = t2), "validate-event": false, size: "mini", onKeyup: withKeys(e.handleConfirm, ["enter"]), onBlur: e.handleConfirm }, null, 8, ["modelValue", "onKeyup", "onBlur"])]), createVNode(k, { size: "mini", type: "text", class: "el-color-dropdown__link-btn", onClick: e.clear }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.colorpicker.clear")), 1)]), _: 1 }, 8, ["onClick"]), createVNode(k, { plain: "", size: "mini", class: "el-color-dropdown__btn", onClick: e.confirmValue }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.colorpicker.confirm")), 1)]), _: 1 }, 8, ["onClick"])])], 512), [[C, e.hide]])]), trigger: withCtx(() => [createVNode("div", { class: ["el-color-picker", e.colorDisabled ? "is-disabled" : "", e.colorSize ? "el-color-picker--" + e.colorSize : ""] }, [e.colorDisabled ? (openBlock(), createBlock("div", ti)) : createCommentVNode("v-if", true), createVNode("div", { class: "el-color-picker__trigger", onClick: t[2] || (t[2] = (...t2) => e.handleTrigger && e.handleTrigger(...t2)) }, [createVNode("span", { class: ["el-color-picker__color", { "is-alpha": e.showAlpha }] }, [createVNode("span", { class: "el-color-picker__color-inner", style: { backgroundColor: e.displayedColor } }, null, 4), e.modelValue || e.showPanelColor ? createCommentVNode("v-if", true) : (openBlock(), createBlock("span", li))], 2), withDirectives(createVNode("span", ai, null, 512), [[vShow, e.modelValue || e.showPanelColor]])])], 2)]), _: 1 }, 8, ["visible", "popper-class"]);
}, Zo.__file = "packages/color-picker/src/index.vue", Zo.install = (e) => {
  e.component(Zo.name, Zo);
};
var ni = Zo;
var oi = defineComponent({ name: "ElContainer", props: { direction: { type: String, default: "" } }, setup: (e, { slots: t }) => ({ isVertical: computed(() => {
  if (e.direction === "vertical")
    return true;
  if (e.direction === "horizontal")
    return false;
  if (t && t.default) {
    return t.default().some((e2) => {
      const t2 = e2.type.name;
      return t2 === "ElHeader" || t2 === "ElFooter";
    });
  }
  return false;
}) }) });
oi.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("section", { class: ["el-container", { "is-vertical": e.isVertical }] }, [renderSlot(e.$slots, "default")], 2);
}, oi.__file = "packages/container/src/container.vue", oi.install = (e) => {
  e.component(oi.name, oi);
};
var ii = oi;
var ri = defineComponent({ props: { date: { type: Object }, minDate: { type: Object }, maxDate: { type: Object }, parsedValue: { type: [Object, Array] }, selectionMode: { type: String, default: "day" }, showWeekNumber: { type: Boolean, default: false }, disabledDate: { type: Function }, cellClassName: { type: Function }, rangeState: { type: Object, default: () => ({ endDate: null, selecting: false }) } }, emits: ["changerange", "pick", "select"], setup(e, t) {
  const a = ref(null), o = ref(null), i = ref([[], [], [], [], [], []]), r = e.date.$locale().weekStart || 7, s = e.date.locale("en").localeData().weekdaysShort().map((e2) => e2.toLowerCase()), u = computed(() => r > 3 ? 7 - r : -r), d = computed(() => {
    const t2 = e.date.startOf("month");
    return t2.subtract(t2.day() || 7, "day");
  }), c = computed(() => s.concat(s).slice(r, r + 7)), p = computed(() => {
    var t2;
    const l = e.date.startOf("month"), a2 = l.day() || 7, n = l.daysInMonth(), o2 = l.subtract(1, "month").daysInMonth(), r2 = u.value, s2 = i.value;
    let c2 = 1;
    const p2 = e.selectionMode === "dates" ? We(e.parsedValue) : [], h3 = (0, import_dayjs.default)().startOf("day");
    for (let l2 = 0; l2 < 6; l2++) {
      const i2 = s2[l2];
      e.showWeekNumber && (i2[0] || (i2[0] = { type: "week", text: d.value.add(7 * l2 + 1, "day").week() }));
      for (let s3 = 0; s3 < 7; s3++) {
        let u2 = i2[e.showWeekNumber ? s3 + 1 : s3];
        u2 || (u2 = { row: l2, column: s3, type: "normal", inRange: false, start: false, end: false });
        const v2 = 7 * l2 + s3, m = d.value.add(v2 - r2, "day");
        u2.type = "normal";
        const f = e.rangeState.endDate || e.maxDate || e.rangeState.selecting && e.minDate;
        u2.inRange = e.minDate && m.isSameOrAfter(e.minDate, "day") && f && m.isSameOrBefore(f, "day") || e.minDate && m.isSameOrBefore(e.minDate, "day") && f && m.isSameOrAfter(f, "day"), ((t2 = e.minDate) === null || t2 === void 0 ? void 0 : t2.isSameOrAfter(f)) ? (u2.start = f && m.isSame(f, "day"), u2.end = e.minDate && m.isSame(e.minDate, "day")) : (u2.start = e.minDate && m.isSame(e.minDate, "day"), u2.end = f && m.isSame(f, "day"));
        if (m.isSame(h3, "day") && (u2.type = "today"), l2 >= 0 && l2 <= 1) {
          const e2 = a2 + r2 < 0 ? 7 + a2 + r2 : a2 + r2;
          s3 + 7 * l2 >= e2 ? u2.text = c2++ : (u2.text = o2 - (e2 - s3 % 7) + 1 + 7 * l2, u2.type = "prev-month");
        } else
          c2 <= n ? u2.text = c2++ : (u2.text = c2++ - n, u2.type = "next-month");
        const g = m.toDate();
        u2.selected = p2.find((e2) => e2.valueOf() === m.valueOf()), u2.disabled = e.disabledDate && e.disabledDate(g), u2.customClass = e.cellClassName && e.cellClassName(g), i2[e.showWeekNumber ? s3 + 1 : s3] = u2;
      }
      if (e.selectionMode === "week") {
        const t3 = e.showWeekNumber ? 1 : 0, l3 = e.showWeekNumber ? 7 : 6, a3 = v(i2[t3 + 1]);
        i2[t3].inRange = a3, i2[t3].start = a3, i2[l3].inRange = a3, i2[l3].end = a3;
      }
    }
    return s2;
  }), h2 = (t2, l) => {
    const a2 = 7 * t2 + (l - (e.showWeekNumber ? 1 : 0)) - u.value;
    return d.value.add(a2, "day");
  }, v = (t2) => {
    if (e.selectionMode !== "week")
      return false;
    let l = e.date.startOf("day");
    if (t2.type === "prev-month" && (l = l.subtract(1, "month")), t2.type === "next-month" && (l = l.add(1, "month")), l = l.date(parseInt(t2.text, 10)), e.parsedValue && !Array.isArray(e.parsedValue)) {
      const t3 = (e.parsedValue.day() - r + 7) % 7 - 1;
      return e.parsedValue.subtract(t3, "day").isSame(l, "day");
    }
    return false;
  };
  return { handleMouseMove: (l) => {
    if (!e.rangeState.selecting)
      return;
    let n = l.target;
    if (n.tagName === "SPAN" && (n = n.parentNode.parentNode), n.tagName === "DIV" && (n = n.parentNode), n.tagName !== "TD")
      return;
    const i2 = n.parentNode.rowIndex - 1, r2 = n.cellIndex;
    p.value[i2][r2].disabled || i2 === a.value && r2 === o.value || (a.value = i2, o.value = r2, t.emit("changerange", { selecting: true, endDate: h2(i2, r2) }));
  }, t: Ca, rows: p, isWeekActive: v, getCellClasses: (t2) => {
    let l = [];
    return t2.type !== "normal" && t2.type !== "today" || t2.disabled ? l.push(t2.type) : (l.push("available"), t2.type === "today" && l.push("today")), e.selectionMode !== "day" || t2.type !== "normal" && t2.type !== "today" || !((t3, l2) => !!l2 && (0, import_dayjs.default)(l2).isSame(e.date.date(Number(t3.text)), "day"))(t2, e.parsedValue) || l.push("current"), !t2.inRange || t2.type !== "normal" && t2.type !== "today" && e.selectionMode !== "week" || (l.push("in-range"), t2.start && l.push("start-date"), t2.end && l.push("end-date")), t2.disabled && l.push("disabled"), t2.selected && l.push("selected"), t2.customClass && l.push(t2.customClass), l.join(" ");
  }, WEEKS: c, handleClick: (l) => {
    let a2 = l.target;
    if (a2.tagName === "SPAN" && (a2 = a2.parentNode.parentNode), a2.tagName === "DIV" && (a2 = a2.parentNode), a2.tagName !== "TD")
      return;
    const n = a2.parentNode.rowIndex - 1, o2 = a2.cellIndex, i2 = p.value[n][o2];
    if (i2.disabled || i2.type === "week")
      return;
    const r2 = h2(n, o2);
    if (e.selectionMode === "range")
      e.rangeState.selecting ? (r2 >= e.minDate ? t.emit("pick", { minDate: e.minDate, maxDate: r2 }) : t.emit("pick", { minDate: r2, maxDate: e.minDate }), t.emit("select", false)) : (t.emit("pick", { minDate: r2, maxDate: null }), t.emit("select", true));
    else if (e.selectionMode === "day")
      t.emit("pick", r2);
    else if (e.selectionMode === "week") {
      const e2 = r2.week(), l2 = r2.year() + "w" + e2;
      t.emit("pick", { year: r2.year(), week: e2, value: l2, date: r2.startOf("week") });
    } else if (e.selectionMode === "dates") {
      const l2 = i2.selected ? We(e.parsedValue).filter((e2) => e2.valueOf() !== r2.valueOf()) : We(e.parsedValue).concat([r2]);
      t.emit("pick", l2);
    }
  } };
} });
var si = { key: 0 };
ri.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("table", { cellspacing: "0", cellpadding: "0", class: ["el-date-table", { "is-week-mode": e.selectionMode === "week" }], onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)), onMousemove: t[2] || (t[2] = (...t2) => e.handleMouseMove && e.handleMouseMove(...t2)) }, [createVNode("tbody", null, [createVNode("tr", null, [e.showWeekNumber ? (openBlock(), createBlock("th", si, toDisplayString(e.t("el.datepicker.week")), 1)) : createCommentVNode("v-if", true), (openBlock(true), createBlock(Fragment, null, renderList(e.WEEKS, (t2, l2) => (openBlock(), createBlock("th", { key: l2 }, toDisplayString(e.t("el.datepicker.weeks." + t2)), 1))), 128))]), (openBlock(true), createBlock(Fragment, null, renderList(e.rows, (t2, l2) => (openBlock(), createBlock("tr", { key: l2, class: ["el-date-table__row", { current: e.isWeekActive(t2[1]) }] }, [(openBlock(true), createBlock(Fragment, null, renderList(t2, (t3, l3) => (openBlock(), createBlock("td", { key: l3, class: e.getCellClasses(t3) }, [createVNode("div", null, [createVNode("span", null, toDisplayString(t3.text), 1)])], 2))), 128))], 2))), 128))])], 34);
}, ri.__file = "packages/date-picker/src/date-picker-com/basic-date-table.vue";
var ui = defineComponent({ props: { disabledDate: { type: Function }, selectionMode: { type: String, default: "month" }, minDate: { type: Object }, maxDate: { type: Object }, date: { type: Object }, parsedValue: { type: Object }, rangeState: { type: Object, default: () => ({ endDate: null, selecting: false }) } }, emits: ["changerange", "pick", "select"], setup(e, t) {
  const a = ref(e.date.locale("en").localeData().monthsShort().map((e2) => e2.toLowerCase())), o = ref([[], [], []]), i = ref(null), r = ref(null), s = computed(() => {
    var t2;
    const l = o.value, a2 = (0, import_dayjs.default)().startOf("month");
    for (let n = 0; n < 3; n++) {
      const o2 = l[n];
      for (let l2 = 0; l2 < 4; l2++) {
        let i2 = o2[l2];
        i2 || (i2 = { row: n, column: l2, type: "normal", inRange: false, start: false, end: false }), i2.type = "normal";
        const r2 = 4 * n + l2, s2 = e.date.startOf("year").month(r2), u = e.rangeState.endDate || e.maxDate || e.rangeState.selecting && e.minDate;
        i2.inRange = e.minDate && s2.isSameOrAfter(e.minDate, "month") && u && s2.isSameOrBefore(u, "month") || e.minDate && s2.isSameOrBefore(e.minDate, "month") && u && s2.isSameOrAfter(u, "month"), ((t2 = e.minDate) === null || t2 === void 0 ? void 0 : t2.isSameOrAfter(u)) ? (i2.start = u && s2.isSame(u, "month"), i2.end = e.minDate && s2.isSame(e.minDate, "month")) : (i2.start = e.minDate && s2.isSame(e.minDate, "month"), i2.end = u && s2.isSame(u, "month"));
        a2.isSame(s2) && (i2.type = "today"), i2.text = r2;
        let d = s2.toDate();
        i2.disabled = e.disabledDate && e.disabledDate(d), o2[l2] = i2;
      }
    }
    return l;
  });
  return { handleMouseMove: (l) => {
    if (!e.rangeState.selecting)
      return;
    let a2 = l.target;
    if (a2.tagName === "A" && (a2 = a2.parentNode.parentNode), a2.tagName === "DIV" && (a2 = a2.parentNode), a2.tagName !== "TD")
      return;
    const n = a2.parentNode.rowIndex, o2 = a2.cellIndex;
    s.value[n][o2].disabled || n === i.value && o2 === r.value || (i.value = n, r.value = o2, t.emit("changerange", { selecting: true, endDate: e.date.startOf("year").month(4 * n + o2) }));
  }, handleMonthTableClick: (l) => {
    let a2 = l.target;
    if (a2.tagName === "A" && (a2 = a2.parentNode.parentNode), a2.tagName === "DIV" && (a2 = a2.parentNode), a2.tagName !== "TD")
      return;
    if (ot(a2, "disabled"))
      return;
    const n = a2.cellIndex, o2 = 4 * a2.parentNode.rowIndex + n, i2 = e.date.startOf("year").month(o2);
    e.selectionMode === "range" ? e.rangeState.selecting ? (i2 >= e.minDate ? t.emit("pick", { minDate: e.minDate, maxDate: i2 }) : t.emit("pick", { minDate: i2, maxDate: e.minDate }), t.emit("select", false)) : (t.emit("pick", { minDate: i2, maxDate: null }), t.emit("select", true)) : t.emit("pick", o2);
  }, rows: s, getCellStyle: (t2) => {
    const l = {}, a2 = e.date.year(), n = new Date(), o2 = t2.text;
    return l.disabled = !!e.disabledDate && ((e2, t3) => {
      const l2 = (0, import_dayjs.default)().startOf("month").month(t3).year(e2), a3 = l2.daysInMonth();
      return Ja(a3).map((e3) => l2.add(e3, "day").toDate());
    })(a2, o2).every(e.disabledDate), l.current = We(e.parsedValue).findIndex((e2) => e2.year() === a2 && e2.month() === o2) >= 0, l.today = n.getFullYear() === a2 && n.getMonth() === o2, t2.inRange && (l["in-range"] = true, t2.start && (l["start-date"] = true), t2.end && (l["end-date"] = true)), l;
  }, t: Ca, months: a };
} });
var di = { class: "cell" };
ui.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("table", { class: "el-month-table", onClick: t[1] || (t[1] = (...t2) => e.handleMonthTableClick && e.handleMonthTableClick(...t2)), onMousemove: t[2] || (t[2] = (...t2) => e.handleMouseMove && e.handleMouseMove(...t2)) }, [createVNode("tbody", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.rows, (t2, l2) => (openBlock(), createBlock("tr", { key: l2 }, [(openBlock(true), createBlock(Fragment, null, renderList(t2, (t3, l3) => (openBlock(), createBlock("td", { key: l3, class: e.getCellStyle(t3) }, [createVNode("div", null, [createVNode("a", di, toDisplayString(e.t("el.datepicker.months." + e.months[t3.text])), 1)])], 2))), 128))]))), 128))])], 32);
}, ui.__file = "packages/date-picker/src/date-picker-com/basic-month-table.vue";
var ci = defineComponent({ props: { disabledDate: { type: Function }, parsedValue: { type: Object }, date: { type: Object } }, emits: ["pick"], setup: (e, t) => ({ startYear: computed(() => 10 * Math.floor(e.date.year() / 10)), getCellStyle: (t2) => {
  const l = {}, a = (0, import_dayjs.default)();
  return l.disabled = !!e.disabledDate && ((e2) => {
    const t3 = (0, import_dayjs.default)(String(e2)).startOf("year"), l2 = t3.endOf("year").dayOfYear();
    return Ja(l2).map((e3) => t3.add(e3, "day").toDate());
  })(t2).every(e.disabledDate), l.current = We(e.parsedValue).findIndex((e2) => e2.year() === t2) >= 0, l.today = a.year() === t2, l;
}, handleYearTableClick: (e2) => {
  const l = e2.target;
  if (l.tagName === "A") {
    if (ot(l.parentNode, "disabled"))
      return;
    const e3 = l.textContent || l.innerText;
    t.emit("pick", Number(e3));
  }
} }) });
var pi = { class: "cell" };
var hi = { class: "cell" };
var vi = { class: "cell" };
var mi = { class: "cell" };
var fi = { class: "cell" };
var gi = { class: "cell" };
var bi = { class: "cell" };
var yi = { class: "cell" };
var ki = { class: "cell" };
var xi = { class: "cell" };
var Ci = createVNode("td", null, null, -1);
var wi = createVNode("td", null, null, -1);
ci.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("table", { class: "el-year-table", onClick: t[1] || (t[1] = (...t2) => e.handleYearTableClick && e.handleYearTableClick(...t2)) }, [createVNode("tbody", null, [createVNode("tr", null, [createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 0)] }, [createVNode("a", pi, toDisplayString(e.startYear), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 1)] }, [createVNode("a", hi, toDisplayString(e.startYear + 1), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 2)] }, [createVNode("a", vi, toDisplayString(e.startYear + 2), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 3)] }, [createVNode("a", mi, toDisplayString(e.startYear + 3), 1)], 2)]), createVNode("tr", null, [createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 4)] }, [createVNode("a", fi, toDisplayString(e.startYear + 4), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 5)] }, [createVNode("a", gi, toDisplayString(e.startYear + 5), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 6)] }, [createVNode("a", bi, toDisplayString(e.startYear + 6), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 7)] }, [createVNode("a", yi, toDisplayString(e.startYear + 7), 1)], 2)]), createVNode("tr", null, [createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 8)] }, [createVNode("a", ki, toDisplayString(e.startYear + 8), 1)], 2), createVNode("td", { class: ["available", e.getCellStyle(e.startYear + 9)] }, [createVNode("a", xi, toDisplayString(e.startYear + 9), 1)], 2), Ci, wi])])]);
}, ci.__file = "packages/date-picker/src/date-picker-com/basic-year-table.vue";
var Si = defineComponent({ components: { DateTable: ri, ElInput: gl, ElButton: ma, TimePickPanel: Ra, MonthTable: ui, YearTable: ci }, directives: { clickoutside: Ht }, props: { visible: { type: Boolean, default: false }, parsedValue: { type: [Object, Array] }, format: { type: String, default: "" }, type: { type: String, required: true, validator: Jt } }, emits: ["pick", "set-picker-option"], setup(e, t) {
  const a = ref((0, import_dayjs.default)()), i = computed(() => a.value.month()), r = computed(() => a.value.year()), s = ref([]), u = ref(null), d = ref(null), c = (t2) => !(s.value.length > 0) || (s.value, e.format, true), p = (e2) => {
    if (D) {
      return (0, import_dayjs.default)(D).year(e2.year()).month(e2.month()).date(e2.date());
    }
    return b.value ? e2.millisecond(0) : e2.startOf("day");
  }, h2 = (e2, ...l) => {
    if (e2)
      if (Array.isArray(e2)) {
        const a2 = e2.map(p);
        t.emit("pick", a2, ...l);
      } else
        t.emit("pick", p(e2), ...l);
    else
      t.emit("pick", e2, ...l);
    u.value = null, d.value = null;
  }, v = ref("date"), m = computed(() => {
    const e2 = Ca("el.datepicker.year");
    if (v.value === "year") {
      const t2 = 10 * Math.floor(r.value / 10);
      return e2 ? t2 + " " + e2 + " - " + (t2 + 9) + " " + e2 : t2 + " - " + (t2 + 9);
    }
    return r.value + " " + e2;
  }), f = computed(() => ["week", "month", "year", "dates"].includes(e.type) ? e.type : "day");
  watch(() => f.value, (e2) => {
    ["month", "year"].includes(e2) ? v.value = e2 : v.value = "date";
  }, { immediate: true });
  const g = computed(() => !!I.length), b = computed(() => e.type === "datetime" || e.type === "datetimerange"), y = computed(() => b.value || f.value === "dates"), k = computed(() => tn(e.format)), x = computed(() => en(e.format)), C = computed(() => d.value ? d.value : e.parsedValue || V ? (e.parsedValue || a.value).format(k.value) : void 0), w = computed(() => u.value ? u.value : e.parsedValue || V ? (e.parsedValue || a.value).format(x.value) : void 0), S = ref(false), _ = () => (0, import_dayjs.default)(V), M = (e2) => {
    const l = { year: { 38: -4, 40: 4, 37: -1, 39: 1, offset: (e3, t2) => e3.setFullYear(e3.getFullYear() + t2) }, month: { 38: -4, 40: 4, 37: -1, 39: 1, offset: (e3, t2) => e3.setMonth(e3.getMonth() + t2) }, week: { 38: -1, 40: 1, 37: -1, 39: 1, offset: (e3, t2) => e3.setDate(e3.getDate() + 7 * t2) }, day: { 38: -7, 40: 7, 37: -1, 39: 1, offset: (e3, t2) => e3.setDate(e3.getDate() + t2) } }, n = a.value.toDate();
    for (; Math.abs(a.value.diff(n, "year", true)) < 1; ) {
      const o = l[f.value];
      if (o.offset(n, o[e2]), O && O(n))
        continue;
      const i2 = (0, import_dayjs.default)(n);
      a.value = i2, t.emit("pick", i2, true);
      break;
    }
  };
  t.emit("set-picker-option", ["isValidValue", (e2) => e2.isValid() && (!O || !O(e2.toDate()))]), t.emit("set-picker-option", ["formatToString", (t2) => f.value === "dates" ? t2.map((t3) => t3.format(e.format)) : t2.format(e.format)]), t.emit("set-picker-option", ["parseUserInput", (t2) => (0, import_dayjs.default)(t2, e.format)]), t.emit("set-picker-option", ["handleKeydown", (t2) => {
    const { code: l, keyCode: n } = t2, o = [Dt.up, Dt.down, Dt.left, Dt.right];
    e.visible && !S.value && (o.includes(l) && (M(n), t2.stopPropagation(), t2.preventDefault()), l === Dt.enter && u.value === null && d.value === null && h2(a, false));
  }]);
  const T = inject("EP_PICKER_BASE"), { shortcuts: I, disabledDate: O, cellClassName: N, defaultTime: D, defaultValue: V, arrowControl: B } = T.props;
  return watch(() => e.parsedValue, (e2) => {
    if (e2) {
      if (f.value === "dates")
        return;
      if (Array.isArray(e2))
        return;
      a.value = e2;
    } else
      a.value = _();
  }, { immediate: true }), { handleTimePick: (t2, l, n) => {
    const o = e.parsedValue ? e.parsedValue.hour(t2.hour()).minute(t2.minute()).second(t2.second()) : t2;
    a.value = o, h2(a.value, true), n || (S.value = l);
  }, handleTimePickClose: () => {
    S.value = false;
  }, onTimePickerInputFocus: () => {
    S.value = true;
  }, timePickerVisible: S, visibleTime: C, visibleDate: w, showTime: b, changeToNow: () => {
    const e2 = (0, import_dayjs.default)().toDate();
    O && O(e2) || !c() || (a.value = (0, import_dayjs.default)(), h2(a.value));
  }, onConfirm: () => {
    if (f.value === "dates")
      h2(e.parsedValue);
    else {
      let t2 = e.parsedValue;
      if (!t2) {
        const e2 = (0, import_dayjs.default)(D), l = _();
        t2 = e2.year(l.year()).month(l.month()).date(l.date());
      }
      a.value = t2, h2(t2);
    }
  }, footerVisible: y, handleYearPick: (e2) => {
    f.value === "year" ? (a.value = a.value.startOf("year").year(e2), h2(a.value)) : (a.value = a.value.year(e2), v.value = "month");
  }, showMonthPicker: () => {
    v.value = "month";
  }, showYearPicker: () => {
    v.value = "year";
  }, handleMonthPick: (e2) => {
    a.value = a.value.startOf("month").month(e2), f.value === "month" ? h2(a.value) : v.value = "date";
  }, hasShortcuts: g, shortcuts: I, arrowControl: B, disabledDate: O, cellClassName: N, selectionMode: f, handleShortcutClick: (e2) => {
    e2.value ? h2((0, import_dayjs.default)(e2.value)) : e2.onClick && e2.onClick(t);
  }, prevYear_: () => {
    v.value === "year" ? a.value = a.value.subtract(10, "year") : a.value = a.value.subtract(1, "year");
  }, nextYear_: () => {
    v.value === "year" ? a.value = a.value.add(10, "year") : a.value = a.value.add(1, "year");
  }, prevMonth_: () => {
    a.value = a.value.subtract(1, "month");
  }, nextMonth_: () => {
    a.value = a.value.add(1, "month");
  }, innerDate: a, t: Ca, yearLabel: m, currentView: v, month: i, handleDatePick: (t2) => {
    if (f.value === "day") {
      let l = e.parsedValue ? e.parsedValue.year(t2.year()).month(t2.month()).date(t2.date()) : t2;
      c() || (l = s.value[0][0].year(t2.year()).month(t2.month()).date(t2.date())), a.value = l, h2(l, b.value);
    } else
      f.value === "week" ? h2(t2.date) : f.value === "dates" && h2(t2, true);
  }, handleVisibleTimeChange: (e2) => {
    const t2 = (0, import_dayjs.default)(e2, k.value);
    t2.isValid() && c() && (a.value = t2.year(a.value.year()).month(a.value.month()).date(a.value.date()), d.value = null, S.value = false, h2(a.value, true));
  }, handleVisibleDateChange: (e2) => {
    const t2 = (0, import_dayjs.default)(e2, x.value);
    if (t2.isValid()) {
      if (O && O(t2.toDate()))
        return;
      a.value = t2.hour(a.value.hour()).minute(a.value.minute()).second(a.value.second()), u.value = null, h2(a.value, true);
    }
  }, timeFormat: k, userInputTime: d, userInputDate: u };
} });
var _i = { class: "el-picker-panel__body-wrapper" };
var Ei = { key: 0, class: "el-picker-panel__sidebar" };
var Mi = { class: "el-picker-panel__body" };
var Ti = { key: 0, class: "el-date-picker__time-header" };
var Ii = { class: "el-date-picker__editor-wrap" };
var Oi = { class: "el-date-picker__editor-wrap" };
var Ni = { class: "el-picker-panel__content" };
var Di = { class: "el-picker-panel__footer" };
Si.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("time-pick-panel"), p = resolveComponent("date-table"), y = resolveComponent("year-table"), k = resolveComponent("month-table"), x = resolveComponent("el-button"), C = resolveDirective("clickoutside");
  return openBlock(), createBlock("div", { class: ["el-picker-panel el-date-picker", [{ "has-sidebar": e.$slots.sidebar || e.hasShortcuts, "has-time": e.showTime }]] }, [createVNode("div", _i, [renderSlot(e.$slots, "sidebar", { class: "el-picker-panel__sidebar" }), e.hasShortcuts ? (openBlock(), createBlock("div", Ei, [(openBlock(true), createBlock(Fragment, null, renderList(e.shortcuts, (t2, l2) => (openBlock(), createBlock("button", { key: l2, type: "button", class: "el-picker-panel__shortcut", onClick: (l3) => e.handleShortcutClick(t2) }, toDisplayString(t2.text), 9, ["onClick"]))), 128))])) : createCommentVNode("v-if", true), createVNode("div", Mi, [e.showTime ? (openBlock(), createBlock("div", Ti, [createVNode("span", Ii, [createVNode(i, { placeholder: e.t("el.datepicker.selectDate"), "model-value": e.visibleDate, size: "small", onInput: t[1] || (t[1] = (t2) => e.userInputDate = t2), onChange: e.handleVisibleDateChange }, null, 8, ["placeholder", "model-value", "onChange"])]), withDirectives(createVNode("span", Oi, [createVNode(i, { placeholder: e.t("el.datepicker.selectTime"), "model-value": e.visibleTime, size: "small", onFocus: e.onTimePickerInputFocus, onInput: t[2] || (t[2] = (t2) => e.userInputTime = t2), onChange: e.handleVisibleTimeChange }, null, 8, ["placeholder", "model-value", "onFocus", "onChange"]), createVNode(r, { visible: e.timePickerVisible, format: e.timeFormat, "time-arrow-control": e.arrowControl, "parsed-value": e.innerDate, onPick: e.handleTimePick }, null, 8, ["visible", "format", "time-arrow-control", "parsed-value", "onPick"])], 512), [[C, e.handleTimePickClose]])])) : createCommentVNode("v-if", true), withDirectives(createVNode("div", { class: ["el-date-picker__header", { "el-date-picker__header--bordered": e.currentView === "year" || e.currentView === "month" }] }, [createVNode("button", { type: "button", "aria-label": e.t("el.datepicker.prevYear"), class: "el-picker-panel__icon-btn el-date-picker__prev-btn el-icon-d-arrow-left", onClick: t[3] || (t[3] = (...t2) => e.prevYear_ && e.prevYear_(...t2)) }, null, 8, ["aria-label"]), withDirectives(createVNode("button", { type: "button", "aria-label": e.t("el.datepicker.prevMonth"), class: "el-picker-panel__icon-btn el-date-picker__prev-btn el-icon-arrow-left", onClick: t[4] || (t[4] = (...t2) => e.prevMonth_ && e.prevMonth_(...t2)) }, null, 8, ["aria-label"]), [[vShow, e.currentView === "date"]]), createVNode("span", { role: "button", class: "el-date-picker__header-label", onClick: t[5] || (t[5] = (...t2) => e.showYearPicker && e.showYearPicker(...t2)) }, toDisplayString(e.yearLabel), 1), withDirectives(createVNode("span", { role: "button", class: ["el-date-picker__header-label", { active: e.currentView === "month" }], onClick: t[6] || (t[6] = (...t2) => e.showMonthPicker && e.showMonthPicker(...t2)) }, toDisplayString(e.t("el.datepicker.month" + (e.month + 1))), 3), [[vShow, e.currentView === "date"]]), createVNode("button", { type: "button", "aria-label": e.t("el.datepicker.nextYear"), class: "el-picker-panel__icon-btn el-date-picker__next-btn el-icon-d-arrow-right", onClick: t[7] || (t[7] = (...t2) => e.nextYear_ && e.nextYear_(...t2)) }, null, 8, ["aria-label"]), withDirectives(createVNode("button", { type: "button", "aria-label": e.t("el.datepicker.nextMonth"), class: "el-picker-panel__icon-btn el-date-picker__next-btn el-icon-arrow-right", onClick: t[8] || (t[8] = (...t2) => e.nextMonth_ && e.nextMonth_(...t2)) }, null, 8, ["aria-label"]), [[vShow, e.currentView === "date"]])], 2), [[vShow, e.currentView !== "time"]]), createVNode("div", Ni, [e.currentView === "date" ? (openBlock(), createBlock(p, { key: 0, "selection-mode": e.selectionMode, date: e.innerDate, "parsed-value": e.parsedValue, "disabled-date": e.disabledDate, onPick: e.handleDatePick }, null, 8, ["selection-mode", "date", "parsed-value", "disabled-date", "onPick"])) : createCommentVNode("v-if", true), e.currentView === "year" ? (openBlock(), createBlock(y, { key: 1, date: e.innerDate, "disabled-date": e.disabledDate, "parsed-value": e.parsedValue, onPick: e.handleYearPick }, null, 8, ["date", "disabled-date", "parsed-value", "onPick"])) : createCommentVNode("v-if", true), e.currentView === "month" ? (openBlock(), createBlock(k, { key: 2, date: e.innerDate, "parsed-value": e.parsedValue, "disabled-date": e.disabledDate, onPick: e.handleMonthPick }, null, 8, ["date", "parsed-value", "disabled-date", "onPick"])) : createCommentVNode("v-if", true)])])]), withDirectives(createVNode("div", Di, [withDirectives(createVNode(x, { size: "mini", type: "text", class: "el-picker-panel__link-btn", onClick: e.changeToNow }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.now")), 1)]), _: 1 }, 8, ["onClick"]), [[vShow, e.selectionMode !== "dates"]]), createVNode(x, { plain: "", size: "mini", class: "el-picker-panel__link-btn", onClick: e.onConfirm }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.confirm")), 1)]), _: 1 }, 8, ["onClick"])], 512), [[vShow, e.footerVisible && e.currentView === "date"]])], 2);
}, Si.__file = "packages/date-picker/src/date-picker-com/panel-date-pick.vue";
var Vi = defineComponent({ directives: { clickoutside: Ht }, components: { TimePickPanel: Ra, DateTable: ri, ElInput: gl, ElButton: ma }, props: { unlinkPanels: Boolean, parsedValue: { type: Array }, type: { type: String, required: true, validator: Jt } }, emits: ["pick", "set-picker-option"], setup(e, t) {
  const a = ref((0, import_dayjs.default)()), i = ref((0, import_dayjs.default)().add(1, "month")), r = ref(null), s = ref(null), u = ref({ min: null, max: null }), d = ref({ min: null, max: null }), c = computed(() => a.value.year() + " " + Ca("el.datepicker.year") + " " + Ca("el.datepicker.month" + (a.value.month() + 1))), p = computed(() => i.value.year() + " " + Ca("el.datepicker.year") + " " + Ca("el.datepicker.month" + (i.value.month() + 1))), h2 = computed(() => a.value.year()), v = computed(() => a.value.month()), m = computed(() => i.value.year()), f = computed(() => i.value.month()), g = computed(() => !!L.length), b = computed(() => u.value.min !== null ? u.value.min : r.value ? r.value.format(w.value) : ""), y = computed(() => u.value.max !== null ? u.value.max : s.value || r.value ? (s.value || r.value).format(w.value) : ""), k = computed(() => d.value.min !== null ? d.value.min : r.value ? r.value.format(C.value) : ""), x = computed(() => d.value.max !== null ? d.value.max : s.value || r.value ? (s.value || r.value).format(C.value) : ""), C = computed(() => tn($)), w = computed(() => en($)), S = computed(() => {
    const t2 = (v.value + 1) % 12, l = v.value + 1 >= 12 ? 1 : 0;
    return e.unlinkPanels && new Date(h2.value + l, t2) < new Date(m.value, f.value);
  }), _ = computed(() => e.unlinkPanels && 12 * m.value + f.value - (12 * h2.value + v.value + 1) >= 12), M = (e2) => Array.isArray(e2) && e2[0] && e2[1] && e2[0].valueOf() <= e2[1].valueOf(), T = ref({ endDate: null, selecting: false }), I = computed(() => !(r.value && s.value && !T.value.selecting && M([r.value, s.value]))), O = computed(() => e.type === "datetime" || e.type === "datetimerange"), N = (e2 = false) => {
    M([r.value, s.value]) && t.emit("pick", [r.value, s.value], e2);
  }, D = (e2, t2) => {
    if (e2) {
      if (H) {
        return (0, import_dayjs.default)(H[t2] || H).year(e2.year()).month(e2.month()).date(e2.date());
      }
      return e2;
    }
  }, V = ref(false), B = ref(false), P = () => {
    a.value = A()[0], i.value = a.value.add(1, "month"), t.emit("pick", null);
  }, A = () => {
    let t2;
    if (Array.isArray(W)) {
      const t3 = (0, import_dayjs.default)(W[0]);
      let l = (0, import_dayjs.default)(W[1]);
      return e.unlinkPanels || (l = t3.add(1, "month")), [t3, l];
    }
    return t2 = W ? (0, import_dayjs.default)(W) : (0, import_dayjs.default)(), [t2, t2.add(1, "month")];
  };
  t.emit("set-picker-option", ["isValidValue", M]), t.emit("set-picker-option", ["parseUserInput", (e2) => Array.isArray(e2) ? e2.map((e3) => (0, import_dayjs.default)(e3, $)) : (0, import_dayjs.default)(e2, $)]), t.emit("set-picker-option", ["formatToString", (e2) => Array.isArray(e2) ? e2.map((e3) => e3.format($)) : e2.format($)]), t.emit("set-picker-option", ["handleClear", P]);
  const z = inject("EP_PICKER_BASE"), { shortcuts: L, disabledDate: F, cellClassName: R, format: $, defaultTime: H, defaultValue: W, arrowControl: j, clearable: K } = z.props;
  return watch(() => e.parsedValue, (t2) => {
    if (t2 && t2.length === 2)
      if (r.value = t2[0], s.value = t2[1], a.value = r.value, e.unlinkPanels && s.value) {
        const e2 = r.value.year(), t3 = r.value.month(), l = s.value.year(), a2 = s.value.month();
        i.value = e2 === l && t3 === a2 ? s.value.add(1, "month") : s.value;
      } else
        i.value = a.value.add(1, "month");
    else {
      const e2 = A();
      r.value = null, s.value = null, a.value = e2[0], i.value = e2[1];
    }
  }, { immediate: true }), { shortcuts: L, disabledDate: F, cellClassName: R, minTimePickerVisible: V, maxTimePickerVisible: B, handleMinTimeClose: () => {
    V.value = false;
  }, handleMaxTimeClose: () => {
    B.value = false;
  }, handleShortcutClick: (e2) => {
    e2.value ? t.emit("pick", [(0, import_dayjs.default)(e2.value[0]), (0, import_dayjs.default)(e2.value[1])]) : e2.onClick && e2.onClick(t);
  }, rangeState: T, minDate: r, maxDate: s, handleRangePick: (e2, t2 = true) => {
    const l = D(e2.minDate, 0), a2 = D(e2.maxDate, 1);
    s.value === a2 && r.value === l || (s.value = a2, r.value = l, t2 && !O.value && N());
  }, onSelect: (e2) => {
    T.value.selecting = e2, e2 || (T.value.endDate = null);
  }, handleChangeRange: (e2) => {
    T.value = e2;
  }, btnDisabled: I, enableYearArrow: _, enableMonthArrow: S, rightPrevMonth: () => {
    i.value = i.value.subtract(1, "month");
  }, rightPrevYear: () => {
    i.value = i.value.subtract(1, "year");
  }, rightNextMonth: () => {
    e.unlinkPanels ? i.value = i.value.add(1, "month") : (a.value = a.value.add(1, "month"), i.value = a.value.add(1, "month"));
  }, rightNextYear: () => {
    e.unlinkPanels ? i.value = i.value.add(1, "year") : (a.value = a.value.add(1, "year"), i.value = a.value.add(1, "month"));
  }, leftPrevMonth: () => {
    a.value = a.value.subtract(1, "month"), e.unlinkPanels || (i.value = a.value.add(1, "month"));
  }, leftPrevYear: () => {
    a.value = a.value.subtract(1, "year"), e.unlinkPanels || (i.value = a.value.add(1, "month"));
  }, leftNextMonth: () => {
    a.value = a.value.add(1, "month");
  }, leftNextYear: () => {
    a.value = a.value.add(1, "year");
  }, hasShortcuts: g, leftLabel: c, rightLabel: p, leftDate: a, rightDate: i, showTime: O, t: Ca, minVisibleDate: b, maxVisibleDate: y, minVisibleTime: k, maxVisibleTime: x, arrowControl: j, handleDateInput: (t2, l) => {
    u.value[l] = t2;
    const n = (0, import_dayjs.default)(t2, w.value);
    if (n.isValid()) {
      if (F && F(n.toDate()))
        return;
      l === "min" ? (a.value = n, r.value = (r.value || a.value).year(n.year()).month(n.month()).date(n.date()), e.unlinkPanels || (i.value = n.add(1, "month"), s.value = r.value.add(1, "month"))) : (i.value = n, s.value = (s.value || i.value).year(n.year()).month(n.month()).date(n.date()), e.unlinkPanels || (a.value = n.subtract(1, "month"), r.value = s.value.subtract(1, "month")));
    }
  }, handleDateChange: (e2, t2) => {
    u.value[t2] = null;
  }, handleTimeInput: (e2, t2) => {
    d.value[t2] = e2;
    const l = (0, import_dayjs.default)(e2, C.value);
    l.isValid() && (t2 === "min" ? (V.value = true, r.value = (r.value || a.value).hour(l.hour()).minute(l.minute()).second(l.second()), s.value && !s.value.isBefore(r.value) || (s.value = r.value)) : (B.value = true, s.value = (s.value || i.value).hour(l.hour()).minute(l.minute()).second(l.second()), i.value = s.value, s.value && s.value.isBefore(r.value) && (r.value = s.value)));
  }, handleTimeChange: (e2, t2) => {
    d.value[t2] = null, t2 === "min" ? (a.value = r.value, V.value = false) : (i.value = s.value, B.value = false);
  }, handleMinTimePick: (e2, t2, l) => {
    d.value.min || (e2 && (a.value = e2, r.value = (r.value || a.value).hour(e2.hour()).minute(e2.minute()).second(e2.second())), l || (V.value = t2), s.value && !s.value.isBefore(r.value) || (s.value = r.value));
  }, handleMaxTimePick: (e2, t2, l) => {
    d.value.max || (e2 && (i.value = e2, s.value = (s.value || i.value).hour(e2.hour()).minute(e2.minute()).second(e2.second())), l || (B.value = t2), s.value && s.value.isBefore(r.value) && (r.value = s.value));
  }, handleClear: P, handleConfirm: N, timeFormat: C, clearable: K };
} });
var Bi = { class: "el-picker-panel__body-wrapper" };
var Pi = { key: 0, class: "el-picker-panel__sidebar" };
var Ai = { class: "el-picker-panel__body" };
var zi = { key: 0, class: "el-date-range-picker__time-header" };
var Li = { class: "el-date-range-picker__editors-wrap" };
var Fi = { class: "el-date-range-picker__time-picker-wrap" };
var Ri = { class: "el-date-range-picker__time-picker-wrap" };
var $i = createVNode("span", { class: "el-icon-arrow-right" }, null, -1);
var Hi = { class: "el-date-range-picker__editors-wrap is-right" };
var Wi = { class: "el-date-range-picker__time-picker-wrap" };
var ji = { class: "el-date-range-picker__time-picker-wrap" };
var Ki = { class: "el-picker-panel__content el-date-range-picker__content is-left" };
var Yi = { class: "el-date-range-picker__header" };
var qi = { class: "el-picker-panel__content el-date-range-picker__content is-right" };
var Ui = { class: "el-date-range-picker__header" };
var Gi = { key: 0, class: "el-picker-panel__footer" };
Vi.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("time-pick-panel"), p = resolveComponent("date-table"), b = resolveComponent("el-button"), y = resolveDirective("clickoutside");
  return openBlock(), createBlock("div", { class: ["el-picker-panel el-date-range-picker", [{ "has-sidebar": e.$slots.sidebar || e.hasShortcuts, "has-time": e.showTime }]] }, [createVNode("div", Bi, [renderSlot(e.$slots, "sidebar", { class: "el-picker-panel__sidebar" }), e.hasShortcuts ? (openBlock(), createBlock("div", Pi, [(openBlock(true), createBlock(Fragment, null, renderList(e.shortcuts, (t2, l2) => (openBlock(), createBlock("button", { key: l2, type: "button", class: "el-picker-panel__shortcut", onClick: (l3) => e.handleShortcutClick(t2) }, toDisplayString(t2.text), 9, ["onClick"]))), 128))])) : createCommentVNode("v-if", true), createVNode("div", Ai, [e.showTime ? (openBlock(), createBlock("div", zi, [createVNode("span", Li, [createVNode("span", Fi, [createVNode(i, { size: "small", disabled: e.rangeState.selecting, placeholder: e.t("el.datepicker.startDate"), class: "el-date-range-picker__editor", "model-value": e.minVisibleDate, onInput: t[1] || (t[1] = (t2) => e.handleDateInput(t2, "min")), onChange: t[2] || (t[2] = (t2) => e.handleDateChange(t2, "min")) }, null, 8, ["disabled", "placeholder", "model-value"])]), withDirectives(createVNode("span", Ri, [createVNode(i, { size: "small", class: "el-date-range-picker__editor", disabled: e.rangeState.selecting, placeholder: e.t("el.datepicker.startTime"), "model-value": e.minVisibleTime, onFocus: t[3] || (t[3] = (t2) => e.minTimePickerVisible = true), onInput: t[4] || (t[4] = (t2) => e.handleTimeInput(t2, "min")), onChange: t[5] || (t[5] = (t2) => e.handleTimeChange(t2, "min")) }, null, 8, ["disabled", "placeholder", "model-value"]), createVNode(r, { visible: e.minTimePickerVisible, format: e.timeFormat, "datetime-role": "start", "time-arrow-control": e.arrowControl, "parsed-value": e.leftDate, onPick: e.handleMinTimePick }, null, 8, ["visible", "format", "time-arrow-control", "parsed-value", "onPick"])], 512), [[y, e.handleMinTimeClose]])]), $i, createVNode("span", Hi, [createVNode("span", Wi, [createVNode(i, { size: "small", class: "el-date-range-picker__editor", disabled: e.rangeState.selecting, placeholder: e.t("el.datepicker.endDate"), "model-value": e.maxVisibleDate, readonly: !e.minDate, onInput: t[6] || (t[6] = (t2) => e.handleDateInput(t2, "max")), onChange: t[7] || (t[7] = (t2) => e.handleDateChange(t2, "max")) }, null, 8, ["disabled", "placeholder", "model-value", "readonly"])]), withDirectives(createVNode("span", ji, [createVNode(i, { size: "small", class: "el-date-range-picker__editor", disabled: e.rangeState.selecting, placeholder: e.t("el.datepicker.endTime"), "model-value": e.maxVisibleTime, readonly: !e.minDate, onFocus: t[8] || (t[8] = (t2) => e.minDate && (e.maxTimePickerVisible = true)), onInput: t[9] || (t[9] = (t2) => e.handleTimeInput(t2, "max")), onChange: t[10] || (t[10] = (t2) => e.handleTimeChange(t2, "max")) }, null, 8, ["disabled", "placeholder", "model-value", "readonly"]), createVNode(r, { "datetime-role": "end", visible: e.maxTimePickerVisible, format: e.timeFormat, "time-arrow-control": e.arrowControl, "parsed-value": e.rightDate, onPick: e.handleMaxTimePick }, null, 8, ["visible", "format", "time-arrow-control", "parsed-value", "onPick"])], 512), [[y, e.handleMaxTimeClose]])])])) : createCommentVNode("v-if", true), createVNode("div", Ki, [createVNode("div", Yi, [createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-d-arrow-left", onClick: t[11] || (t[11] = (...t2) => e.leftPrevYear && e.leftPrevYear(...t2)) }), createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-arrow-left", onClick: t[12] || (t[12] = (...t2) => e.leftPrevMonth && e.leftPrevMonth(...t2)) }), e.unlinkPanels ? (openBlock(), createBlock("button", { key: 0, type: "button", disabled: !e.enableYearArrow, class: [{ "is-disabled": !e.enableYearArrow }, "el-picker-panel__icon-btn el-icon-d-arrow-right"], onClick: t[13] || (t[13] = (...t2) => e.leftNextYear && e.leftNextYear(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), e.unlinkPanels ? (openBlock(), createBlock("button", { key: 1, type: "button", disabled: !e.enableMonthArrow, class: [{ "is-disabled": !e.enableMonthArrow }, "el-picker-panel__icon-btn el-icon-arrow-right"], onClick: t[14] || (t[14] = (...t2) => e.leftNextMonth && e.leftNextMonth(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), createVNode("div", null, toDisplayString(e.leftLabel), 1)]), createVNode(p, { "selection-mode": "range", date: e.leftDate, "min-date": e.minDate, "max-date": e.maxDate, "range-state": e.rangeState, "disabled-date": e.disabledDate, "cell-class-name": e.cellClassName, onChangerange: e.handleChangeRange, onPick: e.handleRangePick, onSelect: e.onSelect }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "cell-class-name", "onChangerange", "onPick", "onSelect"])]), createVNode("div", qi, [createVNode("div", Ui, [e.unlinkPanels ? (openBlock(), createBlock("button", { key: 0, type: "button", disabled: !e.enableYearArrow, class: [{ "is-disabled": !e.enableYearArrow }, "el-picker-panel__icon-btn el-icon-d-arrow-left"], onClick: t[15] || (t[15] = (...t2) => e.rightPrevYear && e.rightPrevYear(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), e.unlinkPanels ? (openBlock(), createBlock("button", { key: 1, type: "button", disabled: !e.enableMonthArrow, class: [{ "is-disabled": !e.enableMonthArrow }, "el-picker-panel__icon-btn el-icon-arrow-left"], onClick: t[16] || (t[16] = (...t2) => e.rightPrevMonth && e.rightPrevMonth(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-d-arrow-right", onClick: t[17] || (t[17] = (...t2) => e.rightNextYear && e.rightNextYear(...t2)) }), createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-arrow-right", onClick: t[18] || (t[18] = (...t2) => e.rightNextMonth && e.rightNextMonth(...t2)) }), createVNode("div", null, toDisplayString(e.rightLabel), 1)]), createVNode(p, { "selection-mode": "range", date: e.rightDate, "min-date": e.minDate, "max-date": e.maxDate, "range-state": e.rangeState, "disabled-date": e.disabledDate, "cell-class-name": e.cellClassName, onChangerange: e.handleChangeRange, onPick: e.handleRangePick, onSelect: e.onSelect }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "cell-class-name", "onChangerange", "onPick", "onSelect"])])])]), e.showTime ? (openBlock(), createBlock("div", Gi, [e.clearable ? (openBlock(), createBlock(b, { key: 0, size: "mini", type: "text", class: "el-picker-panel__link-btn", onClick: e.handleClear }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.clear")), 1)]), _: 1 }, 8, ["onClick"])) : createCommentVNode("v-if", true), createVNode(b, { plain: "", size: "mini", class: "el-picker-panel__link-btn", disabled: e.btnDisabled, onClick: t[19] || (t[19] = (t2) => e.handleConfirm(false)) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.t("el.datepicker.confirm")), 1)]), _: 1 }, 8, ["disabled"])])) : createCommentVNode("v-if", true)], 2);
}, Vi.__file = "packages/date-picker/src/date-picker-com/panel-date-range.vue";
var Xi = defineComponent({ components: { MonthTable: ui }, props: { unlinkPanels: Boolean, parsedValue: { type: Array } }, emits: ["pick", "set-picker-option"], setup(e, t) {
  const a = ref((0, import_dayjs.default)()), i = ref((0, import_dayjs.default)().add(1, "year")), r = computed(() => !!b.length), s = computed(() => `${a.value.year()} ${Ca("el.datepicker.year")}`), u = computed(() => `${i.value.year()} ${Ca("el.datepicker.year")}`), d = computed(() => a.value.year()), c = computed(() => i.value.year() === a.value.year() ? a.value.year() + 1 : i.value.year()), p = computed(() => e.unlinkPanels && c.value > d.value + 1), h2 = ref(null), v = ref(null), m = ref({ endDate: null, selecting: false }), f = (e2 = false) => {
    var l;
    l = [h2.value, v.value], Array.isArray(l) && l && l[0] && l[1] && l[0].valueOf() <= l[1].valueOf() && t.emit("pick", [h2.value, v.value], e2);
  };
  t.emit("set-picker-option", ["formatToString", (e2) => e2.map((e3) => e3.format(k))]);
  const g = inject("EP_PICKER_BASE"), { shortcuts: b, disabledDate: y, format: k, defaultValue: x } = g.props;
  return watch(() => e.parsedValue, (t2) => {
    if (t2 && t2.length === 2)
      if (h2.value = t2[0], v.value = t2[1], a.value = h2.value, e.unlinkPanels && v.value) {
        const e2 = h2.value.year(), t3 = v.value.year();
        i.value = e2 === t3 ? v.value.add(1, "year") : v.value;
      } else
        i.value = a.value.add(1, "year");
    else {
      const t3 = (() => {
        let t4;
        if (Array.isArray(x)) {
          const t5 = (0, import_dayjs.default)(x[0]);
          let l = (0, import_dayjs.default)(x[1]);
          return e.unlinkPanels || (l = t5.add(1, "year")), [t5, l];
        }
        return t4 = x ? (0, import_dayjs.default)(x) : (0, import_dayjs.default)(), [t4, t4.add(1, "year")];
      })();
      a.value = t3[0], i.value = t3[1];
    }
  }, { immediate: true }), { shortcuts: b, disabledDate: y, onSelect: (e2) => {
    m.value.selecting = e2, e2 || (m.value.endDate = null);
  }, handleRangePick: (e2, t2 = true) => {
    const l = e2.minDate, a2 = e2.maxDate;
    v.value === a2 && h2.value === l || (v.value = a2, h2.value = l, t2 && f());
  }, rangeState: m, handleChangeRange: (e2) => {
    m.value = e2;
  }, minDate: h2, maxDate: v, enableYearArrow: p, leftLabel: s, rightLabel: u, leftNextYear: () => {
    a.value = a.value.add(1, "year");
  }, leftPrevYear: () => {
    a.value = a.value.subtract(1, "year"), e.unlinkPanels || (i.value = i.value.subtract(1, "year"));
  }, rightNextYear: () => {
    e.unlinkPanels || (a.value = a.value.add(1, "year")), i.value = i.value.add(1, "year");
  }, rightPrevYear: () => {
    i.value = i.value.subtract(1, "year");
  }, t: Ca, leftDate: a, rightDate: i, hasShortcuts: r, handleShortcutClick: (e2) => {
    e2.value ? t.emit("pick", [(0, import_dayjs.default)(e2.value[0]), (0, import_dayjs.default)(e2.value[1])]) : e2.onClick && e2.onClick(t);
  } };
} });
var Zi = { class: "el-picker-panel__body-wrapper" };
var Qi = { key: 0, class: "el-picker-panel__sidebar" };
var Ji = { class: "el-picker-panel__body" };
var er = { class: "el-picker-panel__content el-date-range-picker__content is-left" };
var tr = { class: "el-date-range-picker__header" };
var lr = { class: "el-picker-panel__content el-date-range-picker__content is-right" };
var ar = { class: "el-date-range-picker__header" };
Xi.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("month-table");
  return openBlock(), createBlock("div", { class: ["el-picker-panel el-date-range-picker", [{ "has-sidebar": e.$slots.sidebar || e.hasShortcuts }]] }, [createVNode("div", Zi, [renderSlot(e.$slots, "sidebar", { class: "el-picker-panel__sidebar" }), e.hasShortcuts ? (openBlock(), createBlock("div", Qi, [(openBlock(true), createBlock(Fragment, null, renderList(e.shortcuts, (t2, l2) => (openBlock(), createBlock("button", { key: l2, type: "button", class: "el-picker-panel__shortcut", onClick: (l3) => e.handleShortcutClick(t2) }, toDisplayString(t2.text), 9, ["onClick"]))), 128))])) : createCommentVNode("v-if", true), createVNode("div", Ji, [createVNode("div", er, [createVNode("div", tr, [createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-d-arrow-left", onClick: t[1] || (t[1] = (...t2) => e.leftPrevYear && e.leftPrevYear(...t2)) }), e.unlinkPanels ? (openBlock(), createBlock("button", { key: 0, type: "button", disabled: !e.enableYearArrow, class: [{ "is-disabled": !e.enableYearArrow }, "el-picker-panel__icon-btn el-icon-d-arrow-right"], onClick: t[2] || (t[2] = (...t2) => e.leftNextYear && e.leftNextYear(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), createVNode("div", null, toDisplayString(e.leftLabel), 1)]), createVNode(i, { "selection-mode": "range", date: e.leftDate, "min-date": e.minDate, "max-date": e.maxDate, "range-state": e.rangeState, "disabled-date": e.disabledDate, onChangerange: e.handleChangeRange, onPick: e.handleRangePick, onSelect: e.onSelect }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "onChangerange", "onPick", "onSelect"])]), createVNode("div", lr, [createVNode("div", ar, [e.unlinkPanels ? (openBlock(), createBlock("button", { key: 0, type: "button", disabled: !e.enableYearArrow, class: [{ "is-disabled": !e.enableYearArrow }, "el-picker-panel__icon-btn el-icon-d-arrow-left"], onClick: t[3] || (t[3] = (...t2) => e.rightPrevYear && e.rightPrevYear(...t2)) }, null, 10, ["disabled"])) : createCommentVNode("v-if", true), createVNode("button", { type: "button", class: "el-picker-panel__icon-btn el-icon-d-arrow-right", onClick: t[4] || (t[4] = (...t2) => e.rightNextYear && e.rightNextYear(...t2)) }), createVNode("div", null, toDisplayString(e.rightLabel), 1)]), createVNode(i, { "selection-mode": "range", date: e.rightDate, "min-date": e.minDate, "max-date": e.maxDate, "range-state": e.rangeState, "disabled-date": e.disabledDate, onChangerange: e.handleChangeRange, onPick: e.handleRangePick, onSelect: e.onSelect }, null, 8, ["date", "min-date", "max-date", "range-state", "disabled-date", "onChangerange", "onPick", "onSelect"])])])])], 2);
}, Xi.__file = "packages/date-picker/src/date-picker-com/panel-month-range.vue", import_dayjs.default.extend(import_localeData.default), import_dayjs.default.extend(import_advancedFormat.default), import_dayjs.default.extend(import_customParseFormat.default), import_dayjs.default.extend(import_weekOfYear.default), import_dayjs.default.extend(import_weekYear.default), import_dayjs.default.extend(import_dayOfYear.default), import_dayjs.default.extend(import_isSameOrAfter.default), import_dayjs.default.extend(import_isSameOrBefore.default);
var nr = defineComponent({ name: "ElDatePicker", install: null, props: Object.assign(Object.assign({}, Sa), { type: { type: String, default: "date" } }), emits: ["update:modelValue"], setup(e, t) {
  provide("ElPopperOptions", e.popperOptions);
  const a = ref(null), n = Object.assign(Object.assign({}, e), { focus: () => {
    var e2;
    (e2 = a.value) === null || e2 === void 0 || e2.handleFocus();
  } });
  return t.expose(n), () => {
    var l;
    const n2 = (l = e.format) !== null && l !== void 0 ? l : wa[e.type] || "YYYY-MM-DD";
    return h(Ia, Object.assign(Object.assign({}, e), { format: n2, type: e.type, ref: a, "onUpdate:modelValue": (e2) => t.emit("update:modelValue", e2) }), { default: (t2) => {
      return h((l2 = e.type) === "daterange" || l2 === "datetimerange" ? Vi : l2 === "monthrange" ? Xi : Si, t2);
      var l2;
    } });
  };
} });
nr.install = (e) => {
  e.component(nr.name, nr);
};
var or = defineComponent({ name: "ElOverlay", props: { mask: { type: Boolean, default: true }, overlayClass: { type: [String, Array, Object] }, zIndex: { type: Number } }, emits: ["click"], setup(e, { slots: t, emit: l }) {
  let a = false, n = false;
  const o = (e2) => {
    a && n && l("click", e2), a = n = false;
  };
  return () => e.mask ? createVNode("div", { class: ["el-overlay", e.overlayClass], style: { zIndex: e.zIndex }, onClick: o, onMousedown: (t2) => {
    e.mask && (a = t2.target === t2.currentTarget);
  }, onMouseup: (t2) => {
    e.mask && (n = t2.target === t2.currentTarget);
  } }, [renderSlot(t, "default")], Al.STYLE | Al.CLASS | Al.PROPS, ["onClick", "onMouseup", "onMousedown"]) : h("div", { class: e.overlayClass, style: { zIndex: e.zIndex, position: "fixed", top: "0px", right: "0px", bottom: "0px", left: "0px" } }, [renderSlot(t, "default")]);
} });
or.__file = "packages/overlay/src/index.vue";
function ir(e, t, a) {
  const r = ref(false), s = ref(false), u = ref(null), d = ref(null), c = ref(null), p = ref(false), h2 = ref(e.zIndex || Ol.nextZIndex()), v = ref(null), m = computed(() => {
    const t2 = {};
    return e.fullscreen || (t2.marginTop = e.top, e.width && (t2.width = Ke(e.width) ? e.width + "px" : e.width)), t2;
  });
  function f() {
    qe(c), qe(d), e.openDelay && e.openDelay > 0 ? d.value = window.setTimeout(() => {
      d.value = null, k();
    }, e.openDelay) : k();
  }
  function g() {
    qe(d), qe(c), e.closeDelay && e.closeDelay > 0 ? c.value = window.setTimeout(() => {
      c.value = null, x();
    }, e.closeDelay) : x();
  }
  function b(e2) {
    e2 || (s.value = true, r.value = false);
  }
  function y() {
    e.beforeClose ? e.beforeClose(b) : g();
  }
  function k() {
    ke || (r.value = true);
  }
  function x() {
    r.value = false;
  }
  return e.lockScroll && Ot(r), e.closeOnPressEscape && Lt({ handleClose: y }, r), Nt(r), watch(() => e.modelValue, (l) => {
    l ? (s.value = false, f(), p.value = true, t.emit("open"), h2.value = e.zIndex ? h2.value++ : Ol.nextZIndex(), nextTick(() => {
      a.value && (a.value.scrollTop = 0);
    })) : r.value && g();
  }), onMounted(() => {
    e.modelValue && (r.value = true, p.value = true, f());
  }), { afterEnter: function() {
    t.emit("opened");
  }, afterLeave: function() {
    t.emit("closed"), t.emit(Gt, false), e.destroyOnClose && (p.value = false);
  }, beforeLeave: function() {
    t.emit("close");
  }, handleClose: y, onModalClick: function() {
    e.closeOnClickModal && y();
  }, closed: s, dialogRef: u, style: m, rendered: p, modalRef: v, visible: r, zIndex: h2 };
}
var rr = defineComponent({ name: "ElDialog", components: { "el-overlay": or }, directives: { TrapFocus: Yt }, props: { appendToBody: { type: Boolean, default: false }, beforeClose: { type: Function }, destroyOnClose: { type: Boolean, default: false }, center: { type: Boolean, default: false }, customClass: { type: String, default: "" }, closeOnClickModal: { type: Boolean, default: true }, closeOnPressEscape: { type: Boolean, default: true }, fullscreen: { type: Boolean, default: false }, lockScroll: { type: Boolean, default: true }, modal: { type: Boolean, default: true }, showClose: { type: Boolean, default: true }, title: { type: String, default: "" }, openDelay: { type: Number, default: 0 }, closeDelay: { type: Number, default: 0 }, top: { type: String, default: "15vh" }, modelValue: { type: Boolean, required: true }, modalClass: String, width: { type: [String, Number], default: "50%", validator: (e) => !!Ke(e) || ["px", "rem", "em", "vw", "%", "vmin", "vmax"].some((t) => e.endsWith(t)) }, zIndex: { type: Number } }, emits: ["open", "opened", "close", "closed", Gt], setup(e, t) {
  const a = ref(null);
  return Object.assign(Object.assign({}, ir(e, t, a)), { dialogRef: a });
} });
var sr = { class: "el-dialog__header" };
var ur = { class: "el-dialog__title" };
var dr = createVNode("i", { class: "el-dialog__close el-icon el-icon-close" }, null, -1);
var cr = { key: 0, class: "el-dialog__body" };
var pr = { key: 1, class: "el-dialog__footer" };
rr.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-overlay"), r = resolveDirective("trap-focus");
  return openBlock(), createBlock(Teleport, { to: "body", disabled: !e.appendToBody }, [createVNode(Transition, { name: "dialog-fade", onAfterEnter: e.afterEnter, onAfterLeave: e.afterLeave, onBeforeLeave: e.beforeLeave }, { default: withCtx(() => [withDirectives(createVNode(i, { mask: e.modal, "overlay-class": e.modalClass, "z-index": e.zIndex, onClick: e.onModalClick }, { default: withCtx(() => [withDirectives(createVNode("div", { ref: "dialogRef", class: ["el-dialog", { "is-fullscreen": e.fullscreen, "el-dialog--center": e.center }, e.customClass], "aria-modal": "true", role: "dialog", "aria-label": e.title || "dialog", style: e.style, onClick: t[2] || (t[2] = withModifiers(() => {
  }, ["stop"])) }, [createVNode("div", sr, [renderSlot(e.$slots, "title", {}, () => [createVNode("span", ur, toDisplayString(e.title), 1)]), e.showClose ? (openBlock(), createBlock("button", { key: 0, "aria-label": "close", class: "el-dialog__headerbtn", type: "button", onClick: t[1] || (t[1] = (...t2) => e.handleClose && e.handleClose(...t2)) }, [dr])) : createCommentVNode("v-if", true)]), e.rendered ? (openBlock(), createBlock("div", cr, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true), e.$slots.footer ? (openBlock(), createBlock("div", pr, [renderSlot(e.$slots, "footer")])) : createCommentVNode("v-if", true)], 14, ["aria-label"]), [[r]])]), _: 3 }, 8, ["mask", "overlay-class", "z-index", "onClick"]), [[vShow, e.visible]])]), _: 1 }, 8, ["onAfterEnter", "onAfterLeave", "onBeforeLeave"])], 8, ["disabled"]);
}, rr.__file = "packages/dialog/src/index.vue", rr.install = (e) => {
  e.component(rr.name, rr);
};
var hr = rr;
var vr = defineComponent({ name: "ElDivider", props: { direction: { type: String, default: "horizontal", validator: (e) => ["horizontal", "vertical"].indexOf(e) !== -1 }, contentPosition: { type: String, default: "center", validator: (e) => ["left", "center", "right"].indexOf(e) !== -1 } } });
vr.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-divider", "el-divider--" + e.direction] }, [e.$slots.default && e.direction !== "vertical" ? (openBlock(), createBlock("div", { key: 0, class: ["el-divider__text", "is-" + e.contentPosition] }, [renderSlot(e.$slots, "default")], 2)) : createCommentVNode("v-if", true)], 2);
}, vr.__file = "packages/divider/src/index.vue", vr.install = (e) => {
  e.component(vr.name, vr);
};
var mr = vr;
var fr = defineComponent({ name: "ElDrawer", components: { [or.name]: or }, directives: { TrapFocus: Yt }, props: { modelValue: { type: Boolean, required: true }, appendToBody: { type: Boolean, default: false }, beforeClose: Function, customClass: { type: String, default: "" }, direction: { type: String, default: "rtl", validator: (e) => ["ltr", "rtl", "ttb", "btt"].indexOf(e) !== -1 }, showClose: { type: Boolean, default: true }, size: { type: [String, Number], default: "30%" }, title: { type: String, default: "" }, closeOnClickModal: { type: Boolean, default: true }, withHeader: { type: Boolean, default: true }, openDelay: { type: Number, default: 0 }, closeDelay: { type: Number, default: 0 }, zIndex: Number, modal: { type: Boolean, default: true }, modalFade: { type: Boolean, default: true }, modalClass: String, lockScroll: { type: Boolean, default: true }, closeOnPressEscape: { type: Boolean, default: true }, destroyOnClose: { type: Boolean, default: false } }, emits: ["open", "opened", "close", "closed", "update:modelValue"], setup(e, t) {
  const a = ref(null);
  return Object.assign(Object.assign({}, ir(e, t, a)), { drawerRef: a, isHorizontal: computed(() => e.direction === "rtl" || e.direction === "ltr"), drawerSize: computed(() => typeof e.size == "number" ? e.size + "px" : e.size) });
} });
var gr = { key: 0, id: "el-drawer__title", class: "el-drawer__header" };
var br = createVNode("i", { class: "el-drawer__close el-icon el-icon-close" }, null, -1);
var yr = { key: 1, class: "el-drawer__body" };
fr.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-overlay"), r = resolveDirective("trap-focus");
  return openBlock(), createBlock(Teleport, { to: "body", disabled: !e.appendToBody }, [createVNode(Transition, { name: "el-drawer-fade", onAfterEnter: e.afterEnter, onAfterLeave: e.afterLeave, onBeforeLeave: e.beforeLeave }, { default: withCtx(() => [withDirectives(createVNode(i, { mask: e.modal, "overlay-class": e.modalClass, "z-index": e.zIndex, onClick: e.onModalClick }, { default: withCtx(() => [withDirectives(createVNode("div", { ref: "drawerRef", "aria-modal": "true", "aria-labelledby": "el-drawer__title", "aria-label": e.title, class: ["el-drawer", e.direction, e.customClass], style: e.isHorizontal ? "width: " + e.drawerSize : "height: " + e.drawerSize, role: "dialog", onClick: t[2] || (t[2] = withModifiers(() => {
  }, ["stop"])) }, [e.withHeader ? (openBlock(), createBlock("header", gr, [renderSlot(e.$slots, "title", {}, () => [createVNode("span", { role: "heading", title: e.title }, toDisplayString(e.title), 9, ["title"])]), e.showClose ? (openBlock(), createBlock("button", { key: 0, "aria-label": "close " + (e.title || "drawer"), class: "el-drawer__close-btn", type: "button", onClick: t[1] || (t[1] = (...t2) => e.handleClose && e.handleClose(...t2)) }, [br], 8, ["aria-label"])) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), e.rendered ? (openBlock(), createBlock("section", yr, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true)], 14, ["aria-label"]), [[r]])]), _: 3 }, 8, ["mask", "overlay-class", "z-index", "onClick"]), [[vShow, e.visible]])]), _: 1 }, 8, ["onAfterEnter", "onAfterLeave", "onBeforeLeave"])], 8, ["disabled"]);
}, fr.__file = "packages/drawer/src/index.vue", fr.install = (e) => {
  e.component(fr.name, fr);
};
var kr = fr;
var xr = () => {
  const e = Xe(), t = inject("elDropdown", {}), l = computed(() => t == null ? void 0 : t.dropdownSize);
  return { ELEMENT: e, elDropdown: t, _elDropdownSize: l };
};
var Cr = (e, t, a) => {
  const n = ref(null), o = ref(null), i = ref(null), r = ref("dropdown-menu-" + He());
  function s() {
    var e2;
    t.setAttribute("tabindex", "-1"), (e2 = o.value) === null || e2 === void 0 || e2.forEach((e3) => {
      e3.setAttribute("tabindex", "-1");
    });
  }
  function u(e2) {
    s(), e2 == null || e2.setAttribute("tabindex", "0");
  }
  function d(e2) {
    const t2 = e2.code;
    [Dt.up, Dt.down].includes(t2) ? (s(), u(n.value[0]), n.value[0].focus(), e2.preventDefault(), e2.stopPropagation()) : t2 === Dt.enter ? a.handleClick() : [Dt.tab, Dt.esc].includes(t2) && a.hide();
  }
  function c(e2) {
    const t2 = e2.code, l = e2.target, i2 = o.value.indexOf(l), r2 = o.value.length - 1;
    let d2;
    [Dt.up, Dt.down].includes(t2) ? (d2 = t2 === Dt.up ? i2 !== 0 ? i2 - 1 : 0 : i2 < r2 ? i2 + 1 : r2, s(), u(n.value[d2]), n.value[d2].focus(), e2.preventDefault(), e2.stopPropagation()) : t2 === Dt.enter ? (p(), l.click(), a.props.hideOnClick && a.hide()) : [Dt.tab, Dt.esc].includes(t2) && (a.hide(), p());
  }
  function p() {
    t.focus();
  }
  i.value = e == null ? void 0 : e.subTree.el, n.value = i.value.querySelectorAll("[tabindex='-1']"), o.value = [].slice.call(n.value), at(t, "keydown", d), at(i.value, "keydown", c, true), i.value.setAttribute("id", r.value), t.setAttribute("aria-haspopup", "list"), t.setAttribute("aria-controls", r.value), a.props.splitButton || (t.setAttribute("role", "button"), t.setAttribute("tabindex", a.props.tabindex), it(t, "el-dropdown-selfdefine"));
};
var wr = defineComponent({ name: "ElDropdown", components: { ElButton: ma, ElButtonGroup: ba, ElScrollbar: Cl, ElPopper: Kl }, props: { trigger: { type: String, default: "hover" }, type: String, size: { type: String, default: "" }, splitButton: Boolean, hideOnClick: { type: Boolean, default: true }, placement: { type: String, default: "bottom" }, showTimeout: { type: Number, default: 150 }, hideTimeout: { type: Number, default: 150 }, tabindex: { type: [Number, String], default: 0 }, effect: { type: String, default: "light" }, maxHeight: { type: [Number, String], default: "" } }, emits: ["visible-change", "click", "command"], setup(t, { emit: a }) {
  const r = getCurrentInstance(), { ELEMENT: s } = xr(), u = ref(null), d = ref(false), c = ref(null), p = computed(() => "max-height: " + lt(t.maxHeight));
  watch(() => d.value, (e) => {
    var t2, l;
    e && ((l = (t2 = m.value) === null || t2 === void 0 ? void 0 : t2.focus) === null || l === void 0 || l.call(t2)), e || function() {
      var e2, t3;
      (t3 = (e2 = m.value) === null || e2 === void 0 ? void 0 : e2.blur) === null || t3 === void 0 || t3.call(e2);
    }(), a("visible-change", e);
  });
  const h2 = ref(false);
  watch(() => h2.value, (e) => {
    const t2 = m.value;
    t2 && (e ? it(t2, "focusing") : rt(t2, "focusing"));
  });
  const v = ref(null), m = computed(() => {
    var e, l, a2, n;
    const o = (a2 = (l = (e = v.value) === null || e === void 0 ? void 0 : e.$refs.triggerRef) === null || l === void 0 ? void 0 : l.children[0]) !== null && a2 !== void 0 ? a2 : {};
    return t.splitButton ? (n = o.children) === null || n === void 0 ? void 0 : n[1] : o;
  });
  function f() {
    var e;
    ((e = m.value) === null || e === void 0 ? void 0 : e.disabled) || (d.value ? b() : g());
  }
  function g() {
    var e;
    ((e = m.value) === null || e === void 0 ? void 0 : e.disabled) || (u.value && clearTimeout(u.value), u.value = window.setTimeout(() => {
      d.value = true;
    }, ["click", "contextmenu"].includes(t.trigger) ? 0 : t.showTimeout));
  }
  function b() {
    var e;
    ((e = m.value) === null || e === void 0 ? void 0 : e.disabled) || (y(), t.tabindex >= 0 && k(m.value), clearTimeout(u.value), u.value = window.setTimeout(() => {
      d.value = false;
    }, ["click", "contextmenu"].includes(t.trigger) ? 0 : t.hideTimeout));
  }
  function y() {
    var e;
    (e = m.value) === null || e === void 0 || e.setAttribute("tabindex", "-1");
  }
  function k(e) {
    y(), e == null || e.setAttribute("tabindex", "0");
  }
  const x = computed(() => t.size || s.size);
  provide("elDropdown", { instance: r, dropdownSize: x, visible: d, handleClick: f, commandHandler: function(...e) {
    a("command", ...e);
  }, show: g, hide: b, trigger: computed(() => t.trigger), hideOnClick: computed(() => t.hideOnClick), triggerElm: m }), onMounted(() => {
    t.splitButton || (at(m.value, "focus", () => {
      h2.value = true;
    }), at(m.value, "blur", () => {
      h2.value = false;
    }), at(m.value, "click", () => {
      h2.value = false;
    })), t.trigger === "hover" ? (at(m.value, "mouseenter", g), at(m.value, "mouseleave", b)) : t.trigger === "click" ? at(m.value, "click", f) : t.trigger === "contextmenu" && at(m.value, "contextmenu", (e) => {
      e.preventDefault(), f();
    }), Object.assign(r, { handleClick: f, hide: b, resetTabindex: k });
  });
  return { visible: d, scrollbar: c, wrapStyle: p, dropdownSize: x, handlerMainButtonClick: (e) => {
    a("click", e), b();
  }, triggerVnode: v };
} });
var Sr = createVNode("i", { class: "el-dropdown__icon el-icon-arrow-down" }, null, -1);
wr.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-scrollbar"), r = resolveComponent("el-button"), p = resolveComponent("el-button-group"), v = resolveComponent("el-popper");
  return openBlock(), createBlock(v, { ref: "triggerVnode", visible: e.visible, "onUpdate:visible": t[1] || (t[1] = (t2) => e.visible = t2), placement: e.placement, "fallback-placements": ["bottom", "top", "right", "left"], effect: e.effect, pure: "", "manual-mode": true, trigger: [e.trigger], "popper-class": "el-dropdown__popper", "append-to-body": "", transition: "el-zoom-in-top", "stop-popper-mouse-event": false, "gpu-acceleration": false }, { default: withCtx(() => [createVNode(i, { ref: "scrollbar", tag: "ul", "wrap-style": e.wrapStyle, "view-class": "el-dropdown__list" }, { default: withCtx(() => [renderSlot(e.$slots, "dropdown")]), _: 3 }, 8, ["wrap-style"])]), trigger: withCtx(() => [createVNode("div", { class: ["el-dropdown", e.dropdownSize ? "el-dropdown--" + e.dropdownSize : ""] }, [e.splitButton ? (openBlock(), createBlock(p, { key: 1 }, { default: withCtx(() => [createVNode(r, { size: e.dropdownSize, type: e.type, onClick: e.handlerMainButtonClick }, { default: withCtx(() => [renderSlot(e.$slots, "default")]), _: 3 }, 8, ["size", "type", "onClick"]), createVNode(r, { size: e.dropdownSize, type: e.type, class: "el-dropdown__caret-button" }, { default: withCtx(() => [Sr]), _: 1 }, 8, ["size", "type"])]), _: 1 })) : renderSlot(e.$slots, "default", { key: 0 })], 2)]), _: 1 }, 8, ["visible", "placement", "effect", "trigger"]);
}, wr.__file = "packages/dropdown/src/dropdown.vue", wr.install = (e) => {
  e.component(wr.name, wr);
};
var _r = wr;
var Er = defineComponent({ name: "ElDropdownItem", props: { command: { type: [Object, String, Number], default: () => ({}) }, disabled: Boolean, divided: Boolean, icon: String }, setup(t) {
  const { elDropdown: l } = xr(), a = getCurrentInstance();
  return { handleClick: function(e) {
    var n, o;
    t.disabled ? e.stopImmediatePropagation() : (l.hideOnClick.value && ((n = l.handleClick) === null || n === void 0 || n.call(l)), (o = l.commandHandler) === null || o === void 0 || o.call(l, t.command, a, e));
  } };
} });
Er.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("li", { class: ["el-dropdown-menu__item", { "is-disabled": e.disabled, "el-dropdown-menu__item--divided": e.divided }], "aria-disabled": e.disabled, tabindex: e.disabled ? null : -1, onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [e.icon ? (openBlock(), createBlock("i", { key: 0, class: e.icon }, null, 2)) : createCommentVNode("v-if", true), renderSlot(e.$slots, "default")], 10, ["aria-disabled", "tabindex"]);
}, Er.__file = "packages/dropdown/src/dropdown-item.vue", Er.install = (e) => {
  e.component(Er.name, Er);
};
var Mr = Er;
var Tr = defineComponent({ name: "ElDropdownMenu", directives: { ClickOutside: Ht }, setup() {
  const { _elDropdownSize: t, elDropdown: l } = xr(), a = t.value;
  function n() {
    var e;
    (e = l.hide) === null || e === void 0 || e.call(l);
  }
  return onMounted(() => {
    const t2 = getCurrentInstance();
    Cr(t2, l.triggerElm.value, l.instance);
  }), { size: a, show: function() {
    var e;
    ["click", "contextmenu"].includes(l.trigger.value) || (e = l.show) === null || e === void 0 || e.call(l);
  }, hide: function() {
    ["click", "contextmenu"].includes(l.trigger.value) || n();
  }, innerHide: n, triggerElm: l.triggerElm };
} });
Tr.render = function(e, t, l, a, n, o) {
  const i = resolveDirective("clickOutside");
  return withDirectives((openBlock(), createBlock("ul", { class: [[e.size && "el-dropdown-menu--" + e.size], "el-dropdown-menu"], onMouseenter: t[1] || (t[1] = withModifiers((...t2) => e.show && e.show(...t2), ["stop"])), onMouseleave: t[2] || (t[2] = withModifiers((...t2) => e.hide && e.hide(...t2), ["stop"])) }, [renderSlot(e.$slots, "default")], 34)), [[i, e.innerHide, e.triggerElm]]);
}, Tr.__file = "packages/dropdown/src/dropdown-menu.vue", Tr.install = (e) => {
  e.component(Tr.name, Tr);
};
var Ir = Tr;
var Or = 0;
var Nr = defineComponent({ name: "ImgEmpty", setup: () => ({ id: ++Or }) });
var Dr = { viewBox: "0 0 79 86", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink" };
var Vr = createVNode("stop", { "stop-color": "#FCFCFD", offset: "0%" }, null, -1);
var Br = createVNode("stop", { "stop-color": "#EEEFF3", offset: "100%" }, null, -1);
var Pr = createVNode("stop", { "stop-color": "#FCFCFD", offset: "0%" }, null, -1);
var Ar = createVNode("stop", { "stop-color": "#E9EBEF", offset: "100%" }, null, -1);
var zr = { id: "Illustrations", stroke: "none", "stroke-width": "1", fill: "none", "fill-rule": "evenodd" };
var Lr = { id: "B-type", transform: "translate(-1268.000000, -535.000000)" };
var Fr = { id: "Group-2", transform: "translate(1268.000000, 535.000000)" };
var Rr = createVNode("path", { id: "Oval-Copy-2", d: "M39.5,86 C61.3152476,86 79,83.9106622 79,81.3333333 C79,78.7560045 57.3152476,78 35.5,78 C13.6847524,78 0,78.7560045 0,81.3333333 C0,83.9106622 17.6847524,86 39.5,86 Z", fill: "#F7F8FC" }, null, -1);
var $r = createVNode("polygon", { id: "Rectangle-Copy-14", fill: "#E5E7E9", transform: "translate(27.500000, 51.500000) scale(1, -1) translate(-27.500000, -51.500000) ", points: "13 58 53 58 42 45 2 45" }, null, -1);
var Hr = { id: "Group-Copy", transform: "translate(34.500000, 31.500000) scale(-1, 1) rotate(-25.000000) translate(-34.500000, -31.500000) translate(7.000000, 10.000000)" };
var Wr = createVNode("polygon", { id: "Rectangle-Copy-10", fill: "#E5E7E9", transform: "translate(11.500000, 5.000000) scale(1, -1) translate(-11.500000, -5.000000) ", points: "2.84078316e-14 3 18 3 23 7 5 7" }, null, -1);
var jr = createVNode("polygon", { id: "Rectangle-Copy-11", fill: "#EDEEF2", points: "-3.69149156e-15 7 38 7 38 43 -3.69149156e-15 43" }, null, -1);
var Kr = createVNode("polygon", { id: "Rectangle-Copy-13", fill: "#F8F9FB", transform: "translate(39.500000, 3.500000) scale(-1, 1) translate(-39.500000, -3.500000) ", points: "24 7 41 7 55 -3.63806207e-12 38 -3.63806207e-12" }, null, -1);
var Yr = { id: "Rectangle-Copy-17", transform: "translate(53.000000, 45.000000)" };
var qr = createVNode("polygon", { id: "Rectangle-Copy-18", fill: "#F8F9FB", transform: "translate(66.000000, 51.500000) scale(-1, 1) translate(-66.000000, -51.500000) ", points: "62 45 79 45 70 58 53 58" }, null, -1);
Nr.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", Dr, [createVNode("defs", null, [createVNode("linearGradient", { id: "linearGradient-1-" + e.id, x1: "38.8503086%", y1: "0%", x2: "61.1496914%", y2: "100%" }, [Vr, Br], 8, ["id"]), createVNode("linearGradient", { id: "linearGradient-2-" + e.id, x1: "0%", y1: "9.5%", x2: "100%", y2: "90.5%" }, [Pr, Ar], 8, ["id"]), createVNode("rect", { id: "path-3-" + e.id, x: "0", y: "0", width: "17", height: "36" }, null, 8, ["id"])]), createVNode("g", zr, [createVNode("g", Lr, [createVNode("g", Fr, [Rr, $r, createVNode("g", Hr, [Wr, jr, createVNode("rect", { id: "Rectangle-Copy-12", fill: `url(#linearGradient-1-${e.id})`, transform: "translate(46.500000, 25.000000) scale(-1, 1) translate(-46.500000, -25.000000) ", x: "38", y: "7", width: "17", height: "36" }, null, 8, ["fill"]), Kr]), createVNode("rect", { id: "Rectangle-Copy-15", fill: `url(#linearGradient-2-${e.id})`, x: "13", y: "45", width: "40", height: "36" }, null, 8, ["fill"]), createVNode("g", Yr, [createVNode("mask", { id: "mask-4-" + e.id, fill: "white" }, [createVNode("use", { "xlink:href": "#path-3-" + e.id }, null, 8, ["xlink:href"])], 8, ["id"]), createVNode("use", { id: "Mask", fill: "#E0E3E9", transform: "translate(8.500000, 18.000000) scale(-1, 1) translate(-8.500000, -18.000000) ", "xlink:href": "#path-3-" + e.id }, null, 8, ["xlink:href"]), createVNode("polygon", { id: "Rectangle-Copy", fill: "#D5D7DE", mask: `url(#mask-4-${e.id})`, transform: "translate(12.000000, 9.000000) scale(-1, 1) translate(-12.000000, -9.000000) ", points: "7 0 24 0 20 18 -1.70530257e-13 16" }, null, 8, ["mask"])]), qr])])])]);
}, Nr.__file = "packages/empty/src/img-empty.vue";
var Ur = defineComponent({ name: "ElEmpty", components: { [Nr.name]: Nr }, props: { image: { type: String, default: "" }, imageSize: Number, description: { type: String, default: "" } }, setup: (e) => ({ emptyDescription: computed(() => e.description || Ca("el.table.emptyText")), imageStyle: computed(() => ({ width: e.imageSize ? e.imageSize + "px" : "" })) }) });
var Gr = { class: "el-empty" };
var Xr = { class: "el-empty__description" };
var Zr = { key: 1 };
var Qr = { key: 0, class: "el-empty__bottom" };
Ur.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("img-empty");
  return openBlock(), createBlock("div", Gr, [createVNode("div", { class: "el-empty__image", style: e.imageStyle }, [e.image ? (openBlock(), createBlock("img", { key: 0, src: e.image, ondragstart: "return false" }, null, 8, ["src"])) : renderSlot(e.$slots, "image", { key: 1 }, () => [createVNode(i)])], 4), createVNode("div", Xr, [e.$slots.description ? renderSlot(e.$slots, "description", { key: 0 }) : (openBlock(), createBlock("p", Zr, toDisplayString(e.emptyDescription), 1))]), e.$slots.default ? (openBlock(), createBlock("div", Qr, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true)]);
}, Ur.__file = "packages/empty/src/index.vue", Ur.install = (e) => {
  e.component(Ur.name, Ur);
};
var Jr = Ur;
var es = defineComponent({ name: "ElFooter", props: { height: { type: String, default: "60px" } } });
es.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("footer", { class: "el-footer", style: { height: e.height } }, [renderSlot(e.$slots, "default")], 4);
}, es.__file = "packages/container/src/footer.vue", es.install = (e) => {
  e.component(es.name, es);
};
var ts = es;
var ls = defineComponent({ name: "ElLabelWrap", props: { isAutoWidth: Boolean, updateAll: Boolean }, setup(e, { slots: t }) {
  const a = ref(null), n = inject("elForm"), s = inject("elFormItem"), u = ref(0);
  watch(u, (t2, l) => {
    e.updateAll && (n.registerLabelWidth(t2, l), s.updateComputedLabelWidth(t2));
  });
  const d = (l = "update") => {
    nextTick(() => {
      t.default && e.isAutoWidth && (l === "update" ? u.value = (() => {
        var e2;
        if ((e2 = a.value) === null || e2 === void 0 ? void 0 : e2.firstElementChild) {
          const e3 = window.getComputedStyle(a.value.firstElementChild).width;
          return Math.ceil(parseFloat(e3));
        }
        return 0;
      })() : l === "remove" && n.deregisterLabelWidth(u.value));
    });
  }, c = () => d("update");
  return onMounted(() => {
    vt(a.value.firstElementChild, c), c();
  }), onUpdated(c), onBeforeUnmount(() => {
    d("remove"), mt(a.value.firstElementChild, c);
  }), function() {
    var e2;
    return t ? h(Fragment, { ref: a }, (e2 = t.default) === null || e2 === void 0 ? void 0 : e2.call(t)) : null;
  };
} });
var as = defineComponent({ name: "ElFormItem", componentName: "ElFormItem", components: { LabelWrap: ls }, props: { label: String, labelWidth: String, prop: String, required: { type: Boolean, default: void 0 }, rules: [Object, Array], error: String, validateStatus: String, for: String, inlineMessage: { type: [String, Boolean], default: "" }, showMessage: { type: Boolean, default: true }, size: { types: String, validator: Qt } }, setup(t, { slots: s }) {
  const u = mitt_es_default(), d = Xe(), c = inject("elForm", {}), p = ref(""), h2 = ref(""), v = ref(false), m = ref(""), f = getCurrentInstance(), g = computed(() => {
    let e = f.parent;
    for (; e && e.type.name !== "ElForm"; ) {
      if (e.type.name === "ElFormItem")
        return true;
      e = e.parent;
    }
    return false;
  });
  let b = void 0;
  watch(() => t.error, (e) => {
    h2.value = e, p.value = e ? "error" : "";
  }, { immediate: true }), watch(() => t.validateStatus, (e) => {
    p.value = e;
  });
  const y = computed(() => t.for || t.prop), k = computed(() => {
    if (c.labelPosition === "top")
      return {};
    const e = t.labelWidth || c.labelWidth;
    return e ? { width: e } : {};
  }), x = computed(() => {
    if (c.labelPosition === "top" || c.inline)
      return {};
    if (!t.label && !t.labelWidth && g.value)
      return {};
    const e = t.labelWidth || c.labelWidth, l = {};
    return t.label || s.label || (l.marginLeft = e), l;
  }), C = computed(() => {
    const e = c.model;
    if (!e || !t.prop)
      return;
    let l = t.prop;
    return l.indexOf(":") !== -1 && (l = l.replace(/:/, ".")), $e(e, l, true).v;
  }), M = computed(() => {
    let e = V(), t2 = false;
    return e && e.length && e.every((e2) => !e2.required || (t2 = true, false)), t2;
  }), T = computed(() => t.size || c.size), I = computed(() => T.value || d.size), O = (e, l = xe) => {
    v.value = false;
    const a = B(e);
    if ((!a || a.length === 0) && t.required === void 0)
      return void l();
    p.value = "validating";
    const n = {};
    a && a.length > 0 && a.forEach((e2) => {
      delete e2.trigger;
    }), n[t.prop] = a;
    const o = new dist_web_default(n), i = {};
    i[t.prop] = C.value, o.validate(i, { firstFields: true }, (e2, a2) => {
      var n2;
      p.value = e2 ? "error" : "success", h2.value = e2 ? e2[0].message : "", l(h2.value, a2), (n2 = c.emit) === null || n2 === void 0 || n2.call(c, "validate", t.prop, !e2, h2.value || null);
    });
  }, N = () => {
    p.value = "", h2.value = "", v.value = false;
  }, D = () => {
    p.value = "", h2.value = "";
    let e = c.model, l = C.value, a = t.prop;
    a.indexOf(":") !== -1 && (a = a.replace(/:/, "."));
    let n = $e(e, a, true);
    v.value = true, Array.isArray(l) ? n.o[n.k] = [].concat(b) : n.o[n.k] = b, nextTick(() => {
      v.value = false;
    });
  }, V = () => {
    const e = c.rules, l = t.rules, a = t.required !== void 0 ? { required: !!t.required } : [], n = $e(e, t.prop || "", false), o = e ? n.o[t.prop || ""] || n.v : [];
    return [].concat(l || o || []).concat(a);
  }, B = (e) => V().filter((t2) => !t2.trigger || e === "" || (Array.isArray(t2.trigger) ? t2.trigger.indexOf(e) > -1 : t2.trigger === e)).map((e2) => Object.assign({}, e2)), P = () => {
    O("blur");
  }, A = () => {
    v.value ? v.value = false : O("change");
  }, z = () => {
    (V().length || t.required !== void 0) && (u.on("el.form.blur", P), u.on("el.form.change", A));
  }, L = reactive(Object.assign(Object.assign({}, toRefs(t)), { size: I, validateState: p, removeValidateEvents: () => {
    u.off("el.form.blur", P), u.off("el.form.change", A);
  }, addValidateEvents: z, resetField: D, clearValidate: N, validate: O, formItemMitt: u, updateComputedLabelWidth: (e) => {
    m.value = e ? e + "px" : "";
  } }));
  onMounted(() => {
    var e;
    if (t.prop) {
      (e = c.formMitt) === null || e === void 0 || e.emit(el, L);
      let t2 = C.value;
      b = Array.isArray(t2) ? [...t2] : t2, z();
    }
  }), onBeforeUnmount(() => {
    var e;
    (e = c.formMitt) === null || e === void 0 || e.emit(tl, L);
  }), provide("elFormItem", L);
  return { formItemClass: computed(() => [{ "el-form-item--feedback": c.statusIcon, "is-error": p.value === "error", "is-validating": p.value === "validating", "is-success": p.value === "success", "is-required": M.value || t.required, "is-no-asterisk": c.hideRequiredAsterisk }, I.value ? "el-form-item--" + I.value : ""]), shouldShowError: computed(() => p.value === "error" && t.showMessage && c.showMessage), elForm: c, labelStyle: k, contentStyle: x, validateMessage: h2, labelFor: y, resetField: D, clearValidate: N };
} });
as.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("LabelWrap");
  return openBlock(), createBlock("div", { class: ["el-form-item", e.formItemClass] }, [createVNode(i, { "is-auto-width": e.labelStyle.width === "auto", "update-all": e.elForm.labelWidth === "auto" }, { default: withCtx(() => [e.label || e.$slots.label ? (openBlock(), createBlock("label", { key: 0, for: e.labelFor, class: "el-form-item__label", style: e.labelStyle }, [renderSlot(e.$slots, "label", {}, () => [createTextVNode(toDisplayString(e.label + e.elForm.labelSuffix), 1)])], 12, ["for"])) : createCommentVNode("v-if", true)]), _: 3 }, 8, ["is-auto-width", "update-all"]), createVNode("div", { class: "el-form-item__content", style: e.contentStyle }, [renderSlot(e.$slots, "default"), createVNode(Transition, { name: "el-zoom-in-top" }, { default: withCtx(() => [e.shouldShowError ? renderSlot(e.$slots, "error", { key: 0, error: e.validateMessage }, () => [createVNode("div", { class: ["el-form-item__error", { "el-form-item__error--inline": typeof e.inlineMessage == "boolean" ? e.inlineMessage : e.elForm.inlineMessage || false }] }, toDisplayString(e.validateMessage), 3)]) : createCommentVNode("v-if", true)]), _: 3 })], 4)], 2);
}, as.__file = "packages/form/src/form-item.vue", as.install = (e) => {
  e.component(as.name, as);
};
var ns = as;
var os = defineComponent({ name: "ElHeader", props: { height: { type: String, default: "60px" } } });
os.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("header", { class: "el-header", style: { height: e.height } }, [renderSlot(e.$slots, "default")], 4);
}, os.__file = "packages/container/src/header.vue", os.install = (e) => {
  e.component(os.name, os);
};
var is = os;
var rs = defineComponent({ name: "ElIcon", props: { name: { type: String, default: "" } } });
rs.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("i", { class: "el-icon-" + e.name }, null, 2);
}, rs.__file = "packages/icon/src/index.vue", rs.install = (e) => {
  e.component(rs.name, rs);
};
var ss = rs;
var us = { CONTAIN: { name: "contain", icon: "el-icon-full-screen" }, ORIGINAL: { name: "original", icon: "el-icon-c-scale-to-original" } };
var ds = !ke && window.navigator.userAgent.match(/firefox/i) ? "DOMMouseScroll" : "mousewheel";
var cs = defineComponent({ name: "ElImageViewer", props: { urlList: { type: Array, default: [] }, zIndex: { type: Number, default: 2e3 }, initialIndex: { type: Number, default: 0 }, infinite: { type: Boolean, default: true }, hideOnClickModal: { type: Boolean, default: false } }, emits: ["close", "switch"], setup(e, { emit: t }) {
  let a = null, r = null, s = null;
  const u = ref(true), d = ref(e.initialIndex), c = ref(null), p = ref(null), h2 = ref(us.CONTAIN);
  let v = ref({ scale: 1, deg: 0, offsetX: 0, offsetY: 0, enableTransition: false });
  const m = computed(() => {
    const { urlList: t2 } = e;
    return t2.length <= 1;
  }), f = computed(() => d.value === 0), g = computed(() => d.value === e.urlList.length - 1), b = computed(() => e.urlList[d.value]), y = computed(() => {
    const { scale: e2, deg: t2, offsetX: l, offsetY: a2, enableTransition: n } = v.value, o = { transform: `scale(${e2}) rotate(${t2}deg)`, transition: n ? "transform .3s" : "", marginLeft: l + "px", marginTop: a2 + "px" };
    return h2.value.name === us.CONTAIN.name && (o.maxWidth = o.maxHeight = "100%"), o;
  });
  function k() {
    nt(document, "keydown", a), nt(document, ds, r), a = null, r = null, t("close");
  }
  function x() {
    v.value = { scale: 1, deg: 0, offsetX: 0, offsetY: 0, enableTransition: false };
  }
  function C() {
    if (u.value)
      return;
    const e2 = Object.keys(us), t2 = Object.values(us), l = h2.value.name, a2 = (t2.findIndex((e3) => e3.name === l) + 1) % e2.length;
    h2.value = us[e2[a2]], x();
  }
  function S() {
    if (f.value && !e.infinite)
      return;
    const t2 = e.urlList.length;
    d.value = (d.value - 1 + t2) % t2;
  }
  function _() {
    if (g.value && !e.infinite)
      return;
    const t2 = e.urlList.length;
    d.value = (d.value + 1) % t2;
  }
  function E(e2, t2 = {}) {
    if (u.value)
      return;
    const { zoomRate: l, rotateDeg: a2, enableTransition: n } = Object.assign({ zoomRate: 0.2, rotateDeg: 90, enableTransition: true }, t2);
    switch (e2) {
      case "zoomOut":
        v.value.scale > 0.2 && (v.value.scale = parseFloat((v.value.scale - l).toFixed(3)));
        break;
      case "zoomIn":
        v.value.scale = parseFloat((v.value.scale + l).toFixed(3));
        break;
      case "clocelise":
        v.value.deg += a2;
        break;
      case "anticlocelise":
        v.value.deg -= a2;
    }
    v.value.enableTransition = n;
  }
  return watch(b, () => {
    nextTick(() => {
      p.value.complete || (u.value = true);
    });
  }), watch(d, (e2) => {
    x(), t("switch", e2);
  }), onMounted(() => {
    var e2, t2;
    a = Ye((e3) => {
      switch (e3.code) {
        case Dt.esc:
          k();
          break;
        case Dt.space:
          C();
          break;
        case Dt.left:
          S();
          break;
        case Dt.up:
          E("zoomIn");
          break;
        case Dt.right:
          _();
          break;
        case Dt.down:
          E("zoomOut");
      }
    }), r = Ye((e3) => {
      E((e3.wheelDelta ? e3.wheelDelta : -e3.detail) > 0 ? "zoomIn" : "zoomOut", { zoomRate: 0.015, enableTransition: false });
    }), at(document, "keydown", a), at(document, ds, r), (t2 = (e2 = c.value) === null || e2 === void 0 ? void 0 : e2.focus) === null || t2 === void 0 || t2.call(e2);
  }), { index: d, wrapper: c, img: p, isSingle: m, isFirst: f, isLast: g, currentImg: b, imgStyle: y, mode: h2, handleActions: E, prev: S, next: _, hide: k, toggleMode: C, handleImgLoad: function() {
    u.value = false;
  }, handleImgError: function(e2) {
    u.value = false, e2.target.alt = Ca("el.image.error");
  }, handleMouseDown: function(e2) {
    if (u.value || e2.button !== 0)
      return;
    const { offsetX: t2, offsetY: l } = v.value, a2 = e2.pageX, n = e2.pageY;
    s = Ye((e3) => {
      v.value = Object.assign(Object.assign({}, v.value), { offsetX: t2 + e3.pageX - a2, offsetY: l + e3.pageY - n });
    }), at(document, "mousemove", s), at(document, "mouseup", () => {
      nt(document, "mousemove", s);
    }), e2.preventDefault();
  } };
} });
var ps = createVNode("i", { class: "el-icon-close" }, null, -1);
var hs = createVNode("i", { class: "el-icon-arrow-left" }, null, -1);
var vs = createVNode("i", { class: "el-icon-arrow-right" }, null, -1);
var ms = { class: "el-image-viewer__btn el-image-viewer__actions" };
var fs = { class: "el-image-viewer__actions__inner" };
var gs = createVNode("i", { class: "el-image-viewer__actions__divider" }, null, -1);
var bs = createVNode("i", { class: "el-image-viewer__actions__divider" }, null, -1);
var ys = { class: "el-image-viewer__canvas" };
cs.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "viewer-fade" }, { default: withCtx(() => [createVNode("div", { ref: "wrapper", tabindex: -1, class: "el-image-viewer__wrapper", style: { zIndex: e.zIndex } }, [createVNode("div", { class: "el-image-viewer__mask", onClick: t[1] || (t[1] = withModifiers((t2) => e.hideOnClickModal && e.hide(), ["self"])) }), createCommentVNode(" CLOSE "), createVNode("span", { class: "el-image-viewer__btn el-image-viewer__close", onClick: t[2] || (t[2] = (...t2) => e.hide && e.hide(...t2)) }, [ps]), createCommentVNode(" ARROW "), e.isSingle ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Fragment, { key: 0 }, [createVNode("span", { class: ["el-image-viewer__btn el-image-viewer__prev", { "is-disabled": !e.infinite && e.isFirst }], onClick: t[3] || (t[3] = (...t2) => e.prev && e.prev(...t2)) }, [hs], 2), createVNode("span", { class: ["el-image-viewer__btn el-image-viewer__next", { "is-disabled": !e.infinite && e.isLast }], onClick: t[4] || (t[4] = (...t2) => e.next && e.next(...t2)) }, [vs], 2)], 64)), createCommentVNode(" ACTIONS "), createVNode("div", ms, [createVNode("div", fs, [createVNode("i", { class: "el-icon-zoom-out", onClick: t[5] || (t[5] = (t2) => e.handleActions("zoomOut")) }), createVNode("i", { class: "el-icon-zoom-in", onClick: t[6] || (t[6] = (t2) => e.handleActions("zoomIn")) }), gs, createVNode("i", { class: e.mode.icon, onClick: t[7] || (t[7] = (...t2) => e.toggleMode && e.toggleMode(...t2)) }, null, 2), bs, createVNode("i", { class: "el-icon-refresh-left", onClick: t[8] || (t[8] = (t2) => e.handleActions("anticlocelise")) }), createVNode("i", { class: "el-icon-refresh-right", onClick: t[9] || (t[9] = (t2) => e.handleActions("clocelise")) })])]), createCommentVNode(" CANVAS "), createVNode("div", ys, [(openBlock(true), createBlock(Fragment, null, renderList(e.urlList, (l2, a2) => withDirectives((openBlock(), createBlock("img", { ref: "img", key: l2, src: l2, style: e.imgStyle, class: "el-image-viewer__img", onLoad: t[10] || (t[10] = (...t2) => e.handleImgLoad && e.handleImgLoad(...t2)), onError: t[11] || (t[11] = (...t2) => e.handleImgError && e.handleImgError(...t2)), onMousedown: t[12] || (t[12] = (...t2) => e.handleMouseDown && e.handleMouseDown(...t2)) }, null, 44, ["src"])), [[vShow, a2 === e.index]])), 128))])], 4)]), _: 1 });
}, cs.__file = "packages/image-viewer/src/index.vue", cs.install = (e) => {
  e.component(Image.name, Image);
};
var ks = cs;
var xs = () => document.documentElement.style.objectFit !== void 0;
var Cs = "none";
var ws = "contain";
var Ss = "cover";
var _s = "fill";
var Es = "scale-down";
var Ms = "";
var Ts = defineComponent({ name: "ElImage", components: { ImageViewer: ks }, inheritAttrs: false, props: { appendToBody: { type: Boolean, default: false }, hideOnClickModal: { type: Boolean, default: false }, src: { type: String, default: "" }, fit: { type: String, default: "" }, lazy: { type: Boolean, default: false }, scrollContainer: { type: [String, Object], default: null }, previewSrcList: { type: Array, default: () => [] }, zIndex: { type: Number, default: 2e3 } }, emits: ["error"], setup(e, { emit: t }) {
  const a = Mt(), s = ref(false), u = ref(true), d = ref(0), c = ref(0), p = ref(false), h2 = ref(null);
  let v = null, m = null;
  const f = computed(() => {
    const { fit: t2 } = e;
    return !ke && t2 ? xs() ? { "object-fit": t2 } : function(e2) {
      const t3 = d.value, l = c.value;
      if (!h2.value)
        return {};
      const { clientWidth: a2, clientHeight: n } = h2.value;
      if (!(t3 && l && a2 && n))
        return {};
      const o = t3 / l, i = a2 / n;
      if (e2 === Es) {
        e2 = t3 < a2 && l < n ? Cs : ws;
      }
      switch (e2) {
        case Cs:
          return { width: "auto", height: "auto" };
        case ws:
          return o < i ? { width: "auto" } : { height: "auto" };
        case Ss:
          return o < i ? { height: "auto" } : { width: "auto" };
        default:
          return {};
      }
    }(t2) : {};
  }), g = computed(() => {
    const { fit: t2 } = e;
    return !ke && !xs() && t2 !== _s;
  }), b = computed(() => {
    const { previewSrcList: t2 } = e;
    return Array.isArray(t2) && t2.length > 0;
  }), y = computed(() => {
    const { src: t2, previewSrcList: l } = e;
    let a2 = 0;
    const n = l.indexOf(t2);
    return n >= 0 && (a2 = n), a2;
  });
  const k = () => {
    if (ke)
      return;
    const t2 = a.value;
    u.value = true, s.value = false;
    const l = new Image();
    l.onload = (e2) => function(e3, t3) {
      d.value = t3.width, c.value = t3.height, u.value = false, s.value = false;
    }(0, l), l.onerror = x, Object.keys(t2).forEach((e2) => {
      if (e2.toLowerCase() === "onload")
        return;
      const a2 = t2[e2];
      l.setAttribute(e2, a2);
    }), l.src = e.src;
  };
  function x(e2) {
    u.value = false, s.value = true, t("error", e2);
  }
  function C() {
    ((e2, t2) => {
      if (ke || !e2 || !t2)
        return false;
      const l = e2.getBoundingClientRect();
      let a2;
      return a2 = [window, document, document.documentElement, null, void 0].includes(t2) ? { top: 0, right: window.innerWidth, bottom: window.innerHeight, left: 0 } : t2.getBoundingClientRect(), l.top < a2.bottom && l.bottom > a2.top && l.right > a2.left && l.left < a2.right;
    })(h2.value, v) && (k(), _());
  }
  function S() {
    if (ke)
      return;
    const { scrollContainer: t2 } = e;
    var l;
    v = (l = t2) && l.nodeType === 1 ? t2 : Me(t2) && t2 !== "" ? document.querySelector(t2) : dt(h2.value), v && (m = (0, import_throttle.default)(C, 200), at(v, "scroll", m), setTimeout(() => C(), 100));
  }
  function _() {
    !ke && v && m && (nt(v, "scroll", m), v = null, m = null);
  }
  return watch(() => e.src, () => {
    k();
  }), onMounted(() => {
    e.lazy ? nextTick(S) : k();
  }), onBeforeUnmount(() => {
    e.lazy && _();
  }), { attrs: a, loading: u, hasLoadError: s, showViewer: p, imgWidth: d, imgHeight: c, imageStyle: f, alignCenter: g, preview: b, imageIndex: y, clickHandler: function() {
    b.value && (Ms = document.body.style.overflow, document.body.style.overflow = "hidden", p.value = true);
  }, closeViewer: function() {
    document.body.style.overflow = Ms, p.value = false;
  }, container: h2, handleError: x, t: Ca };
} });
var Is = createVNode("div", { class: "el-image__placeholder" }, null, -1);
var Os = { class: "el-image__error" };
Ts.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("image-viewer");
  return openBlock(), createBlock("div", { ref: "container", class: ["el-image", e.$attrs.class], style: e.$attrs.style }, [e.loading ? renderSlot(e.$slots, "placeholder", { key: 0 }, () => [Is]) : e.hasLoadError ? renderSlot(e.$slots, "error", { key: 1 }, () => [createVNode("div", Os, toDisplayString(e.t("el.image.error")), 1)]) : (openBlock(), createBlock("img", mergeProps({ key: 2, class: "el-image__inner" }, e.attrs, { src: e.src, style: e.imageStyle, class: { "el-image__inner--center": e.alignCenter, "el-image__preview": e.preview }, onClick: t[1] || (t[1] = (...t2) => e.clickHandler && e.clickHandler(...t2)) }), null, 16, ["src"])), (openBlock(), createBlock(Teleport, { to: "body", disabled: !e.appendToBody }, [e.preview ? (openBlock(), createBlock(Fragment, { key: 0 }, [e.showViewer ? (openBlock(), createBlock(i, { key: 0, "z-index": e.zIndex, "initial-index": e.imageIndex, "url-list": e.previewSrcList, "hide-on-click-modal": e.hideOnClickModal, onClose: e.closeViewer }, null, 8, ["z-index", "initial-index", "url-list", "hide-on-click-modal", "onClose"])) : createCommentVNode("v-if", true)], 2112)) : createCommentVNode("v-if", true)], 8, ["disabled"]))], 6);
}, Ts.__file = "packages/image/src/index.vue", Ts.install = (e) => {
  e.component(Ts.name, Ts);
};
var Ns = Ts;
function Ds(e, t, l, a) {
  return new (l || (l = Promise))(function(n, o) {
    function i(e2) {
      try {
        s(a.next(e2));
      } catch (e3) {
        o(e3);
      }
    }
    function r(e2) {
      try {
        s(a.throw(e2));
      } catch (e3) {
        o(e3);
      }
    }
    function s(e2) {
      var t2;
      e2.done ? n(e2.value) : (t2 = e2.value, t2 instanceof l ? t2 : new l(function(e3) {
        e3(t2);
      })).then(i, r);
    }
    s((a = a.apply(e, t || [])).next());
  });
}
var Vs = "ElInfiniteScroll";
var Bs = { delay: { type: Number, default: 200 }, distance: { type: Number, default: 0 }, disabled: { type: Boolean, default: false }, immediate: { type: Boolean, default: true } };
var Ps = (e, t) => Ue(Bs).reduce((l, [a, n]) => {
  var o, i;
  const { type: r, default: s } = n, u = e.getAttribute("infinite-scroll-" + a);
  let d = (i = (o = t[u]) !== null && o !== void 0 ? o : u) !== null && i !== void 0 ? i : s;
  return d = d !== "false" && d, d = r(d), l[a] = Number.isNaN(d) ? s : d, l;
}, {});
var As = (e) => {
  const { observer: t } = e[Vs];
  t && (t.disconnect(), delete e[Vs].observer);
};
var zs = (e, t) => {
  const { container: l, containerEl: a, instance: n, observer: o, lastScrollTop: i } = e[Vs], { disabled: r, distance: s } = Ps(e, n), { clientHeight: u, scrollHeight: d, scrollTop: c } = a, p = c - i;
  if (e[Vs].lastScrollTop = c, o || r || p < 0)
    return;
  let h2 = false;
  if (l === e)
    h2 = d - (u + c) <= s;
  else {
    const { clientTop: t2, scrollHeight: l2 } = e;
    h2 = c + u >= ((e2, t3) => Math.abs(ct(e2) - ct(t3)))(e, a) + t2 + l2 - s;
  }
  h2 && t.call(n);
};
function Ls(e, t) {
  const { containerEl: l, instance: a } = e[Vs], { disabled: n } = Ps(e, a);
  n || (l.scrollHeight <= l.clientHeight ? t.call(a) : As(e));
}
var Fs = { mounted(e, t) {
  return Ds(this, void 0, void 0, function* () {
    const { instance: l, value: a } = t;
    Ee(a) || Le(Vs, "'v-infinite-scroll' binding value must be a function"), yield nextTick();
    const { delay: n, immediate: o } = Ps(e, l), i = dt(e, true), r = i === window ? document.documentElement : i, s = (0, import_throttle.default)(zs.bind(null, e, a), n);
    if (i) {
      if (e[Vs] = { instance: l, container: i, containerEl: r, delay: n, cb: a, onScroll: s, lastScrollTop: r.scrollTop }, o) {
        const t2 = new MutationObserver((0, import_throttle.default)(Ls.bind(null, e, a), 50));
        e[Vs].observer = t2, t2.observe(e, { childList: true, subtree: true }), Ls(e, a);
      }
      i.addEventListener("scroll", s);
    }
  });
}, unmounted(e) {
  const { container: t, onScroll: l } = e[Vs];
  t == null || t.removeEventListener("scroll", l), As(e);
}, install: (e) => {
  e.directive("InfiniteScroll", Fs);
} };
var Rs = defineComponent({ name: "ElInputNumber", components: { ElInput: gl }, directives: { RepeatClick: Wt }, props: { step: { type: Number, default: 1 }, stepStrictly: { type: Boolean, default: false }, max: { type: Number, default: 1 / 0 }, min: { type: Number, default: -1 / 0 }, modelValue: { required: true, validator: (e) => De(e) === "Number" || e === void 0 }, disabled: { type: Boolean, default: false }, size: { type: String, validator: Qt }, controls: { type: Boolean, default: true }, controlsPosition: { type: String, default: "" }, name: String, label: String, placeholder: String, precision: { type: Number, validator: (e) => e >= 0 && e === parseInt(e + "", 10) } }, emits: ["update:modelValue", "change", "input", "blur", "focus"], setup(e, { emit: t }) {
  const r = Xe(), s = inject("elForm", {}), u = inject("elFormItem", {}), d = ref(null), c = reactive({ currentValue: e.modelValue, userInput: null }), p = computed(() => C(e.modelValue) < e.min), h2 = computed(() => x(e.modelValue) > e.max), v = computed(() => {
    const t2 = k(e.step);
    return e.precision !== void 0 ? (t2 > e.precision && console.warn("[Element Warn][InputNumber]precision should not be less than the decimal places of step"), e.precision) : Math.max(k(e.modelValue), t2);
  }), m = computed(() => e.controls && e.controlsPosition === "right"), f = computed(() => e.size || u.size || r.size), g = computed(() => e.disabled || s.disabled), b = computed(() => {
    if (c.userInput !== null)
      return c.userInput;
    let t2 = c.currentValue;
    return typeof t2 == "number" && e.precision !== void 0 && (t2 = t2.toFixed(e.precision)), t2;
  }), y = (e2, t2) => (t2 === void 0 && (t2 = v.value), parseFloat(Math.round(e2 * Math.pow(10, t2)) / Math.pow(10, t2) + "")), k = (e2) => {
    if (e2 === void 0)
      return 0;
    const t2 = e2.toString(), l = t2.indexOf(".");
    let a = 0;
    return l !== -1 && (a = t2.length - l - 1), a;
  }, x = (t2) => {
    if (typeof t2 != "number" && t2 !== void 0)
      return c.currentValue;
    const l = Math.pow(10, v.value);
    return y((l * t2 + l * e.step) / l);
  }, C = (t2) => {
    if (typeof t2 != "number" && t2 !== void 0)
      return c.currentValue;
    const l = Math.pow(10, v.value);
    return y((l * t2 - l * e.step) / l);
  }, w = (l) => {
    const a = c.currentValue;
    typeof l == "number" && e.precision !== void 0 && (l = y(l, e.precision)), l !== void 0 && l >= e.max && (l = e.max), l !== void 0 && l <= e.min && (l = e.min), a !== l && (c.userInput = null, t("update:modelValue", l), t("input", l), t("change", l, a), c.currentValue = l);
  };
  return watch(() => e.modelValue, (l) => {
    let a = l === void 0 ? l : Number(l);
    if (a !== void 0) {
      if (isNaN(a))
        return;
      if (e.stepStrictly) {
        const t2 = k(e.step), l2 = Math.pow(10, t2);
        a = Math.round(a / e.step) * l2 * e.step / l2;
      }
      e.precision !== void 0 && (a = y(a, e.precision));
    }
    a !== void 0 && a >= e.max && (a = e.max, t("update:modelValue", a)), a !== void 0 && a <= e.min && (a = e.min, t("update:modelValue", a)), c.currentValue = a, c.userInput = null;
  }, { immediate: true }), onMounted(() => {
    let l = d.value.input;
    l.setAttribute("role", "spinbutton"), l.setAttribute("aria-valuemax", e.max), l.setAttribute("aria-valuemin", e.min), l.setAttribute("aria-valuenow", c.currentValue), l.setAttribute("aria-disabled", g.value), De(e.modelValue) !== "Number" && e.modelValue !== void 0 && t("update:modelValue", void 0);
  }), onUpdated(() => {
    d.value.input.setAttribute("aria-valuenow", c.currentValue);
  }), { input: d, displayValue: b, handleInput: (e2) => c.userInput = e2, handleInputChange: (e2) => {
    const t2 = e2 === "" ? void 0 : Number(e2);
    isNaN(t2) && e2 !== "" || w(t2), c.userInput = null;
  }, controlsAtRight: m, decrease: () => {
    if (g.value || p.value)
      return;
    const t2 = e.modelValue || 0, l = C(t2);
    w(l);
  }, increase: () => {
    if (g.value || h2.value)
      return;
    const t2 = e.modelValue || 0, l = x(t2);
    w(l);
  }, inputNumberSize: f, inputNumberDisabled: g, maxDisabled: h2, minDisabled: p };
} });
Rs.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveDirective("repeat-click");
  return openBlock(), createBlock("div", { class: ["el-input-number", e.inputNumberSize ? "el-input-number--" + e.inputNumberSize : "", { "is-disabled": e.inputNumberDisabled }, { "is-without-controls": !e.controls }, { "is-controls-right": e.controlsAtRight }], onDragstart: t[5] || (t[5] = withModifiers(() => {
  }, ["prevent"])) }, [e.controls ? withDirectives((openBlock(), createBlock("span", { key: 0, class: ["el-input-number__decrease", { "is-disabled": e.minDisabled }], role: "button", onKeydown: t[1] || (t[1] = withKeys((...t2) => e.decrease && e.decrease(...t2), ["enter"])) }, [createVNode("i", { class: "el-icon-" + (e.controlsAtRight ? "arrow-down" : "minus") }, null, 2)], 34)), [[r, e.decrease]]) : createCommentVNode("v-if", true), e.controls ? withDirectives((openBlock(), createBlock("span", { key: 1, class: ["el-input-number__increase", { "is-disabled": e.maxDisabled }], role: "button", onKeydown: t[2] || (t[2] = withKeys((...t2) => e.increase && e.increase(...t2), ["enter"])) }, [createVNode("i", { class: "el-icon-" + (e.controlsAtRight ? "arrow-up" : "plus") }, null, 2)], 34)), [[r, e.increase]]) : createCommentVNode("v-if", true), createVNode(i, { ref: "input", "model-value": e.displayValue, placeholder: e.placeholder, disabled: e.inputNumberDisabled, size: e.inputNumberSize, max: e.max, min: e.min, name: e.name, label: e.label, onKeydown: [withKeys(withModifiers(e.increase, ["prevent"]), ["up"]), withKeys(withModifiers(e.decrease, ["prevent"]), ["down"])], onBlur: t[3] || (t[3] = (t2) => e.$emit("blur", t2)), onFocus: t[4] || (t[4] = (t2) => e.$emit("focus", t2)), onInput: e.handleInput, onChange: e.handleInputChange }, null, 8, ["model-value", "placeholder", "disabled", "size", "max", "min", "name", "label", "onKeydown", "onInput", "onChange"])], 34);
}, Rs.__file = "packages/input-number/src/index.vue", Rs.install = (e) => {
  e.component(Rs.name, Rs);
};
var $s = Rs;
var Hs = defineComponent({ name: "ElLink", props: { type: { type: String, default: "default", validator: (e) => ["default", "primary", "success", "warning", "info", "danger"].includes(e) }, underline: { type: Boolean, default: true }, disabled: { type: Boolean, default: false }, href: { type: String, default: "" }, icon: { type: String, default: "" } }, emits: ["click"], setup: (e, { emit: t }) => ({ handleClick: function(l) {
  e.disabled || t("click", l);
} }) });
var Ws = { key: 1, class: "el-link--inner" };
Hs.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("a", { class: ["el-link", e.type ? "el-link--" + e.type : "", e.disabled && "is-disabled", e.underline && !e.disabled && "is-underline"], href: e.disabled ? null : e.href, onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [e.icon ? (openBlock(), createBlock("i", { key: 0, class: e.icon }, null, 2)) : createCommentVNode("v-if", true), e.$slots.default ? (openBlock(), createBlock("span", Ws, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true), e.$slots.icon ? renderSlot(e.$slots, "icon", { key: 2 }) : createCommentVNode("v-if", true)], 10, ["href"]);
}, Hs.__file = "packages/link/src/index.vue", Hs.install = (e) => {
  e.component(Hs.name, Hs);
};
var js = Hs;
var Ks = { parent: null, background: "", spinner: false, text: null, fullscreen: true, body: false, lock: false, customClass: "" };
var Ys = { fullscreenLoading: null };
var qs = (e, t, l) => {
  l.originalPosition.value !== "absolute" && l.originalPosition.value !== "fixed" ? it(t, "el-loading-parent--relative") : rt(t, "el-loading-parent--relative"), e.fullscreen && e.lock ? it(t, "el-loading-parent--hidden") : rt(t, "el-loading-parent--hidden");
};
var Us = function(e = {}) {
  if (ke)
    return;
  typeof (e = Object.assign(Object.assign({}, Ks), e)).target == "string" && (e.target = document.querySelector(e.target)), e.target = e.target || document.body, e.target !== document.body ? e.fullscreen = false : e.body = true, e.fullscreen && Ys.fullscreenLoading && Ys.fullscreenLoading.close();
  const t = e.body ? document.body : e.target;
  e.parent = t;
  const n = function({ options: e2, globalLoadingOption: t2 }) {
    let n2 = null, o2 = null;
    const i = ref(false), r = reactive(Object.assign(Object.assign({}, e2), { originalPosition: "", originalOverflow: "", visible: false }));
    function s() {
      const e3 = r.parent;
      if (!e3.vLoadingAddClassList) {
        let t3 = e3.getAttribute("loading-number");
        t3 = Number.parseInt(t3) - 1, t3 ? e3.setAttribute("loading-number", t3.toString()) : (rt(e3, "el-loading-parent--relative"), e3.removeAttribute("loading-number")), rt(e3, "el-loading-parent--hidden");
      }
      n2.el && n2.el.parentNode && n2.el.parentNode.removeChild(n2.el);
    }
    const u = Object.assign(Object.assign({}, toRefs(r)), { setText: function(e3) {
      r.text = e3;
    }, close: function() {
      r.parent.vLoadingAddClassList = null, r.fullscreen && (t2.fullscreenLoading = void 0), i.value = true, clearTimeout(o2), o2 = window.setTimeout(() => {
        i.value && (i.value = false, s());
      }, 400), r.visible = false;
    }, handleAfterLeave: function() {
      i.value && (i.value = false, s());
    } }), c = { name: "ElLoading", setup: () => u, render() {
      const e3 = h("svg", { class: "circular", viewBox: "25 25 50 50" }, [h("circle", { class: "path", cx: "50", cy: "50", r: "20", fill: "none" })]), t3 = h("i", { class: this.spinner }), l = h("p", { class: "el-loading-text" }, [this.text]);
      return h(Transition, { name: "el-loading-fade", onAfterLeave: this.handleAfterLeave }, { default: withCtx(() => [withDirectives(createVNode("div", { style: { backgroundColor: this.background || "" }, class: ["el-loading-mask", this.customClass, this.fullscreen ? "is-fullscreen" : ""] }, [h("div", { class: "el-loading-spinner" }, [this.spinner ? t3 : e3, this.text ? l : null])]), [[vShow, this.visible]])]) });
    } };
    return n2 = createVNode(c), render(n2, document.createElement("div")), Object.assign(Object.assign({}, u), { vm: n2, get $el() {
      return n2.el;
    } });
  }({ options: e, globalLoadingOption: Ys });
  ((e2, t2, l) => {
    Ds(void 0, void 0, void 0, function* () {
      const a = {};
      e2.fullscreen ? (l.originalPosition.value = st(document.body, "position"), l.originalOverflow.value = st(document.body, "overflow"), a.zIndex = String(Ol.nextZIndex())) : e2.body ? (l.originalPosition.value = st(document.body, "position"), yield nextTick(), ["top", "left"].forEach((t3) => {
        const l2 = t3 === "top" ? "scrollTop" : "scrollLeft";
        a[t3] = e2.target.getBoundingClientRect()[t3] + document.body[l2] + document.documentElement[l2] - parseInt(st(document.body, "margin-" + t3), 10) + "px";
      }), ["height", "width"].forEach((t3) => {
        a[t3] = e2.target.getBoundingClientRect()[t3] + "px";
      })) : l.originalPosition.value = st(t2, "position"), Object.keys(a).forEach((e3) => {
        l.$el.style[e3] = a[e3];
      });
    });
  })(e, t, n), qs(e, t, n), e.parent.vLoadingAddClassList = () => {
    qs(e, t, n);
  };
  let o = t.getAttribute("loading-number");
  return o = o ? Number.parseInt(o) + 1 : 1, t.setAttribute("loading-number", o.toString()), t.appendChild(n.$el), nextTick().then(() => {
    n.visible.value = !Se(e, "visible") || e.visible;
  }), e.fullscreen && (Ys.fullscreenLoading = n), n;
};
var Gs = (e, t) => {
  const l = e.getAttribute("element-loading-text"), a = e.getAttribute("element-loading-spinner"), n = e.getAttribute("element-loading-background"), o = e.getAttribute("element-loading-custom-class"), i = t.instance;
  e.instance = Us({ text: i && i[l] || l, spinner: i && i[a] || a, background: i && i[n] || n, customClass: i && i[o] || o, fullscreen: !!t.modifiers.fullscreen, target: t.modifiers.fullscreen ? null : e, body: !!t.modifiers.body, visible: true, lock: !!t.modifiers.lock });
};
var Xs = { mounted(e, t) {
  t.value && Gs(e, t);
}, updated(e, t) {
  const l = e.instance;
  t.oldValue !== t.value && (t.value ? Gs(e, t) : l.close());
}, unmounted(e) {
  var t;
  (t = e == null ? void 0 : e.instance) === null || t === void 0 || t.close();
} };
var Zs = { install(e) {
  e.directive("loading", Xs), e.config.globalProperties.$loading = Us;
}, directive: Xs, service: Us };
var Qs = defineComponent({ name: "ElMain" });
var Js = { class: "el-main" };
Qs.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("main", Js, [renderSlot(e.$slots, "default")]);
}, Qs.__file = "packages/container/src/main.vue", Qs.install = (e) => {
  e.component(Qs.name, Qs);
};
var eu = Qs;
var tu = class {
  constructor(e, t) {
    this.parent = e, this.domNode = t, this.subIndex = 0, this.subIndex = 0, this.init();
  }
  init() {
    this.subMenuItems = this.domNode.querySelectorAll("li"), this.addListeners();
  }
  gotoSubIndex(e) {
    e === this.subMenuItems.length ? e = 0 : e < 0 && (e = this.subMenuItems.length - 1), this.subMenuItems[e].focus(), this.subIndex = e;
  }
  addListeners() {
    const e = this.parent.domNode;
    Array.prototype.forEach.call(this.subMenuItems, (t) => {
      t.addEventListener("keydown", (t2) => {
        let l = false;
        switch (t2.code) {
          case Dt.down:
            this.gotoSubIndex(this.subIndex + 1), l = true;
            break;
          case Dt.up:
            this.gotoSubIndex(this.subIndex - 1), l = true;
            break;
          case Dt.tab:
            At(e, "mouseleave");
            break;
          case Dt.enter:
          case Dt.space:
            l = true, t2.currentTarget.click();
        }
        return l && (t2.preventDefault(), t2.stopPropagation()), false;
      });
    });
  }
};
var lu = class {
  constructor(e) {
    this.domNode = e, this.submenu = null, this.submenu = null, this.init();
  }
  init() {
    this.domNode.setAttribute("tabindex", "0");
    const e = this.domNode.querySelector(".el-menu");
    e && (this.submenu = new tu(this, e)), this.addListeners();
  }
  addListeners() {
    this.domNode.addEventListener("keydown", (e) => {
      let t = false;
      switch (e.code) {
        case Dt.down:
          At(e.currentTarget, "mouseenter"), this.submenu && this.submenu.gotoSubIndex(0), t = true;
          break;
        case Dt.up:
          At(e.currentTarget, "mouseenter"), this.submenu && this.submenu.gotoSubIndex(this.submenu.subMenuItems.length - 1), t = true;
          break;
        case Dt.tab:
          At(e.currentTarget, "mouseleave");
          break;
        case Dt.enter:
        case Dt.space:
          t = true, e.currentTarget.click();
      }
      t && e.preventDefault();
    });
  }
};
var au = class {
  constructor(e) {
    this.domNode = e, this.init();
  }
  init() {
    const e = this.domNode.childNodes;
    [].filter.call(e, (e2) => e2.nodeType === 1).forEach((e2) => {
      new lu(e2);
    });
  }
};
var nu = defineComponent({ name: "ElMenuCollapseTransition", setup: () => ({ on: { beforeEnter(e) {
  e.style.opacity = 0.2;
}, enter(e, t) {
  it(e, "el-opacity-transition"), e.style.opacity = 1, t();
}, afterEnter(e) {
  rt(e, "el-opacity-transition"), e.style.opacity = "";
}, beforeLeave(e) {
  e.dataset || (e.dataset = {}), ot(e, "el-menu--collapse") ? (rt(e, "el-menu--collapse"), e.dataset.oldOverflow = e.style.overflow, e.dataset.scrollWidth = e.clientWidth, it(e, "el-menu--collapse")) : (it(e, "el-menu--collapse"), e.dataset.oldOverflow = e.style.overflow, e.dataset.scrollWidth = e.clientWidth, rt(e, "el-menu--collapse")), e.style.width = e.scrollWidth + "px", e.style.overflow = "hidden";
}, leave(e) {
  it(e, "horizontal-collapse-transition"), e.style.width = e.dataset.scrollWidth + "px";
} } }) });
function ou(e = "") {
  const t = ref("");
  return e ? (t.value = function(e2, t2 = 0.2) {
    let { red: l, green: a, blue: n } = function(e3) {
      let t3 = e3.replace("#", "");
      if (/^[0-9a-fA-F]{3}$/.test(t3)) {
        const e4 = t3.split("");
        for (let t4 = 2; t4 >= 0; t4--)
          e4.splice(t4, 0, e4[t4]);
        t3 = e4.join("");
      }
      return /^[0-9a-fA-F]{6}$/.test(t3) ? { red: parseInt(t3.slice(0, 2), 16), green: parseInt(t3.slice(2, 4), 16), blue: parseInt(t3.slice(4, 6), 16) } : { red: 255, green: 255, blue: 255 };
    }(e2);
    return t2 > 0 ? (l *= 1 - t2, a *= 1 - t2, n *= 1 - t2) : (l += (255 - l) * t2, a += (255 - a) * t2, n += (255 - n) * t2), `rgb(${Math.round(l)}, ${Math.round(a)}, ${Math.round(n)})`;
  }(e), t) : t;
}
nu.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, mergeProps({ mode: "out-in" }, toHandlers(e.on)), { default: withCtx(() => [renderSlot(e.$slots, "default")]), _: 3 }, 16);
}, nu.__file = "packages/menu/src/menu-collapse-transition.vue";
var iu = defineComponent({ name: "ElMenu", componentName: "ElMenu", components: { ElMenuCollapseTransition: nu }, props: { mode: { type: String, default: "vertical" }, defaultActive: { type: String, default: "" }, defaultOpeneds: Array, uniqueOpened: Boolean, router: Boolean, menuTrigger: { type: String, default: "hover" }, collapse: Boolean, backgroundColor: { type: String }, textColor: { type: String }, activeTextColor: { type: String }, collapseTransition: { type: Boolean, default: true } }, emits: ["close", "open", "select"], setup(t, a) {
  const r = ref(t.defaultOpeneds && !t.collapse ? t.defaultOpeneds.slice(0) : []), s = getCurrentInstance(), u = ref(t.defaultActive), d = ref({}), c = ref({}), p = ref(false), h2 = mitt_es_default(), v = s.appContext.config.globalProperties.$router, m = ou(t.backgroundColor), f = computed(() => t.mode === "horizontal" || t.mode === "vertical" && t.collapse), g = () => {
    const e = u.value, l = d.value[e];
    if (!l || t.mode === "horizontal" || t.collapse)
      return;
    l.indexPath.forEach((e2) => {
      let t2 = c.value[e2];
      t2 && k(e2, t2 == null ? void 0 : t2.indexPath);
    });
  }, b = (e) => {
    c.value[e.index] = e;
  }, y = (e) => {
    delete c.value[e.index];
  }, k = (e, l) => {
    r.value.includes(e) || (t.uniqueOpened && (r.value = r.value.filter((e2) => (isRef(l) ? l.value : l).indexOf(e2) !== -1)), r.value.push(e));
  }, C = (e) => {
    const t2 = r.value.indexOf(e);
    t2 !== -1 && r.value.splice(t2, 1);
  }, w = (e) => {
    const { index: t2, indexPath: l } = e;
    r.value.includes(t2) ? (C(t2), a.emit("close", t2, l.value)) : (k(t2, l), a.emit("open", t2, l.value));
  }, S = (e) => {
    const { index: l, indexPath: n } = e, o = e.index !== null, i = u.value;
    o && (u.value = e.index), a.emit("select", l, n.value, e), (t.mode === "horizontal" || t.collapse) && (r.value = []), t.router && v && o && E(e, (e2) => {
      if (u.value = i, e2) {
        if (e2.name === "NavigationDuplicated")
          return;
        console.error(e2);
      }
    });
  }, E = (e, t2) => {
    let l = e.route || e.index;
    try {
      v == null || v.push(l, () => null, t2);
    } catch (e2) {
      console.error(e2);
    }
  }, M = (e) => {
    const l = d.value, a2 = l[e] || l[u.value] || l[t.defaultActive];
    a2 ? (u.value = a2.index, g()) : p.value ? p.value = false : u.value = null;
  };
  return watch(() => t.defaultActive, (e) => {
    d.value[e] || (u.value = ""), M(e);
  }), watch(d.value, () => {
    M();
  }), watch(() => t.collapse, (e, l) => {
    e !== l && (p.value = true), e && (r.value = []), h2.emit("rootMenu:toggle-collapse", Boolean(t.collapse));
  }), provide("rootMenu", { props: t, openedMenus: r, items: d, submenus: c, hoverBackground: m, activeIndex: u, isMenuPopup: f, methods: { addMenuItem: (e) => {
    d.value[e.index] = e;
  }, removeMenuItem: (e) => {
    delete d.value[e.index];
  }, addSubMenu: b, removeSubMenu: y, openMenu: k, closeMenu: C }, rootMenuEmit: h2.emit, rootMenuOn: h2.on }), provide("subMenu:" + s.uid, { addSubMenu: b, removeSubMenu: y }), onMounted(() => {
    g(), h2.on("menuItem:item-click", S), h2.on("submenu:submenu-click", w), t.mode === "horizontal" && new au(s.vnode.el);
  }), { hoverBackground: m, isMenuPopup: f, props: t, open: (e) => {
    const { indexPath: t2 } = c.value[e.toString()];
    t2.forEach((e2) => k(e2, t2));
  }, close: (e) => {
    C(e);
  } };
} });
iu.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-menu-collapse-transition");
  return e.props.collapseTransition ? (openBlock(), createBlock(i, { key: 0 }, { default: withCtx(() => [(openBlock(), createBlock("ul", { key: +e.props.collapse, role: "menubar", style: { backgroundColor: e.props.backgroundColor || "" }, class: { "el-menu": true, "el-menu--horizontal": e.mode === "horizontal", "el-menu--collapse": e.props.collapse } }, [renderSlot(e.$slots, "default")], 6))]), _: 3 })) : (openBlock(), createBlock("ul", { key: +e.props.collapse, role: "menubar", style: { backgroundColor: e.props.backgroundColor || "" }, class: { "el-menu": true, "el-menu--horizontal": e.mode === "horizontal", "el-menu--collapse": e.props.collapse } }, [renderSlot(e.$slots, "default")], 6));
}, iu.__file = "packages/menu/src/menu.vue", iu.install = (e) => {
  e.component(iu.name, iu);
};
var ru = iu;
function su(e, t) {
  const l = inject("rootMenu"), a = computed(() => {
    let l2 = e.parent;
    const a2 = [t];
    for (; l2.type.name !== "ElMenu"; )
      l2.props.index && a2.unshift(l2.props.index), l2 = l2.parent;
    return a2;
  });
  return { parentMenu: computed(() => {
    let t2 = e.parent;
    for (; t2 && ["ElMenu", "ElSubmenu"].indexOf(t2.type.name) === -1; )
      t2 = t2.parent;
    return t2;
  }), paddingStyle: computed(() => {
    let t2 = e.parent;
    if (l.props.mode !== "vertical")
      return {};
    let a2 = 20;
    if (l.props.collapse)
      a2 = 20;
    else
      for (; t2 && t2.type.name !== "ElMenu"; )
        t2.type.name === "ElSubmenu" && (a2 += 20), t2 = t2.parent;
    return { paddingLeft: a2 + "px" };
  }), indexPath: a };
}
var uu = defineComponent({ name: "ElTooltip", components: { ElPopper: Kl }, props: Object.assign(Object.assign({}, Vl), { manual: { type: Boolean, default: false }, modelValue: { type: Boolean, validator: (e) => typeof e == "boolean", default: void 0 }, openDelay: { type: Number, default: 0 }, visibleArrow: { type: Boolean, default: true }, tabindex: { type: [String, Number], default: "0" } }), emits: [Gt], setup(e, t) {
  e.manual && e.modelValue === void 0 && Le("[ElTooltip]", "You need to pass a v-model to el-tooltip when `manual` is true");
  const a = ref(null);
  return { popper: a, onUpdateVisible: (e2) => {
    t.emit(Gt, e2);
  }, updatePopper: () => a.value.update() };
}, render() {
  const { $slots: e, content: t, manual: l, openDelay: a, onUpdateVisible: n, showAfter: o, visibleArrow: i, modelValue: r, tabindex: s } = this, u = () => {
    Le("[ElTooltip]", "you need to provide a valid default slot.");
  };
  return h(Kl, Object.assign(Object.assign({}, Object.keys(Vl).reduce((e2, t2) => Object.assign(Object.assign({}, e2), { [t2]: this[t2] }), {})), { ref: "popper", manualMode: l, showAfter: a || o, showArrow: i, visible: r, "onUpdate:visible": n }), { default: () => e.content ? e.content() : t, trigger: () => {
    if (e.default) {
      const t2 = Rl(e.default(), 1);
      return t2 || u(), cloneVNode(t2, { tabindex: s }, true);
    }
    u();
  } });
} });
uu.install = (e) => {
  e.component(uu.name, uu);
};
var du = uu;
var cu = defineComponent({ name: "ElMenuItem", componentName: "ElMenuItem", components: { ElTooltip: du }, props: { index: { default: null, validator: (e) => typeof e == "string" || e === null }, route: [String, Object], disabled: Boolean }, emits: ["click"], setup(t, { emit: l, slots: a }) {
  const o = getCurrentInstance(), s = inject("rootMenu"), { parentMenu: u, paddingStyle: d, indexPath: c } = su(o, t.index), { addSubMenu: p, removeSubMenu: h2 } = inject("subMenu:" + u.value.uid), v = computed(() => t.index === s.activeIndex.value), m = computed(() => s.hoverBackground.value), f = computed(() => s.props.backgroundColor || ""), g = computed(() => s.props.activeTextColor || ""), b = computed(() => s.props.textColor || ""), y = computed(() => s.props.mode), k = computed(() => u.value.type.name !== "ElMenu"), x = computed(() => {
    const e = { color: v.value ? g.value : b.value, borderBottomColor: "" };
    return y.value !== "horizontal" || k.value || (e.borderBottomColor = v.value ? s.props.activeTextColor ? g.value : "" : "transparent"), e;
  });
  return onMounted(() => {
    p({ index: t.index, indexPath: c, active: v }), s.methods.addMenuItem({ index: t.index, indexPath: c, active: v });
  }), onBeforeUnmount(() => {
    h2({ index: t.index, indexPath: c, active: v }), s.methods.removeMenuItem({ index: t.index, indexPath: c, active: v });
  }), { parentMenu: u, rootMenu: s, slots: a, paddingStyle: d, itemStyle: x, backgroundColor: f, active: v, handleClick: () => {
    t.disabled || (s.rootMenuEmit("menuItem:item-click", { index: t.index, indexPath: c, route: t.route }), l("click", { index: t.index, indexPath: c.value }));
  }, onMouseEnter: () => {
    (y.value !== "horizontal" || s.props.backgroundColor) && (o.vnode.el.style.backgroundColor = m.value);
  }, onMouseLeave: () => {
    (y.value !== "horizontal" || s.props.backgroundColor) && (o.vnode.el.style.backgroundColor = f.value);
  } };
} });
var pu = { style: { position: "absolute", left: "0", top: "0", height: "100%", width: "100%", display: "inline-block", "box-sizing": "border-box", padding: "0 20px" } };
cu.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-tooltip");
  return openBlock(), createBlock("li", { class: ["el-menu-item", { "is-active": e.active, "is-disabled": e.disabled }], role: "menuitem", tabindex: "-1", style: [e.paddingStyle, e.itemStyle, { backgroundColor: e.backgroundColor }], onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)), onMouseenter: t[2] || (t[2] = (...t2) => e.onMouseEnter && e.onMouseEnter(...t2)), onFocus: t[3] || (t[3] = (...t2) => e.onMouseEnter && e.onMouseEnter(...t2)), onBlur: t[4] || (t[4] = (...t2) => e.onMouseLeave && e.onMouseLeave(...t2)), onMouseleave: t[5] || (t[5] = (...t2) => e.onMouseLeave && e.onMouseLeave(...t2)) }, [e.parentMenu.type.name === "ElMenu" && e.rootMenu.props.collapse && e.slots.title ? (openBlock(), createBlock(i, { key: 0, effect: "dark", placement: "right" }, { content: withCtx(() => [renderSlot(e.$slots, "title")]), default: withCtx(() => [createVNode("div", pu, [renderSlot(e.$slots, "default")])]), _: 3 })) : (openBlock(), createBlock(Fragment, { key: 1 }, [renderSlot(e.$slots, "default"), renderSlot(e.$slots, "title")], 64))], 38);
}, cu.__file = "packages/menu/src/menuItem.vue", cu.install = (e) => {
  e.component(cu.name, cu);
};
var hu = cu;
var vu = defineComponent({ name: "ElMenuItemGroup", componentName: "ElMenuItemGroup", props: { title: { type: String } }, setup(t, { slots: l }) {
  const o = reactive({ paddingLeft: 20 }), i = getCurrentInstance(), r = computed(() => {
    let e = 20, t2 = i.parent;
    if (s.collapse)
      return 20;
    for (; t2 && t2.type.name !== "ElMenu"; )
      t2.type.name === "ElSubmenu" && (e += 20), t2 = t2.parent;
    return e;
  }), { props: s } = inject("rootMenu");
  return { data: o, levelPadding: r, props: t, slots: l };
} });
var mu = { class: "el-menu-item-group" };
vu.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("li", mu, [createVNode("div", { class: "el-menu-item-group__title", style: { paddingLeft: e.levelPadding + "px" } }, [e.slots.title ? renderSlot(e.$slots, "title", { key: 1 }) : (openBlock(), createBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(e.title), 1)], 2112))], 4), createVNode("ul", null, [renderSlot(e.$slots, "default")])]);
}, vu.__file = "packages/menu/src/menuItemGroup.vue", vu.install = (e) => {
  e.component(vu.name, vu);
};
var fu = vu;
var gu = { success: "success", info: "info", warning: "warning", error: "error" };
var bu = defineComponent({ name: "ElMessage", props: { customClass: { type: String, default: "" }, center: { type: Boolean, default: false }, dangerouslyUseHTMLString: { type: Boolean, default: false }, duration: { type: Number, default: 3e3 }, iconClass: { type: String, default: "" }, id: { type: String, default: "" }, message: { type: [String, Object], default: "" }, onClose: { type: Function, required: true }, showClose: { type: Boolean, default: false }, type: { type: String, default: "info" }, offset: { type: Number, default: 20 }, zIndex: { type: Number, default: 0 } }, emits: ["destroy"], setup(e) {
  const t = computed(() => {
    const t2 = e.type;
    return t2 && gu[t2] ? "el-message__icon el-icon-" + gu[t2] : "";
  }), a = computed(() => ({ top: e.offset + "px", zIndex: e.zIndex })), o = ref(false);
  let s = null;
  function u() {
    e.duration > 0 && (s = setTimeout(() => {
      o.value && d();
    }, e.duration));
  }
  function d() {
    o.value = false;
  }
  function c({ code: e2 }) {
    e2 === Dt.esc ? o.value && d() : u();
  }
  return onMounted(() => {
    u(), o.value = true, at(document, "keydown", c);
  }), onBeforeUnmount(() => {
    nt(document, "keydown", c);
  }), { typeClass: t, customStyle: a, visible: o, close: d, clearTimer: function() {
    clearTimeout(s), s = null;
  }, startTimer: u };
} });
var yu = { key: 0, class: "el-message__content" };
bu.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "el-message-fade", onBeforeLeave: e.onClose, onAfterLeave: t[4] || (t[4] = (t2) => e.$emit("destroy")) }, { default: withCtx(() => [withDirectives(createVNode("div", { id: e.id, class: ["el-message", e.type && !e.iconClass ? "el-message--" + e.type : "", e.center ? "is-center" : "", e.showClose ? "is-closable" : "", e.customClass], style: e.customStyle, role: "alert", onMouseenter: t[2] || (t[2] = (...t2) => e.clearTimer && e.clearTimer(...t2)), onMouseleave: t[3] || (t[3] = (...t2) => e.startTimer && e.startTimer(...t2)) }, [e.type || e.iconClass ? (openBlock(), createBlock("i", { key: 0, class: [e.typeClass, e.iconClass] }, null, 2)) : createCommentVNode("v-if", true), renderSlot(e.$slots, "default", {}, () => [e.dangerouslyUseHTMLString ? (openBlock(), createBlock(Fragment, { key: 1 }, [createCommentVNode(" Caution here, message could've been compromised, never use user's input as message "), createCommentVNode("  eslint-disable-next-line "), createVNode("p", { class: "el-message__content", innerHTML: e.message }, null, 8, ["innerHTML"])], 2112)) : (openBlock(), createBlock("p", yu, toDisplayString(e.message), 1))]), e.showClose ? (openBlock(), createBlock("div", { key: 1, class: "el-message__closeBtn el-icon-close", onClick: t[1] || (t[1] = withModifiers((...t2) => e.close && e.close(...t2), ["stop"])) })) : createCommentVNode("v-if", true)], 46, ["id"]), [[vShow, e.visible]])]), _: 3 }, 8, ["onBeforeLeave"]);
}, bu.__file = "packages/message/src/index.vue";
var ku = [];
var xu = 1;
var Cu = function(e = {}) {
  if (ke)
    return;
  typeof e == "string" && (e = { message: e });
  let t = e, l = e.offset || 20;
  ku.forEach(({ vm: e2 }) => {
    l += (e2.el.offsetHeight || 0) + 16;
  }), l += 16;
  const a = "message_" + xu++, n = t.onClose;
  t = Object.assign(Object.assign({}, t), { onClose: () => {
    !function(e2, t2) {
      const l2 = ku.findIndex(({ vm: t3 }) => {
        const { id: l3 } = t3.component.props;
        return e2 === l3;
      });
      if (l2 === -1)
        return;
      const { vm: a2 } = ku[l2];
      if (!a2)
        return;
      t2 == null || t2(a2);
      const n2 = a2.el.offsetHeight;
      ku.splice(l2, 1);
      const o2 = ku.length;
      if (o2 < 1)
        return;
      for (let e3 = l2; e3 < o2; e3++) {
        const t3 = parseInt(ku[e3].vm.el.style.top, 10) - n2 - 16;
        ku[e3].vm.component.props.offset = t3;
      }
    }(a, n);
  }, offset: l, id: a, zIndex: Ol.nextZIndex() });
  const o = document.createElement("div");
  o.className = "container_" + a;
  const i = t.message, r = createVNode(bu, t, isVNode(t.message) ? { default: () => i } : null);
  return r.props.onDestroy = () => {
    render(null, o);
  }, render(r, o), ku.push({ vm: r }), document.body.appendChild(o.firstElementChild), { close: () => r.component.proxy.visible = false };
};
["success", "warning", "info", "error"].forEach((e) => {
  Cu[e] = (t) => (typeof t == "string" ? t = { message: t, type: e } : t.type = e, Cu(t));
}), Cu.closeAll = function() {
  for (let e = ku.length - 1; e >= 0; e--) {
    ku[e].vm.component.ctx.close();
  }
};
var wu = Cu;
wu.install = (e) => {
  e.config.globalProperties.$message = wu;
};
var Su = { success: "success", info: "info", warning: "warning", error: "error" };
var _u = defineComponent({ name: "ElMessageBox", directives: { TrapFocus: Yt }, components: { ElButton: ma, ElInput: gl, ElOverlay: or }, inheritAttrs: false, props: { buttonSize: { type: String, validator: Qt }, modal: { type: Boolean, default: true }, lockScroll: { type: Boolean, default: true }, showClose: { type: Boolean, default: true }, closeOnClickModal: { type: Boolean, default: true }, closeOnPressEscape: { type: Boolean, default: true }, closeOnHashChange: { type: Boolean, default: true }, center: Boolean, roundButton: { default: false, type: Boolean }, container: { type: String, default: "body" }, boxType: { type: String, default: "" } }, emits: ["vanish", "action"], setup(e, { emit: t }) {
  const s = ref(false), u = reactive({ beforeClose: null, callback: null, cancelButtonText: "", cancelButtonClass: "", confirmButtonText: "", confirmButtonClass: "", customClass: "", dangerouslyUseHTMLString: false, distinguishCancelAndClose: false, iconClass: "", inputPattern: null, inputPlaceholder: "", inputType: "text", inputValue: null, inputValidator: null, inputErrorMessage: "", message: null, modalFade: true, modalClass: "", showCancelButton: false, showConfirmButton: true, type: "", title: void 0, showInput: false, action: "", confirmButtonLoading: false, cancelButtonLoading: false, confirmButtonDisabled: false, editorErrorMessage: "", validateError: false, zIndex: Ol.nextZIndex() }), d = computed(() => u.iconClass || (u.type && Su[u.type] ? "el-icon-" + Su[u.type] : "")), c = computed(() => !!u.message), p = ref(null), h2 = ref(null), v = computed(() => "el-button--primary " + u.confirmButtonClass);
  function m() {
    s.value && (s.value = false, nextTick(() => {
      u.action && t("action", u.action);
    }));
  }
  watch(() => u.inputValue, (t2) => Ds(this, void 0, void 0, function* () {
    yield nextTick(), e.boxType === "prompt" && t2 !== null && g();
  }), { immediate: true }), watch(() => s.value, (t2) => {
    t2 && (e.boxType !== "alert" && e.boxType !== "confirm" || nextTick().then(() => {
      var e2, t3, l;
      (l = (t3 = (e2 = h2.value) === null || e2 === void 0 ? void 0 : e2.$el) === null || t3 === void 0 ? void 0 : t3.focus) === null || l === void 0 || l.call(t3);
    }), u.zIndex = Ol.nextZIndex()), e.boxType === "prompt" && (t2 ? nextTick().then(() => {
      p.value && p.value.$el && b().focus();
    }) : (u.editorErrorMessage = "", u.validateError = false));
  }), onMounted(() => Ds(this, void 0, void 0, function* () {
    yield nextTick(), e.closeOnHashChange && at(window, "hashchange", m);
  })), onBeforeUnmount(() => {
    e.closeOnHashChange && nt(window, "hashchange", m);
  });
  const f = (t2) => {
    var l;
    (e.boxType !== "prompt" || t2 !== "confirm" || g()) && (u.action = t2, u.beforeClose ? (l = u.beforeClose) === null || l === void 0 || l.call(u, t2, u, m) : m());
  }, g = () => {
    if (e.boxType === "prompt") {
      const e2 = u.inputPattern;
      if (e2 && !e2.test(u.inputValue || ""))
        return u.editorErrorMessage = u.inputErrorMessage || Ca("el.messagebox.error"), u.validateError = true, false;
      const t2 = u.inputValidator;
      if (typeof t2 == "function") {
        const e3 = t2(u.inputValue);
        if (e3 === false)
          return u.editorErrorMessage = u.inputErrorMessage || Ca("el.messagebox.error"), u.validateError = true, false;
        if (typeof e3 == "string")
          return u.editorErrorMessage = e3, u.validateError = true, false;
      }
    }
    return u.editorErrorMessage = "", u.validateError = false, true;
  }, b = () => {
    const e2 = p.value.$refs;
    return e2.input || e2.textarea;
  }, y = () => {
    f("close");
  };
  return e.closeOnPressEscape ? Lt({ handleClose: y }, s) : ((e2, t2, l) => {
    const a = (e3) => {
      l(e3) && e3.stopImmediatePropagation();
    };
    watch(() => e2.value, (e3) => {
      e3 ? at(document, t2, a, true) : nt(document, t2, a, true);
    }, { immediate: true });
  })(s, "keydown", (e2) => e2.code === Dt.esc), e.lockScroll && Ot(s), Nt(s), Object.assign(Object.assign({}, toRefs(u)), { visible: s, hasMessage: c, icon: d, confirmButtonClasses: v, inputRef: p, confirmRef: h2, doClose: m, handleClose: y, handleWrapperClick: () => {
    e.closeOnClickModal && f(u.distinguishCancelAndClose ? "close" : "cancel");
  }, handleInputEnter: () => {
    if (u.inputType !== "textarea")
      return f("confirm");
  }, handleAction: f, t: Ca });
} });
var Eu = { key: 0, class: "el-message-box__header" };
var Mu = { class: "el-message-box__title" };
var Tu = createVNode("i", { class: "el-message-box__close el-icon-close" }, null, -1);
var Iu = { class: "el-message-box__content" };
var Ou = { class: "el-message-box__container" };
var Nu = { key: 1, class: "el-message-box__message" };
var Du = { key: 0 };
var Vu = { class: "el-message-box__input" };
var Bu = { class: "el-message-box__btns" };
_u.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input"), r = resolveComponent("el-button"), y = resolveComponent("el-overlay"), k = resolveDirective("trap-focus");
  return openBlock(), createBlock(Transition, { name: "fade-in-linear", onAfterLeave: t[8] || (t[8] = (t2) => e.$emit("vanish")) }, { default: withCtx(() => [withDirectives(createVNode(y, { "z-index": e.zIndex, "overlay-class": ["is-message-box", e.modalClass], mask: e.modal, onClick: withModifiers(e.handleWrapperClick, ["self"]) }, { default: withCtx(() => [withDirectives(createVNode("div", { ref: "root", "aria-label": e.title || "dialog", "aria-modal": "true", class: ["el-message-box", e.customClass, { "el-message-box--center": e.center }] }, [e.title !== null && e.title !== void 0 ? (openBlock(), createBlock("div", Eu, [createVNode("div", Mu, [e.icon && e.center ? (openBlock(), createBlock("div", { key: 0, class: ["el-message-box__status", e.icon] }, null, 2)) : createCommentVNode("v-if", true), createVNode("span", null, toDisplayString(e.title), 1)]), e.showClose ? (openBlock(), createBlock("button", { key: 0, type: "button", class: "el-message-box__headerbtn", "aria-label": "Close", onClick: t[1] || (t[1] = (t2) => e.handleAction(e.distinguishCancelAndClose ? "close" : "cancel")), onKeydown: t[2] || (t[2] = withKeys((t2) => e.handleAction(e.distinguishCancelAndClose ? "close" : "cancel"), ["enter"])) }, [Tu], 32)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createVNode("div", Iu, [createVNode("div", Ou, [e.icon && !e.center && e.hasMessage ? (openBlock(), createBlock("div", { key: 0, class: ["el-message-box__status", e.icon] }, null, 2)) : createCommentVNode("v-if", true), e.hasMessage ? (openBlock(), createBlock("div", Nu, [renderSlot(e.$slots, "default", {}, () => [e.dangerouslyUseHTMLString ? (openBlock(), createBlock("p", { key: 1, innerHTML: e.message }, null, 8, ["innerHTML"])) : (openBlock(), createBlock("p", Du, toDisplayString(e.message), 1))])])) : createCommentVNode("v-if", true)]), withDirectives(createVNode("div", Vu, [createVNode(i, { ref: "inputRef", modelValue: e.inputValue, "onUpdate:modelValue": t[3] || (t[3] = (t2) => e.inputValue = t2), type: e.inputType, placeholder: e.inputPlaceholder, class: { invalid: e.validateError }, onKeydown: withKeys(withModifiers(e.handleInputEnter, ["prevent"]), ["enter"]) }, null, 8, ["modelValue", "type", "placeholder", "class", "onKeydown"]), createVNode("div", { class: "el-message-box__errormsg", style: { visibility: e.editorErrorMessage ? "visible" : "hidden" } }, toDisplayString(e.editorErrorMessage), 5)], 512), [[vShow, e.showInput]])]), createVNode("div", Bu, [e.showCancelButton ? (openBlock(), createBlock(r, { key: 0, loading: e.cancelButtonLoading, class: [e.cancelButtonClass], round: e.roundButton, size: e.buttonSize || "small", onClick: t[4] || (t[4] = (t2) => e.handleAction("cancel")), onKeydown: t[5] || (t[5] = withKeys((t2) => e.handleAction("cancel"), ["enter"])) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.cancelButtonText || e.t("el.messagebox.cancel")), 1)]), _: 1 }, 8, ["loading", "class", "round", "size"])) : createCommentVNode("v-if", true), withDirectives(createVNode(r, { ref: "confirmRef", loading: e.confirmButtonLoading, class: [e.confirmButtonClasses], round: e.roundButton, disabled: e.confirmButtonDisabled, size: e.buttonSize || "small", onClick: t[6] || (t[6] = (t2) => e.handleAction("confirm")), onKeydown: t[7] || (t[7] = withKeys((t2) => e.handleAction("confirm"), ["enter"])) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.confirmButtonText || e.t("el.messagebox.confirm")), 1)]), _: 1 }, 8, ["loading", "class", "round", "disabled", "size"]), [[vShow, e.showConfirmButton]])])], 10, ["aria-label"]), [[k]])]), _: 3 }, 8, ["z-index", "overlay-class", "mask", "onClick"]), [[vShow, e.visible]])]), _: 1 });
}, _u.__file = "packages/message-box/src/index.vue";
var Pu = new Map();
var Au = (e) => {
  const t = document.createElement("div");
  e.onVanish = () => {
    render(null, t), Pu.delete(a);
  }, e.onAction = (t2) => {
    const n = Pu.get(a);
    let o;
    o = e.showInput ? { value: a.inputValue, action: t2 } : t2, e.callback ? e.callback(o, l.proxy) : t2 === "cancel" || t2 === "close" ? e.distinguishCancelAndClose && t2 !== "cancel" ? n.reject("close") : n.reject("cancel") : n.resolve(o);
  };
  const l = ((e2, t2) => {
    const l2 = h(_u, e2);
    return render(l2, t2), document.body.appendChild(t2.firstElementChild), l2.component;
  })(e, t), a = l.proxy;
  for (const t2 in e)
    Se(e, t2) && !Se(a.$props, t2) && (a[t2] = e[t2]);
  return watch(() => a.message, (e2, t2) => {
    isVNode(e2) ? l.slots.default = () => [e2] : isVNode(t2) && !isVNode(e2) && delete l.slots.default;
  }, { immediate: true }), a.visible = true, a;
};
function zu(e) {
  if (ke)
    return;
  let t;
  return Me(e) || isVNode(e) ? e = { message: e } : t = e.callback, new Promise((l, a) => {
    const n = Au(e);
    Pu.set(n, { options: e, callback: t, resolve: l, reject: a });
  });
}
zu.alert = (e, t, l) => (typeof t == "object" ? (l = t, t = "") : t === void 0 && (t = ""), zu(Object.assign({ title: t, message: e, type: "", closeOnPressEscape: false, closeOnClickModal: false }, l, { boxType: "alert" }))), zu.confirm = (e, t, l) => (typeof t == "object" ? (l = t, t = "") : t === void 0 && (t = ""), zu(Object.assign({ title: t, message: e, type: "", showCancelButton: true }, l, { boxType: "confirm" }))), zu.prompt = (e, t, l) => (typeof t == "object" ? (l = t, t = "") : t === void 0 && (t = ""), zu(Object.assign({ title: t, message: e, showCancelButton: true, showInput: true, type: "" }, l, { boxType: "prompt" }))), zu.close = () => {
  Pu.forEach((e, t) => {
    t.doClose();
  }), Pu.clear();
};
var Lu = zu;
Lu.install = (e) => {
  e.config.globalProperties.$msgbox = Lu, e.config.globalProperties.$messageBox = Lu, e.config.globalProperties.$alert = Lu.alert, e.config.globalProperties.$confirm = Lu.confirm, e.config.globalProperties.$prompt = Lu.prompt;
};
var Fu = { success: "success", info: "info", warning: "warning", error: "error" };
var Ru = defineComponent({ name: "ElNotification", props: { customClass: { type: String, default: "" }, dangerouslyUseHTMLString: { type: Boolean, default: false }, duration: { type: Number, default: 4500 }, iconClass: { type: String, default: "" }, id: { type: String, default: "" }, message: { type: [String, Object], default: "" }, offset: { type: Number, default: 0 }, onClick: { type: Function, default: () => {
} }, onClose: { type: Function, required: true }, position: { type: String, default: "top-right" }, showClose: { type: Boolean, default: true }, title: { type: String, default: "" }, type: { type: String, default: "" }, zIndex: { type: Number, default: 0 } }, emits: ["destroy"], setup(e) {
  const t = ref(false);
  let a = null;
  const o = computed(() => {
    const t2 = e.type;
    return t2 && Fu[t2] ? "el-icon-" + Fu[t2] : "";
  }), s = computed(() => e.position.indexOf("right") > 1 ? "right" : "left"), u = computed(() => e.position.startsWith("top") ? "top" : "bottom"), d = computed(() => ({ [u.value]: e.offset + "px", "z-index": e.zIndex }));
  function c() {
    e.duration > 0 && (a = setTimeout(() => {
      t.value && h2();
    }, e.duration));
  }
  function p() {
    clearTimeout(a), a = null;
  }
  function h2() {
    t.value = false;
  }
  function v({ code: e2 }) {
    e2 === Dt.delete || e2 === Dt.backspace ? p() : e2 === Dt.esc ? t.value && h2() : c();
  }
  return onMounted(() => {
    c(), t.value = true, at(document, "keydown", v);
  }), onBeforeUnmount(() => {
    nt(document, "keydown", v);
  }), { horizontalClass: s, typeClass: o, positionStyle: d, visible: t, close: h2, clearTimer: p, startTimer: c };
} });
var $u = { key: 0 };
Ru.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock(Transition, { name: "el-notification-fade", onBeforeLeave: e.onClose, onAfterLeave: t[5] || (t[5] = (t2) => e.$emit("destroy")) }, { default: withCtx(() => [withDirectives(createVNode("div", { id: e.id, class: ["el-notification", e.customClass, e.horizontalClass], style: e.positionStyle, role: "alert", onMouseenter: t[2] || (t[2] = (...t2) => e.clearTimer && e.clearTimer(...t2)), onMouseleave: t[3] || (t[3] = (...t2) => e.startTimer && e.startTimer(...t2)), onClick: t[4] || (t[4] = (...t2) => e.onClick && e.onClick(...t2)) }, [e.type || e.iconClass ? (openBlock(), createBlock("i", { key: 0, class: ["el-notification__icon", [e.typeClass, e.iconClass]] }, null, 2)) : createCommentVNode("v-if", true), createVNode("div", { class: ["el-notification__group", { "is-with-icon": e.typeClass || e.iconClass }] }, [createVNode("h2", { class: "el-notification__title", textContent: toDisplayString(e.title) }, null, 8, ["textContent"]), withDirectives(createVNode("div", { class: "el-notification__content", style: e.title ? null : "margin: 0" }, [renderSlot(e.$slots, "default", {}, () => [e.dangerouslyUseHTMLString ? (openBlock(), createBlock(Fragment, { key: 1 }, [createCommentVNode(" Caution here, message could've been compromized, nerver use user's input as message "), createCommentVNode(" eslint-disable-next-line "), createVNode("p", { innerHTML: e.message }, null, 8, ["innerHTML"])], 2112)) : (openBlock(), createBlock("p", $u, toDisplayString(e.message), 1))])], 4), [[vShow, e.message]]), e.showClose ? (openBlock(), createBlock("div", { key: 0, class: "el-notification__closeBtn el-icon-close", onClick: t[1] || (t[1] = withModifiers((...t2) => e.close && e.close(...t2), ["stop"])) })) : createCommentVNode("v-if", true)], 2)], 46, ["id"]), [[vShow, e.visible]])]), _: 3 }, 8, ["onBeforeLeave"]);
}, Ru.__file = "packages/notification/src/index.vue";
var Hu = { "top-left": [], "top-right": [], "bottom-left": [], "bottom-right": [] };
var Wu = 1;
var ju = function(e = {}) {
  if (ke)
    return;
  const t = e.position || "top-right";
  let l = e.offset || 0;
  Hu[t].forEach(({ vm: e2 }) => {
    l += (e2.el.offsetHeight || 0) + 16;
  }), l += 16;
  const a = "notification_" + Wu++, n = e.onClose;
  e = Object.assign(Object.assign({}, e), { onClose: () => {
    !function(e2, t2, l2) {
      const a2 = Hu[t2], n2 = a2.findIndex(({ vm: t3 }) => t3.component.props.id === e2);
      if (n2 === -1)
        return;
      const { vm: o2 } = a2[n2];
      if (!o2)
        return;
      l2 == null || l2(o2);
      const i2 = o2.el.offsetHeight, r = t2.split("-")[0];
      a2.splice(n2, 1);
      const s = a2.length;
      if (s < 1)
        return;
      for (let e3 = n2; e3 < s; e3++) {
        const { el: t3, component: l3 } = a2[e3].vm, n3 = parseInt(t3.style[r], 10) - i2 - 16;
        l3.props.offset = n3;
      }
    }(a, t, n);
  }, offset: l, id: a, zIndex: Ol.nextZIndex() });
  const o = document.createElement("div"), i = createVNode(Ru, e, isVNode(e.message) ? { default: () => e.message } : null);
  return i.props.onDestroy = () => {
    render(null, o);
  }, render(i, o), Hu[t].push({ vm: i }), document.body.appendChild(o.firstElementChild), { close: () => {
    i.component.proxy.visible = false;
  } };
};
["success", "warning", "info", "error"].forEach((e) => {
  Object.assign(ju, { [e]: (t = {}) => ((typeof t == "string" || isVNode(t)) && (t = { message: t }), t.type = e, ju(t)) });
});
var Ku = ju;
Ku.install = (e) => {
  e.config.globalProperties.$notify = Ku;
};
var Yu = "elOptionQueryChange";
var qu = "elOptionGroupQueryChange";
function Uu(t, l) {
  const a = inject("ElSelect"), i = inject("ElSelectGroup", { disabled: false }), r = computed(() => Object.prototype.toString.call(t.value).toLowerCase() === "[object object]"), s = computed(() => a.props.multiple ? v(a.props.modelValue, t.value) : m(t.value, a.props.modelValue)), u = computed(() => {
    if (a.props.multiple) {
      const e = a.props.modelValue || [];
      return !s.value && e.length >= a.props.multipleLimit && a.props.multipleLimit > 0;
    }
    return false;
  }), d = computed(() => t.label || (r.value ? "" : t.value)), c = computed(() => t.value || t.label || ""), p = computed(() => t.disabled || l.groupDisabled || u.value), h2 = getCurrentInstance(), v = (e = [], t2) => {
    if (r.value) {
      const l2 = a.props.valueKey;
      return e && e.some((e2) => Re(e2, l2) === Re(t2, l2));
    }
    return e && e.indexOf(t2) > -1;
  }, m = (e, t2) => {
    if (r.value) {
      const { valueKey: l2 } = a.props;
      return Re(e, l2) === Re(t2, l2);
    }
    return e === t2;
  };
  return watch(() => d.value, () => {
    t.created || a.props.remote || a.setSelected();
  }), watch(() => t.value, (e, l2) => {
    const { remote: n, valueKey: o } = a.props;
    if (!t.created && !n) {
      if (o && typeof e == "object" && typeof l2 == "object" && e[o] === l2[o])
        return;
      a.setSelected();
    }
  }), watch(() => i.disabled, () => {
    l.groupDisabled = i.disabled;
  }, { immediate: true }), a.selectEmitter.on(Yu, (e) => {
    const n = new RegExp(((e2 = "") => String(e2).replace(/[|\\{}()[\]^$+*?.]/g, "\\$&"))(e), "i");
    l.visible = n.test(d.value) || t.created, l.visible || a.filteredOptionsCount--;
  }), { select: a, currentLabel: d, currentValue: c, itemSelected: s, isDisabled: p, hoverItem: () => {
    t.disabled || i.disabled || (a.hoverIndex = a.optionsArray.indexOf(h2));
  } };
}
var Gu = defineComponent({ name: "ElOption", componentName: "ElOption", props: { value: { required: true, type: [String, Number, Boolean, Object] }, label: [String, Number], created: Boolean, disabled: { type: Boolean, default: false } }, setup(t) {
  const l = reactive({ index: -1, groupDisabled: false, visible: true, hitState: false, hover: false }), { currentLabel: n, itemSelected: o, isDisabled: i, select: s, hoverItem: u } = Uu(t, l), { visible: d, hover: c } = toRefs(l), p = getCurrentInstance().proxy;
  return s.onOptionCreate(p), onBeforeUnmount(() => {
    const { selected: e } = s;
    let l2 = s.props.multiple ? e : [e];
    const a = s.cachedOptions.has(t.value), n2 = l2.some((e2) => e2.value === p.value);
    a && !n2 && s.cachedOptions.delete(t.value), s.onOptionDestroy(t.value);
  }), { currentLabel: n, itemSelected: o, isDisabled: i, select: s, hoverItem: u, visible: d, hover: c, selectOptionClick: function() {
    t.disabled !== true && l.groupDisabled !== true && s.handleOptionSelect(p, true);
  } };
} });
Gu.render = function(e, t, l, a, n, o) {
  return withDirectives((openBlock(), createBlock("li", { class: ["el-select-dropdown__item", { selected: e.itemSelected, "is-disabled": e.isDisabled, hover: e.hover }], onMouseenter: t[1] || (t[1] = (...t2) => e.hoverItem && e.hoverItem(...t2)), onClick: t[2] || (t[2] = withModifiers((...t2) => e.selectOptionClick && e.selectOptionClick(...t2), ["stop"])) }, [renderSlot(e.$slots, "default", {}, () => [createVNode("span", null, toDisplayString(e.currentLabel), 1)])], 34)), [[vShow, e.visible]]);
}, Gu.__file = "packages/select/src/option.vue";
var Xu = defineComponent({ name: "ElSelectDropdown", componentName: "ElSelectDropdown", setup() {
  const e = inject("ElSelect"), t = computed(() => e.props.popperClass), a = computed(() => e.props.multiple), o = ref("");
  function s() {
    var t2;
    o.value = ((t2 = e.selectWrapper) === null || t2 === void 0 ? void 0 : t2.getBoundingClientRect().width) + "px";
  }
  return onMounted(() => {
    vt(e.selectWrapper, s);
  }), onBeforeUnmount(() => {
    mt(e.selectWrapper, s);
  }), { minWidth: o, popperClass: t, isMultiple: a };
} });
Xu.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-select-dropdown", [{ "is-multiple": e.isMultiple }, e.popperClass]], style: { minWidth: e.minWidth } }, [renderSlot(e.$slots, "default")], 6);
}, Xu.__file = "packages/select/src/select-dropdown.vue";
var Zu = (e, t, a) => {
  const i = Xe(), r = ref(null), s = ref(null), u = ref(null), d = ref(null), c = ref(null), p = ref(null), h2 = ref(-1), v = inject("elForm", {}), m = inject("elFormItem", {}), f = computed(() => !e.filterable || e.multiple || !(!ke && !isNaN(Number(document.documentMode))) && !(!ke && navigator.userAgent.indexOf("Edge") > -1) && !t.visible), g = computed(() => e.disabled || v.disabled), b = computed(() => {
    const l = e.multiple ? Array.isArray(e.modelValue) && e.modelValue.length > 0 : e.modelValue !== void 0 && e.modelValue !== null && e.modelValue !== "";
    return e.clearable && !g.value && t.inputHovering && l;
  }), y = computed(() => e.remote && e.filterable ? "" : t.visible ? "arrow-up is-reverse" : "arrow-up"), k = computed(() => e.remote ? 300 : 0), x = computed(() => e.loading ? e.loadingText || Ca("el.select.loading") : (!e.remote || t.query !== "" || t.options.size !== 0) && (e.filterable && t.query && t.options.size > 0 && t.filteredOptionsCount === 0 ? e.noMatchText || Ca("el.select.noMatch") : t.options.size === 0 ? e.noDataText || Ca("el.select.noData") : null)), C = computed(() => Array.from(t.options.values())), S = computed(() => Array.from(t.cachedOptions.values())), _ = computed(() => {
    const l = C.value.filter((e2) => !e2.created).some((e2) => e2.currentLabel === t.query);
    return e.filterable && e.allowCreate && t.query !== "" && !l;
  }), M = computed(() => e.size || m.size || i.size), T = computed(() => ["small", "mini"].indexOf(M.value) > -1 ? "mini" : "small"), I = computed(() => t.visible && x.value !== false);
  watch(() => g.value, () => {
    nextTick(() => {
      O();
    });
  }), watch(() => e.placeholder, (e2) => {
    t.cachedPlaceHolder = t.currentPlaceholder = e2;
  }), watch(() => e.modelValue, (l, a2) => {
    var n;
    e.multiple && (O(), l && l.length > 0 || s.value && t.query !== "" ? t.currentPlaceholder = "" : t.currentPlaceholder = t.cachedPlaceHolder, e.filterable && !e.reserveKeyword && (t.query = "", N(t.query))), B(), e.filterable && !e.multiple && (t.inputLength = 20), (0, import_isEqual.default)(l, a2) || (n = m.formItemMitt) === null || n === void 0 || n.emit("el.form.change", l);
  }, { flush: "post", deep: true }), watch(() => t.visible, (l) => {
    var n, o;
    l ? ((o = (n = u.value) === null || n === void 0 ? void 0 : n.update) === null || o === void 0 || o.call(n), e.filterable && (t.filteredOptionsCount = t.optionsCount, t.query = e.remote ? "" : t.selectedLabel, e.multiple ? s.value.focus() : t.selectedLabel && (t.currentPlaceholder = t.selectedLabel, t.selectedLabel = ""), N(t.query), e.multiple || e.remote || (t.selectEmitter.emit("elOptionQueryChange", ""), t.selectEmitter.emit("elOptionGroupQueryChange")))) : (s.value && s.value.blur(), t.query = "", t.previousQuery = null, t.selectedLabel = "", t.inputLength = 20, t.menuVisibleOnFocus = false, A(), nextTick(() => {
      s.value && s.value.value === "" && t.selected.length === 0 && (t.currentPlaceholder = t.cachedPlaceHolder);
    }), e.multiple || (t.selected && (e.filterable && e.allowCreate && t.createdSelected && t.createdLabel ? t.selectedLabel = t.createdLabel : t.selectedLabel = t.selected.currentLabel, e.filterable && (t.query = t.selectedLabel)), e.filterable && (t.currentPlaceholder = t.cachedPlaceHolder))), a.emit("visible-change", l);
  }), watch(() => t.options.entries(), () => {
    var l, a2, n;
    if (ke)
      return;
    (a2 = (l = u.value) === null || l === void 0 ? void 0 : l.update) === null || a2 === void 0 || a2.call(l), e.multiple && O();
    const o = ((n = c.value) === null || n === void 0 ? void 0 : n.querySelectorAll("input")) || [];
    [].indexOf.call(o, document.activeElement) === -1 && B(), e.defaultFirstOption && (e.filterable || e.remote) && t.filteredOptionsCount && V();
  }, { flush: "post" }), watch(() => t.hoverIndex, (e2) => {
    typeof e2 == "number" && e2 > -1 && (h2.value = C.value[e2] || {}), C.value.forEach((e3) => {
      e3.hover = h2.value === e3;
    });
  });
  const O = () => {
    e.collapseTags && !e.filterable || nextTick(() => {
      var e2, l;
      if (!r.value)
        return;
      const a2 = r.value.$el.childNodes, n = [].filter.call(a2, (e3) => e3.tagName === "INPUT")[0], o = d.value, i2 = t.initialInputHeight || 40;
      n.style.height = t.selected.length === 0 ? i2 + "px" : Math.max(o ? o.clientHeight + (o.clientHeight > i2 ? 6 : 0) : 0, i2) + "px", t.tagInMultiLine = parseFloat(n.style.height) > i2, t.visible && x.value !== false && ((l = (e2 = u.value) === null || e2 === void 0 ? void 0 : e2.update) === null || l === void 0 || l.call(e2));
    });
  }, N = (l) => {
    t.previousQuery === l || t.isOnComposition || (t.previousQuery !== null || typeof e.filterMethod != "function" && typeof e.remoteMethod != "function" ? (t.previousQuery = l, nextTick(() => {
      var e2, l2;
      t.visible && ((l2 = (e2 = u.value) === null || e2 === void 0 ? void 0 : e2.update) === null || l2 === void 0 || l2.call(e2));
    }), t.hoverIndex = -1, e.multiple && e.filterable && nextTick(() => {
      const l2 = 15 * s.value.length + 20;
      t.inputLength = e.collapseTags ? Math.min(50, l2) : l2, D(), O();
    }), e.remote && typeof e.remoteMethod == "function" ? (t.hoverIndex = -1, e.remoteMethod(l)) : typeof e.filterMethod == "function" ? (e.filterMethod(l), t.selectEmitter.emit("elOptionGroupQueryChange")) : (t.filteredOptionsCount = t.optionsCount, t.selectEmitter.emit("elOptionQueryChange", l), t.selectEmitter.emit("elOptionGroupQueryChange")), e.defaultFirstOption && (e.filterable || e.remote) && t.filteredOptionsCount && V()) : t.previousQuery = l);
  }, D = () => {
    t.currentPlaceholder !== "" && (t.currentPlaceholder = s.value.value ? "" : t.cachedPlaceHolder);
  }, V = () => {
    t.hoverIndex = -1;
    let e2 = false;
    for (let l = t.options.size - 1; l >= 0; l--)
      if (C.value[l].created) {
        e2 = true, t.hoverIndex = l;
        break;
      }
    if (!e2)
      for (let e3 = 0; e3 !== t.options.size; ++e3) {
        const l = C.value[e3];
        if (t.query) {
          if (!l.disabled && !l.groupDisabled && l.visible) {
            t.hoverIndex = e3;
            break;
          }
        } else if (l.itemSelected) {
          t.hoverIndex = e3;
          break;
        }
      }
  }, B = () => {
    var l;
    if (!e.multiple) {
      const a3 = P(e.modelValue);
      return ((l = a3.props) === null || l === void 0 ? void 0 : l.created) ? (t.createdLabel = a3.props.value, t.createdSelected = true) : t.createdSelected = false, t.selectedLabel = a3.currentLabel, t.selected = a3, void (e.filterable && (t.query = t.selectedLabel));
    }
    const a2 = [];
    Array.isArray(e.modelValue) && e.modelValue.forEach((e2) => {
      a2.push(P(e2));
    }), t.selected = a2, nextTick(() => {
      O();
    });
  }, P = (l) => {
    let a2;
    const n = De(l).toLowerCase() === "object", o = De(l).toLowerCase() === "null", i2 = De(l).toLowerCase() === "undefined";
    for (let o2 = t.cachedOptions.size - 1; o2 >= 0; o2--) {
      const t2 = S.value[o2];
      if (n ? Re(t2.value, e.valueKey) === Re(l, e.valueKey) : t2.value === l) {
        a2 = { value: l, currentLabel: t2.currentLabel, isDisabled: t2.isDisabled };
        break;
      }
    }
    if (a2)
      return a2;
    const r2 = { value: l, currentLabel: n || o || i2 ? "" : l };
    return e.multiple && (r2.hitState = false), r2;
  }, A = () => {
    setTimeout(() => {
      e.multiple ? t.selected.length > 0 ? t.hoverIndex = Math.min.apply(null, t.selected.map((e2) => C.value.indexOf(e2))) : t.hoverIndex = -1 : t.hoverIndex = C.value.indexOf(t.selected);
    }, 300);
  }, z = () => {
    var e2;
    t.inputWidth = (e2 = r.value) === null || e2 === void 0 ? void 0 : e2.$el.getBoundingClientRect().width;
  }, L = (0, import_debounce2.default)(() => {
    e.filterable && t.query !== t.selectedLabel && (t.query = t.selectedLabel, N(t.query));
  }, k.value), F = (0, import_debounce2.default)((e2) => {
    N(e2.target.value);
  }, k.value), R = (t2) => {
    (0, import_isEqual.default)(e.modelValue, t2) || a.emit("change", t2);
  }, $ = (l) => {
    l.stopPropagation();
    const n = e.multiple ? [] : "";
    if (typeof n != "string")
      for (const e2 of t.selected)
        e2.isDisabled && n.push(e2.value);
    a.emit(Gt, n), R(n), t.visible = false, a.emit("clear");
  }, H = (l, n) => {
    if (e.multiple) {
      const n2 = (e.modelValue || []).slice(), o = W(n2, l.value);
      o > -1 ? n2.splice(o, 1) : (e.multipleLimit <= 0 || n2.length < e.multipleLimit) && n2.push(l.value), a.emit(Gt, n2), R(n2), l.created && (t.query = "", N(""), t.inputLength = 20), e.filterable && s.value.focus();
    } else
      a.emit(Gt, l.value), R(l.value), t.visible = false;
    t.isSilentBlur = n, j(), t.visible || nextTick(() => {
      K(l);
    });
  }, W = (t2 = [], l) => {
    if (!Te(l))
      return t2.indexOf(l);
    const a2 = e.valueKey;
    let n = -1;
    return t2.some((e2, t3) => Re(e2, a2) === Re(l, a2) && (n = t3, true)), n;
  }, j = () => {
    t.softFocus = true;
    const e2 = s.value || r.value;
    e2 && e2.focus();
  }, K = (e2) => {
    var t2, l, a2, n;
    const o = Array.isArray(e2) ? e2[0] : e2;
    let i2 = null;
    if (o == null ? void 0 : o.value) {
      const e3 = C.value.filter((e4) => e4.value === o.value);
      e3.length > 0 && (i2 = e3[0].$el);
    }
    if (u.value && i2) {
      const e3 = (a2 = (l = (t2 = u.value) === null || t2 === void 0 ? void 0 : t2.popperRef) === null || l === void 0 ? void 0 : l.querySelector) === null || a2 === void 0 ? void 0 : a2.call(l, ".el-select-dropdown__wrap");
      e3 && Qn(e3, i2);
    }
    (n = p.value) === null || n === void 0 || n.handleScroll();
  }, Y = (e2) => {
    if (!Array.isArray(t.selected))
      return;
    const l = t.selected[t.selected.length - 1];
    return l ? e2 === true || e2 === false ? (l.hitState = e2, e2) : (l.hitState = !l.hitState, l.hitState) : void 0;
  }, q = () => {
    e.automaticDropdown || g.value || (t.menuVisibleOnFocus ? t.menuVisibleOnFocus = false : t.visible = !t.visible, t.visible && (s.value || r.value).focus());
  }, U = computed(() => C.value.filter((e2) => e2.visible).every((e2) => e2.disabled)), G = (e2) => {
    if (t.visible) {
      if (t.options.size !== 0 && t.filteredOptionsCount !== 0 && !U.value) {
        e2 === "next" ? (t.hoverIndex++, t.hoverIndex === t.options.size && (t.hoverIndex = 0)) : e2 === "prev" && (t.hoverIndex--, t.hoverIndex < 0 && (t.hoverIndex = t.options.size - 1));
        const l = C.value[t.hoverIndex];
        l.disabled !== true && l.groupDisabled !== true && l.visible || G(e2), nextTick(() => K(h2.value));
      }
    } else
      t.visible = true;
  };
  return { optionsArray: C, selectSize: M, handleResize: () => {
    var t2, l;
    z(), (l = (t2 = u.value) === null || t2 === void 0 ? void 0 : t2.update) === null || l === void 0 || l.call(t2), e.multiple && O();
  }, debouncedOnInputChange: L, debouncedQueryChange: F, deletePrevTag: (l) => {
    if (l.target.value.length <= 0 && !Y()) {
      const t2 = e.modelValue.slice();
      t2.pop(), a.emit(Gt, t2), R(t2);
    }
    l.target.value.length === 1 && e.modelValue.length === 0 && (t.currentPlaceholder = t.cachedPlaceHolder);
  }, deleteTag: (l, n) => {
    const o = t.selected.indexOf(n);
    if (o > -1 && !g.value) {
      const t2 = e.modelValue.slice();
      t2.splice(o, 1), a.emit(Gt, t2), R(t2), a.emit("remove-tag", n.value);
    }
    l.stopPropagation();
  }, deleteSelected: $, handleOptionSelect: H, scrollToOption: K, readonly: f, resetInputHeight: O, showClose: b, iconClass: y, showNewOption: _, collapseTagSize: T, setSelected: B, managePlaceholder: D, selectDisabled: g, emptyText: x, toggleLastOptionHitState: Y, resetInputState: (e2) => {
    e2.code !== Dt.backspace && Y(false), t.inputLength = 15 * s.value.length + 20, O();
  }, handleComposition: (e2) => {
    const l = e2.target.value;
    if (e2.type === "compositionend")
      t.isOnComposition = false, nextTick(() => N(l));
    else {
      const e3 = l[l.length - 1] || "";
      t.isOnComposition = !Zt(e3);
    }
  }, onOptionCreate: (e2) => {
    t.optionsCount++, t.filteredOptionsCount++, t.options.set(e2.value, e2), t.cachedOptions.set(e2.value, e2);
  }, onOptionDestroy: (e2) => {
    t.optionsCount--, t.filteredOptionsCount--, t.options.delete(e2);
  }, handleMenuEnter: () => {
    nextTick(() => K(t.selected));
  }, handleFocus: (l) => {
    t.softFocus ? t.softFocus = false : ((e.automaticDropdown || e.filterable) && (t.visible = true, e.filterable && (t.menuVisibleOnFocus = true)), a.emit("focus", l));
  }, blur: () => {
    t.visible = false, r.value.blur();
  }, handleBlur: (e2) => {
    nextTick(() => {
      t.isSilentBlur ? t.isSilentBlur = false : a.emit("blur", e2);
    }), t.softFocus = false;
  }, handleClearClick: (e2) => {
    $(e2);
  }, handleClose: () => {
    t.visible = false;
  }, toggleMenu: q, selectOption: () => {
    t.visible ? C.value[t.hoverIndex] && H(C.value[t.hoverIndex], void 0) : q();
  }, getValueKey: (t2) => Te(t2.value) ? Re(t2.value, e.valueKey) : t2.value, navigateOptions: G, dropMenuVisible: I, reference: r, input: s, popper: u, tags: d, selectWrapper: c, scrollbar: p };
};
var Qu = defineComponent({ name: "ElSelect", componentName: "ElSelect", components: { ElInput: gl, ElSelectMenu: Xu, ElOption: Gu, ElTag: ro, ElScrollbar: Cl, ElPopper: Kl }, directives: { ClickOutside: Ht }, props: { name: String, id: String, modelValue: [Array, String, Number, Boolean, Object], autocomplete: { type: String, default: "off" }, automaticDropdown: Boolean, size: { type: String, validator: Qt }, disabled: Boolean, clearable: Boolean, filterable: Boolean, allowCreate: Boolean, loading: Boolean, popperClass: { type: String, default: "" }, remote: Boolean, loadingText: String, noMatchText: String, noDataText: String, remoteMethod: Function, filterMethod: Function, multiple: Boolean, multipleLimit: { type: Number, default: 0 }, placeholder: { type: String }, defaultFirstOption: Boolean, reserveKeyword: Boolean, valueKey: { type: String, default: "value" }, collapseTags: Boolean, popperAppendToBody: { type: Boolean, default: true }, clearIcon: { type: String, default: "el-icon-circle-close" } }, emits: [Gt, "change", "remove-tag", "clear", "visible-change", "focus", "blur"], setup(e, t) {
  const l = function(e2) {
    const t2 = mitt_es_default();
    return reactive({ options: new Map(), cachedOptions: new Map(), createdLabel: null, createdSelected: false, selected: e2.multiple ? [] : {}, inputLength: 20, inputWidth: 0, initialInputHeight: 0, optionsCount: 0, filteredOptionsCount: 0, visible: false, softFocus: false, selectedLabel: "", hoverIndex: -1, query: "", previousQuery: null, inputHovering: false, cachedPlaceHolder: "", currentPlaceholder: Ca("el.select.placeholder"), menuVisibleOnFocus: false, isOnComposition: false, isSilentBlur: false, selectEmitter: t2, prefixWidth: null, tagInMultiLine: false });
  }(e), { optionsArray: o, selectSize: s, readonly: u, handleResize: d, collapseTagSize: c, debouncedOnInputChange: p, debouncedQueryChange: h2, deletePrevTag: v, deleteTag: m, deleteSelected: f, handleOptionSelect: g, scrollToOption: b, setSelected: y, resetInputHeight: k, managePlaceholder: x, showClose: C, selectDisabled: E, iconClass: M, showNewOption: T, emptyText: I, toggleLastOptionHitState: O, resetInputState: N, handleComposition: D, onOptionCreate: V, onOptionDestroy: B, handleMenuEnter: P, handleFocus: A, blur: z, handleBlur: L, handleClearClick: F, handleClose: R, toggleMenu: $, selectOption: H, getValueKey: W, navigateOptions: j, dropMenuVisible: K, reference: Y, input: q, popper: U, tags: G, selectWrapper: X, scrollbar: Z } = Zu(e, l, t), { focus: Q } = (J = Y, { focus: () => {
    var e2, t2;
    (t2 = (e2 = J.value) === null || e2 === void 0 ? void 0 : e2.focus) === null || t2 === void 0 || t2.call(e2);
  } });
  var J;
  const { inputWidth: ee, selected: te2, inputLength: le2, filteredOptionsCount: ne, visible: oe2, softFocus: ie2, selectedLabel: re2, hoverIndex: se2, query: ue2, inputHovering: de2, currentPlaceholder: ce2, menuVisibleOnFocus: pe2, isOnComposition: he2, isSilentBlur: ve2, options: me2, cachedOptions: fe2, optionsCount: ge, prefixWidth: be2, tagInMultiLine: ye2 } = toRefs(l);
  provide("ElSelect", reactive({ props: e, options: me2, optionsArray: o, cachedOptions: fe2, optionsCount: ge, filteredOptionsCount: ne, hoverIndex: se2, handleOptionSelect: g, selectEmitter: l.selectEmitter, onOptionCreate: V, onOptionDestroy: B, selectWrapper: X, selected: te2, setSelected: y })), onMounted(() => {
    if (l.cachedPlaceHolder = ce2.value = e.placeholder || Ca("el.select.placeholder"), e.multiple && Array.isArray(e.modelValue) && e.modelValue.length > 0 && (ce2.value = ""), vt(X.value, d), Y.value && Y.value.$el) {
      const e2 = { medium: 36, small: 32, mini: 28 }, t2 = Y.value.input;
      l.initialInputHeight = t2.getBoundingClientRect().height || e2[s.value];
    }
    e.remote && e.multiple && k(), nextTick(() => {
      if (Y.value.$el && (ee.value = Y.value.$el.getBoundingClientRect().width), t.slots.prefix) {
        const e2 = Y.value.$el.childNodes, t2 = [].filter.call(e2, (e3) => e3.tagName === "INPUT")[0], a = Y.value.$el.querySelector(".el-input__prefix");
        be2.value = Math.max(a.getBoundingClientRect().width + 5, 30), l.prefixWidth && (t2.style.paddingLeft = Math.max(l.prefixWidth, 30) + "px");
      }
    }), y();
  }), onBeforeUnmount(() => {
    mt(X.value, d);
  }), e.multiple && !Array.isArray(e.modelValue) && t.emit(Gt, []), !e.multiple && Array.isArray(e.modelValue) && t.emit(Gt, "");
  const ke2 = computed(() => {
    var e2;
    return (e2 = U.value) === null || e2 === void 0 ? void 0 : e2.popperRef;
  });
  return { tagInMultiLine: ye2, prefixWidth: be2, selectSize: s, readonly: u, handleResize: d, collapseTagSize: c, debouncedOnInputChange: p, debouncedQueryChange: h2, deletePrevTag: v, deleteTag: m, deleteSelected: f, handleOptionSelect: g, scrollToOption: b, inputWidth: ee, selected: te2, inputLength: le2, filteredOptionsCount: ne, visible: oe2, softFocus: ie2, selectedLabel: re2, hoverIndex: se2, query: ue2, inputHovering: de2, currentPlaceholder: ce2, menuVisibleOnFocus: pe2, isOnComposition: he2, isSilentBlur: ve2, options: me2, resetInputHeight: k, managePlaceholder: x, showClose: C, selectDisabled: E, iconClass: M, showNewOption: T, emptyText: I, toggleLastOptionHitState: O, resetInputState: N, handleComposition: D, handleMenuEnter: P, handleFocus: A, blur: z, handleBlur: L, handleClearClick: F, handleClose: R, toggleMenu: $, selectOption: H, getValueKey: W, navigateOptions: j, dropMenuVisible: K, focus: Q, reference: Y, input: q, popper: U, popperPaneRef: ke2, tags: G, selectWrapper: X, scrollbar: Z };
} });
var Ju = { class: "select-trigger" };
var ed = { key: 0 };
var td = { class: "el-select__tags-text" };
var ld = { style: { height: "100%", display: "flex", "justify-content": "center", "align-items": "center" } };
var ad = { key: 1, class: "el-select-dropdown__empty" };
Qu.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-tag"), r = resolveComponent("el-input"), f = resolveComponent("el-option"), y = resolveComponent("el-scrollbar"), k = resolveComponent("el-select-menu"), x = resolveComponent("el-popper"), C = resolveDirective("click-outside");
  return withDirectives((openBlock(), createBlock("div", { ref: "selectWrapper", class: ["el-select", [e.selectSize ? "el-select--" + e.selectSize : ""]], onClick: t[26] || (t[26] = withModifiers((...t2) => e.toggleMenu && e.toggleMenu(...t2), ["stop"])) }, [createVNode(x, { ref: "popper", visible: e.dropMenuVisible, "onUpdate:visible": t[25] || (t[25] = (t2) => e.dropMenuVisible = t2), placement: "bottom-start", "append-to-body": e.popperAppendToBody, "popper-class": "el-select__popper " + e.popperClass, "fallback-placements": ["bottom-start", "top-start", "right", "left"], "manual-mode": "", effect: "light", pure: "", trigger: "click", transition: "el-zoom-in-top", "stop-popper-mouse-event": false, "gpu-acceleration": false, onBeforeEnter: e.handleMenuEnter }, { trigger: withCtx(() => [createVNode("div", Ju, [e.multiple ? (openBlock(), createBlock("div", { key: 0, ref: "tags", class: "el-select__tags", style: { "max-width": e.inputWidth - 32 + "px", width: "100%" } }, [e.collapseTags && e.selected.length ? (openBlock(), createBlock("span", ed, [createVNode(i, { closable: !e.selectDisabled && !e.selected[0].isDisabled, size: e.collapseTagSize, hit: e.selected[0].hitState, type: "info", "disable-transitions": "", onClose: t[1] || (t[1] = (t2) => e.deleteTag(t2, e.selected[0])) }, { default: withCtx(() => [createVNode("span", { class: "el-select__tags-text", style: { "max-width": e.inputWidth - 123 + "px" } }, toDisplayString(e.selected[0].currentLabel), 5)]), _: 1 }, 8, ["closable", "size", "hit"]), e.selected.length > 1 ? (openBlock(), createBlock(i, { key: 0, closable: false, size: e.collapseTagSize, type: "info", "disable-transitions": "" }, { default: withCtx(() => [createVNode("span", td, "+ " + toDisplayString(e.selected.length - 1), 1)]), _: 1 }, 8, ["size"])) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true), createCommentVNode(" <div> "), e.collapseTags ? createCommentVNode("v-if", true) : (openBlock(), createBlock(Transition, { key: 1, onAfterLeave: e.resetInputHeight }, { default: withCtx(() => [createVNode("span", { style: { marginLeft: e.prefixWidth && e.selected.length ? e.prefixWidth + "px" : null } }, [(openBlock(true), createBlock(Fragment, null, renderList(e.selected, (t2) => (openBlock(), createBlock(i, { key: e.getValueKey(t2), closable: !e.selectDisabled && !t2.isDisabled, size: e.collapseTagSize, hit: t2.hitState, type: "info", "disable-transitions": "", onClose: (l2) => e.deleteTag(l2, t2) }, { default: withCtx(() => [createVNode("span", { class: "el-select__tags-text", style: { "max-width": e.inputWidth - 75 + "px" } }, toDisplayString(t2.currentLabel), 5)]), _: 2 }, 1032, ["closable", "size", "hit", "onClose"]))), 128))], 4)]), _: 1 }, 8, ["onAfterLeave"])), createCommentVNode(" </div> "), e.filterable ? withDirectives((openBlock(), createBlock("input", { key: 2, ref: "input", "onUpdate:modelValue": t[2] || (t[2] = (t2) => e.query = t2), type: "text", class: ["el-select__input", [e.selectSize ? "is-" + e.selectSize : ""]], disabled: e.selectDisabled, autocomplete: e.autocomplete, style: { marginLeft: e.prefixWidth && !e.selected.length || e.tagInMultiLine ? e.prefixWidth + "px" : null, flexGrow: "1", width: e.inputLength / (e.inputWidth - 32) + "%", maxWidth: e.inputWidth - 42 + "px" }, onFocus: t[3] || (t[3] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onBlur: t[4] || (t[4] = (...t2) => e.handleBlur && e.handleBlur(...t2)), onKeyup: t[5] || (t[5] = (...t2) => e.managePlaceholder && e.managePlaceholder(...t2)), onKeydown: [t[6] || (t[6] = (...t2) => e.resetInputState && e.resetInputState(...t2)), t[7] || (t[7] = withKeys(withModifiers((t2) => e.navigateOptions("next"), ["prevent"]), ["down"])), t[8] || (t[8] = withKeys(withModifiers((t2) => e.navigateOptions("prev"), ["prevent"]), ["up"])), t[9] || (t[9] = withKeys(withModifiers((t2) => e.visible = false, ["stop", "prevent"]), ["esc"])), t[10] || (t[10] = withKeys(withModifiers((...t2) => e.selectOption && e.selectOption(...t2), ["stop", "prevent"]), ["enter"])), t[11] || (t[11] = withKeys((...t2) => e.deletePrevTag && e.deletePrevTag(...t2), ["delete"])), t[12] || (t[12] = withKeys((t2) => e.visible = false, ["tab"]))], onCompositionstart: t[13] || (t[13] = (...t2) => e.handleComposition && e.handleComposition(...t2)), onCompositionupdate: t[14] || (t[14] = (...t2) => e.handleComposition && e.handleComposition(...t2)), onCompositionend: t[15] || (t[15] = (...t2) => e.handleComposition && e.handleComposition(...t2)), onInput: t[16] || (t[16] = (...t2) => e.debouncedQueryChange && e.debouncedQueryChange(...t2)) }, null, 46, ["disabled", "autocomplete"])), [[vModelText, e.query]]) : createCommentVNode("v-if", true)], 4)) : createCommentVNode("v-if", true), createVNode(r, { id: e.id, ref: "reference", modelValue: e.selectedLabel, "onUpdate:modelValue": t[18] || (t[18] = (t2) => e.selectedLabel = t2), type: "text", placeholder: e.currentPlaceholder, name: e.name, autocomplete: e.autocomplete, size: e.selectSize, disabled: e.selectDisabled, readonly: e.readonly, "validate-event": false, class: { "is-focus": e.visible }, tabindex: e.multiple && e.filterable ? "-1" : null, onFocus: e.handleFocus, onBlur: e.handleBlur, onInput: e.debouncedOnInputChange, onPaste: e.debouncedOnInputChange, onKeydown: [t[19] || (t[19] = withKeys(withModifiers((t2) => e.navigateOptions("next"), ["stop", "prevent"]), ["down"])), t[20] || (t[20] = withKeys(withModifiers((t2) => e.navigateOptions("prev"), ["stop", "prevent"]), ["up"])), withKeys(withModifiers(e.selectOption, ["stop", "prevent"]), ["enter"]), t[21] || (t[21] = withKeys(withModifiers((t2) => e.visible = false, ["stop", "prevent"]), ["esc"])), t[22] || (t[22] = withKeys((t2) => e.visible = false, ["tab"]))], onMouseenter: t[23] || (t[23] = (t2) => e.inputHovering = true), onMouseleave: t[24] || (t[24] = (t2) => e.inputHovering = false) }, createSlots({ suffix: withCtx(() => [withDirectives(createVNode("i", { class: ["el-select__caret", "el-input__icon", "el-icon-" + e.iconClass] }, null, 2), [[vShow, !e.showClose]]), e.showClose ? (openBlock(), createBlock("i", { key: 0, class: "el-select__caret el-input__icon " + e.clearIcon, onClick: t[17] || (t[17] = (...t2) => e.handleClearClick && e.handleClearClick(...t2)) }, null, 2)) : createCommentVNode("v-if", true)]), _: 2 }, [e.$slots.prefix ? { name: "prefix", fn: withCtx(() => [createVNode("div", ld, [renderSlot(e.$slots, "prefix")])]) } : void 0]), 1032, ["id", "modelValue", "placeholder", "name", "autocomplete", "size", "disabled", "readonly", "class", "tabindex", "onFocus", "onBlur", "onInput", "onPaste", "onKeydown"])])]), default: withCtx(() => [createVNode(k, null, { default: withCtx(() => [withDirectives(createVNode(y, { ref: "scrollbar", tag: "ul", "wrap-class": "el-select-dropdown__wrap", "view-class": "el-select-dropdown__list", class: { "is-empty": !e.allowCreate && e.query && e.filteredOptionsCount === 0 } }, { default: withCtx(() => [e.showNewOption ? (openBlock(), createBlock(f, { key: 0, value: e.query, created: true }, null, 8, ["value"])) : createCommentVNode("v-if", true), renderSlot(e.$slots, "default")]), _: 3 }, 8, ["class"]), [[vShow, e.options.size > 0 && !e.loading]]), e.emptyText && (!e.allowCreate || e.loading || e.allowCreate && e.options.size === 0) ? (openBlock(), createBlock(Fragment, { key: 0 }, [e.$slots.empty ? renderSlot(e.$slots, "empty", { key: 0 }) : (openBlock(), createBlock("p", ad, toDisplayString(e.emptyText), 1))], 2112)) : createCommentVNode("v-if", true)]), _: 3 })]), _: 1 }, 8, ["visible", "append-to-body", "popper-class", "onBeforeEnter"])], 2)), [[C, e.handleClose, e.popperPaneRef]]);
}, Qu.__file = "packages/select/src/select.vue", Qu.install = (e) => {
  e.component(Qu.name, Qu);
};
var nd = Qu;
var od = Gu;
od.install = (e) => {
  e.component(od.name, od);
};
var id = defineComponent({ name: "ElOptionGroup", componentName: "ElOptionGroup", props: { label: String, disabled: { type: Boolean, default: false } }, setup(e) {
  const t = ref(true);
  provide("ElSelectGroup", reactive(Object.assign({}, toRefs(e))));
  const n = inject("ElSelect");
  return n.selectEmitter.on(qu, () => {
    var e2;
    t.value = (e2 = n == null ? void 0 : n.optionsArray) === null || e2 === void 0 ? void 0 : e2.some((e3) => e3.visible === true);
  }), { visible: t };
} });
var rd = { class: "el-select-group__wrap" };
var sd = { class: "el-select-group__title" };
var ud = { class: "el-select-group" };
id.render = function(e, t, l, a, n, o) {
  return withDirectives((openBlock(), createBlock("ul", rd, [createVNode("li", sd, toDisplayString(e.label), 1), createVNode("li", null, [createVNode("ul", ud, [renderSlot(e.$slots, "default")])])], 512)), [[vShow, e.visible]]);
}, id.__file = "packages/select/src/option-group.vue", id.install = (e) => {
  e.component(id.name, id);
};
var dd = id;
var cd = defineComponent({ name: "ElPageHeader", props: { icon: { type: String, default: "el-icon-back" }, title: { type: String, default: () => Ca("el.pageHeader.title") }, content: { type: String, default: "" } }, emits: ["back"], setup: (e, { emit: t }) => ({ handleClick: function() {
  t("back");
} }) });
var pd = { class: "el-page-header" };
var hd = { key: 0, class: "el-page-header__icon" };
var vd = { class: "el-page-header__title" };
var md = { class: "el-page-header__content" };
cd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", pd, [createVNode("div", { class: "el-page-header__left", onClick: t[1] || (t[1] = (...t2) => e.handleClick && e.handleClick(...t2)) }, [e.icon || e.$slots.icon ? (openBlock(), createBlock("div", hd, [renderSlot(e.$slots, "icon", {}, () => [createVNode("i", { class: e.icon }, null, 2)])])) : createCommentVNode("v-if", true), createVNode("div", vd, [renderSlot(e.$slots, "title", {}, () => [createTextVNode(toDisplayString(e.title), 1)])])]), createVNode("div", md, [renderSlot(e.$slots, "content", {}, () => [createTextVNode(toDisplayString(e.content), 1)])])]);
}, cd.__file = "packages/page-header/src/index.vue", cd.install = (e) => {
  e.component(cd.name, cd);
};
var fd = cd;
var gd = defineComponent({ name: "Prev", props: { disabled: Boolean, currentPage: { type: Number, default: 1 }, prevText: { type: String, default: "" } }, setup: (e) => ({ internalDisabled: computed(() => e.disabled || e.currentPage <= 1) }) });
var bd = { key: 0 };
var yd = { key: 1, class: "el-icon el-icon-arrow-left" };
gd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("button", { type: "button", class: "btn-prev", disabled: e.internalDisabled, onClick: t[1] || (t[1] = withModifiers(() => {
  }, ["self", "prevent"])) }, [e.prevText ? (openBlock(), createBlock("span", bd, toDisplayString(e.prevText), 1)) : (openBlock(), createBlock("i", yd))], 8, ["disabled"]);
}, gd.__file = "packages/pagination/src/prev.vue";
var kd = defineComponent({ name: "Next", props: { disabled: Boolean, currentPage: { type: Number, default: 1 }, pageCount: { type: Number, default: 50 }, nextText: { type: String, default: "" } }, setup: (e) => ({ internalDisabled: computed(() => e.disabled || e.currentPage === e.pageCount || e.pageCount === 0) }) });
var xd = { key: 0 };
var Cd = { key: 1, class: "el-icon el-icon-arrow-right" };
kd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("button", { type: "button", class: "btn-next", disabled: e.internalDisabled, onClick: t[1] || (t[1] = withModifiers(() => {
  }, ["self", "prevent"])) }, [e.nextText ? (openBlock(), createBlock("span", xd, toDisplayString(e.nextText), 1)) : (openBlock(), createBlock("i", Cd))], 8, ["disabled"]);
}, kd.__file = "packages/pagination/src/next.vue";
var wd = () => {
  const e = inject("pagination", {});
  return { pagination: e, pageCount: e.pageCount, disabled: e.disabled, currentPage: e.currentPage };
};
var Sd = defineComponent({ name: "Sizes", components: { ElSelect: nd, ElOption: od }, props: { pageSize: Number, pageSizes: { type: Array, default: () => [10, 20, 30, 40, 50, 100] }, popperClass: { type: String, default: "" }, disabled: Boolean }, emits: ["page-size-change"], setup(e, { emit: t }) {
  const { pagination: a } = wd(), i = ref(e.pageSize);
  watch(() => e.pageSizes, (l, a2) => {
    if (!(0, import_isEqual.default)(l, a2) && Array.isArray(l)) {
      const a3 = l.indexOf(e.pageSize) > -1 ? e.pageSize : e.pageSizes[0];
      t("page-size-change", a3);
    }
  }), watch(() => e.pageSize, (e2) => {
    i.value = e2;
  });
  const r = computed(() => e.pageSizes);
  return { t: Ca, innerPagesizes: r, innerPageSize: i, handleChange: function(e2) {
    e2 !== i.value && (i.value = e2, a == null || a.handleSizesChange(Number(e2)));
  } };
} });
var _d = { class: "el-pagination__sizes" };
Sd.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-option"), r = resolveComponent("el-select");
  return openBlock(), createBlock("span", _d, [createVNode(r, { "model-value": e.innerPageSize, disabled: e.disabled, "popper-class": e.popperClass, size: "mini", onChange: e.handleChange }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.innerPagesizes, (t2) => (openBlock(), createBlock(i, { key: t2, value: t2, label: t2 + e.t("el.pagination.pagesize") }, null, 8, ["value", "label"]))), 128))]), _: 1 }, 8, ["model-value", "disabled", "popper-class", "onChange"])]);
}, Sd.__file = "packages/pagination/src/sizes.vue";
var Ed = defineComponent({ components: { ElInput: gl }, setup() {
  const { pagination: e, pageCount: t, disabled: a, currentPage: o } = wd(), i = ref(null), r = computed(() => {
    var e2;
    return (e2 = i.value) !== null && e2 !== void 0 ? e2 : o.value;
  });
  return { t: Ca, userInput: i, pageCount: t, disabled: a, handleInput: function(e2) {
    i.value = Number(e2);
  }, handleChange: function(t2) {
    e == null || e.changeEvent(Number(t2)), i.value = null;
  }, innerValue: r };
} });
var Md = { class: "el-pagination__jump" };
Ed.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input");
  return openBlock(), createBlock("span", Md, [createTextVNode(toDisplayString(e.t("el.pagination.goto")) + " ", 1), createVNode(i, { size: "mini", class: "el-pagination__editor is-in-pagination", min: 1, max: e.pageCount, disabled: e.disabled, "model-value": e.innerValue, type: "number", "onUpdate:modelValue": e.handleInput, onChange: e.handleChange }, null, 8, ["max", "disabled", "model-value", "onUpdate:modelValue", "onChange"]), createTextVNode(" " + toDisplayString(e.t("el.pagination.pageClassifier")), 1)]);
}, Ed.__file = "packages/pagination/src/jumper.vue";
var Td = defineComponent({ name: "Total", props: { total: { type: Number, default: 1e3 } }, setup: () => ({ t: Ca }) });
var Id = { class: "el-pagination__total" };
Td.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("span", Id, toDisplayString(e.t("el.pagination.total", { total: e.total })), 1);
}, Td.__file = "packages/pagination/src/total.vue";
var Od = defineComponent({ name: "ElPager", props: { currentPage: { type: Number, default: 1 }, pageCount: { type: Number }, pagerCount: { type: Number, default: 7 }, disabled: Boolean }, emits: ["change"], setup(e, { emit: t }) {
  const a = ref(false), o = ref(false), i = ref("el-icon-more"), r = ref("el-icon-more"), s = computed(() => {
    const t2 = e.pagerCount, l = (t2 - 1) / 2, a2 = Number(e.currentPage), n = Number(e.pageCount);
    let o2 = false, i2 = false;
    n > t2 && (a2 > t2 - l && (o2 = true), a2 < n - l && (i2 = true));
    const r2 = [];
    if (o2 && !i2) {
      for (let e2 = n - (t2 - 2); e2 < n; e2++)
        r2.push(e2);
    } else if (!o2 && i2)
      for (let e2 = 2; e2 < t2; e2++)
        r2.push(e2);
    else if (o2 && i2) {
      const e2 = Math.floor(t2 / 2) - 1;
      for (let t3 = a2 - e2; t3 <= a2 + e2; t3++)
        r2.push(t3);
    } else
      for (let e2 = 2; e2 < n; e2++)
        r2.push(e2);
    return r2;
  });
  return watchEffect(() => {
    const t2 = (e.pagerCount - 1) / 2;
    a.value = false, o.value = false, e.pageCount > e.pagerCount && (e.currentPage > e.pagerCount - t2 && (a.value = true), e.currentPage < e.pageCount - t2 && (o.value = true));
  }), watchEffect(() => {
    a.value || (r.value = "el-icon-more");
  }), watchEffect(() => {
    o.value || (i.value = "el-icon-more");
  }), { showPrevMore: a, showNextMore: o, quicknextIconClass: i, quickprevIconClass: r, pagers: s, onMouseenter: function(t2) {
    e.disabled || (t2 === "left" ? r.value = "el-icon-d-arrow-left" : i.value = "el-icon-d-arrow-right");
  }, onPagerClick: function(l) {
    const a2 = l.target;
    if (a2.tagName.toLowerCase() === "ul" || e.disabled)
      return;
    let n = Number(a2.textContent);
    const o2 = e.pageCount, i2 = e.currentPage, r2 = e.pagerCount - 2;
    a2.className.includes("more") && (a2.className.includes("quickprev") ? n = i2 - r2 : a2.className.includes("quicknext") && (n = i2 + r2)), isNaN(n) || (n < 1 && (n = 1), n > o2 && (n = o2)), n !== i2 && t("change", n);
  } };
} });
Od.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("ul", { class: "el-pager", onClick: t[5] || (t[5] = (...t2) => e.onPagerClick && e.onPagerClick(...t2)) }, [e.pageCount > 0 ? (openBlock(), createBlock("li", { key: 0, class: [{ active: e.currentPage === 1, disabled: e.disabled }, "number"] }, " 1 ", 2)) : createCommentVNode("v-if", true), e.showPrevMore ? (openBlock(), createBlock("li", { key: 1, class: ["el-icon more btn-quickprev", [e.quickprevIconClass, { disabled: e.disabled }]], onMouseenter: t[1] || (t[1] = (t2) => e.onMouseenter("left")), onMouseleave: t[2] || (t[2] = (t2) => e.quickprevIconClass = "el-icon-more") }, null, 34)) : createCommentVNode("v-if", true), (openBlock(true), createBlock(Fragment, null, renderList(e.pagers, (t2) => (openBlock(), createBlock("li", { key: t2, class: [{ active: e.currentPage === t2, disabled: e.disabled }, "number"] }, toDisplayString(t2), 3))), 128)), e.showNextMore ? (openBlock(), createBlock("li", { key: 2, class: ["el-icon more btn-quicknext", [e.quicknextIconClass, { disabled: e.disabled }]], onMouseenter: t[3] || (t[3] = (t2) => e.onMouseenter("right")), onMouseleave: t[4] || (t[4] = (t2) => e.quicknextIconClass = "el-icon-more") }, null, 34)) : createCommentVNode("v-if", true), e.pageCount > 1 ? (openBlock(), createBlock("li", { key: 3, class: [{ active: e.currentPage === e.pageCount, disabled: e.disabled }, "number"] }, toDisplayString(e.pageCount), 3)) : createCommentVNode("v-if", true)]);
}, Od.__file = "packages/pagination/src/pager.vue";
var Nd = (e) => Number.isNaN(e) ? 10 : e;
var Dd = defineComponent({ name: "ElPagination", components: { Prev: gd, Next: kd, Sizes: Sd, Jumper: Ed, Total: Td, Pager: Od }, props: { pageSize: { type: Number, default: 10 }, small: Boolean, total: { type: Number }, pageCount: { type: Number }, pagerCount: { type: Number, validator: (e) => (0 | e) === e && e > 4 && e < 22 && e % 2 == 1, default: 7 }, currentPage: { type: Number, default: 1 }, layout: { type: String, default: "prev, pager, next, jumper, ->, total" }, pageSizes: { type: Array, default: () => [10, 20, 30, 40, 50, 100] }, popperClass: { type: String, default: "" }, prevText: { type: String, default: "" }, nextText: { type: String, default: "" }, background: Boolean, disabled: Boolean, hideOnSinglePage: Boolean }, emits: ["size-change", "current-change", "prev-click", "next-click", "update:currentPage", "update:pageSize"], setup(e, { emit: t }) {
  const a = ref(-1), i = ref(false), r = ref(Nd(e.pageSize)), s = computed(() => typeof e.total == "number" ? Math.max(1, Math.ceil(e.total / r.value)) : typeof e.pageCount == "number" ? Math.max(1, e.pageCount) : null), u = ref(p(e.currentPage));
  function d() {
    (u.value !== a.value || i.value) && (a.value = u.value, i.value = false, t("update:currentPage", u.value), t("current-change", u.value));
  }
  function c(e2) {
    u.value = p(e2), i.value = true, d();
  }
  function p(e2) {
    let t2;
    return typeof e2 == "string" && (e2 = parseInt(e2, 10)), isNaN(e2) || e2 < 1 ? t2 = 1 : s.value < e2 && (t2 = s.value), t2 != null ? t2 : e2;
  }
  return watch(() => e.currentPage, (e2) => {
    u.value = p(e2), a.value = u.value;
  }), watch(() => e.pageSize, (e2) => {
    r.value = Nd(e2);
  }), watch(() => s.value, (e2) => {
    const t2 = u.value;
    e2 > 0 && t2 === 0 ? u.value = 1 : t2 > e2 && (u.value = e2 === 0 ? 1 : e2, d());
  }), provide("pagination", { pageCount: computed(() => e.pageCount), disabled: computed(() => e.disabled), currentPage: computed(() => u.value), changeEvent: c, handleSizesChange: function(e2) {
    i.value = true, r.value = e2, t("update:pageSize", e2), t("size-change", e2);
  } }), { internalCurrentPage: u, internalPageSize: r, lastEmittedPage: a, userChangePageSize: i, internalPageCount: s, getValidCurrentPage: p, emitChange: d, handleCurrentChange: c, prev: function() {
    if (e.disabled)
      return;
    const l = u.value - 1;
    u.value = p(l), t("prev-click", u.value), d();
  }, next: function() {
    if (e.disabled)
      return;
    const l = u.value + 1;
    u.value = p(l), t("next-click", u.value), d();
  } };
}, render() {
  var e, t, l;
  const a = this.layout;
  if (!a)
    return null;
  if (this.hideOnSinglePage && this.internalPageCount <= 1)
    return null;
  const n = h("div", { class: ["el-pagination", { "is-background": this.background, "el-pagination--small": this.small }] }), o = [], i = [], r = h("div", { class: "el-pagination__rightwrapper" }, i), s = { prev: h(gd, { disabled: this.disabled, currentPage: this.internalCurrentPage, prevText: this.prevText, onClick: this.prev }), jumper: h(Ed), pager: h(Od, { currentPage: this.internalCurrentPage, pageCount: this.internalPageCount, pagerCount: this.pagerCount, onChange: this.handleCurrentChange, disabled: this.disabled }), next: h(kd, { disabled: this.disabled, currentPage: this.internalCurrentPage, pageCount: this.internalPageCount, nextText: this.nextText, onClick: this.next }), sizes: h(Sd, { pageSize: this.pageSize, pageSizes: this.pageSizes, popperClass: this.popperClass, disabled: this.disabled }), slot: (l = (t = (e = this.$slots) === null || e === void 0 ? void 0 : e.default) === null || t === void 0 ? void 0 : t.call(e)) !== null && l !== void 0 ? l : null, total: h(Td, { total: this.total }) }, u = a.split(",").map((e2) => e2.trim());
  let d = false;
  return u.forEach((e2) => {
    e2 !== "->" ? d ? i.push(s[e2]) : o.push(s[e2]) : d = true;
  }), d && i.length > 0 && o.unshift(r), h(n, {}, o);
} });
Dd.install = (e) => {
  e.component(Dd.name, Dd);
};
var Vd = defineComponent({ name: "ElPopconfirm", components: { ElButton: ma, ElPopper: Kl }, props: { title: { type: String }, confirmButtonText: { type: String }, cancelButtonText: { type: String }, confirmButtonType: { type: String, default: "primary" }, cancelButtonType: { type: String, default: "text" }, icon: { type: String, default: "el-icon-question" }, iconColor: { type: String, default: "#f90" }, hideIcon: { type: Boolean, default: false } }, emits: ["confirm", "cancel"], setup(e, { emit: t }) {
  const a = ref(false), o = computed(() => e.confirmButtonText || Ca("el.popconfirm.confirmButtonText")), i = computed(() => e.cancelButtonText || Ca("el.popconfirm.cancelButtonText"));
  return { visible: a, confirm: () => {
    a.value = false, t("confirm");
  }, cancel: () => {
    a.value = false, t("cancel");
  }, confirmButtonText_: o, cancelButtonText_: i };
} });
var Bd = { class: "el-popconfirm" };
var Pd = { class: "el-popconfirm__main" };
var Ad = { class: "el-popconfirm__action" };
Vd.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-button"), r = resolveComponent("el-popper");
  return openBlock(), createBlock(r, { visible: e.visible, "onUpdate:visible": t[1] || (t[1] = (t2) => e.visible = t2), trigger: "click", effect: "light", "popper-class": "el-popover", "append-to-body": "", "fallback-placements": ["bottom", "top", "right", "left"] }, { trigger: withCtx(() => [renderSlot(e.$slots, "reference")]), default: withCtx(() => [createVNode("div", Bd, [createVNode("p", Pd, [e.hideIcon ? createCommentVNode("v-if", true) : (openBlock(), createBlock("i", { key: 0, class: [e.icon, "el-popconfirm__icon"], style: { color: e.iconColor } }, null, 6)), createTextVNode(" " + toDisplayString(e.title), 1)]), createVNode("div", Ad, [createVNode(i, { size: "mini", type: e.cancelButtonType, onClick: e.cancel }, { default: withCtx(() => [createTextVNode(toDisplayString(e.cancelButtonText_), 1)]), _: 1 }, 8, ["type", "onClick"]), createVNode(i, { size: "mini", type: e.confirmButtonType, onClick: e.confirm }, { default: withCtx(() => [createTextVNode(toDisplayString(e.confirmButtonText_), 1)]), _: 1 }, 8, ["type", "onClick"])])])]), _: 1 }, 8, ["visible"]);
}, Vd.__file = "packages/popconfirm/src/index.vue", Vd.install = (e) => {
  e.component(Vd.name, Vd);
};
var zd = Vd;
var Ld = ["update:visible", "after-enter", "after-leave", "show", "hide"];
var Fd = { key: 0, class: "el-popover__title", role: "title" };
var Rd = defineComponent({ name: "ElPopover", components: { ElPopper: Kl }, props: Object.assign(Object.assign({}, Vl), { content: { type: String }, trigger: { type: String, default: "click" }, title: { type: String }, transition: { type: String, default: "fade-in-linear" }, width: { type: [String, Number], default: 150 }, appendToBody: { type: Boolean, default: true }, tabindex: [String, Number] }), emits: Ld, setup(e, t) {
  e.visible && !t.slots.reference && Fe("ElPopover", "\n        You cannot init popover without given reference\n      ");
  return function(e2, t2) {
    const a = ref(Ol.nextZIndex()), i = computed(() => Me(e2.width) ? e2.width : e2.width + "px"), r = computed(() => ({ width: i.value, zIndex: a.value })), s = Bl(e2, t2);
    return watch(s.visibility, (e3) => {
      e3 && (a.value = Ol.nextZIndex()), t2.emit(e3 ? "show" : "hide");
    }), Object.assign(Object.assign({}, s), { popperStyle: r });
  }(e, t);
}, render() {
  const { $slots: e } = this, t = e.reference ? e.reference() : null, l = $l(this.title, "div", Fd, toDisplayString(this.title), Al.TEXT), a = renderSlot(e, "default", {}, () => [createTextVNode(toDisplayString(this.content), Al.TEXT)]), { events: n, onAfterEnter: o, onAfterLeave: i, onPopperMouseEnter: r, onPopperMouseLeave: s, popperStyle: u, popperId: d, popperClass: p, showArrow: h2, transition: b, visibility: y, tabindex: k } = this, x = [this.content ? "el-popover--plain" : "", "el-popover", p].join(" ");
  let C = Pl({ effect: Dl.LIGHT, name: b, popperClass: x, popperStyle: u, popperId: d, visibility: y, onMouseenter: r, onMouseleave: s, onAfterEnter: o, onAfterLeave: i, stopPopperMouseEvent: false }, [l, a, Wl(h2)]);
  const w = t ? Hl(t, Object.assign({ ariaDescribedby: d, ref: "triggerRef", tabindex: k }, n)) : createCommentVNode("v-if", true);
  return h(Fragment, null, [this.trigger === "click" ? withDirectives(w, [[Ht, this.hide]]) : w, h(Teleport, { disabled: !this.appendToBody, to: "body" }, [C])]);
} });
Rd.__file = "packages/popover/src/index.vue";
var $d = (e, t, l) => {
  const a = t.arg || t.value, n = l.dirs[0].instance.$refs[a];
  n && (n.triggerRef = e, e.setAttribute("tabindex", n.tabindex), Object.entries(n.events).forEach(([t2, l2]) => {
    at(e, t2.toLowerCase().slice(2), l2);
  }));
};
var Hd = { mounted(e, t, l) {
  $d(e, t, l);
}, updated(e, t, l) {
  $d(e, t, l);
} };
Rd.install = (e) => {
  e.component(Rd.name, Rd), e.directive("popover", Hd);
}, Rd.directive = Hd;
var Wd = Rd;
var jd = defineComponent({ name: "ElProgress", props: { type: { type: String, default: "line", validator: (e) => ["line", "circle", "dashboard"].indexOf(e) > -1 }, percentage: { type: Number, default: 0, required: true, validator: (e) => e >= 0 && e <= 100 }, status: { type: String, default: "", validator: (e) => ["", "success", "exception", "warning"].indexOf(e) > -1 }, indeterminate: { type: Boolean, default: false }, duration: { type: Number, default: 3 }, strokeWidth: { type: Number, default: 6 }, strokeLinecap: { type: String, default: "round" }, textInside: { type: Boolean, default: false }, width: { type: Number, default: 126 }, showText: { type: Boolean, default: true }, color: { type: [String, Array, Function], default: "" }, format: { type: Function, default: (e) => e + "%" } }, setup(e) {
  const t = computed(() => ({ width: e.percentage + "%", animationDuration: e.duration + "s", backgroundColor: m(e.percentage) })), l = computed(() => (e.strokeWidth / e.width * 100).toFixed(1)), a = computed(() => e.type === "circle" || e.type === "dashboard" ? parseInt("" + (50 - parseFloat(l.value) / 2), 10) : 0), o = computed(() => {
    const t2 = a.value, l2 = e.type === "dashboard";
    return `
          M 50 50
          m 0 ${l2 ? "" : "-"}${t2}
          a ${t2} ${t2} 0 1 1 0 ${l2 ? "-" : ""}${2 * t2}
          a ${t2} ${t2} 0 1 1 0 ${l2 ? "" : "-"}${2 * t2}
          `;
  }), i = computed(() => 2 * Math.PI * a.value), r = computed(() => e.type === "dashboard" ? 0.75 : 1), s = computed(() => -1 * i.value * (1 - r.value) / 2 + "px"), u = computed(() => ({ strokeDasharray: `${i.value * r.value}px, ${i.value}px`, strokeDashoffset: s.value })), d = computed(() => ({ strokeDasharray: `${i.value * r.value * (e.percentage / 100)}px, ${i.value}px`, strokeDashoffset: s.value, transition: "stroke-dasharray 0.6s ease 0s, stroke 0.6s ease" })), c = computed(() => {
    let t2;
    if (e.color)
      t2 = m(e.percentage);
    else
      switch (e.status) {
        case "success":
          t2 = "#13ce66";
          break;
        case "exception":
          t2 = "#ff4949";
          break;
        case "warning":
          t2 = "#e6a23c";
          break;
        default:
          t2 = "#20a0ff";
      }
    return t2;
  }), p = computed(() => e.status === "warning" ? "el-icon-warning" : e.type === "line" ? e.status === "success" ? "el-icon-circle-check" : "el-icon-circle-close" : e.status === "success" ? "el-icon-check" : "el-icon-close"), h2 = computed(() => e.type === "line" ? 12 + 0.4 * e.strokeWidth : 0.111111 * e.width + 2), v = computed(() => e.format(e.percentage)), m = (t2) => {
    var l2;
    const { color: a2 } = e;
    if (typeof a2 == "function")
      return a2(t2);
    if (typeof a2 == "string")
      return a2;
    {
      const e2 = 100 / a2.length, n = a2.map((t3, l3) => typeof t3 == "string" ? { color: t3, percentage: (l3 + 1) * e2 } : t3).sort((e3, t3) => e3.percentage - t3.percentage);
      for (let e3 = 0; e3 < n.length; e3++)
        if (n[e3].percentage > t2)
          return n[e3].color;
      return (l2 = n[n.length - 1]) === null || l2 === void 0 ? void 0 : l2.color;
    }
  }, f = computed(() => ({ percentage: e.percentage }));
  return { barStyle: t, relativeStrokeWidth: l, radius: a, trackPath: o, perimeter: i, rate: r, strokeDashoffset: s, trailPathStyle: u, circlePathStyle: d, stroke: c, iconClass: p, progressTextSize: h2, content: v, getCurrentColor: m, slotData: f };
} });
var Kd = { key: 0, class: "el-progress-bar" };
var Yd = { key: 0, class: "el-progress-bar__innerText" };
var qd = { viewBox: "0 0 100 100" };
var Ud = { key: 0 };
jd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-progress", ["el-progress--" + e.type, e.status ? "is-" + e.status : "", { "el-progress--without-text": !e.showText, "el-progress--text-inside": e.textInside }]], role: "progressbar", "aria-valuenow": e.percentage, "aria-valuemin": "0", "aria-valuemax": "100" }, [e.type === "line" ? (openBlock(), createBlock("div", Kd, [createVNode("div", { class: "el-progress-bar__outer", style: { height: e.strokeWidth + "px" } }, [createVNode("div", { class: ["el-progress-bar__inner", { "el-progress-bar__inner--indeterminate": e.indeterminate }], style: e.barStyle }, [(e.showText || e.$slots.default) && e.textInside ? (openBlock(), createBlock("div", Yd, [renderSlot(e.$slots, "default", e.slotData, () => [createVNode("span", null, toDisplayString(e.content), 1)])])) : createCommentVNode("v-if", true)], 6)], 4)])) : (openBlock(), createBlock("div", { key: 1, class: "el-progress-circle", style: { height: e.width + "px", width: e.width + "px" } }, [(openBlock(), createBlock("svg", qd, [createVNode("path", { class: "el-progress-circle__track", d: e.trackPath, stroke: "#e5e9f2", "stroke-width": e.relativeStrokeWidth, fill: "none", style: e.trailPathStyle }, null, 12, ["d", "stroke-width"]), createVNode("path", { class: "el-progress-circle__path", d: e.trackPath, stroke: e.stroke, fill: "none", "stroke-linecap": e.strokeLinecap, "stroke-width": e.percentage ? e.relativeStrokeWidth : 0, style: e.circlePathStyle }, null, 12, ["d", "stroke", "stroke-linecap", "stroke-width"])]))], 4)), !e.showText && !e.$slots.default || e.textInside ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", { key: 2, class: "el-progress__text", style: { fontSize: e.progressTextSize + "px" } }, [renderSlot(e.$slots, "default", e.slotData, () => [e.status ? (openBlock(), createBlock("i", { key: 1, class: e.iconClass }, null, 2)) : (openBlock(), createBlock("span", Ud, toDisplayString(e.content), 1))])], 4))], 10, ["aria-valuenow"]);
}, jd.__file = "packages/progress/src/index.vue", jd.install = (e) => {
  e.component(jd.name, jd);
};
var Gd = jd;
var Xd = defineComponent({ name: "ElRadioButton", props: { label: { type: [String, Number, Boolean], default: "" }, disabled: Boolean, name: { type: String, default: "" } }, setup(e) {
  const { isGroup: t, radioGroup: l, elFormItemSize: a, ELEMENT: o, focus: i, elForm: r } = Vn(), s = computed(() => l.radioGroupSize || a.value || o.size), u = computed({ get: () => l.modelValue, set(e2) {
    l.changeEvent(e2);
  } }), { isDisabled: d, tabIndex: c } = Bn(e, { model: u, elForm: r, radioGroup: l, isGroup: t });
  return { isGroup: t, size: s, isDisabled: d, tabIndex: c, value: u, focus: i, activeStyle: computed(() => ({ backgroundColor: l.fill || "", borderColor: l.fill || "", boxShadow: l.fill ? "-1px 0 0 0 " + l.fill : "", color: l.textColor || "" })) };
} });
Xd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("label", { class: ["el-radio-button", [e.size ? "el-radio-button--" + e.size : "", { "is-active": e.value === e.label, "is-disabled": e.isDisabled, "is-focus": e.focus }]], role: "radio", "aria-checked": e.value === e.label, "aria-disabled": e.isDisabled, tabindex: e.tabIndex, onKeydown: t[5] || (t[5] = withKeys(withModifiers((t2) => e.value = e.isDisabled ? e.value : e.label, ["stop", "prevent"]), ["space"])) }, [withDirectives(createVNode("input", { "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.value = t2), class: "el-radio-button__orig-radio", value: e.label, type: "radio", name: e.name, disabled: e.isDisabled, tabindex: "-1", onFocus: t[2] || (t[2] = (t2) => e.focus = true), onBlur: t[3] || (t[3] = (t2) => e.focus = false) }, null, 40, ["value", "name", "disabled"]), [[vModelRadio, e.value]]), createVNode("span", { class: "el-radio-button__inner", style: e.value === e.label ? e.activeStyle : null, onKeydown: t[4] || (t[4] = withModifiers(() => {
  }, ["stop"])) }, [renderSlot(e.$slots, "default", {}, () => [createTextVNode(toDisplayString(e.label), 1)])], 36)], 42, ["aria-checked", "aria-disabled", "tabindex"]);
}, Xd.__file = "packages/radio/src/radio-button.vue", Xd.install = (e) => {
  e.component(Xd.name, Xd);
};
var Zd = Xd;
var Qd = defineComponent({ name: "ElRadioGroup", componentName: "ElRadioGroup", props: { modelValue: { type: [String, Number, Boolean], default: "" }, size: { type: String, validator: Qt }, fill: { type: String, default: "" }, textColor: { type: String, default: "" }, disabled: Boolean }, emits: [Gt, "change"], setup(e, t) {
  const r = ref(null), s = inject("elFormItem", {}), u = computed(() => e.size || s.size);
  provide("RadioGroup", reactive(Object.assign(Object.assign({ name: "ElRadioGroup" }, toRefs(e)), { radioGroupSize: u, changeEvent: (e2) => {
    t.emit(Gt, e2), nextTick(() => {
      t.emit("change", e2);
    });
  } }))), watch(() => e.modelValue, (e2) => {
    var t2;
    (t2 = s.formItemMitt) === null || t2 === void 0 || t2.emit("el.form.change", [e2]);
  });
  return onMounted(() => {
    const e2 = r.value.querySelectorAll("[type=radio]"), t2 = e2[0];
    !Array.from(e2).some((e3) => e3.checked) && t2 && (t2.tabIndex = 0);
  }), { handleKeydown: (e2) => {
    const t2 = e2.target, l = t2.nodeName === "INPUT" ? "[type=radio]" : "[role=radio]", a = r.value.querySelectorAll(l), n = a.length, o = Array.from(a).indexOf(t2), i = r.value.querySelectorAll("[role=radio]");
    let s2 = null;
    switch (e2.code) {
      case Dt.left:
      case Dt.up:
        e2.stopPropagation(), e2.preventDefault(), s2 = o === 0 ? n - 1 : o - 1;
        break;
      case Dt.right:
      case Dt.down:
        e2.stopPropagation(), e2.preventDefault(), s2 = o === n - 1 ? 0 : o + 1;
    }
    s2 !== null && (i[s2].click(), i[s2].focus());
  }, radioGroupSize: u, radioGroup: r };
} });
Qd.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { ref: "radioGroup", class: "el-radio-group", role: "radiogroup", onKeydown: t[1] || (t[1] = (...t2) => e.handleKeydown && e.handleKeydown(...t2)) }, [renderSlot(e.$slots, "default")], 544);
}, Qd.__file = "packages/radio/src/radio-group.vue", Qd.install = (e) => {
  e.component(Qd.name, Qd);
};
var Jd = Qd;
var ec = defineComponent({ name: "ElRate", props: { modelValue: { type: Number, default: 0 }, lowThreshold: { type: Number, default: 2 }, highThreshold: { type: Number, default: 4 }, max: { type: Number, default: 5 }, colors: { type: [Array, Object], default: () => ["#F7BA2A", "#F7BA2A", "#F7BA2A"] }, voidColor: { type: String, default: "#C6D1DE" }, disabledVoidColor: { type: String, default: "#EFF2F7" }, iconClasses: { type: [Array, Object], default: () => ["el-icon-star-on", "el-icon-star-on", "el-icon-star-on"] }, voidIconClass: { type: String, default: "el-icon-star-off" }, disabledVoidIconClass: { type: String, default: "el-icon-star-on" }, disabled: { type: Boolean, default: false }, allowHalf: { type: Boolean, default: false }, showText: { type: Boolean, default: false }, showScore: { type: Boolean, default: false }, textColor: { type: String, default: "#1f2d3d" }, texts: { type: Array, default: () => ["Extremely bad", "Disappointed", "Fair", "Satisfied", "Surprise"] }, scoreTemplate: { type: String, default: "{value}" } }, emits: ["update:modelValue", "change"], setup(e, { emit: t }) {
  const a = inject("elForm", {}), i = ref(e.modelValue), r = computed(() => e.disabled || a.disabled), s = computed(() => {
    let t2 = "";
    return e.showScore ? t2 = e.scoreTemplate.replace(/\{\s*value\s*\}/, r.value ? "" + e.modelValue : "" + i.value) : e.showText && (t2 = e.texts[Math.ceil(i.value) - 1]), t2;
  });
  function u(e2, t2) {
    const l = Object.keys(t2).filter((l2) => {
      const a3 = t2[l2];
      return !!Te(a3) && a3.excluded ? e2 < l2 : e2 <= l2;
    }).sort((e3, t3) => e3 - t3), a2 = t2[l[0]];
    return Te(a2) ? a2.value : a2 || "";
  }
  const d = computed(() => 100 * e.modelValue - 100 * Math.floor(e.modelValue)), c = computed(() => _e(e.colors) ? { [e.lowThreshold]: e.colors[0], [e.highThreshold]: { value: e.colors[1], excluded: true }, [e.max]: e.colors[2] } : e.colors), p = computed(() => u(i.value, c.value)), h2 = computed(() => {
    let t2 = "";
    return r.value ? t2 = d.value + "%" : e.allowHalf && (t2 = "50%"), { color: p.value, width: t2 };
  }), v = computed(() => _e(e.iconClasses) ? { [e.lowThreshold]: e.iconClasses[0], [e.highThreshold]: { value: e.iconClasses[1], excluded: true }, [e.max]: e.iconClasses[2] } : e.iconClasses), m = computed(() => u(e.modelValue, v.value)), f = computed(() => r.value ? e.disabledVoidIconClass : e.voidIconClass), g = computed(() => u(i.value, v.value)), b = computed(() => {
    let t2 = Array(e.max), l = i.value;
    return t2.fill(g.value, 0, l), t2.fill(f.value, l, e.max), t2;
  }), y = ref(true);
  watch(() => e.modelValue, (t2) => {
    i.value = t2, y.value = e.modelValue !== Math.floor(e.modelValue);
  });
  const k = ref(-1);
  return e.modelValue || t("update:modelValue", 0), { hoverIndex: k, currentValue: i, rateDisabled: r, text: s, decimalStyle: h2, decimalIconClass: m, classes: b, showDecimalIcon: function(t2) {
    let l = r.value && d.value > 0 && t2 - 1 < e.modelValue && t2 > e.modelValue, a2 = e.allowHalf && y.value && t2 - 0.5 <= i.value && t2 > i.value;
    return l || a2;
  }, getIconStyle: function(t2) {
    const l = r.value ? e.disabledVoidColor : e.voidColor;
    return { color: t2 <= i.value ? p.value : l };
  }, selectValue: function(l) {
    r.value || (e.allowHalf && y.value ? (t("update:modelValue", i.value), e.modelValue !== i.value && t("change", i.value)) : (t("update:modelValue", l), e.modelValue !== l && t("change", l)));
  }, handleKey: function(l) {
    if (r.value)
      return;
    let a2 = i.value;
    const n = l.code;
    return n === Dt.up || n === Dt.right ? (e.allowHalf ? a2 += 0.5 : a2 += 1, l.stopPropagation(), l.preventDefault()) : n !== Dt.left && n !== Dt.down || (e.allowHalf ? a2 -= 0.5 : a2 -= 1, l.stopPropagation(), l.preventDefault()), a2 = a2 < 0 ? 0 : a2, a2 = a2 > e.max ? e.max : a2, t("update:modelValue", a2), t("change", a2), a2;
  }, setCurrentValue: function(t2, l) {
    if (!r.value) {
      if (e.allowHalf) {
        let e2 = l.target;
        ot(e2, "el-rate__item") && (e2 = e2.querySelector(".el-rate__icon")), ot(e2, "el-rate__decimal") && (e2 = e2.parentNode), y.value = 2 * l.offsetX <= e2.clientWidth, i.value = y.value ? t2 - 0.5 : t2;
      } else
        i.value = t2;
      k.value = t2;
    }
  }, resetCurrentValue: function() {
    r.value || (e.allowHalf && (y.value = e.modelValue !== Math.floor(e.modelValue)), i.value = e.modelValue, k.value = -1);
  } };
} });
ec.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: "el-rate", role: "slider", "aria-valuenow": e.currentValue, "aria-valuetext": e.text, "aria-valuemin": "0", "aria-valuemax": e.max, tabindex: "0", onKeydown: t[2] || (t[2] = (...t2) => e.handleKey && e.handleKey(...t2)) }, [(openBlock(true), createBlock(Fragment, null, renderList(e.max, (l2, a2) => (openBlock(), createBlock("span", { key: a2, class: "el-rate__item", style: { cursor: e.rateDisabled ? "auto" : "pointer" }, onMousemove: (t2) => e.setCurrentValue(l2, t2), onMouseleave: t[1] || (t[1] = (...t2) => e.resetCurrentValue && e.resetCurrentValue(...t2)), onClick: (t2) => e.selectValue(l2) }, [createVNode("i", { class: [[e.classes[l2 - 1], { hover: e.hoverIndex === l2 }], "el-rate__icon"], style: e.getIconStyle(l2) }, [e.showDecimalIcon(l2) ? (openBlock(), createBlock("i", { key: 0, class: [e.decimalIconClass, "el-rate__decimal"], style: e.decimalStyle }, null, 6)) : createCommentVNode("v-if", true)], 6)], 44, ["onMousemove", "onClick"]))), 128)), e.showText || e.showScore ? (openBlock(), createBlock("span", { key: 0, class: "el-rate__text", style: { color: e.textColor } }, toDisplayString(e.text), 5)) : createCommentVNode("v-if", true)], 40, ["aria-valuenow", "aria-valuetext", "aria-valuemax"]);
}, ec.__file = "packages/rate/src/index.vue", ec.install = (e) => {
  e.component(ec.name, ec);
};
var tc = ec;
var lc = defineComponent({ name: "ElRow", props: { tag: { type: String, default: "div" }, gutter: { type: Number, default: 0 }, type: { type: String, default: "" }, justify: { type: String, default: "start" }, align: { type: String, default: "top" } }, setup(e, { slots: t }) {
  const l = computed(() => e.gutter);
  provide("ElRow", { gutter: l });
  const a = computed(() => {
    const t2 = { marginLeft: "", marginRight: "" };
    return e.gutter && (t2.marginLeft = `-${e.gutter / 2}px`, t2.marginRight = t2.marginLeft), t2;
  });
  return () => {
    var l2;
    return h(e.tag, { class: ["el-row", e.justify !== "start" ? "is-justify-" + e.justify : "", e.align !== "top" ? "is-align-" + e.align : "", e.type === "flex" ? "el-row--flex" : ""], style: a.value }, (l2 = t.default) === null || l2 === void 0 ? void 0 : l2.call(t));
  };
} });
lc.install = (e) => {
  e.component(lc.name, lc);
};
var ac = (e, t, a) => {
  const { disabled: i, min: r, max: s, step: u, showTooltip: d, precision: c, sliderSize: p, formatTooltip: h2, emitChange: v, resetSize: m, updateDragging: f } = inject("SliderProvider"), { tooltip: g, tooltipVisible: b, formatValue: y, displayTooltip: k, hideTooltip: x } = ((e2, t2, a2) => {
    const o = ref(null), i2 = ref(false), r2 = computed(() => t2.value instanceof Function), s2 = computed(() => r2.value && t2.value(e2.modelValue) || e2.modelValue), u2 = (0, import_debounce2.default)(() => {
      a2.value && (i2.value = true);
    }, 50), d2 = (0, import_debounce2.default)(() => {
      a2.value && (i2.value = false);
    }, 50);
    return { tooltip: o, tooltipVisible: i2, formatValue: s2, displayTooltip: u2, hideTooltip: d2 };
  })(e, h2, d), C = computed(() => (e.modelValue - r.value) / (s.value - r.value) * 100 + "%"), S = computed(() => e.vertical ? { bottom: C.value } : { left: C.value }), _ = (e2) => {
    let t2, l;
    return e2.type.startsWith("touch") ? (l = e2.touches[0].clientY, t2 = e2.touches[0].clientX) : (l = e2.clientY, t2 = e2.clientX), { clientX: t2, clientY: l };
  }, M = (l) => {
    t.dragging = true, t.isClick = true;
    const { clientX: a2, clientY: n } = _(l);
    e.vertical ? t.startY = n : t.startX = a2, t.startPosition = parseFloat(C.value), t.newPosition = t.startPosition;
  }, T = (l) => {
    if (t.dragging) {
      let a2;
      t.isClick = false, k(), m();
      const { clientX: n, clientY: o } = _(l);
      e.vertical ? (t.currentY = o, a2 = (t.startY - t.currentY) / p.value * 100) : (t.currentX = n, a2 = (t.currentX - t.startX) / p.value * 100), t.newPosition = t.startPosition + a2, O(t.newPosition);
    }
  }, I = () => {
    t.dragging && (setTimeout(() => {
      t.dragging = false, t.hovering || x(), t.isClick || (O(t.newPosition), v());
    }, 0), nt(window, "mousemove", T), nt(window, "touchmove", T), nt(window, "mouseup", I), nt(window, "touchend", I), nt(window, "contextmenu", I));
  }, O = (l) => Ds(void 0, void 0, void 0, function* () {
    if (l === null || isNaN(l))
      return;
    l < 0 ? l = 0 : l > 100 && (l = 100);
    const n = 100 / ((s.value - r.value) / u.value);
    let o = Math.round(l / n) * n * (s.value - r.value) * 0.01 + r.value;
    o = parseFloat(o.toFixed(c.value)), a(Gt, o), t.dragging || e.modelValue === t.oldValue || (t.oldValue = e.modelValue), yield nextTick(), t.dragging && k(), g.value.updatePopper();
  });
  return watch(() => t.dragging, (e2) => {
    f(e2);
  }), { tooltip: g, tooltipVisible: b, showTooltip: d, wrapperStyle: S, formatValue: y, handleMouseEnter: () => {
    t.hovering = true, k();
  }, handleMouseLeave: () => {
    t.hovering = false, t.dragging || x();
  }, onButtonDown: (e2) => {
    i.value || (e2.preventDefault(), M(e2), at(window, "mousemove", T), at(window, "touchmove", T), at(window, "mouseup", I), at(window, "touchend", I), at(window, "contextmenu", I));
  }, onLeftKeyDown: () => {
    i.value || (t.newPosition = parseFloat(C.value) - u.value / (s.value - r.value) * 100, O(t.newPosition), v());
  }, onRightKeyDown: () => {
    i.value || (t.newPosition = parseFloat(C.value) + u.value / (s.value - r.value) * 100, O(t.newPosition), v());
  }, setPosition: O };
};
var nc = defineComponent({ name: "ElSliderButton", components: { ElTooltip: du }, props: { modelValue: { type: Number, default: 0 }, vertical: { type: Boolean, default: false }, tooltipClass: { type: String, default: "" } }, emits: [Gt], setup(e, { emit: t }) {
  const l = reactive({ hovering: false, dragging: false, isClick: false, startX: 0, currentX: 0, startY: 0, currentY: 0, startPosition: 0, newPosition: 0, oldValue: e.modelValue }), { tooltip: n, showTooltip: o, tooltipVisible: i, wrapperStyle: r, formatValue: s, handleMouseEnter: u, handleMouseLeave: d, onButtonDown: c, onLeftKeyDown: p, onRightKeyDown: h2, setPosition: v } = ac(e, l, t), { hovering: m, dragging: f } = toRefs(l);
  return { tooltip: n, tooltipVisible: i, showTooltip: o, wrapperStyle: r, formatValue: s, handleMouseEnter: u, handleMouseLeave: d, onButtonDown: c, onLeftKeyDown: p, onRightKeyDown: h2, setPosition: v, hovering: m, dragging: f };
} });
nc.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-tooltip");
  return openBlock(), createBlock("div", { ref: "button", class: ["el-slider__button-wrapper", { hover: e.hovering, dragging: e.dragging }], style: e.wrapperStyle, tabindex: "0", onMouseenter: t[2] || (t[2] = (...t2) => e.handleMouseEnter && e.handleMouseEnter(...t2)), onMouseleave: t[3] || (t[3] = (...t2) => e.handleMouseLeave && e.handleMouseLeave(...t2)), onMousedown: t[4] || (t[4] = (...t2) => e.onButtonDown && e.onButtonDown(...t2)), onTouchstart: t[5] || (t[5] = (...t2) => e.onButtonDown && e.onButtonDown(...t2)), onFocus: t[6] || (t[6] = (...t2) => e.handleMouseEnter && e.handleMouseEnter(...t2)), onBlur: t[7] || (t[7] = (...t2) => e.handleMouseLeave && e.handleMouseLeave(...t2)), onKeydown: [t[8] || (t[8] = withKeys((...t2) => e.onLeftKeyDown && e.onLeftKeyDown(...t2), ["left"])), t[9] || (t[9] = withKeys((...t2) => e.onRightKeyDown && e.onRightKeyDown(...t2), ["right"])), t[10] || (t[10] = withKeys(withModifiers((...t2) => e.onLeftKeyDown && e.onLeftKeyDown(...t2), ["prevent"]), ["down"])), t[11] || (t[11] = withKeys(withModifiers((...t2) => e.onRightKeyDown && e.onRightKeyDown(...t2), ["prevent"]), ["up"]))] }, [createVNode(i, { ref: "tooltip", modelValue: e.tooltipVisible, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.tooltipVisible = t2), placement: "top", "stop-popper-mouse-event": false, "popper-class": e.tooltipClass, disabled: !e.showTooltip, manual: "" }, { content: withCtx(() => [createVNode("span", null, toDisplayString(e.formatValue), 1)]), default: withCtx(() => [createVNode("div", { class: ["el-slider__button", { hover: e.hovering, dragging: e.dragging }] }, null, 2)]), _: 1 }, 8, ["modelValue", "popper-class", "disabled"])], 38);
}, nc.__file = "packages/slider/src/button.vue";
var oc = defineComponent({ name: "ElMarker", props: { mark: { type: [String, Object], default: () => {
} } }, setup: (e) => ({ label: computed(() => typeof e.mark == "string" ? e.mark : e.mark.label) }), render() {
  var e;
  return h("div", { class: "el-slider__marks-text", style: (e = this.mark) === null || e === void 0 ? void 0 : e.style }, this.label);
} });
oc.__file = "packages/slider/src/marker.vue";
var ic = defineComponent({ name: "ElSlider", components: { ElInputNumber: $s, SliderButton: nc, SliderMarker: oc }, props: { modelValue: { type: [Number, Array], default: 0 }, min: { type: Number, default: 0 }, max: { type: Number, default: 100 }, step: { type: Number, default: 1 }, showInput: { type: Boolean, default: false }, showInputControls: { type: Boolean, default: true }, inputSize: { type: String, default: "small" }, showStops: { type: Boolean, default: false }, showTooltip: { type: Boolean, default: true }, formatTooltip: { type: Function, default: void 0 }, disabled: { type: Boolean, default: false }, range: { type: Boolean, default: false }, vertical: { type: Boolean, default: false }, height: { type: String, default: "" }, debounce: { type: Number, default: 300 }, label: { type: String, default: void 0 }, tooltipClass: { type: String, default: void 0 }, marks: Object }, emits: [Gt, "change", "input"], setup(e, { emit: t }) {
  const o = reactive({ firstValue: 0, secondValue: 0, oldValue: 0, dragging: false, sliderSize: 1 }), { elFormItem: i, slider: r, firstButton: s, secondButton: u, sliderDisabled: d, minValue: c, maxValue: p, runwayStyle: h2, barStyle: v, resetSize: m, emitChange: f, onSliderClick: g } = ((e2, t2, a) => {
    const o2 = inject("elForm", {}), i2 = inject("elFormItem", {}), r2 = ref(null), s2 = ref(null), u2 = ref(null), d2 = { firstButton: s2, secondButton: u2 }, c2 = computed(() => e2.disabled || o2.disabled || false), p2 = computed(() => Math.min(t2.firstValue, t2.secondValue)), h3 = computed(() => Math.max(t2.firstValue, t2.secondValue)), v2 = computed(() => e2.range ? 100 * (h3.value - p2.value) / (e2.max - e2.min) + "%" : 100 * (t2.firstValue - e2.min) / (e2.max - e2.min) + "%"), m2 = computed(() => e2.range ? 100 * (p2.value - e2.min) / (e2.max - e2.min) + "%" : "0%"), f2 = computed(() => e2.vertical ? { height: e2.height } : {}), g2 = computed(() => e2.vertical ? { height: v2.value, bottom: m2.value } : { width: v2.value, left: m2.value }), b2 = () => {
      r2.value && (t2.sliderSize = r2.value["client" + (e2.vertical ? "Height" : "Width")]);
    }, y2 = (l) => {
      const a2 = e2.min + l * (e2.max - e2.min) / 100;
      if (!e2.range)
        return void s2.value.setPosition(l);
      let n;
      n = Math.abs(p2.value - a2) < Math.abs(h3.value - a2) ? t2.firstValue < t2.secondValue ? "firstButton" : "secondButton" : t2.firstValue > t2.secondValue ? "firstButton" : "secondButton", d2[n].value.setPosition(l);
    }, k2 = () => Ds(void 0, void 0, void 0, function* () {
      yield nextTick(), a("change", e2.range ? [p2.value, h3.value] : e2.modelValue);
    });
    return { elFormItem: i2, slider: r2, firstButton: s2, secondButton: u2, sliderDisabled: c2, minValue: p2, maxValue: h3, runwayStyle: f2, barStyle: g2, resetSize: b2, setPosition: y2, emitChange: k2, onSliderClick: (l) => {
      if (!c2.value && !t2.dragging) {
        if (b2(), e2.vertical) {
          const e3 = r2.value.getBoundingClientRect().bottom;
          y2((e3 - l.clientY) / t2.sliderSize * 100);
        } else {
          const e3 = r2.value.getBoundingClientRect().left;
          y2((l.clientX - e3) / t2.sliderSize * 100);
        }
        k2();
      }
    } };
  })(e, o, t), { stops: b, getStopStyle: y } = ((e2, t2, l, a) => ({ stops: computed(() => {
    if (!e2.showStops || e2.min > e2.max)
      return [];
    if (e2.step === 0)
      return console.warn("[Element Warn][Slider]step should not be 0."), [];
    const n = (e2.max - e2.min) / e2.step, o2 = 100 * e2.step / (e2.max - e2.min), i2 = Array.from({ length: n - 1 }).map((e3, t3) => (t3 + 1) * o2);
    return e2.range ? i2.filter((t3) => t3 < 100 * (l.value - e2.min) / (e2.max - e2.min) || t3 > 100 * (a.value - e2.min) / (e2.max - e2.min)) : i2.filter((l2) => l2 > 100 * (t2.firstValue - e2.min) / (e2.max - e2.min));
  }), getStopStyle: (t3) => e2.vertical ? { bottom: t3 + "%" } : { left: t3 + "%" } }))(e, o, c, p), k = ((e2) => computed(() => e2.marks ? Object.keys(e2.marks).map(parseFloat).sort((e3, t2) => e3 - t2).filter((t2) => t2 <= e2.max && t2 >= e2.min).map((t2) => ({ point: t2, position: 100 * (t2 - e2.min) / (e2.max - e2.min), mark: e2.marks[t2] })) : []))(e);
  rc(e, o, c, p, t, i);
  const x = computed(() => {
    let t2 = [e.min, e.max, e.step].map((e2) => {
      let t3 = ("" + e2).split(".")[1];
      return t3 ? t3.length : 0;
    });
    return Math.max.apply(null, t2);
  }), { sliderWrapper: C } = sc(e, o, m), { firstValue: M, secondValue: T, oldValue: I, dragging: O, sliderSize: N } = toRefs(o);
  return provide("SliderProvider", Object.assign(Object.assign({}, toRefs(e)), { sliderSize: N, disabled: d, precision: x, emitChange: f, resetSize: m, updateDragging: (e2) => {
    o.dragging = e2;
  } })), { firstValue: M, secondValue: T, oldValue: I, dragging: O, sliderSize: N, slider: r, firstButton: s, secondButton: u, sliderDisabled: d, runwayStyle: h2, barStyle: v, emitChange: f, onSliderClick: g, getStopStyle: y, stops: b, markList: k, sliderWrapper: C };
} });
var rc = (e, t, l, a, n, i) => {
  const r = (e2) => {
    n(Gt, e2), n("input", e2);
  }, s = () => e.range ? ![l.value, a.value].every((e2, l2) => e2 === t.oldValue[l2]) : e.modelValue !== t.oldValue, u = () => {
    var n2, o;
    if (e.min > e.max)
      return void Le("Slider", "min should not be greater than max.");
    const u2 = e.modelValue;
    e.range && Array.isArray(u2) ? u2[1] < e.min ? r([e.min, e.min]) : u2[0] > e.max ? r([e.max, e.max]) : u2[0] < e.min ? r([e.min, u2[1]]) : u2[1] > e.max ? r([u2[0], e.max]) : (t.firstValue = u2[0], t.secondValue = u2[1], s() && ((n2 = i.formItemMitt) === null || n2 === void 0 || n2.emit("el.form.change", [l.value, a.value]), t.oldValue = u2.slice())) : e.range || typeof u2 != "number" || isNaN(u2) || (u2 < e.min ? r(e.min) : u2 > e.max ? r(e.max) : (t.firstValue = u2, s() && ((o = i.formItemMitt) === null || o === void 0 || o.emit("el.form.change", u2), t.oldValue = u2)));
  };
  u(), watch(() => t.dragging, (e2) => {
    e2 || u();
  }), watch(() => t.firstValue, (t2) => {
    e.range ? r([l.value, a.value]) : r(t2);
  }), watch(() => t.secondValue, () => {
    e.range && r([l.value, a.value]);
  }), watch(() => e.modelValue, (e2, l2) => {
    t.dragging || Array.isArray(e2) && Array.isArray(l2) && e2.every((e3, t2) => e3 === l2[t2]) || u();
  }), watch(() => [e.min, e.max], () => {
    u();
  });
};
var sc = (e, t, a) => {
  const n = ref(null);
  return onMounted(() => Ds(void 0, void 0, void 0, function* () {
    let l;
    e.range ? (Array.isArray(e.modelValue) ? (t.firstValue = Math.max(e.min, e.modelValue[0]), t.secondValue = Math.min(e.max, e.modelValue[1])) : (t.firstValue = e.min, t.secondValue = e.max), t.oldValue = [t.firstValue, t.secondValue], l = `${t.firstValue}-${t.secondValue}`) : (typeof e.modelValue != "number" || isNaN(e.modelValue) ? t.firstValue = e.min : t.firstValue = Math.min(e.max, Math.max(e.min, e.modelValue)), t.oldValue = t.firstValue, l = t.firstValue), n.value.setAttribute("aria-valuetext", l), n.value.setAttribute("aria-label", e.label ? e.label : `slider between ${e.min} and ${e.max}`), at(window, "resize", a), yield nextTick(), a();
  })), onBeforeUnmount(() => {
    nt(window, "resize", a);
  }), { sliderWrapper: n };
};
var uc = { key: 1 };
var dc = { class: "el-slider__marks" };
ic.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-input-number"), r = resolveComponent("slider-button"), c = resolveComponent("slider-marker");
  return openBlock(), createBlock("div", { ref: "sliderWrapper", class: ["el-slider", { "is-vertical": e.vertical, "el-slider--with-input": e.showInput }], role: "slider", "aria-valuemin": e.min, "aria-valuemax": e.max, "aria-orientation": e.vertical ? "vertical" : "horizontal", "aria-disabled": e.sliderDisabled }, [e.showInput && !e.range ? (openBlock(), createBlock(i, { key: 0, ref: "input", modelValue: e.firstValue, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.firstValue = t2), class: "el-slider__input", step: e.step, disabled: e.sliderDisabled, controls: e.showInputControls, min: e.min, max: e.max, debounce: e.debounce, size: e.inputSize, onChange: e.emitChange }, null, 8, ["modelValue", "step", "disabled", "controls", "min", "max", "debounce", "size", "onChange"])) : createCommentVNode("v-if", true), createVNode("div", { ref: "slider", class: ["el-slider__runway", { "show-input": e.showInput && !e.range, disabled: e.sliderDisabled }], style: e.runwayStyle, onClick: t[4] || (t[4] = (...t2) => e.onSliderClick && e.onSliderClick(...t2)) }, [createVNode("div", { class: "el-slider__bar", style: e.barStyle }, null, 4), createVNode(r, { ref: "firstButton", modelValue: e.firstValue, "onUpdate:modelValue": t[2] || (t[2] = (t2) => e.firstValue = t2), vertical: e.vertical, "tooltip-class": e.tooltipClass }, null, 8, ["modelValue", "vertical", "tooltip-class"]), e.range ? (openBlock(), createBlock(r, { key: 0, ref: "secondButton", modelValue: e.secondValue, "onUpdate:modelValue": t[3] || (t[3] = (t2) => e.secondValue = t2), vertical: e.vertical, "tooltip-class": e.tooltipClass }, null, 8, ["modelValue", "vertical", "tooltip-class"])) : createCommentVNode("v-if", true), e.showStops ? (openBlock(), createBlock("div", uc, [(openBlock(true), createBlock(Fragment, null, renderList(e.stops, (t2, l2) => (openBlock(), createBlock("div", { key: l2, class: "el-slider__stop", style: e.getStopStyle(t2) }, null, 4))), 128))])) : createCommentVNode("v-if", true), e.markList.length > 0 ? (openBlock(), createBlock(Fragment, { key: 2 }, [createVNode("div", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.markList, (t2, l2) => (openBlock(), createBlock("div", { key: l2, style: e.getStopStyle(t2.position), class: "el-slider__stop el-slider__marks-stop" }, null, 4))), 128))]), createVNode("div", dc, [(openBlock(true), createBlock(Fragment, null, renderList(e.markList, (t2, l2) => (openBlock(), createBlock(c, { key: l2, mark: t2.mark, style: e.getStopStyle(t2.position) }, null, 8, ["mark", "style"]))), 128))])], 64)) : createCommentVNode("v-if", true)], 6)], 10, ["aria-valuemin", "aria-valuemax", "aria-orientation", "aria-disabled"]);
}, ic.__file = "packages/slider/src/index.vue", ic.install = (e) => {
  e.component(ic.name, ic);
};
var cc = ic;
var pc = defineComponent({ name: "ElStep", props: { title: { type: String, default: "" }, icon: { type: String, default: "" }, description: { type: String, default: "" }, status: { type: String, default: "", validator: (e) => ["", "wait", "process", "finish", "error", "success"].includes(e) } }, setup(t) {
  const s = ref(-1), u = ref({}), d = ref(""), c = inject("ElSteps"), p = getCurrentInstance();
  onMounted(() => {
    watch([() => c.props.active, () => c.props.processStatus, () => c.props.finishStatus], ([e]) => {
      S(e);
    }, { immediate: true });
  }), onBeforeUnmount(() => {
    c.steps.value = c.steps.value.filter((e) => e.uid !== p.uid);
  });
  const h2 = computed(() => t.status || d.value), v = computed(() => {
    const e = c.steps.value[s.value - 1];
    return e ? e.currentStatus : "wait";
  }), m = computed(() => c.props.alignCenter), f = computed(() => c.props.direction === "vertical"), g = computed(() => c.props.simple), b = computed(() => c.steps.value.length), y = computed(() => {
    var e;
    return ((e = c.steps.value[b.value - 1]) === null || e === void 0 ? void 0 : e.uid) === p.uid;
  }), k = computed(() => g.value ? "" : c.props.space), x = computed(() => {
    const e = { flexBasis: typeof k.value == "number" ? k.value + "px" : k.value ? k.value : 100 / (b.value - (m.value ? 0 : 1)) + "%" };
    return f.value || y.value && (e.maxWidth = 100 / b.value + "%"), e;
  }), C = (e) => {
    s.value = e;
  }, w = (e) => {
    let t2 = 100;
    const l = {};
    l.transitionDelay = 150 * s.value + "ms", e === c.props.processStatus ? t2 = 0 : e === "wait" && (t2 = 0, l.transitionDelay = -150 * s.value + "ms"), l.borderWidth = t2 && !g.value ? "1px" : 0, l[c.props.direction === "vertical" ? "height" : "width"] = t2 + "%", u.value = l;
  }, S = (e) => {
    e > s.value ? d.value = c.props.finishStatus : e === s.value && v.value !== "error" ? d.value = c.props.processStatus : d.value = "wait";
    const t2 = c.steps.value[b.value - 1];
    t2 && t2.calcProgress(d.value);
  }, _ = reactive({ uid: computed(() => p.uid), currentStatus: h2, setIndex: C, calcProgress: w });
  return c.steps.value = [...c.steps.value, _], { index: s, lineStyle: u, currentStatus: h2, isCenter: m, isVertical: f, isSimple: g, isLast: y, space: k, style: x, parent: c, setIndex: C, calcProgress: w, updateStatus: S };
} });
var hc = { class: "el-step__line" };
var vc = { key: 1, class: "el-step__icon-inner" };
var mc = { class: "el-step__main" };
var fc = { key: 0, class: "el-step__arrow" };
pc.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { style: e.style, class: ["el-step", e.isSimple ? "is-simple" : "is-" + e.parent.props.direction, e.isLast && !e.space && !e.isCenter && "is-flex", e.isCenter && !e.isVertical && !e.isSimple && "is-center"] }, [createCommentVNode(" icon & line "), createVNode("div", { class: ["el-step__head", "is-" + e.currentStatus] }, [createVNode("div", hc, [createVNode("i", { class: "el-step__line-inner", style: e.lineStyle }, null, 4)]), createVNode("div", { class: ["el-step__icon", "is-" + (e.icon ? "icon" : "text")] }, [e.currentStatus !== "success" && e.currentStatus !== "error" ? renderSlot(e.$slots, "icon", { key: 0 }, () => [e.icon ? (openBlock(), createBlock("i", { key: 0, class: ["el-step__icon-inner", e.icon] }, null, 2)) : createCommentVNode("v-if", true), e.icon || e.isSimple ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", vc, toDisplayString(e.index + 1), 1))]) : (openBlock(), createBlock("i", { key: 1, class: ["el-step__icon-inner", "is-status", "el-icon-" + (e.currentStatus === "success" ? "check" : "close")] }, null, 2))], 2)], 2), createCommentVNode(" title & description "), createVNode("div", mc, [createVNode("div", { class: ["el-step__title", "is-" + e.currentStatus] }, [renderSlot(e.$slots, "title", {}, () => [createTextVNode(toDisplayString(e.title), 1)])], 2), e.isSimple ? (openBlock(), createBlock("div", fc)) : (openBlock(), createBlock("div", { key: 1, class: ["el-step__description", "is-" + e.currentStatus] }, [renderSlot(e.$slots, "description", {}, () => [createTextVNode(toDisplayString(e.description), 1)])], 2))])], 6);
}, pc.__file = "packages/steps/src/item.vue", pc.install = (e) => {
  e.component(pc.name, pc);
};
var gc = pc;
var bc = defineComponent({ name: "ElSteps", props: { space: { type: [Number, String], default: "" }, active: { type: Number, default: 0 }, direction: { type: String, default: "horizontal", validator: (e) => ["horizontal", "vertical"].includes(e) }, alignCenter: { type: Boolean, default: false }, simple: { type: Boolean, default: false }, finishStatus: { type: String, default: "finish", validator: (e) => ["wait", "process", "finish", "error", "success"].includes(e) }, processStatus: { type: String, default: "process", validator: (e) => ["wait", "process", "finish", "error", "success"].includes(e) } }, emits: ["change"], setup(e, { emit: t }) {
  const a = ref([]);
  return watch(a, () => {
    a.value.forEach((e2, t2) => {
      e2.setIndex(t2);
    });
  }), provide("ElSteps", { props: e, steps: a }), watch(() => e.active, (e2, l) => {
    t("change", e2, l);
  }), { steps: a };
} });
bc.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-steps", e.simple ? "el-steps--simple" : "el-steps--" + e.direction] }, [renderSlot(e.$slots, "default")], 2);
}, bc.__file = "packages/steps/src/index.vue", bc.install = (e) => {
  e.component(bc.name, bc);
};
var yc = bc;
var kc = defineComponent({ name: "ElSubmenu", componentName: "ElSubmenu", props: { index: { type: String, required: true }, showTimeout: { type: Number, default: 300 }, hideTimeout: { type: Number, default: 300 }, popperClass: String, disabled: Boolean, popperAppendToBody: { type: Boolean, default: void 0 } }, setup(t) {
  const o = reactive({ popperJS: null, timeout: null, items: {}, submenus: {}, currentPlacement: "", mouseInChild: false, opened: false }), s = ref(null), u = ref(null), d = getCurrentInstance(), { paddingStyle: c, indexPath: p, parentMenu: h2 } = su(d, t.index), { openedMenus: v, isMenuPopup: m, hoverBackground: f, methods: g, props: b, methods: { closeMenu: y }, rootMenuOn: k, rootMenuEmit: x } = inject("rootMenu"), { addSubMenu: C, removeSubMenu: w, handleMouseleave: S } = inject("subMenu:" + h2.value.uid), M = computed(() => A.value === "horizontal" && T.value || A.value === "vertical" && !b.collapse ? "el-icon-arrow-down" : "el-icon-arrow-right"), T = computed(() => {
    let e = true, t2 = d.parent;
    for (; t2 && t2.type.name !== "ElMenu"; ) {
      if (["ElSubmenu", "ElMenuItemGroup"].includes(t2.type.name)) {
        e = false;
        break;
      }
      t2 = t2.parent;
    }
    return e;
  }), I = computed(() => t.popperAppendToBody === void 0 ? T.value : Boolean(t.popperAppendToBody)), O = computed(() => b.collapse ? "el-zoom-in-left" : "el-zoom-in-top"), N = computed(() => v.value.includes(t.index)), D = computed(() => {
    let e = false;
    const t2 = o.submenus, l = o.items;
    return Object.keys(l).forEach((t3) => {
      l[t3].active && (e = true);
    }), Object.keys(t2).forEach((l2) => {
      t2[l2].active && (e = true);
    }), e;
  }), V = computed(() => b.backgroundColor || ""), B = computed(() => b.activeTextColor || ""), P = computed(() => b.textColor || ""), A = computed(() => b.mode), z = computed(() => A.value !== "horizontal" ? { color: P.value } : { borderBottomColor: D.value ? b.activeTextColor ? B.value : "" : "transparent", color: D.value ? B.value : P.value }), L = mitt_es_default(), F = (e) => {
    var t2;
    e ? W() : (t2 = u.value) === null || t2 === void 0 || t2.doDestroy();
  }, R = (e) => {
    o.submenus[e.index] = e;
  }, $ = (e) => {
    delete o.submenus[e.index];
  }, H = (e = false) => {
    b.menuTrigger === "click" && b.mode === "horizontal" || !b.collapse && b.mode === "vertical" || (L.emit("submenu:mouse-leave-child"), clearTimeout(o.timeout), o.timeout = setTimeout(() => {
      !o.mouseInChild && y(t.index);
    }, t.hideTimeout), I.value && e && d.parent.type.name === "ElSubmenu" && S(true));
  }, W = () => {
    o.currentPlacement = A.value === "horizontal" && T.value ? "bottom-start" : "right-start";
  };
  return provide("subMenu:" + d.uid, { addSubMenu: R, removeSubMenu: $, handleMouseleave: H }), onBeforeMount(() => {
    k("rootMenu:toggle-collapse", (e) => {
      F(e);
    }), L.on("submenu:mouse-enter-child", () => {
      o.mouseInChild = true, clearTimeout(o.timeout);
    }), L.on("submenu:mouse-leave-child", () => {
      o.mouseInChild = false, clearTimeout(o.timeout);
    });
  }), onMounted(() => {
    g.addSubMenu({ index: t.index, indexPath: p, active: D }), C({ index: t.index, indexPath: p, active: D }), W();
  }), onBeforeUnmount(() => {
    w({ index: t.index, indexPath: p, active: D }), g.removeSubMenu({ index: t.index, indexPath: p, active: D });
  }), { data: o, props: t, mode: A, active: D, isMenuPopup: m, opened: N, paddingStyle: c, titleStyle: z, backgroundColor: V, rootProps: b, menuTransitionName: O, submenuTitleIcon: M, appendToBody: I, handleClick: () => {
    const e = t.disabled;
    b.menuTrigger === "hover" && b.mode === "horizontal" || b.collapse && b.mode === "vertical" || e || x("submenu:submenu-click", { index: t.index, indexPath: p });
  }, handleMouseenter: (e, l = t.showTimeout) => {
    if (!("ActiveXObject" in window) && e.type === "focus" && !e.relatedTarget)
      return;
    const a = t.disabled;
    b.menuTrigger === "click" && b.mode === "horizontal" || !b.collapse && b.mode === "vertical" || a || (L.emit("submenu:mouse-enter-child"), clearTimeout(o.timeout), o.timeout = setTimeout(() => {
      g.openMenu(t.index, p);
    }, l), I.value && h2.value.vnode.el.dispatchEvent(new MouseEvent("mouseenter")));
  }, handleMouseleave: H, handleTitleMouseenter: () => {
    var e;
    if (A.value === "horizontal" && !b.backgroundColor)
      return;
    const t2 = ((e = u.value) === null || e === void 0 ? void 0 : e.triggerRef) || s.value;
    t2 && (t2.style.backgroundColor = f.value);
  }, handleTitleMouseleave: () => {
    var e;
    if (A.value === "horizontal" && !b.backgroundColor)
      return;
    const t2 = ((e = u.value) === null || e === void 0 ? void 0 : e.triggerRef) || s.value;
    t2 && (t2.style.backgroundColor = b.backgroundColor || "");
  }, addItem: (e) => {
    o.items[e.index] = e;
  }, removeItem: (e) => {
    delete o.items[e.index];
  }, addSubMenu: R, removeSubMenu: $, popperVnode: u, verticalTitleRef: s };
}, render() {
  var e, t;
  const l = [(t = (e = this.$slots).title) === null || t === void 0 ? void 0 : t.call(e), h("i", { class: ["el-submenu__icon-arrow", this.submenuTitleIcon] }, null)], a = { backgroundColor: this.rootProps.backgroundColor || "" }, n = this.isMenuPopup ? h(Kl, { ref: "popperVNode", manualMode: true, visible: this.opened, "onUpdate:visible": (e2) => this.opened = e2, effect: "light", pure: true, offset: 6, showArrow: false, popperClass: this.popperClass, placement: this.data.currentPlacement, appendToBody: this.appendToBody, transition: this.menuTransitionName, gpuAcceleration: false }, { default: () => {
    var e2, t2;
    return h("div", { ref: "menu", class: ["el-menu--" + this.mode, this.popperClass], onMouseenter: (e3) => this.handleMouseenter(e3, 100), onMouseleave: () => this.handleMouseleave(true), onFocus: (e3) => this.handleMouseenter(e3, 100) }, [h("ul", { class: ["el-menu el-menu--popup", "el-menu--popup-" + this.data.currentPlacement], style: a }, [(t2 = (e2 = this.$slots).default) === null || t2 === void 0 ? void 0 : t2.call(e2)])]);
  }, trigger: () => h("div", { class: "el-submenu__title", style: [this.paddingStyle, this.titleStyle, { backgroundColor: this.backgroundColor }], onClick: this.handleClick, onMouseenter: this.handleTitleMouseenter, onMouseleave: this.handleTitleMouseleave }, l) }) : h(Fragment, {}, [h("div", { class: "el-submenu__title", style: [this.paddingStyle, this.titleStyle, { backgroundColor: this.backgroundColor }], ref: "verticalTitleRef", onClick: this.handleClick, onMouseenter: this.handleTitleMouseenter, onMouseleave: this.handleTitleMouseleave }, l), h(Eo, {}, { default: () => {
    var e2, t2;
    return withDirectives(h("ul", { role: "menu", class: "el-menu el-menu--inline", style: a }, [(t2 = (e2 = this.$slots).default) === null || t2 === void 0 ? void 0 : t2.call(e2)]), [[vShow, this.opened]]);
  } })]);
  return h("li", { class: ["el-submenu", { "is-active": this.active, "is-opened": this.opened, "is-disabled": this.disabled }], role: "menuitem", ariaHaspopup: true, ariaExpanded: this.opened, onMouseenter: this.handleMouseenter, onMouseleave: () => this.handleMouseleave(true), onFocus: this.handleMouseenter }, [n]);
} });
kc.__file = "packages/menu/src/submenu.vue", kc.install = (e) => {
  e.component(kc.name, kc);
};
var xc = kc;
var Cc = defineComponent({ name: "ElSwitch", props: { modelValue: { type: [Boolean, String, Number], default: false }, value: { type: [Boolean, String, Number], default: false }, disabled: { type: Boolean, default: false }, width: { type: Number, default: 40 }, activeIconClass: { type: String, default: "" }, inactiveIconClass: { type: String, default: "" }, activeText: { type: String, default: "" }, inactiveText: { type: String, default: "" }, activeColor: { type: String, default: "" }, inactiveColor: { type: String, default: "" }, activeValue: { type: [Boolean, String, Number], default: true }, inactiveValue: { type: [Boolean, String, Number], default: false }, name: { type: String, default: "" }, validateEvent: { type: Boolean, default: true }, id: String, loading: { type: Boolean, default: false }, beforeChange: Function }, emits: ["update:modelValue", "change", "input"], setup(e, t) {
  const a = inject("elForm", {}), r = inject("elFormItem", {}), s = ref(e.modelValue !== false), u = ref(null), d = ref(null), c = "ElSwitch";
  watch(() => e.modelValue, () => {
    s.value = true;
  }), watch(() => e.value, () => {
    s.value = false;
  });
  const p = computed(() => s.value ? e.modelValue : e.value), h2 = computed(() => p.value === e.activeValue);
  ~[e.activeValue, e.inactiveValue].indexOf(p.value) || (t.emit("update:modelValue", e.inactiveValue), t.emit("change", e.inactiveValue), t.emit("input", e.inactiveValue)), watch(h2, () => {
    var t2;
    u.value.checked = h2.value, (e.activeColor || e.inactiveColor) && f(), e.validateEvent && ((t2 = r.formItemMitt) === null || t2 === void 0 || t2.emit("el.form.change", [p.value]));
  });
  const v = computed(() => e.disabled || e.loading || (a || {}).disabled), m = () => {
    const l = h2.value ? e.inactiveValue : e.activeValue;
    t.emit("update:modelValue", l), t.emit("change", l), t.emit("input", l), nextTick(() => {
      u.value.checked = h2.value;
    });
  }, f = () => {
    const t2 = h2.value ? e.activeColor : e.inactiveColor, l = d.value;
    l.style.borderColor = t2, l.style.backgroundColor = t2, l.children[0].style.color = t2;
  };
  return onMounted(() => {
    (e.activeColor || e.inactiveColor) && f(), u.value.checked = h2.value;
  }), { input: u, core: d, switchDisabled: v, checked: h2, handleChange: m, switchValue: () => {
    if (v.value)
      return;
    const { beforeChange: t2 } = e;
    if (!t2)
      return void m();
    const l = t2();
    [Ie(l), je(l)].some((e2) => e2) || Le(c, "beforeChange must return type `Promise<boolean>` or `boolean`"), Ie(l) ? l.then((e2) => {
      e2 && m();
    }).catch((e2) => {
      Fe(c, "some error occurred: " + e2);
    }) : l && m();
  }, focus: () => {
    var e2, t2;
    (t2 = (e2 = u.value) === null || e2 === void 0 ? void 0 : e2.focus) === null || t2 === void 0 || t2.call(e2);
  } };
} });
var wc = { class: "el-switch__action" };
var Sc = { key: 0, class: "el-icon-loading" };
Cc.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-switch", { "is-disabled": e.switchDisabled, "is-checked": e.checked }], role: "switch", "aria-checked": e.checked, "aria-disabled": e.switchDisabled, onClick: t[3] || (t[3] = withModifiers((...t2) => e.switchValue && e.switchValue(...t2), ["prevent"])) }, [createVNode("input", { id: e.id, ref: "input", class: "el-switch__input", type: "checkbox", name: e.name, "true-value": e.activeValue, "false-value": e.inactiveValue, disabled: e.switchDisabled, onChange: t[1] || (t[1] = (...t2) => e.handleChange && e.handleChange(...t2)), onKeydown: t[2] || (t[2] = withKeys((...t2) => e.switchValue && e.switchValue(...t2), ["enter"])) }, null, 40, ["id", "name", "true-value", "false-value", "disabled"]), e.inactiveIconClass || e.inactiveText ? (openBlock(), createBlock("span", { key: 0, class: ["el-switch__label", "el-switch__label--left", e.checked ? "" : "is-active"] }, [e.inactiveIconClass ? (openBlock(), createBlock("i", { key: 0, class: [e.inactiveIconClass] }, null, 2)) : createCommentVNode("v-if", true), !e.inactiveIconClass && e.inactiveText ? (openBlock(), createBlock("span", { key: 1, "aria-hidden": e.checked }, toDisplayString(e.inactiveText), 9, ["aria-hidden"])) : createCommentVNode("v-if", true)], 2)) : createCommentVNode("v-if", true), createVNode("span", { ref: "core", class: "el-switch__core", style: { width: (e.width || 40) + "px" } }, [createVNode("div", wc, [e.loading ? (openBlock(), createBlock("i", Sc)) : createCommentVNode("v-if", true)])], 4), e.activeIconClass || e.activeText ? (openBlock(), createBlock("span", { key: 1, class: ["el-switch__label", "el-switch__label--right", e.checked ? "is-active" : ""] }, [e.activeIconClass ? (openBlock(), createBlock("i", { key: 0, class: [e.activeIconClass] }, null, 2)) : createCommentVNode("v-if", true), !e.activeIconClass && e.activeText ? (openBlock(), createBlock("span", { key: 1, "aria-hidden": !e.checked }, toDisplayString(e.activeText), 9, ["aria-hidden"])) : createCommentVNode("v-if", true)], 2)) : createCommentVNode("v-if", true)], 10, ["aria-checked", "aria-disabled"]);
}, Cc.__file = "packages/switch/src/index.vue", Cc.install = (e) => {
  e.component(Cc.name, Cc);
};
var _c = Cc;
var Ec = defineComponent({ name: "ElTabPane", props: { label: { type: String, default: "" }, name: { type: String, default: "" }, closable: Boolean, disabled: Boolean, lazy: Boolean }, setup(t) {
  const a = ref(null), o = ref(false), i = inject("rootTabs"), r = inject("updatePaneState");
  if (!i || !r)
    throw new Error("ElTabPane must use with ElTabs");
  const s = computed(() => t.closable || i.props.closable), u = computed(() => {
    const e = i.currentName.value === (t.name || a.value);
    return e && (o.value = true), e;
  }), d = computed(() => t.name || a.value), c = computed(() => !t.lazy || o.value || u.value), p = getCurrentInstance();
  return r({ uid: p.uid, instance: p, props: t, paneName: d, active: u, index: a, isClosable: s }), { index: a, loaded: o, isClosable: s, active: u, paneName: d, shouldBeRender: c };
} });
Ec.render = function(e, t, l, a, n, o) {
  return e.shouldBeRender ? withDirectives((openBlock(), createBlock("div", { key: 0, id: "pane-" + e.paneName, class: "el-tab-pane", role: "tabpanel", "aria-hidden": !e.active, "aria-labelledby": "tab-" + e.paneName }, [renderSlot(e.$slots, "default")], 8, ["id", "aria-hidden", "aria-labelledby"])), [[vShow, e.active]]) : createCommentVNode("v-if", true);
}, Ec.__file = "packages/tabs/src/tab-pane.vue", Ec.install = (e) => {
  e.component(Ec.name, Ec);
};
var Mc = Ec;
var Tc = function(e) {
  let t = e.target;
  for (; t && t.tagName.toUpperCase() !== "HTML"; ) {
    if (t.tagName.toUpperCase() === "TD")
      return t;
    t = t.parentNode;
  }
  return null;
};
var Ic = function(e) {
  return e !== null && typeof e == "object";
};
var Oc = function(e, t, l, a, n) {
  if (!t && !a && (!n || Array.isArray(n) && !n.length))
    return e;
  l = typeof l == "string" ? l === "descending" ? -1 : 1 : l && l < 0 ? -1 : 1;
  const o = a ? null : function(l2, a2) {
    return n ? (Array.isArray(n) || (n = [n]), n.map(function(t2) {
      return typeof t2 == "string" ? Re(l2, t2) : t2(l2, a2, e);
    })) : (t !== "$key" && Ic(l2) && "$value" in l2 && (l2 = l2.$value), [Ic(l2) ? Re(l2, t) : l2]);
  };
  return e.map(function(e2, t2) {
    return { value: e2, index: t2, key: o ? o(e2, t2) : null };
  }).sort(function(e2, t2) {
    let n2 = function(e3, t3) {
      if (a)
        return a(e3.value, t3.value);
      for (let l2 = 0, a2 = e3.key.length; l2 < a2; l2++) {
        if (e3.key[l2] < t3.key[l2])
          return -1;
        if (e3.key[l2] > t3.key[l2])
          return 1;
      }
      return 0;
    }(e2, t2);
    return n2 || (n2 = e2.index - t2.index), n2 * +l;
  }).map((e2) => e2.value);
};
var Nc = function(e, t) {
  let l = null;
  return e.columns.forEach(function(e2) {
    e2.id === t && (l = e2);
  }), l;
};
var Dc = function(e, t) {
  const l = (t.className || "").match(/el-table_[^\s]+/gm);
  return l ? Nc(e, l[0]) : null;
};
var Vc = (e, t) => {
  if (!e)
    throw new Error("row is required when get row identity");
  if (typeof t == "string") {
    if (t.indexOf(".") < 0)
      return e[t] + "";
    const l = t.split(".");
    let a = e;
    for (let e2 = 0; e2 < l.length; e2++)
      a = a[l[e2]];
    return a + "";
  }
  if (typeof t == "function")
    return t.call(null, e);
};
var Bc = function(e, t) {
  const l = {};
  return (e || []).forEach((e2, a) => {
    l[Vc(e2, t)] = { row: e2, index: a };
  }), l;
};
function Pc(e) {
  return e !== void 0 && (e = parseInt(e, 10), isNaN(e) && (e = null)), +e;
}
function Ac(e) {
  return typeof e == "number" ? e : typeof e == "string" ? /^\d+(?:px)?$/.test(e) ? parseInt(e, 10) : e : null;
}
function zc(e, t, l) {
  let a = false;
  const n = e.indexOf(t), o = n !== -1, i = () => {
    e.push(t), a = true;
  }, r = () => {
    e.splice(n, 1), a = true;
  };
  return typeof l == "boolean" ? l && !o ? i() : !l && o && r() : o ? r() : i(), a;
}
function Lc(e, t, l = "children", a = "hasChildren") {
  const n = (e2) => !(Array.isArray(e2) && e2.length);
  function o(e2, i, r) {
    t(e2, i, r), i.forEach((e3) => {
      if (e3[a])
        return void t(e3, null, r + 1);
      const i2 = e3[l];
      n(i2) || o(e3, i2, r + 1);
    });
  }
  e.forEach((e2) => {
    if (e2[a])
      return void t(e2, null, 0);
    const i = e2[l];
    n(i) || o(e2, i, 0);
  });
}
var Fc;
var Rc = (e) => {
  const t = [];
  return e.forEach((e2) => {
    e2.children ? t.push.apply(t, Rc(e2.children)) : t.push(e2);
  }), t;
};
function $c() {
  const t = getCurrentInstance(), a = ref(null), i = ref([]), r = ref([]), s = ref(false), u = ref([]), d = ref([]), c = ref([]), p = ref([]), h2 = ref([]), v = ref([]), m = ref([]), f = ref([]), g = ref(0), b = ref(0), y = ref(0), k = ref(false), x = ref([]), C = ref(false), w = ref(false), S = ref(null), _ = ref({}), E = ref(null), M = ref(null), T = ref(null), I = ref(null), O = ref(null);
  watch(i, () => t.state && D(false), { deep: true });
  const N = () => {
    p.value = u.value.filter((e2) => e2.fixed === true || e2.fixed === "left"), h2.value = u.value.filter((e2) => e2.fixed === "right"), p.value.length > 0 && u.value[0] && u.value[0].type === "selection" && !u.value[0].fixed && (u.value[0].fixed = true, p.value.unshift(u.value[0]));
    const e = u.value.filter((e2) => !e2.fixed);
    d.value = [].concat(p.value).concat(e).concat(h2.value);
    const t2 = Rc(e), l = Rc(p.value), a2 = Rc(h2.value);
    g.value = t2.length, b.value = l.length, y.value = a2.length, c.value = [].concat(l).concat(t2).concat(a2), s.value = p.value.length > 0 || h2.value.length > 0;
  }, D = (e, l = false) => {
    e && N(), l ? t.state.doLayout() : t.state.debouncedUpdateLayout();
  }, V = (e, t2, l) => {
    M.value && M.value !== e && (M.value.order = null), M.value = e, T.value = t2, I.value = l;
  }, B = () => {
    let e = unref(r);
    Object.keys(_.value).forEach((t2) => {
      const l = _.value[t2];
      if (!l || l.length === 0)
        return;
      const a2 = Nc({ columns: c.value }, t2);
      a2 && a2.filterMethod && (e = e.filter((e2) => l.some((t3) => a2.filterMethod.call(null, t3, e2, a2))));
    }), E.value = e;
  }, P = () => {
    i.value = ((e, t2) => {
      const l = t2.sortingColumn;
      return l && typeof l.sortable != "string" ? Oc(e, t2.sortProp, t2.sortOrder, l.sortMethod, l.sortBy) : e;
    })(E.value, { sortingColumn: M.value, sortProp: T.value, sortOrder: I.value });
  }, { setExpandRowKeys: A, toggleRowExpansion: z, updateExpandRows: L, states: F, isRowExpanded: R } = function(t2) {
    const a2 = getCurrentInstance(), n = ref(false), o = ref([]);
    return { updateExpandRows: () => {
      const e = t2.data.value || [], l = t2.rowKey.value;
      if (n.value)
        o.value = e.slice();
      else if (l) {
        const t3 = Bc(o.value, l);
        o.value = e.reduce((e2, a3) => {
          const n2 = Vc(a3, l);
          return t3[n2] && e2.push(a3), e2;
        }, []);
      } else
        o.value = [];
    }, toggleRowExpansion: (e, t3) => {
      zc(o.value, e, t3) && (a2.emit("expand-change", e, o.value.slice()), a2.store.scheduleLayout());
    }, setExpandRowKeys: (e) => {
      a2.store.assertRowKey();
      const l = t2.data.value || [], n2 = t2.rowKey.value, i2 = Bc(l, n2);
      o.value = e.reduce((e2, t3) => {
        const l2 = i2[t3];
        return l2 && e2.push(l2.row), e2;
      }, []);
    }, isRowExpanded: (e) => {
      const l = t2.rowKey.value;
      return l ? !!Bc(o.value, l)[Vc(e, l)] : o.value.indexOf(e) !== -1;
    }, states: { expandRows: o, defaultExpandAll: n } };
  }({ data: i, rowKey: a }), { updateTreeExpandKeys: $, toggleTreeExpansion: H, loadOrToggle: W, states: j } = function(t2) {
    const a2 = ref([]), i2 = ref({}), r2 = ref(16), s2 = ref(false), u2 = ref({}), d2 = ref("hasChildren"), c2 = ref("children"), p2 = getCurrentInstance(), h3 = computed(() => {
      if (!t2.rowKey.value)
        return {};
      const e = t2.data.value || [];
      return m2(e);
    }), v2 = computed(() => {
      const e = t2.rowKey.value, l = Object.keys(u2.value), a3 = {};
      return l.length ? (l.forEach((t3) => {
        if (u2.value[t3].length) {
          const l2 = { children: [] };
          u2.value[t3].forEach((t4) => {
            const n = Vc(t4, e);
            l2.children.push(n), t4[d2.value] && !a3[n] && (a3[n] = { children: [] });
          }), a3[t3] = l2;
        }
      }), a3) : a3;
    }), m2 = (e) => {
      const l = t2.rowKey.value, a3 = {};
      return Lc(e, (e2, t3, n) => {
        const o = Vc(e2, l);
        Array.isArray(t3) ? a3[o] = { children: t3.map((e3) => Vc(e3, l)), level: n } : s2.value && (a3[o] = { children: [], lazy: true, level: n });
      }, c2.value, d2.value), a3;
    }, f2 = () => {
      var e, t3;
      const l = h3.value, n = v2.value, o = Object.keys(l), r3 = {};
      if (o.length) {
        const t4 = unref(i2), u3 = (e = p2.store) === null || e === void 0 ? void 0 : e.states.defaultExpandAll.value, d3 = [], c3 = (e2, t5) => {
          const l2 = u3 || a2.value && a2.value.indexOf(t5) !== -1;
          return !!(e2 && e2.expanded || l2);
        };
        o.forEach((e2) => {
          const a3 = t4[e2], n2 = Object.assign({}, l[e2]);
          if (n2.expanded = c3(a3, e2), n2.lazy) {
            const { loaded: t5 = false, loading: l2 = false } = a3 || {};
            n2.loaded = !!t5, n2.loading = !!l2, d3.push(e2);
          }
          r3[e2] = n2;
        });
        const h4 = Object.keys(n);
        s2.value && h4.length && d3.length && h4.forEach((e2) => {
          const l2 = t4[e2], a3 = n[e2].children;
          if (d3.indexOf(e2) !== -1) {
            if (r3[e2].children.length !== 0)
              throw new Error("[ElTable]children must be an empty array.");
            r3[e2].children = a3;
          } else {
            const { loaded: t5 = false, loading: n2 = false } = l2 || {};
            r3[e2] = { lazy: true, loaded: !!t5, loading: !!n2, expanded: c3(l2, e2), children: a3, level: "" };
          }
        });
      }
      i2.value = r3, (t3 = p2.store) === null || t3 === void 0 || t3.updateTableScrollY();
    };
    watch(() => h3.value, f2), watch(() => v2.value, f2);
    const g2 = (e, l) => {
      p2.store.assertRowKey();
      const a3 = t2.rowKey.value, n = Vc(e, a3), o = n && i2.value[n];
      if (n && o && "expanded" in o) {
        const t3 = o.expanded;
        l = l === void 0 ? !o.expanded : l, i2.value[n].expanded = l, t3 !== l && p2.emit("expand-change", e, l), p2.store.updateTableScrollY();
      }
    }, b2 = (e, t3, l) => {
      const { load: a3 } = p2.props;
      a3 && !i2.value[t3].loaded && (i2.value[t3].loading = true, a3(e, l, (l2) => {
        if (!Array.isArray(l2))
          throw new Error("[ElTable] data must be an array");
        i2.value[t3].loading = false, i2.value[t3].loaded = true, i2.value[t3].expanded = true, l2.length && (u2.value[t3] = l2), p2.emit("expand-change", e, true);
      }));
    };
    return { loadData: b2, loadOrToggle: (e) => {
      p2.store.assertRowKey();
      const l = t2.rowKey.value, a3 = Vc(e, l), n = i2.value[a3];
      s2.value && n && "loaded" in n && !n.loaded ? b2(e, a3, n) : g2(e, void 0);
    }, toggleTreeExpansion: g2, updateTreeExpandKeys: (e) => {
      a2.value = e, f2();
    }, updateTreeData: f2, normalize: m2, states: { expandRowKeys: a2, treeData: i2, indent: r2, lazy: s2, lazyTreeNodeMap: u2, lazyColumnIdentifier: d2, childrenColumnName: c2 } };
  }({ data: i, rowKey: a }), { updateCurrentRowData: K, updateCurrentRow: Y, setCurrentRowKey: q, states: U } = function(t2) {
    const a2 = getCurrentInstance(), n = ref(null), o = ref(null), i2 = () => {
      n.value = null;
    }, r2 = (e) => {
      const { data: l = [], rowKey: a3 } = t2;
      let n2 = null;
      a3.value && (n2 = Ze(unref(l), (t3) => Vc(t3, a3.value) === e)), o.value = n2;
    };
    return { setCurrentRowKey: (e) => {
      a2.store.assertRowKey(), n.value = e, r2(e);
    }, restoreCurrentRowKey: i2, setCurrentRowByKey: r2, updateCurrentRow: (e) => {
      const t3 = o.value;
      if (e && e !== t3)
        return o.value = e, void a2.emit("current-change", o.value, t3);
      !e && t3 && (o.value = null, a2.emit("current-change", null, t3));
    }, updateCurrentRowData: () => {
      const e = t2.rowKey.value, l = t2.data.value || [], s2 = o.value;
      if (l.indexOf(s2) === -1 && s2) {
        if (e) {
          const t3 = Vc(s2, e);
          r2(t3);
        } else
          o.value = null;
        o.value === null && a2.emit("current-change", null, s2);
      } else
        n.value && (r2(n.value), i2());
    }, states: { _currentRowKey: n, currentRow: o } };
  }({ data: i, rowKey: a });
  return { assertRowKey: () => {
    if (!a.value)
      throw new Error("[ElTable] prop row-key is required");
  }, updateColumns: N, scheduleLayout: D, isSelected: (e) => x.value.indexOf(e) > -1, clearSelection: () => {
    k.value = false;
    x.value.length && (x.value = [], t.emit("selection-change", []));
  }, cleanSelection: () => {
    let e;
    if (a.value) {
      e = [];
      const t2 = Bc(x.value, a.value), l = Bc(i.value, a.value);
      for (const a2 in t2)
        Se(t2, a2) && !l[a2] && e.push(t2[a2].row);
    } else
      e = x.value.filter((e2) => i.value.indexOf(e2) === -1);
    if (e.length) {
      const l = x.value.filter((t2) => e.indexOf(t2) === -1);
      x.value = l, t.emit("selection-change", l.slice());
    }
  }, toggleRowSelection: (e, l, a2 = true) => {
    if (zc(x.value, e, l)) {
      const l2 = (x.value || []).slice();
      a2 && t.emit("select", l2, e), t.emit("selection-change", l2);
    }
  }, _toggleAllSelection: () => {
    const e = w.value ? !k.value : !(k.value || x.value.length);
    k.value = e;
    let l = false;
    i.value.forEach((t2, a2) => {
      S.value ? S.value.call(null, t2, a2) && zc(x.value, t2, e) && (l = true) : zc(x.value, t2, e) && (l = true);
    }), l && t.emit("selection-change", x.value ? x.value.slice() : []), t.emit("select-all", x.value);
  }, toggleAllSelection: null, updateSelectionByRowKey: () => {
    const e = Bc(x.value, a.value);
    i.value.forEach((t2) => {
      const l = Vc(t2, a.value), n = e[l];
      n && (x.value[n.index] = t2);
    });
  }, updateAllSelected: () => {
    var e;
    if (((e = i.value) === null || e === void 0 ? void 0 : e.length) === 0)
      return void (k.value = false);
    let t2;
    a.value && (t2 = Bc(x.value, a.value));
    let l = true, n = 0;
    for (let e2 = 0, r2 = (i.value || []).length; e2 < r2; e2++) {
      const r3 = i.value[e2], s2 = S.value && S.value.call(null, r3, e2);
      if (o = r3, t2 ? t2[Vc(o, a.value)] : x.value.indexOf(o) !== -1)
        n++;
      else if (!S.value || s2) {
        l = false;
        break;
      }
    }
    var o;
    n === 0 && (l = false), k.value = l;
  }, updateFilters: (e, t2) => {
    Array.isArray(e) || (e = [e]);
    const l = {};
    return e.forEach((e2) => {
      _.value[e2.id] = t2, l[e2.columnKey || e2.id] = t2;
    }), l;
  }, updateCurrentRow: Y, updateSort: V, execFilter: B, execSort: P, execQuery: (e) => {
    e && e.filter || B(), P();
  }, clearFilter: (e) => {
    const { tableHeader: l, fixedTableHeader: a2, rightFixedTableHeader: n } = t.refs;
    let o = {};
    l && (o = Object.assign(o, l.filterPanels)), a2 && (o = Object.assign(o, a2.filterPanels)), n && (o = Object.assign(o, n.filterPanels));
    const i2 = Object.keys(o);
    if (i2.length)
      if (typeof e == "string" && (e = [e]), Array.isArray(e)) {
        const l2 = e.map((e2) => function(e3, t2) {
          let l3 = null;
          for (let a3 = 0; a3 < e3.columns.length; a3++) {
            const n2 = e3.columns[a3];
            if (n2.columnKey === t2) {
              l3 = n2;
              break;
            }
          }
          return l3;
        }({ columns: c.value }, e2));
        i2.forEach((e2) => {
          const t2 = l2.find((t3) => t3.id === e2);
          t2 && (t2.filteredValue = []);
        }), t.store.commit("filterChange", { column: l2, values: [], silent: true, multi: true });
      } else
        i2.forEach((e2) => {
          const t2 = c.value.find((t3) => t3.id === e2);
          t2 && (t2.filteredValue = []);
        }), _.value = {}, t.store.commit("filterChange", { column: {}, values: [], silent: true });
  }, clearSort: () => {
    M.value && (V(null, null, null), t.store.commit("changeSortCondition", { silent: true }));
  }, toggleRowExpansion: z, setExpandRowKeysAdapter: (e) => {
    A(e), $(e);
  }, setCurrentRowKey: q, toggleRowExpansionAdapter: (e, t2) => {
    c.value.some(({ type: e2 }) => e2 === "expand") ? z(e, t2) : H(e, t2);
  }, isRowExpanded: R, updateExpandRows: L, updateCurrentRowData: K, loadOrToggle: W, states: Object.assign(Object.assign(Object.assign({ rowKey: a, data: i, _data: r, isComplex: s, _columns: u, originColumns: d, columns: c, fixedColumns: p, rightFixedColumns: h2, leafColumns: v, fixedLeafColumns: m, rightFixedLeafColumns: f, leafColumnsLength: g, fixedLeafColumnsLength: b, rightFixedLeafColumnsLength: y, isAllSelected: k, selection: x, reserveSelection: C, selectOnIndeterminate: w, selectable: S, filters: _, filteredData: E, sortingColumn: M, sortProp: T, sortOrder: I, hoverRow: O }, F), j), U) };
}
function Hc(e, t) {
  return e.map((e2) => {
    var l;
    return e2.id === t.id ? t : (((l = e2.children) === null || l === void 0 ? void 0 : l.length) && (e2.children = Hc(e2.children, t)), e2);
  });
}
function Wc(e) {
  e.forEach((e2) => {
    var t, l;
    e2.no = (t = e2.getColumnIndex) === null || t === void 0 ? void 0 : t.call(e2), ((l = e2.children) === null || l === void 0 ? void 0 : l.length) && Wc(e2.children);
  }), e.sort((e2, t) => e2.no - t.no);
}
function jc() {
  const t = getCurrentInstance(), l = $c(), a = { setData(e, l2) {
    const a2 = unref(e.data) !== l2;
    e.data.value = l2, e._data.value = l2, t.store.execQuery(), t.store.updateCurrentRowData(), t.store.updateExpandRows(), unref(e.reserveSelection) ? (t.store.assertRowKey(), t.store.updateSelectionByRowKey()) : a2 ? t.store.clearSelection() : t.store.cleanSelection(), t.store.updateAllSelected(), t.$ready && t.store.scheduleLayout();
  }, insertColumn(e, l2, a2) {
    const n = unref(e._columns);
    let o = [];
    a2 ? (a2 && !a2.children && (a2.children = []), a2.children.push(l2), o = Hc(n, a2)) : (n.push(l2), o = n), Wc(o), e._columns.value = o, l2.type === "selection" && (e.selectable.value = l2.selectable, e.reserveSelection.value = l2.reserveSelection), t.$ready && (t.store.updateColumns(), t.store.scheduleLayout());
  }, removeColumn(e, l2, a2) {
    const n = unref(e._columns) || [];
    if (a2)
      a2.children.splice(a2.children.findIndex((e2) => e2.id === l2.id), 1), a2.children.length === 0 && delete a2.children, e._columns.value = Hc(n, a2);
    else {
      const t2 = n.indexOf(l2);
      t2 > -1 && (n.splice(t2, 1), e._columns.value = n);
    }
    t.$ready && (t.store.updateColumns(), t.store.scheduleLayout());
  }, sort(e, l2) {
    const { prop: a2, order: n, init: o } = l2;
    if (a2) {
      const l3 = Ze(unref(e.columns), (e2) => e2.property === a2);
      l3 && (l3.order = n, t.store.updateSort(l3, a2, n), t.store.commit("changeSortCondition", { init: o }));
    }
  }, changeSortCondition(e, l2) {
    const { sortingColumn: a2, sortProp: n, sortOrder: o } = e;
    unref(o) === null && (e.sortingColumn.value = null, e.sortProp.value = null);
    t.store.execQuery({ filter: true }), l2 && (l2.silent || l2.init) || t.emit("sort-change", { column: unref(a2), prop: unref(n), order: unref(o) }), t.store.updateTableScrollY();
  }, filterChange(e, l2) {
    const { column: a2, values: n, silent: o } = l2, i = t.store.updateFilters(a2, n);
    t.store.execQuery(), o || t.emit("filter-change", i), t.store.updateTableScrollY();
  }, toggleAllSelection() {
    t.store.toggleAllSelection();
  }, rowSelectedChanged(e, l2) {
    t.store.toggleRowSelection(l2), t.store.updateAllSelected();
  }, setHoverRow(e, t2) {
    e.hoverRow.value = t2;
  }, setCurrentRow(e, l2) {
    t.store.updateCurrentRow(l2);
  } };
  return Object.assign(Object.assign({}, l), { mutations: a, commit: function(e, ...l2) {
    const a2 = t.store.mutations;
    if (!a2[e])
      throw new Error("Action not found: " + e);
    a2[e].apply(t, [t.store.states].concat(l2));
  }, updateTableScrollY: function() {
    nextTick(() => t.layout.updateScrollY.apply(t.layout));
  } });
}
var Kc = { rowKey: "rowKey", defaultExpandAll: "defaultExpandAll", selectOnIndeterminate: "selectOnIndeterminate", indent: "indent", lazy: "lazy", data: "data", "treeProps.hasChildren": { key: "lazyColumnIdentifier", default: "hasChildren" }, "treeProps.children": { key: "childrenColumnName", default: "children" } };
function Yc(e, t) {
  if (!e)
    throw new Error("Table is required.");
  const l = jc();
  return l.toggleAllSelection = (0, import_debounce2.default)(l._toggleAllSelection, 10), Object.keys(Kc).forEach((e2) => {
    qc(Uc(t, e2), e2, l);
  }), function(e2, t2) {
    Object.keys(Kc).forEach((l2) => {
      watch(() => Uc(t2, l2), (t3) => {
        qc(t3, l2, e2);
      });
    });
  }(l, t), l;
}
function qc(e, t, l) {
  let a = e, n = Kc[t];
  typeof Kc[t] == "object" && (n = n.key, a = a || Kc[t].default), l.states[n].value = a;
}
function Uc(e, t) {
  if (t.includes(".")) {
    const l = t.split(".");
    let a = e;
    return l.forEach((e2) => {
      a = a[e2];
    }), a;
  }
  return e[t];
}
var Gc = class {
  constructor(e) {
    this.observers = [], this.table = null, this.store = null, this.columns = [], this.fit = true, this.showHeader = true, this.height = ref(null), this.scrollX = ref(false), this.scrollY = ref(false), this.bodyWidth = ref(null), this.fixedWidth = ref(null), this.rightFixedWidth = ref(null), this.tableHeight = ref(null), this.headerHeight = ref(44), this.appendHeight = ref(0), this.footerHeight = ref(44), this.viewportHeight = ref(null), this.bodyHeight = ref(null), this.fixedBodyHeight = ref(null), this.gutterWidth = It();
    for (const t in e)
      Se(e, t) && (isRef(this[t]) ? this[t].value = e[t] : this[t] = e[t]);
    if (!this.table)
      throw new Error("table is required for Table Layout");
    if (!this.store)
      throw new Error("store is required for Table Layout");
  }
  updateScrollY() {
    if (this.height.value === null)
      return false;
    const e = this.table.refs.bodyWrapper;
    if (this.table.vnode.el && e) {
      let t = true;
      const l = this.scrollY.value;
      if (this.bodyHeight.value === null)
        t = false;
      else {
        t = e.querySelector(".el-table__body").offsetHeight > this.bodyHeight.value;
      }
      return this.scrollY.value = t, l !== t;
    }
    return false;
  }
  setHeight(e, t = "height") {
    if (ke)
      return;
    const l = this.table.vnode.el;
    if (e = Ac(e), this.height.value = Number(e), !l && (e || e === 0))
      return nextTick(() => this.setHeight(e, t));
    typeof e == "number" ? (l.style[t] = e + "px", this.updateElsHeight()) : typeof e == "string" && (l.style[t] = e, this.updateElsHeight());
  }
  setMaxHeight(e) {
    this.setHeight(e, "max-height");
  }
  getFlattenColumns() {
    const e = [];
    return this.table.store.states.columns.value.forEach((t) => {
      t.isColumnGroup ? e.push.apply(e, t.columns) : e.push(t);
    }), e;
  }
  updateElsHeight() {
    if (!this.table.$ready)
      return nextTick(() => this.updateElsHeight());
    const { headerWrapper: e, appendWrapper: t, footerWrapper: l } = this.table.refs;
    if (this.appendHeight.value = t ? t.offsetHeight : 0, this.showHeader && !e)
      return;
    const a = e ? e.querySelector(".el-table__header tr") : null, n = this.headerDisplayNone(a), o = this.headerHeight.value = this.showHeader ? e.offsetHeight : 0;
    if (this.showHeader && !n && e.offsetWidth > 0 && (this.table.store.states.columns.value || []).length > 0 && o < 2)
      return nextTick(() => this.updateElsHeight());
    const i = this.tableHeight.value = this.table.vnode.el.clientHeight, r = this.footerHeight.value = l ? l.offsetHeight : 0;
    this.height.value !== null && (this.bodyHeight.value = i - o - r + (l ? 1 : 0)), this.fixedBodyHeight.value = this.scrollX.value ? this.bodyHeight.value - this.gutterWidth : this.bodyHeight.value, this.viewportHeight.value = this.scrollX.value ? i - this.gutterWidth : i, this.updateScrollY(), this.notifyObservers("scrollable");
  }
  headerDisplayNone(e) {
    if (!e)
      return true;
    let t = e;
    for (; t.tagName !== "DIV"; ) {
      if (getComputedStyle(t).display === "none")
        return true;
      t = t.parentElement;
    }
    return false;
  }
  updateColumnsWidth() {
    if (ke)
      return;
    const e = this.fit, t = this.table.vnode.el.clientWidth;
    let l = 0;
    const a = this.getFlattenColumns(), n = a.filter((e2) => typeof e2.width != "number");
    if (a.forEach((e2) => {
      typeof e2.width == "number" && e2.realWidth && (e2.realWidth = null);
    }), n.length > 0 && e) {
      a.forEach((e3) => {
        l += Number(e3.width || e3.minWidth || 80);
      });
      const e2 = this.scrollY.value ? this.gutterWidth : 0;
      if (l <= t - e2) {
        this.scrollX.value = false;
        const a2 = t - e2 - l;
        if (n.length === 1)
          n[0].realWidth = Number(n[0].minWidth || 80) + a2;
        else {
          const e3 = a2 / n.reduce((e4, t3) => e4 + Number(t3.minWidth || 80), 0);
          let t2 = 0;
          n.forEach((l2, a3) => {
            if (a3 === 0)
              return;
            const n2 = Math.floor(Number(l2.minWidth || 80) * e3);
            t2 += n2, l2.realWidth = Number(l2.minWidth || 80) + n2;
          }), n[0].realWidth = Number(n[0].minWidth || 80) + a2 - t2;
        }
      } else
        this.scrollX.value = true, n.forEach(function(e3) {
          e3.realWidth = Number(e3.minWidth);
        });
      this.bodyWidth.value = Math.max(l, t), this.table.state.resizeState.value.width = this.bodyWidth.value;
    } else
      a.forEach((e2) => {
        e2.width || e2.minWidth ? e2.realWidth = Number(e2.width || e2.minWidth) : e2.realWidth = 80, l += e2.realWidth;
      }), this.scrollX.value = l > t, this.bodyWidth.value = l;
    const o = this.store.states.fixedColumns.value;
    if (o.length > 0) {
      let e2 = 0;
      o.forEach(function(t2) {
        e2 += Number(t2.realWidth || t2.width);
      }), this.fixedWidth.value = e2;
    }
    const i = this.store.states.rightFixedColumns.value;
    if (i.length > 0) {
      let e2 = 0;
      i.forEach(function(t2) {
        e2 += Number(t2.realWidth || t2.width);
      }), this.rightFixedWidth.value = e2;
    }
    this.notifyObservers("columns");
  }
  addObserver(e) {
    this.observers.push(e);
  }
  removeObserver(e) {
    const t = this.observers.indexOf(e);
    t !== -1 && this.observers.splice(t, 1);
  }
  notifyObservers(e) {
    this.observers.forEach((t) => {
      var l, a;
      switch (e) {
        case "columns":
          (l = t.state) === null || l === void 0 || l.onColumnsChange(this);
          break;
        case "scrollable":
          (a = t.state) === null || a === void 0 || a.onScrollableChange(this);
          break;
        default:
          throw new Error(`Table Layout don't have event ${e}.`);
      }
    });
  }
};
var Xc = defineComponent({ name: "ElTableFilterPanel", components: { ElCheckbox: Dn, ElCheckboxGroup: ko, ElScrollbar: Cl, ElPopper: Kl }, directives: { ClickOutside: Ht }, props: { placement: { type: String, default: "bottom-start" }, store: { type: Object }, column: { type: Object }, upDataColumn: { type: Function } }, setup(t) {
  const a = getCurrentInstance(), i = a.parent;
  i.filterPanels.value[t.column.id] || (i.filterPanels.value[t.column.id] = a);
  const r = ref(false), s = ref(null), u = computed(() => t.column && t.column.filters), d = computed({ get: () => (t.column.filteredValue || [])[0], set: (e) => {
    c.value && (e != null ? c.value.splice(0, 1, e) : c.value.splice(0, 1));
  } }), c = computed({ get: () => t.column && t.column.filteredValue || [], set(e) {
    t.column && t.upDataColumn("filteredValue", e);
  } }), p = computed(() => !t.column || t.column.filterMultiple), h2 = () => {
    r.value = false;
  }, v = (e) => {
    t.store.commit("filterChange", { column: t.column, values: e }), t.store.updateAllSelected();
  };
  watch(r, (e) => {
    t.column && t.upDataColumn("filterOpened", e);
  }, { immediate: true });
  const m = computed(() => {
    var e;
    return (e = s.value) === null || e === void 0 ? void 0 : e.popperRef;
  });
  return { tooltipVisible: r, multiple: p, filteredValue: c, filterValue: d, filters: u, handleConfirm: () => {
    v(c.value), h2();
  }, handleReset: () => {
    c.value = [], v(c.value), h2();
  }, handleSelect: (e) => {
    d.value = e, v(e != null ? c.value : []), h2();
  }, isActive: (e) => e.value === d.value, t: Ca, showFilterPanel: (e) => {
    e.stopPropagation(), r.value = !r.value;
  }, hideFilterPanel: () => {
    r.value = false;
  }, popperPaneRef: m, tooltip: s };
} });
var Zc = { key: 0 };
var Qc = { class: "el-table-filter__content" };
var Jc = { class: "el-table-filter__bottom" };
var ep = { key: 1, class: "el-table-filter__list" };
function tp(t) {
  const l = getCurrentInstance();
  onBeforeMount(() => {
    a.value.addObserver(l);
  }), onMounted(() => {
    o(a.value), r(a.value);
  }), onUpdated(() => {
    o(a.value), r(a.value);
  }), onUnmounted(() => {
    a.value.removeObserver(l);
  });
  const a = computed(() => {
    const e = t.layout;
    if (!e)
      throw new Error("Can not find table layout.");
    return e;
  }), o = (e) => {
    var l2;
    const a2 = ((l2 = t.vnode.el) === null || l2 === void 0 ? void 0 : l2.querySelectorAll("colgroup > col")) || [];
    if (!a2.length)
      return;
    const n = e.getFlattenColumns(), o2 = {};
    n.forEach((e2) => {
      o2[e2.id] = e2;
    });
    for (let e2 = 0, t2 = a2.length; e2 < t2; e2++) {
      const t3 = a2[e2], l3 = t3.getAttribute("name"), n2 = o2[l3];
      n2 && t3.setAttribute("width", n2.realWidth || n2.width);
    }
  }, r = (e) => {
    const l2 = t.vnode.el.querySelectorAll("colgroup > col[name=gutter]");
    for (let t2 = 0, a3 = l2.length; t2 < a3; t2++) {
      l2[t2].setAttribute("width", e.scrollY.value ? e.gutterWidth : "0");
    }
    const a2 = t.vnode.el.querySelectorAll("th.gutter");
    for (let t2 = 0, l3 = a2.length; t2 < l3; t2++) {
      const l4 = a2[t2];
      l4.style.width = e.scrollY.value ? e.gutterWidth + "px" : "0", l4.style.display = e.scrollY.value ? "" : "none";
    }
  };
  return { tableLayout: a.value, onColumnsChange: o, onScrollableChange: r };
}
function lp(t) {
  const l = getCurrentInstance().parent, a = l.store.states;
  return { getHeaderRowStyle: (e) => {
    const t2 = l.props.headerRowStyle;
    return typeof t2 == "function" ? t2.call(null, { rowIndex: e }) : t2;
  }, getHeaderRowClass: (e) => {
    const t2 = [], a2 = l.props.headerRowClassName;
    return typeof a2 == "string" ? t2.push(a2) : typeof a2 == "function" && t2.push(a2.call(null, { rowIndex: e })), t2.join(" ");
  }, getHeaderCellStyle: (e, t2, a2, n) => {
    const o = l.props.headerCellStyle;
    return typeof o == "function" ? o.call(null, { rowIndex: e, columnIndex: t2, row: a2, column: n }) : o;
  }, getHeaderCellClass: (e, n, o, i) => {
    const r = [i.id, i.order, i.headerAlign, i.className, i.labelClassName];
    e === 0 && ((e2, l2) => {
      let n2 = 0;
      for (let t2 = 0; t2 < e2; t2++)
        n2 += l2[t2].colSpan;
      const o2 = n2 + l2[e2].colSpan - 1;
      return t.fixed === "left" ? o2 >= a.fixedLeafColumnsLength.value : t.fixed === "right" ? n2 < a.columns.value.length - a.rightFixedLeafColumnsLength.value : o2 < a.fixedLeafColumnsLength.value || n2 >= a.columns.value.length - a.rightFixedLeafColumnsLength.value;
    })(n, o) && r.push("is-hidden"), i.children || r.push("is-leaf"), i.sortable && r.push("is-sortable");
    const s = l.props.headerCellClassName;
    return typeof s == "string" ? r.push(s) : typeof s == "function" && r.push(s.call(null, { rowIndex: e, columnIndex: n, row: o, column: i })), r.join(" ");
  } };
}
Xc.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-checkbox"), r = resolveComponent("el-checkbox-group"), c = resolveComponent("el-scrollbar"), p = resolveComponent("el-popper"), m = resolveDirective("click-outside");
  return openBlock(), createBlock(p, { ref: "tooltip", visible: e.tooltipVisible, "onUpdate:visible": t[6] || (t[6] = (t2) => e.tooltipVisible = t2), offset: 0, placement: e.placement, "show-arrow": false, "stop-popper-mouse-event": false, effect: "light", pure: "", "manual-mode": "", "popper-class": "el-table-filter", "append-to-body": "" }, { default: withCtx(() => [e.multiple ? (openBlock(), createBlock("div", Zc, [createVNode("div", Qc, [createVNode(c, { "wrap-class": "el-table-filter__wrap" }, { default: withCtx(() => [createVNode(r, { modelValue: e.filteredValue, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.filteredValue = t2), class: "el-table-filter__checkbox-group" }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.filters, (e2) => (openBlock(), createBlock(i, { key: e2.value, label: e2.value }, { default: withCtx(() => [createTextVNode(toDisplayString(e2.text), 1)]), _: 2 }, 1032, ["label"]))), 128))]), _: 1 }, 8, ["modelValue"])]), _: 1 })]), createVNode("div", Jc, [createVNode("button", { class: { "is-disabled": e.filteredValue.length === 0 }, disabled: e.filteredValue.length === 0, type: "", onClick: t[2] || (t[2] = (...t2) => e.handleConfirm && e.handleConfirm(...t2)) }, toDisplayString(e.t("el.table.confirmFilter")), 11, ["disabled"]), createVNode("button", { type: "", onClick: t[3] || (t[3] = (...t2) => e.handleReset && e.handleReset(...t2)) }, toDisplayString(e.t("el.table.resetFilter")), 1)])])) : (openBlock(), createBlock("ul", ep, [createVNode("li", { class: [{ "is-active": e.filterValue === void 0 || e.filterValue === null }, "el-table-filter__list-item"], onClick: t[4] || (t[4] = (t2) => e.handleSelect(null)) }, toDisplayString(e.t("el.table.clearFilter")), 3), (openBlock(true), createBlock(Fragment, null, renderList(e.filters, (t2) => (openBlock(), createBlock("li", { key: t2.value, class: [{ "is-active": e.isActive(t2) }, "el-table-filter__list-item"], label: t2.value, onClick: (l2) => e.handleSelect(t2.value) }, toDisplayString(t2.text), 11, ["label", "onClick"]))), 128))]))]), trigger: withCtx(() => [withDirectives(createVNode("span", { class: "el-table__column-filter-trigger el-none-outline", onClick: t[5] || (t[5] = (...t2) => e.showFilterPanel && e.showFilterPanel(...t2)) }, [createVNode("i", { class: ["el-icon-arrow-down", e.column.filterOpened ? "el-icon-arrow-up" : ""] }, null, 2)], 512), [[m, e.hideFilterPanel, e.popperPaneRef]])]), _: 1 }, 8, ["visible", "placement"]);
}, Xc.__file = "packages/table/src/filter-panel.vue";
var ap = (e) => {
  const t = [];
  return e.forEach((e2) => {
    e2.children ? (t.push(e2), t.push.apply(t, ap(e2.children))) : t.push(e2);
  }), t;
};
function np(t) {
  const l = getCurrentInstance().parent, a = computed(() => ((e) => {
    let t2 = 1;
    const l2 = (e2, a3) => {
      if (a3 && (e2.level = a3.level + 1, t2 < e2.level && (t2 = e2.level)), e2.children) {
        let t3 = 0;
        e2.children.forEach((a4) => {
          l2(a4, e2), t3 += a4.colSpan;
        }), e2.colSpan = t3;
      } else
        e2.colSpan = 1;
    };
    e.forEach((e2) => {
      e2.level = 1, l2(e2, void 0);
    });
    const a2 = [];
    for (let e2 = 0; e2 < t2; e2++)
      a2.push([]);
    return ap(e).forEach((e2) => {
      e2.children ? e2.rowSpan = 1 : e2.rowSpan = t2 - e2.level + 1, a2[e2.level - 1].push(e2);
    }), a2;
  })(t.store.states.originColumns.value));
  return { isGroup: computed(() => {
    const e = a.value.length > 1;
    return e && (l.state.isGroup.value = true), e;
  }), toggleAllSelection: (e) => {
    e.stopPropagation(), l.store.commit("toggleAllSelection");
  }, columnRows: a };
}
function op() {
  return h("col", { name: "gutter" });
}
function ip(e, t = false) {
  return h("colgroup", {}, [...e.map((e2) => h("col", { name: e2.id, key: e2.id })), t && op()]);
}
var rp = defineComponent({ name: "ElTableHeader", components: { ElCheckbox: Dn }, props: { fixed: { type: String, default: "" }, store: { required: true, type: Object }, border: Boolean, defaultSort: { type: Object, default: () => ({ prop: "", order: "" }) } }, setup(t, { emit: a }) {
  const o = getCurrentInstance(), r = o.parent, s = r.store.states, u = ref({}), { tableLayout: d, onColumnsChange: c, onScrollableChange: p } = tp(r), h2 = computed(() => !t.fixed && d.gutterWidth);
  onMounted(() => {
    nextTick(() => {
      const { prop: e, order: l } = t.defaultSort;
      r.store.commit("sort", { prop: e, order: l, init: true });
    });
  });
  const { handleHeaderClick: v, handleHeaderContextMenu: m, handleMouseDown: f, handleMouseMove: g, handleMouseOut: b, handleSortClick: y, handleFilterClick: k } = function(t2, a2) {
    const n = getCurrentInstance(), o2 = n.parent, i = (e) => {
      e.stopPropagation();
    }, r2 = ref(null), s2 = ref(false), u2 = ref({}), d2 = (e, l, a3) => {
      e.stopPropagation();
      const n2 = l.order === a3 ? null : a3 || (({ order: e2, sortOrders: t3 }) => {
        if (e2 === "")
          return t3[0];
        const l2 = t3.indexOf(e2 || null);
        return t3[l2 > t3.length - 2 ? 0 : l2 + 1];
      })(l);
      let i2 = e.target;
      for (; i2 && i2.tagName !== "TH"; )
        i2 = i2.parentNode;
      if (i2 && i2.tagName === "TH" && ot(i2, "noclick"))
        return void rt(i2, "noclick");
      if (!l.sortable)
        return;
      const r3 = t2.store.states;
      let s3, u3 = r3.sortProp.value;
      const d3 = r3.sortingColumn.value;
      (d3 !== l || d3 === l && d3.order === null) && (d3 && (d3.order = null), r3.sortingColumn.value = l, u3 = l.property), s3 = l.order = n2 || null, r3.sortProp.value = u3, r3.sortOrder.value = s3, o2.store.commit("changeSortCondition");
    };
    return { handleHeaderClick: (e, t3) => {
      !t3.filters && t3.sortable ? d2(e, t3, false) : t3.filterable && !t3.sortable && i(e), o2.emit("header-click", t3, e);
    }, handleHeaderContextMenu: (e, t3) => {
      o2.emit("header-contextmenu", t3, e);
    }, handleMouseDown: (e, l) => {
      if (!ke && !(l.children && l.children.length > 0) && r2.value && t2.border) {
        s2.value = true;
        const i2 = o2;
        a2("set-drag-visible", true);
        const d3 = i2.vnode.el.getBoundingClientRect().left, c2 = n.vnode.el.querySelector("th." + l.id), p2 = c2.getBoundingClientRect(), h3 = p2.left - d3 + 30;
        it(c2, "noclick"), u2.value = { startMouseLeft: e.clientX, startLeft: p2.right - d3, startColumnLeft: p2.left - d3, tableLeft: d3 };
        const v2 = i2.refs.resizeProxy;
        v2.style.left = u2.value.startLeft + "px", document.onselectstart = function() {
          return false;
        }, document.ondragstart = function() {
          return false;
        };
        const m2 = (e2) => {
          const t3 = e2.clientX - u2.value.startMouseLeft, l2 = u2.value.startLeft + t3;
          v2.style.left = Math.max(h3, l2) + "px";
        }, f2 = () => {
          if (s2.value) {
            const { startColumnLeft: n2, startLeft: o3 } = u2.value, d4 = parseInt(v2.style.left, 10) - n2;
            l.width = l.realWidth = d4, i2.emit("header-dragend", l.width, o3 - n2, l, e), t2.store.scheduleLayout(false, true), document.body.style.cursor = "", s2.value = false, r2.value = null, u2.value = {}, a2("set-drag-visible", false);
          }
          document.removeEventListener("mousemove", m2), document.removeEventListener("mouseup", f2), document.onselectstart = null, document.ondragstart = null, setTimeout(function() {
            rt(c2, "noclick");
          }, 0);
        };
        document.addEventListener("mousemove", m2), document.addEventListener("mouseup", f2);
      }
    }, handleMouseMove: (e, l) => {
      if (l.children && l.children.length > 0)
        return;
      let a3 = e.target;
      for (; a3 && a3.tagName !== "TH"; )
        a3 = a3.parentNode;
      if (l && l.resizable && !s2.value && t2.border) {
        const t3 = a3.getBoundingClientRect(), n2 = document.body.style;
        t3.width > 12 && t3.right - e.pageX < 8 ? (n2.cursor = "col-resize", ot(a3, "is-sortable") && (a3.style.cursor = "col-resize"), r2.value = l) : s2.value || (n2.cursor = "", ot(a3, "is-sortable") && (a3.style.cursor = "pointer"), r2.value = null);
      }
    }, handleMouseOut: () => {
      ke || (document.body.style.cursor = "");
    }, handleSortClick: d2, handleFilterClick: i };
  }(t, a), { getHeaderRowStyle: x, getHeaderRowClass: C, getHeaderCellStyle: S, getHeaderCellClass: _ } = lp(t), { isGroup: E, toggleAllSelection: M, columnRows: T } = np(t);
  return o.state = { onColumnsChange: c, onScrollableChange: p }, o.filterPanels = u, { columns: s.columns, filterPanels: u, hasGutter: h2, onColumnsChange: c, onScrollableChange: p, columnRows: T, getHeaderRowClass: C, getHeaderRowStyle: x, getHeaderCellClass: _, getHeaderCellStyle: S, handleHeaderClick: v, handleHeaderContextMenu: m, handleMouseDown: f, handleMouseMove: g, handleMouseOut: b, handleSortClick: y, handleFilterClick: k, isGroup: E, toggleAllSelection: M };
}, render() {
  return h("table", { border: "0", cellpadding: "0", cellspacing: "0", class: "el-table__header" }, [ip(this.columns, this.hasGutter), h("thead", { class: { "is-group": this.isGroup, "has-gutter": this.hasGutter } }, this.columnRows.map((e, t) => h("tr", { class: this.getHeaderRowClass(t), key: t, style: this.getHeaderRowStyle(t) }, e.map((l, a) => h("th", { class: this.getHeaderCellClass(t, a, e, l), colspan: l.colSpan, key: l.id + "-thead", rowSpan: l.rowSpan, style: this.getHeaderCellStyle(t, a, e, l), onClick: (e2) => this.handleHeaderClick(e2, l), onContextmenu: (e2) => this.handleHeaderContextMenu(e2, l), onMousedown: (e2) => this.handleMouseDown(e2, l), onMousemove: (e2) => this.handleMouseMove(e2, l), onMouseout: this.handleMouseOut }, [h("div", { class: ["cell", l.filteredValue && l.filteredValue.length > 0 ? "highlight" : "", l.labelClassName] }, [l.renderHeader ? l.renderHeader({ column: l, $index: a, store: this.store, _self: this.$parent }) : l.label, l.sortable && h("span", { onClick: (e2) => this.handleSortClick(e2, l), class: "caret-wrapper" }, [h("i", { onClick: (e2) => this.handleSortClick(e2, l, "ascending"), class: "sort-caret ascending" }), h("i", { onClick: (e2) => this.handleSortClick(e2, l, "descending"), class: "sort-caret descending" })]), l.filterable && h(Xc, { store: this.$parent.store, placement: l.filterPlacement || "bottom-start", column: l, upDataColumn: (e2, t2) => {
    l[e2] = t2;
  } })])])))))]);
} });
function sp(t) {
  const a = getCurrentInstance().parent, n = ref(""), o = ref(h("div")), i = (e, l, n2) => {
    const o2 = a, i2 = Tc(e);
    let r;
    i2 && (r = Dc({ columns: t.store.states.columns.value }, i2), r && o2.emit("cell-" + n2, l, r, i2, e)), o2.emit("row-" + n2, l, r, e);
  };
  return { handleDoubleClick: (e, t2) => {
    i(e, t2, "dblclick");
  }, handleClick: (e, l) => {
    t.store.commit("setCurrentRow", l), i(e, l, "click");
  }, handleContextMenu: (e, t2) => {
    i(e, t2, "contextmenu");
  }, handleMouseEnter: (0, import_debounce2.default)(function(e) {
    t.store.commit("setHoverRow", e);
  }, 30), handleMouseLeave: (0, import_debounce2.default)(function() {
    t.store.commit("setHoverRow", null);
  }, 30), handleCellMouseEnter: (e, l) => {
    const n2 = a, o2 = Tc(e);
    if (o2) {
      const a2 = Dc({ columns: t.store.states.columns.value }, o2), i3 = n2.hoverState = { cell: o2, column: a2, row: l };
      n2.emit("cell-mouse-enter", i3.row, i3.column, i3.cell, e);
    }
    const i2 = e.target.querySelector(".cell");
    if (!ot(i2, "el-tooltip") || !i2.childNodes.length)
      return;
    const r = document.createRange();
    r.setStart(i2, 0), r.setEnd(i2, i2.childNodes.length);
    (r.getBoundingClientRect().width + ((parseInt(st(i2, "paddingLeft"), 10) || 0) + (parseInt(st(i2, "paddingRight"), 10) || 0)) > i2.offsetWidth || i2.scrollWidth > i2.offsetWidth) && function(e2, t2, l2, a2) {
      function n3() {
        o3 && o3.update();
      }
      Fc = function t3() {
        try {
          o3 && o3.destroy(), i3 && document.body.removeChild(i3), nt(e2, "mouseenter", n3), nt(e2, "mouseleave", t3);
        } catch (e3) {
        }
      };
      let o3 = null;
      const i3 = function() {
        const e3 = a2 === "light", l3 = document.createElement("div");
        return l3.className = "el-popper " + (e3 ? "is-light" : "is-dark"), l3.innerHTML = t2, l3.style.zIndex = String(Ol.nextZIndex()), document.body.appendChild(l3), l3;
      }(), r2 = function() {
        const e3 = document.createElement("div");
        return e3.className = "el-popper__arrow", e3.style.bottom = "-4px", e3;
      }();
      i3.appendChild(r2), o3 = createPopper3(e2, i3, Object.assign({ modifiers: [{ name: "offset", options: { offset: [0, 8] } }, { name: "arrow", options: { element: r2, padding: 10 } }] }, l2)), at(e2, "mouseenter", n3), at(e2, "mouseleave", Fc);
    }(o2, o2.innerText || o2.textContent, { placement: "top", strategy: "fixed" }, l.tooltipEffect);
  }, handleCellMouseLeave: (e) => {
    if (!Tc(e))
      return;
    const t2 = a.hoverState;
    a.emit("cell-mouse-leave", t2 == null ? void 0 : t2.row, t2 == null ? void 0 : t2.column, t2 == null ? void 0 : t2.cell, e);
  }, tooltipContent: n, tooltipTrigger: o };
}
function up(t) {
  const l = getCurrentInstance().parent, { handleDoubleClick: a, handleClick: o, handleContextMenu: i, handleMouseEnter: r, handleMouseLeave: s, handleCellMouseEnter: u, handleCellMouseLeave: d, tooltipContent: c, tooltipTrigger: p } = sp(t), { getRowStyle: h2, getRowClass: v, getCellStyle: m, getCellClass: f, getSpan: g, getColspanRealWidth: b } = function(t2) {
    const l2 = getCurrentInstance().parent, a2 = (e) => t2.fixed === "left" ? e >= t2.store.states.fixedLeafColumnsLength.value : t2.fixed === "right" ? e < t2.store.states.columns.value.length - t2.store.states.rightFixedLeafColumnsLength.value : e < t2.store.states.fixedLeafColumnsLength.value || e >= t2.store.states.columns.value.length - t2.store.states.rightFixedLeafColumnsLength.value;
    return { getRowStyle: (e, t3) => {
      const a3 = l2.props.rowStyle;
      return typeof a3 == "function" ? a3.call(null, { row: e, rowIndex: t3 }) : a3 || null;
    }, getRowClass: (e, a3) => {
      const n = ["el-table__row"];
      l2.props.highlightCurrentRow && e === t2.store.states.currentRow.value && n.push("current-row"), t2.stripe && a3 % 2 == 1 && n.push("el-table__row--striped");
      const o2 = l2.props.rowClassName;
      return typeof o2 == "string" ? n.push(o2) : typeof o2 == "function" && n.push(o2.call(null, { row: e, rowIndex: a3 })), t2.store.states.expandRows.value.indexOf(e) > -1 && n.push("expanded"), n;
    }, getCellStyle: (e, t3, a3, n) => {
      const o2 = l2.props.cellStyle;
      return typeof o2 == "function" ? o2.call(null, { rowIndex: e, columnIndex: t3, row: a3, column: n }) : o2;
    }, getCellClass: (e, t3, n, o2) => {
      const i2 = [o2.id, o2.align, o2.className];
      a2(t3) && i2.push("is-hidden");
      const r2 = l2.props.cellClassName;
      return typeof r2 == "string" ? i2.push(r2) : typeof r2 == "function" && i2.push(r2.call(null, { rowIndex: e, columnIndex: t3, row: n, column: o2 })), i2.join(" ");
    }, getSpan: (e, t3, a3, n) => {
      let o2 = 1, i2 = 1;
      const r2 = l2.props.spanMethod;
      if (typeof r2 == "function") {
        const l3 = r2({ row: e, column: t3, rowIndex: a3, columnIndex: n });
        Array.isArray(l3) ? (o2 = l3[0], i2 = l3[1]) : typeof l3 == "object" && (o2 = l3.rowspan, i2 = l3.colspan);
      }
      return { rowspan: o2, colspan: i2 };
    }, getColspanRealWidth: (e, t3, l3) => {
      if (t3 < 1)
        return e[l3].realWidth;
      const a3 = e.map(({ realWidth: e2, width: t4 }) => e2 || t4).slice(l3, l3 + t3);
      return Number(a3.reduce((e2, t4) => Number(e2) + Number(t4), -1));
    }, isColumnHidden: a2 };
  }(t), y = computed(() => {
    return e = t.store.states.columns.value, l2 = ({ type: e2 }) => e2 === "default", e.findIndex(l2);
    var e, l2;
  }), k = (e, t2) => {
    const a2 = l.props.rowKey;
    return a2 ? Vc(e, a2) : t2;
  }, x = (e, n, c2) => {
    const { tooltipEffect: p2, store: x2 } = t, { indent: C, columns: w } = x2.states, S = v(e, n);
    let _ = true;
    c2 && (S.push("el-table__row--level-" + c2.level), _ = c2.display);
    return h("tr", { style: [_ ? null : { display: "none" }, h2(e, n)], class: S, key: k(e, n), onDblclick: (t2) => a(t2, e), onClick: (t2) => o(t2, e), onContextmenu: (t2) => i(t2, e), onMouseenter: () => r(n), onMouseleave: s }, w.value.map((a2, o2) => {
      const { rowspan: i2, colspan: r2 } = g(e, a2, n, o2);
      if (!i2 || !r2)
        return null;
      const s2 = Object.assign({}, a2);
      s2.realWidth = b(w.value, r2, o2);
      const h3 = { store: t.store, _self: t.context || l, column: s2, row: e, $index: n };
      o2 === y.value && c2 && (h3.treeNode = { indent: c2.level * C.value, level: c2.level }, typeof c2.expanded == "boolean" && (h3.treeNode.expanded = c2.expanded, "loading" in c2 && (h3.treeNode.loading = c2.loading), "noLazyChildren" in c2 && (h3.treeNode.noLazyChildren = c2.noLazyChildren)));
      const v2 = `${n},${o2}`, k2 = s2.columnKey || s2.rawColumnKey || "";
      return h("td", { style: m(n, o2, e, a2), class: f(n, o2, e, a2), key: `${k2}${v2}`, rowspan: i2, colspan: r2, onMouseenter: (t2) => u(t2, Object.assign(Object.assign({}, e), { tooltipEffect: p2 })), onMouseleave: d }, [a2.renderCell(h3)]);
    }));
  };
  return { wrappedRowRender: (e, a2) => {
    const n = t.store, { isRowExpanded: o2, assertRowKey: i2 } = n, { treeData: r2, lazyTreeNodeMap: s2, childrenColumnName: u2, rowKey: d2 } = n.states;
    if (n.states.columns.value.some(({ type: e2 }) => e2 === "expand") && o2(e)) {
      const t2 = l.renderExpanded, o3 = x(e, a2, void 0);
      return t2 ? [[o3, h("tr", { key: "expanded-row__" + o3.key }, [h("td", { colspan: n.states.columns.value.length, class: "el-table__expanded-cell" }, [t2({ row: e, $index: a2, store: n })])])]] : (console.error("[Element Error]renderExpanded is required."), o3);
    }
    if (Object.keys(r2.value).length) {
      i2();
      const t2 = Vc(e, d2.value);
      let l2 = r2.value[t2], n2 = null;
      l2 && (n2 = { expanded: l2.expanded, level: l2.level, display: true }, typeof l2.lazy == "boolean" && (typeof l2.loaded == "boolean" && l2.loaded && (n2.noLazyChildren = !(l2.children && l2.children.length)), n2.loading = l2.loading));
      const o3 = [x(e, a2, n2)];
      if (l2) {
        let n3 = 0;
        const i3 = (e2, t3) => {
          e2 && e2.length && t3 && e2.forEach((e3) => {
            const c3 = { display: t3.display && t3.expanded, level: t3.level + 1, expanded: false, noLazyChildren: false, loading: false }, p2 = Vc(e3, d2.value);
            if (p2 == null)
              throw new Error("for nested data item, row-key is required.");
            if (l2 = Object.assign({}, r2.value[p2]), l2 && (c3.expanded = l2.expanded, l2.level = l2.level || c3.level, l2.display = !(!l2.expanded || !c3.display), typeof l2.lazy == "boolean" && (typeof l2.loaded == "boolean" && l2.loaded && (c3.noLazyChildren = !(l2.children && l2.children.length)), c3.loading = l2.loading)), n3++, o3.push(x(e3, a2 + n3, c3)), l2) {
              const t4 = s2.value[p2] || e3[u2.value];
              i3(t4, l2);
            }
          });
        };
        l2.display = true;
        const c2 = s2.value[t2] || e[u2.value];
        i3(c2, l2);
      }
      return o3;
    }
    return x(e, a2, void 0);
  }, tooltipContent: c, tooltipTrigger: p };
}
var dp = { store: { required: true, type: Object }, stripe: Boolean, tooltipEffect: String, context: { default: () => ({}), type: Object }, rowClassName: [String, Function], rowStyle: [Object, Function], fixed: { type: String, default: "" }, highlight: Boolean };
var cp = defineComponent({ name: "ElTableBody", props: dp, setup(t) {
  const l = getCurrentInstance(), a = l.parent, { wrappedRowRender: n, tooltipContent: i, tooltipTrigger: r } = up(t), { onColumnsChange: s, onScrollableChange: u } = tp(a);
  return watch(t.store.states.hoverRow, (e, a2) => {
    if (!t.store.states.isComplex.value || ke)
      return;
    let n2 = window.requestAnimationFrame;
    n2 || (n2 = (e2) => window.setTimeout(e2, 16)), n2(() => {
      const t2 = l.vnode.el.querySelectorAll(".el-table__row"), n3 = t2[a2], o = t2[e];
      n3 && rt(n3, "hover-row"), o && it(o, "hover-row");
    });
  }), onUnmounted(() => {
    Fc == null || Fc();
  }), onUpdated(() => {
    Fc == null || Fc();
  }), { onColumnsChange: s, onScrollableChange: u, wrappedRowRender: n, tooltipContent: i, tooltipTrigger: r };
}, render() {
  const e = this.store.states.data.value || [];
  return h("table", { class: "el-table__body", cellspacing: "0", cellpadding: "0", border: "0" }, [ip(this.store.states.columns.value), h("tbody", {}, [e.reduce((e2, t) => e2.concat(this.wrappedRowRender(t, e2.length)), [])])]);
} });
function pp(t) {
  const l = getCurrentInstance().parent, a = l.store, { leftFixedLeafCount: o, rightFixedLeafCount: i, columnsCount: r, leftFixedCount: s, rightFixedCount: u, columns: d } = function() {
    const t2 = getCurrentInstance().parent.store;
    return { leftFixedLeafCount: computed(() => t2.states.fixedLeafColumnsLength.value), rightFixedLeafCount: computed(() => t2.states.rightFixedColumns.value.length), columnsCount: computed(() => t2.states.columns.value.length), leftFixedCount: computed(() => t2.states.fixedColumns.value.length), rightFixedCount: computed(() => t2.states.rightFixedColumns.value.length), columns: t2.states.columns };
  }(), c = computed(() => !t.fixed && l.layout.gutterWidth);
  return { hasGutter: c, getRowClasses: (e, l2) => {
    const n = [e.id, e.align, e.labelClassName];
    return e.className && n.push(e.className), ((e2, l3, a2) => {
      if (t.fixed || t.fixed === "left")
        return e2 >= o.value;
      if (t.fixed === "right") {
        let t2 = 0;
        for (let a3 = 0; a3 < e2; a3++)
          t2 += l3[a3].colSpan;
        return t2 < r.value - i.value;
      }
      return !(t.fixed || !a2.fixed) || e2 < s.value || e2 >= r.value - u.value;
    })(l2, a.states.columns.value, e) && n.push("is-hidden"), e.children || n.push("is-leaf"), n;
  }, columns: d };
}
var hp = defineComponent({ name: "ElTableFooter", props: { fixed: { type: String, default: "" }, store: { required: true, type: Object }, summaryMethod: Function, sumText: String, border: Boolean, defaultSort: { type: Object, default: () => ({ prop: "", order: "" }) } }, setup(e) {
  const { hasGutter: t, getRowClasses: l, columns: a } = pp(e);
  return { getRowClasses: l, hasGutter: t, columns: a };
}, render() {
  let e = [];
  return this.summaryMethod ? e = this.summaryMethod({ columns: this.columns, data: this.store.states.data.value }) : this.columns.forEach((t, l) => {
    if (l === 0)
      return void (e[l] = this.sumText);
    const a = this.store.states.data.value.map((e2) => Number(e2[t.property])), n = [];
    let o = true;
    a.forEach((e2) => {
      if (!isNaN(e2)) {
        o = false;
        const t2 = ("" + e2).split(".")[1];
        n.push(t2 ? t2.length : 0);
      }
    });
    const i = Math.max.apply(null, n);
    e[l] = o ? "" : a.reduce((e2, t2) => {
      const l2 = Number(t2);
      return isNaN(l2) ? e2 : parseFloat((e2 + t2).toFixed(Math.min(i, 20)));
    }, 0);
  }), h("table", { class: "el-table__footer", cellspacing: "0", cellpadding: "0", border: "0" }, [ip(this.columns, this.hasGutter), h("tbody", { class: [{ "has-gutter": this.hasGutter }] }, [h("tr", {}, [...this.columns.map((t, l) => h("td", { key: l, colspan: t.colSpan, rowspan: t.rowSpan, class: this.getRowClasses(t, l) }, [h("div", { class: ["cell", t.labelClassName] }, [e[l]])])), this.hasGutter && op()])])]);
} });
function vp(e, t, a, r) {
  const s = Xe(), u = ref(false), d = ref(null), c = ref(false), p = ref({ width: null, height: null }), h2 = ref(false);
  watchEffect(() => {
    t.setHeight(e.height);
  }), watchEffect(() => {
    t.setMaxHeight(e.maxHeight);
  }), watch(() => [e.currentRowKey, a.states.rowKey], ([e2, t2]) => {
    unref(t2) && a.setCurrentRowKey(e2 + "");
  }, { immediate: true }), watch(() => e.data, (e2) => {
    r.store.commit("setData", e2);
  }, { immediate: true, deep: true }), watchEffect(() => {
    e.expandRowKeys && a.setExpandRowKeysAdapter(e.expandRowKeys);
  });
  const v = computed(() => e.height || e.maxHeight || a.states.fixedColumns.value.length > 0 || a.states.rightFixedColumns.value.length > 0), m = () => {
    v.value && t.updateElsHeight(), t.updateColumnsWidth(), g();
  };
  onMounted(() => {
    f("is-scrolling-left"), b(), a.updateColumns(), m(), p.value = { width: r.vnode.el.offsetWidth, height: r.vnode.el.offsetHeight }, a.states.columns.value.forEach((e2) => {
      e2.filteredValue && e2.filteredValue.length && r.store.commit("filterChange", { column: e2, values: e2.filteredValue, silent: true });
    }), r.$ready = true;
  });
  const f = (e2) => {
    const { bodyWrapper: l } = r.refs;
    ((e3, l2) => {
      if (!e3)
        return;
      const a2 = Array.from(e3.classList).filter((e4) => !e4.startsWith("is-scrolling-"));
      a2.push(t.scrollX.value ? l2 : "is-scrolling-none"), e3.className = a2.join(" ");
    })(l, e2);
  }, g = (0, import_throttle.default)(function() {
    if (!r.refs.bodyWrapper)
      return;
    const { scrollLeft: e2, scrollTop: t2, offsetWidth: l, scrollWidth: a2 } = r.refs.bodyWrapper, { headerWrapper: n, footerWrapper: o, fixedBodyWrapper: i, rightFixedBodyWrapper: s2 } = r.refs;
    n && (n.scrollLeft = e2), o && (o.scrollLeft = e2), i && (i.scrollTop = t2), s2 && (s2.scrollTop = t2);
    f(e2 >= a2 - l - 1 ? "is-scrolling-right" : e2 === 0 ? "is-scrolling-left" : "is-scrolling-middle");
  }, 10), b = () => {
    window.addEventListener("resize", m), r.refs.bodyWrapper.addEventListener("scroll", g, { passive: true }), e.fit && vt(r.vnode.el, x);
  };
  onUnmounted(() => {
    y();
  });
  const y = () => {
    var t2;
    (t2 = r.refs.bodyWrapper) === null || t2 === void 0 || t2.removeEventListener("scroll", g, true), window.removeEventListener("resize", m), e.fit && mt(r.vnode.el, x);
  }, x = () => {
    if (!r.$ready)
      return;
    let t2 = false;
    const l = r.vnode.el, { width: a2, height: n } = p.value, o = l.offsetWidth;
    a2 !== o && (t2 = true);
    const i = l.offsetHeight;
    (e.height || v.value) && n !== i && (t2 = true), t2 && (p.value = { width: o, height: i }, m());
  }, w = computed(() => e.size || s.size), S = computed(() => {
    const { bodyWidth: e2, scrollY: l, gutterWidth: a2 } = t;
    return e2.value ? e2.value - (l.value ? a2 : 0) + "px" : "";
  });
  return { isHidden: u, renderExpanded: d, setDragVisible: (e2) => {
    c.value = e2;
  }, isGroup: h2, handleMouseLeave: () => {
    r.store.commit("setHoverRow", null), r.hoverState && (r.hoverState = null);
  }, handleHeaderFooterMousewheel: (e2, t2) => {
    const { pixelX: l, pixelY: a2 } = t2;
    Math.abs(l) >= Math.abs(a2) && (r.refs.bodyWrapper.scrollLeft += t2.pixelX / 5);
  }, tableSize: w, bodyHeight: computed(() => {
    const l = t.headerHeight.value || 0, a2 = t.bodyHeight.value, n = t.footerHeight.value || 0;
    if (e.height)
      return { height: a2 ? a2 + "px" : "" };
    if (e.maxHeight) {
      const t2 = Ac(e.maxHeight);
      if (typeof t2 == "number")
        return { "max-height": t2 - n - (e.showHeader ? l : 0) + "px" };
    }
    return {};
  }), emptyBlockStyle: computed(() => {
    if (e.data && e.data.length)
      return null;
    let l = "100%";
    return t.appendHeight.value && (l = `calc(100% - ${t.appendHeight.value}px)`), { width: S.value, height: l };
  }), handleFixedMousewheel: (e2, t2) => {
    const l = r.refs.bodyWrapper;
    if (Math.abs(t2.spinY) > 0) {
      const a2 = l.scrollTop;
      t2.pixelY < 0 && a2 !== 0 && e2.preventDefault(), t2.pixelY > 0 && l.scrollHeight - l.clientHeight > a2 && e2.preventDefault(), l.scrollTop += Math.ceil(t2.pixelY / 5);
    } else
      l.scrollLeft += Math.ceil(t2.pixelX / 5);
  }, fixedHeight: computed(() => e.maxHeight ? e.showSummary ? { bottom: 0 } : { bottom: t.scrollX.value && e.data.length ? t.gutterWidth + "px" : "" } : e.showSummary ? { height: t.tableHeight.value ? t.tableHeight.value + "px" : "" } : { height: t.viewportHeight.value ? t.viewportHeight.value + "px" : "" }), fixedBodyHeight: computed(() => {
    if (e.height)
      return { height: t.fixedBodyHeight.value ? t.fixedBodyHeight.value + "px" : "" };
    if (e.maxHeight) {
      let l = Ac(e.maxHeight);
      if (typeof l == "number")
        return l = t.scrollX.value ? l - t.gutterWidth : l, e.showHeader && (l -= t.headerHeight.value), l -= t.footerHeight.value, { "max-height": l + "px" };
    }
    return {};
  }), resizeProxyVisible: c, bodyWidth: S, resizeState: p, doLayout: m };
}
var mp = { data: { type: Array, default: () => [] }, size: String, width: [String, Number], height: [String, Number], maxHeight: [String, Number], fit: { type: Boolean, default: true }, stripe: Boolean, border: Boolean, rowKey: [String, Function], showHeader: { type: Boolean, default: true }, showSummary: Boolean, sumText: String, summaryMethod: Function, rowClassName: [String, Function], rowStyle: [Object, Function], cellClassName: [String, Function], cellStyle: [Object, Function], headerRowClassName: [String, Function], headerRowStyle: [Object, Function], headerCellClassName: [String, Function], headerCellStyle: [Object, Function], highlightCurrentRow: Boolean, currentRowKey: [String, Number], emptyText: String, expandRowKeys: Array, defaultExpandAll: Boolean, defaultSort: Object, tooltipEffect: String, spanMethod: Function, selectOnIndeterminate: { type: Boolean, default: true }, indent: { type: Number, default: 16 }, treeProps: { type: Object, default: () => ({ hasChildren: "hasChildren", children: "children" }) }, lazy: Boolean, load: Function, style: { type: Object, default: () => ({}) }, className: { type: String, default: "" } };
var fp = 1;
var gp = defineComponent({ name: "ElTable", directives: { Mousewheel: Ut }, components: { TableHeader: rp, TableBody: cp, TableFooter: hp }, props: mp, emits: ["select", "select-all", "selection-change", "cell-mouse-enter", "cell-mouse-leave", "cell-click", "cell-dblclick", "row-click", "row-contextmenu", "row-dblclick", "header-click", "header-contextmenu", "sort-change", "filter-change", "current-change", "header-dragend", "expand-change"], setup(t) {
  let l = getCurrentInstance();
  const a = Yc(l, t);
  l.store = a;
  const n = new Gc({ store: l.store, table: l, fit: t.fit, showHeader: t.showHeader });
  l.layout = n;
  const { setCurrentRow: o, toggleRowSelection: i, clearSelection: r, clearFilter: s, toggleAllSelection: u, toggleRowExpansion: d, clearSort: c, sort: p } = function(e) {
    return { setCurrentRow: (t2) => {
      e.commit("setCurrentRow", t2);
    }, toggleRowSelection: (t2, l2) => {
      e.toggleRowSelection(t2, l2, false), e.updateAllSelected();
    }, clearSelection: () => {
      e.clearSelection();
    }, clearFilter: (t2) => {
      e.clearFilter(t2);
    }, toggleAllSelection: () => {
      e.commit("toggleAllSelection");
    }, toggleRowExpansion: (t2, l2) => {
      e.toggleRowExpansionAdapter(t2, l2);
    }, clearSort: () => {
      e.clearSort();
    }, sort: (t2, l2) => {
      e.commit("sort", { prop: t2, order: l2 });
    } };
  }(a), { isHidden: h2, renderExpanded: v, setDragVisible: m, isGroup: f, handleMouseLeave: g, handleHeaderFooterMousewheel: b, tableSize: y, bodyHeight: k, emptyBlockStyle: x, handleFixedMousewheel: C, fixedHeight: w, fixedBodyHeight: S, resizeProxyVisible: _, bodyWidth: E, resizeState: M, doLayout: T } = vp(t, n, a, l), I = (0, import_debounce2.default)(T, 50), O = "el-table_" + fp++;
  return l.tableId = O, l.state = { isGroup: f, resizeState: M, doLayout: T, debouncedUpdateLayout: I }, { layout: n, store: a, handleHeaderFooterMousewheel: b, handleMouseLeave: g, tableId: O, tableSize: y, isHidden: h2, renderExpanded: v, resizeProxyVisible: _, resizeState: M, isGroup: f, bodyWidth: E, bodyHeight: k, emptyBlockStyle: x, debouncedUpdateLayout: I, handleFixedMousewheel: C, fixedHeight: w, fixedBodyHeight: S, setCurrentRow: o, toggleRowSelection: i, clearSelection: r, clearFilter: s, toggleAllSelection: u, toggleRowExpansion: d, clearSort: c, doLayout: T, sort: p, t: Ca, setDragVisible: m, context: l };
} });
var bp = { ref: "hiddenColumns", class: "hidden-columns" };
var yp = { key: 0, ref: "headerWrapper", class: "el-table__header-wrapper" };
var kp = { class: "el-table__empty-text" };
var xp = { key: 1, ref: "appendWrapper", class: "el-table__append-wrapper" };
var Cp = { key: 1, ref: "footerWrapper", class: "el-table__footer-wrapper" };
var wp = { key: 0, ref: "fixedHeaderWrapper", class: "el-table__fixed-header-wrapper" };
var Sp = { key: 1, ref: "fixedFooterWrapper", class: "el-table__fixed-footer-wrapper" };
var _p = { key: 0, ref: "rightFixedHeaderWrapper", class: "el-table__fixed-header-wrapper" };
var Ep = { key: 1, ref: "rightFixedFooterWrapper", class: "el-table__fixed-footer-wrapper" };
var Mp = { ref: "resizeProxy", class: "el-table__column-resize-proxy" };
gp.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("table-header"), r = resolveComponent("table-body"), p = resolveComponent("table-footer"), h2 = resolveDirective("mousewheel");
  return openBlock(), createBlock("div", { class: [{ "el-table--fit": e.fit, "el-table--striped": e.stripe, "el-table--border": e.border || e.isGroup, "el-table--hidden": e.isHidden, "el-table--group": e.isGroup, "el-table--fluid-height": e.maxHeight, "el-table--scrollable-x": e.layout.scrollX.value, "el-table--scrollable-y": e.layout.scrollY.value, "el-table--enable-row-hover": !e.store.states.isComplex.value, "el-table--enable-row-transition": (e.store.states.data.value || []).length !== 0 && (e.store.states.data.value || []).length < 100 }, e.tableSize ? "el-table--" + e.tableSize : "", e.className, "el-table"], style: e.style, onMouseleave: t[1] || (t[1] = (t2) => e.handleMouseLeave()) }, [createVNode("div", bp, [renderSlot(e.$slots, "default")], 512), e.showHeader ? withDirectives((openBlock(), createBlock("div", yp, [createVNode(i, { ref: "tableHeader", border: e.border, "default-sort": e.defaultSort, store: e.store, style: { width: e.layout.bodyWidth.value ? e.layout.bodyWidth.value + "px" : "" }, onSetDragVisible: e.setDragVisible }, null, 8, ["border", "default-sort", "store", "style", "onSetDragVisible"])], 512)), [[h2, e.handleHeaderFooterMousewheel]]) : createCommentVNode("v-if", true), createVNode("div", { ref: "bodyWrapper", style: [e.bodyHeight], class: "el-table__body-wrapper" }, [createVNode(r, { context: e.context, highlight: e.highlightCurrentRow, "row-class-name": e.rowClassName, "tooltip-effect": e.tooltipEffect, "row-style": e.rowStyle, store: e.store, stripe: e.stripe, style: { width: e.bodyWidth } }, null, 8, ["context", "highlight", "row-class-name", "tooltip-effect", "row-style", "store", "stripe", "style"]), e.data && e.data.length !== 0 ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", { key: 0, ref: "emptyBlock", style: e.emptyBlockStyle, class: "el-table__empty-block" }, [createVNode("span", kp, [renderSlot(e.$slots, "empty", {}, () => [createTextVNode(toDisplayString(e.emptyText || e.t("el.table.emptyText")), 1)])])], 4)), e.$slots.append ? (openBlock(), createBlock("div", xp, [renderSlot(e.$slots, "append")], 512)) : createCommentVNode("v-if", true)], 4), e.showSummary ? withDirectives((openBlock(), createBlock("div", Cp, [createVNode(p, { border: e.border, "default-sort": e.defaultSort, store: e.store, style: { width: e.layout.bodyWidth.value ? e.layout.bodyWidth.value + "px" : "" }, "sum-text": e.sumText || e.t("el.table.sumText"), "summary-method": e.summaryMethod }, null, 8, ["border", "default-sort", "store", "style", "sum-text", "summary-method"])], 512)), [[vShow, e.data && e.data.length > 0], [h2, e.handleHeaderFooterMousewheel]]) : createCommentVNode("v-if", true), e.store.states.fixedColumns.value.length > 0 ? withDirectives((openBlock(), createBlock("div", { key: 2, ref: "fixedWrapper", style: [{ width: e.layout.fixedWidth.value ? e.layout.fixedWidth.value + "px" : "" }, e.fixedHeight], class: "el-table__fixed" }, [e.showHeader ? (openBlock(), createBlock("div", wp, [createVNode(i, { ref: "fixedTableHeader", border: e.border, store: e.store, style: { width: e.bodyWidth }, fixed: "left", onSetDragVisible: e.setDragVisible }, null, 8, ["border", "store", "style", "onSetDragVisible"])], 512)) : createCommentVNode("v-if", true), createVNode("div", { ref: "fixedBodyWrapper", style: [{ top: e.layout.headerHeight.value + "px" }, e.fixedBodyHeight], class: "el-table__fixed-body-wrapper" }, [createVNode(r, { highlight: e.highlightCurrentRow, "row-class-name": e.rowClassName, "tooltip-effect": e.tooltipEffect, "row-style": e.rowStyle, store: e.store, stripe: e.stripe, style: { width: e.bodyWidth }, fixed: "left" }, null, 8, ["highlight", "row-class-name", "tooltip-effect", "row-style", "store", "stripe", "style"]), e.$slots.append ? (openBlock(), createBlock("div", { key: 0, style: { height: e.layout.appendHeight.value + "px" }, class: "el-table__append-gutter" }, null, 4)) : createCommentVNode("v-if", true)], 4), e.showSummary ? withDirectives((openBlock(), createBlock("div", Sp, [createVNode(p, { border: e.border, store: e.store, style: { width: e.bodyWidth }, "sum-text": e.sumText || e.t("el.table.sumText"), "summary-method": e.summaryMethod, fixed: "left" }, null, 8, ["border", "store", "style", "sum-text", "summary-method"])], 512)), [[vShow, e.data && e.data.length > 0]]) : createCommentVNode("v-if", true)], 4)), [[h2, e.handleFixedMousewheel]]) : createCommentVNode("v-if", true), e.store.states.rightFixedColumns.value.length > 0 ? withDirectives((openBlock(), createBlock("div", { key: 3, ref: "rightFixedWrapper", style: [{ width: e.layout.rightFixedWidth.value ? e.layout.rightFixedWidth.value + "px" : "", right: e.layout.scrollY.value ? (e.border ? e.layout.gutterWidth : e.layout.gutterWidth || 0) + "px" : "" }, e.fixedHeight], class: "el-table__fixed-right" }, [e.showHeader ? (openBlock(), createBlock("div", _p, [createVNode(i, { ref: "rightFixedTableHeader", border: e.border, store: e.store, style: { width: e.bodyWidth }, fixed: "right", onSetDragVisible: e.setDragVisible }, null, 8, ["border", "store", "style", "onSetDragVisible"])], 512)) : createCommentVNode("v-if", true), createVNode("div", { ref: "rightFixedBodyWrapper", style: [{ top: e.layout.headerHeight.value + "px" }, e.fixedBodyHeight], class: "el-table__fixed-body-wrapper" }, [createVNode(r, { highlight: e.highlightCurrentRow, "row-class-name": e.rowClassName, "tooltip-effect": e.tooltipEffect, "row-style": e.rowStyle, store: e.store, stripe: e.stripe, style: { width: e.bodyWidth }, fixed: "right" }, null, 8, ["highlight", "row-class-name", "tooltip-effect", "row-style", "store", "stripe", "style"]), e.$slots.append ? (openBlock(), createBlock("div", { key: 0, style: { height: e.layout.appendHeight.value + "px" }, class: "el-table__append-gutter" }, null, 4)) : createCommentVNode("v-if", true)], 4), e.showSummary ? withDirectives((openBlock(), createBlock("div", Ep, [createVNode(p, { border: e.border, store: e.store, style: { width: e.bodyWidth }, "sum-text": e.sumText || e.t("el.table.sumText"), "summary-method": e.summaryMethod, fixed: "right" }, null, 8, ["border", "store", "style", "sum-text", "summary-method"])], 512)), [[vShow, e.data && e.data.length > 0]]) : createCommentVNode("v-if", true)], 4)), [[h2, e.handleFixedMousewheel]]) : createCommentVNode("v-if", true), e.store.states.rightFixedColumns.value.length > 0 ? (openBlock(), createBlock("div", { key: 4, ref: "rightFixedPatch", style: { width: e.layout.scrollY.value ? e.layout.gutterWidth + "px" : "0", height: e.layout.headerHeight.value + "px" }, class: "el-table__fixed-right-patch" }, null, 4)) : createCommentVNode("v-if", true), withDirectives(createVNode("div", Mp, null, 512), [[vShow, e.resizeProxyVisible]])], 38);
}, gp.__file = "packages/table/src/table.vue", gp.install = (e) => {
  e.component(gp.name, gp);
};
var Tp = gp;
var Ip = { default: { order: "" }, selection: { width: 48, minWidth: 48, realWidth: 48, order: "", className: "el-table-column--selection" }, expand: { width: 48, minWidth: 48, realWidth: 48, order: "" }, index: { width: 48, minWidth: 48, realWidth: 48, order: "" } };
var Op = { selection: { renderHeader: function({ store: e }) {
  return h(Dn, { disabled: e.states.data.value && e.states.data.value.length === 0, indeterminate: e.states.selection.value.length > 0 && !e.states.isAllSelected.value, "onUpdate:modelValue": e.toggleAllSelection, modelValue: e.states.isAllSelected.value });
}, renderCell: function({ row: e, column: t, store: l, $index: a }) {
  return h(Dn, { disabled: !!t.selectable && !t.selectable.call(null, e, a), onChange: () => {
    l.commit("rowSelectedChanged", e);
  }, onClick: (e2) => e2.stopPropagation(), modelValue: l.isSelected(e) });
}, sortable: false, resizable: false }, index: { renderHeader: function({ column: e }) {
  return e.label || "#";
}, renderCell: function({ column: e, $index: t }) {
  let l = t + 1;
  const a = e.index;
  return typeof a == "number" ? l = t + a : typeof a == "function" && (l = a(t)), h("div", {}, [l]);
}, sortable: false }, expand: { renderHeader: function({ column: e }) {
  return e.label || "";
}, renderCell: function({ row: e, store: t }) {
  const l = ["el-table__expand-icon"];
  t.states.expandRows.value.indexOf(e) > -1 && l.push("el-table__expand-icon--expanded");
  return h("div", { class: l, onClick: function(l2) {
    l2.stopPropagation(), t.toggleRowExpansion(e);
  } }, [h("i", { class: "el-icon el-icon-arrow-right" })]);
}, sortable: false, resizable: false, className: "el-table__expand-column" } };
function Np({ row: e, column: t, $index: l }) {
  var a;
  const n = t.property, o = n && $e(e, n, false).v;
  return t && t.formatter ? t.formatter(e, t, o, l) : ((a = o == null ? void 0 : o.toString) === null || a === void 0 ? void 0 : a.call(o)) || "";
}
function Dp(t, a, o) {
  const i = getCurrentInstance(), r = ref(""), s = ref(false), u = ref(), d = ref();
  watchEffect(() => {
    u.value = t.align ? "is-" + t.align : null, u.value;
  }), watchEffect(() => {
    d.value = t.headerAlign ? "is-" + t.headerAlign : u.value, d.value;
  });
  const c = computed(() => {
    let e = i.vnode.vParent || i.parent;
    for (; e && !e.tableId && !e.columnId; )
      e = e.vnode.vParent || e.parent;
    return e;
  }), p = ref(Pc(t.width)), h2 = ref(((v = t.minWidth) !== void 0 && (v = Pc(v), isNaN(v) && (v = 80)), v));
  var v;
  return { columnId: r, realAlign: u, isSubColumn: s, realHeaderAlign: d, columnOrTableParent: c, setColumnWidth: (e) => (p.value && (e.width = p.value), h2.value && (e.minWidth = h2.value), e.minWidth || (e.minWidth = 80), e.realWidth = Number(e.width === void 0 ? e.minWidth : e.width), e), setColumnForcedProps: (e) => {
    const t2 = e.type, l = Op[t2] || {};
    return Object.keys(l).forEach((t3) => {
      const a2 = l[t3];
      a2 !== void 0 && (e[t3] = t3 === "className" ? `${e[t3]} ${a2}` : a2);
    }), e;
  }, setColumnRenders: (e) => {
    t.renderHeader ? console.warn("[Element Warn][TableColumn]Comparing to render-header, scoped-slot header is easier to use. We recommend users to use scoped-slot header.") : e.type !== "selection" && (e.renderHeader = (t2) => {
      i.columnConfig.value.label;
      const l2 = a.header;
      return l2 ? l2(t2) : e.label;
    });
    let l = e.renderCell;
    return e.type === "expand" ? (e.renderCell = (e2) => h("div", { class: "cell" }, [l(e2)]), o.value.renderExpanded = (e2) => a.default ? a.default(e2) : a.default) : (l = l || Np, e.renderCell = (t2) => {
      let n = null;
      n = a.default ? a.default(t2) : l(t2);
      const o2 = function({ row: e2, treeNode: t3, store: l2 }) {
        if (!t3)
          return null;
        const a2 = [], n2 = function(t4) {
          t4.stopPropagation(), l2.loadOrToggle(e2);
        };
        if (t3.indent && a2.push(h("span", { class: "el-table__indent", style: { "padding-left": t3.indent + "px" } })), typeof t3.expanded != "boolean" || t3.noLazyChildren)
          a2.push(h("span", { class: "el-table__placeholder" }));
        else {
          const e3 = ["el-table__expand-icon", t3.expanded ? "el-table__expand-icon--expanded" : ""];
          let l3 = ["el-icon-arrow-right"];
          t3.loading && (l3 = ["el-icon-loading"]), a2.push(h("div", { class: e3, onClick: n2 }, [h("i", { class: l3 })]));
        }
        return a2;
      }(t2), r2 = { class: "cell", style: {} };
      return e.showOverflowTooltip && (r2.class += " el-tooltip", r2.style = { width: (t2.column.realWidth || Number(t2.column.width)) - 1 + "px" }), ((e2) => {
        function t3(e3) {
          var t4;
          ((t4 = e3 == null ? void 0 : e3.type) === null || t4 === void 0 ? void 0 : t4.name) === "ElTableColumn" && (e3.vParent = i);
        }
        e2 instanceof Array ? e2.forEach((e3) => t3(e3)) : t3(e2);
      })(n), h("div", r2, [o2, n]);
    }), e;
  }, getPropsData: (...e) => e.reduce((e2, l) => (Array.isArray(l) && l.forEach((l2) => {
    e2[l2] = t[l2];
  }), e2), {}), getColumnElIndex: (e, t2) => [].indexOf.call(e, t2) };
}
var Vp = { type: { type: String, default: "default" }, label: String, className: String, labelClassName: String, property: String, prop: String, width: { type: [String, Number], default: "" }, minWidth: { type: [String, Number], default: "" }, renderHeader: Function, sortable: { type: [Boolean, String], default: false }, sortMethod: Function, sortBy: [String, Function, Array], resizable: { type: Boolean, default: true }, columnKey: String, align: String, headerAlign: String, showTooltipWhenOverflow: Boolean, showOverflowTooltip: Boolean, fixed: [Boolean, String], formatter: Function, selectable: Function, reserveSelection: Boolean, filterMethod: Function, filteredValue: Array, filters: Array, filterPlacement: String, filterMultiple: { type: Boolean, default: true }, index: [Number, Function], sortOrders: { type: Array, default: () => ["ascending", "descending", null], validator: (e) => e.every((e2) => ["ascending", "descending", null].indexOf(e2) > -1) } };
var Bp = 1;
var Pp = defineComponent({ name: "ElTableColumn", components: { ElCheckbox: Dn }, props: Vp, setup(t, { slots: a }) {
  const s = getCurrentInstance(), u = ref({}), d = computed(() => {
    let e = s.parent;
    for (; e && !e.tableId; )
      e = e.parent;
    return e;
  }), { registerNormalWatchers: c, registerComplexWatchers: p } = function(t2, l) {
    const a2 = getCurrentInstance();
    return { registerComplexWatchers: () => {
      const e = { realWidth: "width", realMinWidth: "minWidth" }, n = ["fixed"].reduce((e2, t3) => (e2[t3] = t3, e2), e);
      Object.keys(n).forEach((n2) => {
        const i = e[n2];
        Se(l, i) && watch(() => l[i], (e2) => {
          a2.columnConfig.value[i] = e2, a2.columnConfig.value[n2] = e2;
          const l2 = i === "fixed";
          t2.value.store.scheduleLayout(l2);
        });
      });
    }, registerNormalWatchers: () => {
      const e = { property: "prop", align: "realAlign", headerAlign: "realHeaderAlign" }, t3 = ["label", "filters", "filterMultiple", "sortable", "index", "formatter", "className", "labelClassName", "showOverflowTooltip"].reduce((e2, t4) => (e2[t4] = t4, e2), e);
      Object.keys(t3).forEach((t4) => {
        const n = e[t4];
        Se(l, n) && watch(() => l[n], (e2) => {
          a2.columnConfig.value[t4] = e2;
        });
      });
    } };
  }(d, t), { columnId: h2, isSubColumn: v, realHeaderAlign: m, columnOrTableParent: f, setColumnWidth: g, setColumnForcedProps: b, setColumnRenders: y, getPropsData: k, getColumnElIndex: x, realAlign: C } = Dp(t, a, d), w = f.value;
  h2.value = (w.tableId || w.columnId) + "_column_" + Bp++, onBeforeMount(() => {
    v.value = d.value !== w;
    const e = t.type || "default", l = t.sortable === "" || t.sortable, a2 = Object.assign(Object.assign({}, Ip[e]), { id: h2.value, type: e, property: t.prop || t.property, align: C, headerAlign: m, showOverflowTooltip: t.showOverflowTooltip || t.showTooltipWhenOverflow, filterable: t.filters || t.filterMethod, filteredValue: [], filterPlacement: "", isColumnGroup: false, filterOpened: false, sortable: l, index: t.index, rawColumnKey: s.vnode.key });
    let n = k(["columnKey", "label", "className", "labelClassName", "type", "renderHeader", "formatter", "fixed", "resizable"], ["sortMethod", "sortBy", "sortOrders"], ["selectable", "reserveSelection"], ["filterMethod", "filters", "filterMultiple", "filterOpened", "filteredValue", "filterPlacement"]);
    n = function(e2, t2) {
      const l2 = {};
      let a3;
      for (a3 in e2)
        l2[a3] = e2[a3];
      for (a3 in t2)
        if (Se(t2, a3)) {
          const e3 = t2[a3];
          e3 !== void 0 && (l2[a3] = e3);
        }
      return l2;
    }(a2, n);
    n = function(...e2) {
      return e2.length === 0 ? (e3) => e3 : e2.length === 1 ? e2[0] : e2.reduce((e3, t2) => (...l2) => e3(t2(...l2)));
    }(y, g, b)(n), u.value = n, c(), p();
  }), onMounted(() => {
    var e;
    const t2 = f.value, l = v.value ? t2.vnode.el.children : (e = t2.refs.hiddenColumns) === null || e === void 0 ? void 0 : e.children, a2 = () => x(l || [], s.vnode.el);
    u.value.getColumnIndex = a2;
    a2() > -1 && d.value.store.commit("insertColumn", u.value, v.value ? t2.columnConfig.value : null);
  }), onBeforeUnmount(() => {
    d.value.store.commit("removeColumn", u.value, v.value ? w.columnConfig.value : null);
  }), s.columnId = h2.value, s.columnConfig = u;
}, render() {
  var e, t, l;
  let a = [];
  try {
    const n = (t = (e = this.$slots).default) === null || t === void 0 ? void 0 : t.call(e, { row: {}, column: {}, $index: -1 });
    if (n instanceof Array)
      for (const e2 of n)
        ((l = e2.type) === null || l === void 0 ? void 0 : l.name) === "ElTableColumn" || e2.shapeFlag !== 36 ? a.push(e2) : e2.type === Fragment && e2.children instanceof Array && n.push(...e2.children);
  } catch (e2) {
    a = [];
  }
  return h("div", a);
} });
Pp.install = (e) => {
  e.component(Pp.name, Pp);
};
var Ap = defineComponent({ name: "ElTabBar", props: { tabs: { type: Array, default: () => [] } }, setup(t) {
  const a = inject("rootTabs");
  if (!a)
    throw new Error("ElTabBar must use with ElTabs");
  const n = getCurrentInstance(), i = () => {
    let e = {}, l = 0, o = 0;
    const i2 = ["top", "bottom"].includes(a.props.tabPosition) ? "width" : "height", r2 = i2 === "width" ? "x" : "y";
    t.tabs.every((e2) => {
      var a2;
      let r3 = (a2 = n.parent.refs) === null || a2 === void 0 ? void 0 : a2["tab-" + e2.paneName];
      if (!r3)
        return false;
      if (e2.active) {
        o = r3["client" + Ae(i2)];
        const e3 = window.getComputedStyle(r3);
        return i2 === "width" && (t.tabs.length > 1 && (o -= parseFloat(e3.paddingLeft) + parseFloat(e3.paddingRight)), l += parseFloat(e3.paddingLeft)), false;
      }
      return l += r3["client" + Ae(i2)], true;
    });
    const s = `translate${Ae(r2)}(${l}px)`;
    return e[i2] = o + "px", e.transform = s, e.msTransform = s, e.webkitTransform = s, e;
  }, r = ref(i());
  return watch(() => t.tabs, () => {
    nextTick(() => {
      r.value = i();
    });
  }), { rootTabs: a, barStyle: r };
} });
Ap.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: ["el-tabs__active-bar", "is-" + e.rootTabs.props.tabPosition], style: e.barStyle }, null, 6);
}, Ap.__file = "packages/tabs/src/tab-bar.vue";
var zp = defineComponent({ name: "ElTabNav", components: { TabBar: Ap }, props: { panes: { type: Array, default: () => [] }, currentName: { type: String, default: "" }, editable: Boolean, onTabClick: { type: Function, default: xe }, onTabRemove: { type: Function, default: xe }, type: { type: String, default: "" }, stretch: Boolean }, setup() {
  const e = inject("rootTabs");
  e || Le("[ElTabNav]", "ElTabNav must be nested inside ElTabs");
  const t = ref(false), a = ref(0), o = ref(false), s = ref(true), u = ref(null), d = ref(null), c = ref(null), p = computed(() => ["top", "bottom"].includes(e.props.tabPosition) ? "width" : "height"), h2 = computed(() => ({ transform: `translate${p.value === "width" ? "X" : "Y"}(-${a.value}px)` })), v = () => {
    if (!t.value)
      return;
    const l = d.value, n = c.value.querySelector(".is-active");
    if (!n)
      return;
    const o2 = u.value, i = ["top", "bottom"].includes(e.props.tabPosition), r = n.getBoundingClientRect(), s2 = o2.getBoundingClientRect(), p2 = i ? l.offsetWidth - s2.width : l.offsetHeight - s2.height, h3 = a.value;
    let v2 = h3;
    i ? (r.left < s2.left && (v2 = h3 - (s2.left - r.left)), r.right > s2.right && (v2 = h3 + r.right - s2.right)) : (r.top < s2.top && (v2 = h3 - (s2.top - r.top)), r.bottom > s2.bottom && (v2 = h3 + (r.bottom - s2.bottom))), v2 = Math.max(v2, 0), a.value = Math.min(v2, p2);
  }, m = () => {
    if (!d.value)
      return;
    const e2 = d.value["offset" + Ae(p.value)], l = u.value["offset" + Ae(p.value)], n = a.value;
    if (l < e2) {
      const n2 = a.value;
      t.value = t.value || {}, t.value.prev = n2, t.value.next = n2 + l < e2, e2 - n2 < l && (a.value = e2 - l);
    } else
      t.value = false, n > 0 && (a.value = 0);
  }, f = () => {
    s.value && (o.value = true);
  }, g = () => {
    const e2 = document.visibilityState;
    e2 === "hidden" ? s.value = false : e2 === "visible" && setTimeout(() => {
      s.value = true;
    }, 50);
  }, b = () => {
    s.value = false;
  }, y = () => {
    setTimeout(() => {
      s.value = true;
    }, 50);
  };
  return onUpdated(() => {
    m();
  }), onMounted(() => {
    vt(c.value, m), at(document, "visibilitychange", g), at(window, "blur", b), at(window, "focus", y), setTimeout(() => {
      v();
    }, 0);
  }), onBeforeUnmount(() => {
    c.value && mt(c.value, m), nt(document, "visibilitychange", g), nt(window, "blur", b), nt(window, "focus", y);
  }), { rootTabs: e, scrollable: t, navOffset: a, isFocus: o, focusable: s, navScroll$: u, nav$: d, el$: c, sizeName: p, navStyle: h2, scrollPrev: () => {
    const e2 = u.value["offset" + Ae(p.value)], t2 = a.value;
    if (!t2)
      return;
    let l = t2 > e2 ? t2 - e2 : 0;
    a.value = l;
  }, scrollNext: () => {
    const e2 = d.value["offset" + Ae(p.value)], t2 = u.value["offset" + Ae(p.value)], l = a.value;
    if (e2 - l <= t2)
      return;
    let n = e2 - l > 2 * t2 ? l + t2 : e2 - t2;
    a.value = n;
  }, scrollToActiveTab: v, update: m, changeTab: (e2) => {
    const t2 = e2.code;
    let l, a2, n;
    const { up: o2, down: i, left: r, right: s2 } = Dt;
    [o2, i, r, s2].indexOf(t2) !== -1 && (n = e2.currentTarget.querySelectorAll("[role=tab]"), a2 = Array.prototype.indexOf.call(n, e2.target), l = t2 === r || t2 === o2 ? a2 === 0 ? n.length - 1 : a2 - 1 : a2 < n.length - 1 ? a2 + 1 : 0, n[l].focus(), n[l].click(), f());
  }, setFocus: f, removeFocus: () => {
    o.value = false;
  }, visibilityChangeHandler: g, windowBlurHandler: b, windowFocusHandler: y };
}, render() {
  const { type: e, panes: t, editable: l, stretch: a, onTabClick: n, onTabRemove: o, navStyle: i, scrollable: r, scrollNext: s, scrollPrev: u, changeTab: d, setFocus: c, removeFocus: p, rootTabs: h2, isFocus: v } = this, m = r ? [h("span", { class: ["el-tabs__nav-prev", r.prev ? "" : "is-disabled"], onClick: u }, [h("i", { class: "el-icon-arrow-left" })]), h("span", { class: ["el-tabs__nav-next", r.next ? "" : "is-disabled"], onClick: s }, [h("i", { class: "el-icon-arrow-right" })])] : null, f = t.map((e2, t2) => {
    var a2, i2;
    let r2 = e2.props.name || e2.index || "" + t2;
    const s2 = e2.isClosable || l;
    e2.index = "" + t2;
    const u2 = s2 ? h("span", { class: "el-icon-close", onClick: (t3) => {
      o(e2, t3);
    } }) : null, d2 = ((i2 = (a2 = e2.instance.slots).label) === null || i2 === void 0 ? void 0 : i2.call(a2)) || e2.props.label, m2 = e2.active ? 0 : -1;
    return h("div", { class: { "el-tabs__item": true, ["is-" + h2.props.tabPosition]: true, "is-active": e2.active, "is-disabled": e2.props.disabled, "is-closable": s2, "is-focus": v }, id: "tab-" + r2, key: "tab-" + r2, "aria-controls": "pane-" + r2, role: "tab", "aria-selected": e2.active, ref: "tab-" + r2, tabindex: m2, onFocus: () => {
      c();
    }, onBlur: () => {
      p();
    }, onClick: (t3) => {
      p(), n(e2, r2, t3);
    }, onKeydown: (t3) => {
      !s2 || t3.code !== Dt.delete && t3.code !== Dt.backspace || o(e2, t3);
    } }, [d2, u2]);
  });
  return h("div", { ref: "el$", class: ["el-tabs__nav-wrap", r ? "is-scrollable" : "", "is-" + h2.props.tabPosition] }, [m, h("div", { class: "el-tabs__nav-scroll", ref: "navScroll$" }, [h("div", { class: ["el-tabs__nav", "is-" + h2.props.tabPosition, a && ["top", "bottom"].includes(h2.props.tabPosition) ? "is-stretch" : ""], ref: "nav$", style: i, role: "tablist", onKeydown: d }, [e ? null : h(Ap, { tabs: t }), f])])]);
} });
zp.__file = "packages/tabs/src/tab-nav.vue";
var Lp = defineComponent({ name: "ElTabs", components: { TabNav: zp }, props: { type: { type: String, default: "" }, activeName: { type: String, default: "" }, closable: Boolean, addable: Boolean, modelValue: { type: String, default: "" }, editable: Boolean, tabPosition: { type: String, default: "top" }, beforeLeave: { type: Function, default: null }, stretch: Boolean }, emits: ["tab-click", "edit", "tab-remove", "tab-add", "input", "update:modelValue"], setup(t, a) {
  const n = ref(null), r = ref(t.modelValue || t.activeName || "0"), s = ref([]), u = getCurrentInstance(), d = {};
  provide("rootTabs", { props: t, currentName: r }), provide("updatePaneState", (e) => {
    d[e.uid] = e;
  }), watch(() => t.activeName, (e) => {
    v(e);
  }), watch(() => t.modelValue, (e) => {
    v(e);
  }), watch(r, () => {
    n.value && nextTick(() => {
      n.value.$nextTick(() => {
        n.value.scrollToActiveTab();
      });
    }), p(true);
  });
  const c = (e, t2 = []) => (Array.from(e.children || []).forEach((e2) => {
    let l = e2.type;
    l = l.name || l, l === "ElTabPane" && e2.component ? t2.push(e2.component) : l !== Fragment && l !== "template" || c(e2, t2);
  }), t2), p = (e = false) => {
    if (a.slots.default) {
      const t2 = u.subTree.children, l = Array.from(t2).find(({ props: e2 }) => e2.class === "el-tabs__content");
      if (!l)
        return;
      const a2 = c(l).map((e2) => d[e2.uid]), n2 = !(a2.length === s.value.length && a2.every((e2, t3) => e2.uid === s.value[t3].uid));
      (e || n2) && (s.value = a2);
    } else
      s.value.length !== 0 && (s.value = []);
  }, h2 = (e) => {
    r.value = e, a.emit("input", e), a.emit("update:modelValue", e);
  }, v = (e) => {
    if (r.value === e)
      return;
    const l = t.beforeLeave, a2 = l && l(e, r.value);
    a2 && Ie(a2) ? a2.then(() => {
      var t2, l2;
      h2(e), (l2 = (t2 = n.value).removeFocus) === null || l2 === void 0 || l2.call(t2);
    }, () => {
    }) : a2 !== false && h2(e);
  };
  return onUpdated(() => {
    p();
  }), onMounted(() => {
    p();
  }), { nav$: n, handleTabClick: (e, t2, l) => {
    e.props.disabled || (v(t2), a.emit("tab-click", e, l));
  }, handleTabRemove: (e, t2) => {
    e.props.disabled || (t2.stopPropagation(), a.emit("edit", e.props.name, "remove"), a.emit("tab-remove", e.props.name));
  }, handleTabAdd: () => {
    a.emit("edit", null, "add"), a.emit("tab-add");
  }, currentName: r, panes: s };
}, render() {
  var e;
  let { type: t, handleTabClick: l, handleTabRemove: a, handleTabAdd: n, currentName: o, panes: i, editable: r, addable: s, tabPosition: u, stretch: d } = this;
  const c = r || s ? h("span", { class: "el-tabs__new-tab", tabindex: "0", onClick: n, onKeydown: (e2) => {
    e2.code === Dt.enter && n();
  } }, [h("i", { class: "el-icon-plus" })]) : null, p = h("div", { class: ["el-tabs__header", "is-" + u] }, [c, h(zp, { currentName: o, editable: r, type: t, panes: i, stretch: d, ref: "nav$", onTabClick: l, onTabRemove: a })]), h2 = h("div", { class: "el-tabs__content" }, (e = this.$slots) === null || e === void 0 ? void 0 : e.default());
  return h("div", { class: { "el-tabs": true, "el-tabs--card": t === "card", ["el-tabs--" + u]: true, "el-tabs--border-card": t === "border-card" } }, u !== "bottom" ? [p, h2] : [h2, p]);
} });
Lp.__file = "packages/tabs/src/tabs.vue", Lp.install = (e) => {
  e.component(Lp.name, Lp);
};
var Fp = Lp;
var Rp = (e) => {
  const t = (e || "").split(":");
  if (t.length >= 2) {
    return { hours: parseInt(t[0], 10), minutes: parseInt(t[1], 10) };
  }
  return null;
};
var $p = (e, t) => {
  const l = Rp(e), a = Rp(t), n = l.minutes + 60 * l.hours, o = a.minutes + 60 * a.hours;
  return n === o ? 0 : n > o ? 1 : -1;
};
var Hp = (e, t) => {
  const l = Rp(e), a = Rp(t), n = { hours: l.hours, minutes: l.minutes };
  return n.minutes += a.minutes, n.hours += a.hours, n.hours += Math.floor(n.minutes / 60), n.minutes = n.minutes % 60, ((e2) => (e2.hours < 10 ? "0" + e2.hours : e2.hours) + ":" + (e2.minutes < 10 ? "0" + e2.minutes : e2.minutes))(n);
};
var Wp = defineComponent({ name: "ElTimeSelect", components: { ElSelect: nd, ElOption: od }, model: { prop: "value", event: "change" }, props: { modelValue: String, editable: { type: Boolean, default: true }, clearable: { type: Boolean, default: true }, size: { type: String, default: "", validator: (e) => !e || ["medium", "small", "mini"].indexOf(e) !== -1 }, placeholder: { type: String, default: "" }, start: { type: String, default: "09:00" }, end: { type: String, default: "18:00" }, step: { type: String, default: "00:30" }, minTime: { type: String, default: "" }, maxTime: { type: String, default: "" }, name: { type: String, default: "" }, prefixIcon: { type: String, default: "el-icon-time" }, clearIcon: { type: String, default: "el-icon-circle-close" } }, emits: ["change", "blur", "focus", "update:modelValue"], setup: (e) => ({ value: computed(() => e.modelValue), items: computed(() => {
  const t = [];
  if (e.start && e.end && e.step) {
    let l = e.start;
    for (; $p(l, e.end) <= 0; )
      t.push({ value: l, disabled: $p(l, e.minTime || "-1:-1") <= 0 || $p(l, e.maxTime || "100:100") >= 0 }), l = Hp(l, e.step);
  }
  return t;
}) }) });
Wp.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-option"), r = resolveComponent("el-select");
  return openBlock(), createBlock(r, { "model-value": e.value, disabled: !e.editable, clearable: e.clearable, "clear-icon": e.clearIcon, size: e.size, placeholder: e.placeholder, "default-first-option": "", filterable: "", "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.$emit("update:modelValue", t2)), onChange: t[2] || (t[2] = (t2) => e.$emit("change", t2)), onBlur: t[3] || (t[3] = (t2) => e.$emit("blur", t2)), onFocus: t[4] || (t[4] = (t2) => e.$emit("focus", t2)) }, { prefix: withCtx(() => [createVNode("i", { class: "el-input__icon " + e.prefixIcon }, null, 2)]), default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.items, (e2) => (openBlock(), createBlock(i, { key: e2.value, label: e2.value, value: e2.value, disabled: e2.disabled }, null, 8, ["label", "value", "disabled"]))), 128))]), _: 1 }, 8, ["model-value", "disabled", "clearable", "clear-icon", "size", "placeholder"]);
}, Wp.__file = "packages/time-select/src/time-select.vue", Wp.install = (e) => {
  e.component(Wp.name, Wp);
};
var jp = Wp;
var Kp = defineComponent({ name: "ElTimeline", setup: (e, t) => (provide("timeline", t), () => {
  var e2, l;
  return h("ul", { class: { "el-timeline": true } }, (l = (e2 = t.slots).default) === null || l === void 0 ? void 0 : l.call(e2));
}) });
Kp.__file = "packages/timeline/src/index.vue", Kp.install = (e) => {
  e.component(Kp.name, Kp);
};
var Yp = Kp;
var qp = defineComponent({ name: "ElTimelineItem", props: { timestamp: { type: String, default: "" }, hideTimestamp: { type: Boolean, default: false }, placement: { type: String, default: "bottom" }, type: { type: String, default: "" }, color: { type: String, default: "" }, size: { type: String, default: "normal" }, icon: { type: String, default: "" } }, setup() {
  inject("timeline");
} });
var Up = { class: "el-timeline-item" };
var Gp = createVNode("div", { class: "el-timeline-item__tail" }, null, -1);
var Xp = { key: 1, class: "el-timeline-item__dot" };
var Zp = { class: "el-timeline-item__wrapper" };
var Qp = { key: 0, class: "el-timeline-item__timestamp is-top" };
var Jp = { class: "el-timeline-item__content" };
var eh = { key: 1, class: "el-timeline-item__timestamp is-bottom" };
qp.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("li", Up, [Gp, e.$slots.dot ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", { key: 0, class: ["el-timeline-item__node", ["el-timeline-item__node--" + (e.size || ""), "el-timeline-item__node--" + (e.type || "")]], style: { backgroundColor: e.color } }, [e.icon ? (openBlock(), createBlock("i", { key: 0, class: ["el-timeline-item__icon", e.icon] }, null, 2)) : createCommentVNode("v-if", true)], 6)), e.$slots.dot ? (openBlock(), createBlock("div", Xp, [renderSlot(e.$slots, "dot")])) : createCommentVNode("v-if", true), createVNode("div", Zp, [e.hideTimestamp || e.placement !== "top" ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", Qp, toDisplayString(e.timestamp), 1)), createVNode("div", Jp, [renderSlot(e.$slots, "default")]), e.hideTimestamp || e.placement !== "bottom" ? createCommentVNode("v-if", true) : (openBlock(), createBlock("div", eh, toDisplayString(e.timestamp), 1))])]);
}, qp.__file = "packages/timeline/src/item.vue", qp.install = (e) => {
  e.component(qp.name, qp);
};
var th = qp;
var lh = defineComponent({ name: "ElTransferPanel", components: { ElCheckboxGroup: ko, ElCheckbox: Dn, ElInput: gl, OptionContent: ({ option: e }) => e }, props: { data: { type: Array, default: () => [] }, optionRender: Function, placeholder: String, title: String, filterable: Boolean, format: Object, filterMethod: Function, defaultChecked: Array, props: Object }, emits: ["checked-change"], setup(e, { emit: t, slots: l }) {
  const i = reactive({ checked: [], allChecked: false, query: "", inputHover: false, checkChangeByUser: true }), { labelProp: r, keyProp: s, disabledProp: u, filteredData: d, checkedSummary: c, isIndeterminate: p, handleAllCheckedChange: h2 } = ((e2, t2, l2) => {
    const a = computed(() => e2.props.label || "label"), i2 = computed(() => e2.props.key || "key"), r2 = computed(() => e2.props.disabled || "disabled"), s2 = computed(() => e2.data.filter((l3) => typeof e2.filterMethod == "function" ? e2.filterMethod(t2.query, l3) : (l3[a.value] || l3[i2.value].toString()).toLowerCase().includes(t2.query.toLowerCase()))), u2 = computed(() => s2.value.filter((e3) => !e3[r2.value])), d2 = computed(() => {
      const l3 = t2.checked.length, a2 = e2.data.length, { noChecked: n, hasChecked: o } = e2.format;
      return n && o ? l3 > 0 ? o.replace(/\${checked}/g, l3.toString()).replace(/\${total}/g, a2.toString()) : n.replace(/\${total}/g, a2.toString()) : `${l3}/${a2}`;
    }), c2 = computed(() => {
      const e3 = t2.checked.length;
      return e3 > 0 && e3 < u2.value.length;
    }), p2 = () => {
      const e3 = u2.value.map((e4) => e4[i2.value]);
      t2.allChecked = e3.length > 0 && e3.every((e4) => t2.checked.includes(e4));
    };
    return watch(() => t2.checked, (e3, a2) => {
      if (p2(), t2.checkChangeByUser) {
        const t3 = e3.concat(a2).filter((t4) => !e3.includes(t4) || !a2.includes(t4));
        l2("checked-change", e3, t3);
      } else
        l2("checked-change", e3), t2.checkChangeByUser = true;
    }), watch(u2, () => {
      p2();
    }), watch(() => e2.data, () => {
      const e3 = [], l3 = s2.value.map((e4) => e4[i2.value]);
      t2.checked.forEach((t3) => {
        l3.includes(t3) && e3.push(t3);
      }), t2.checkChangeByUser = false, t2.checked = e3;
    }), watch(() => e2.defaultChecked, (e3, l3) => {
      if (l3 && e3.length === l3.length && e3.every((e4) => l3.includes(e4)))
        return;
      const a2 = [], n = u2.value.map((e4) => e4[i2.value]);
      e3.forEach((e4) => {
        n.includes(e4) && a2.push(e4);
      }), t2.checkChangeByUser = false, t2.checked = a2;
    }, { immediate: true }), { labelProp: a, keyProp: i2, disabledProp: r2, filteredData: s2, checkableData: u2, checkedSummary: d2, isIndeterminate: c2, updateAllChecked: p2, handleAllCheckedChange: (e3) => {
      t2.checked = e3 ? u2.value.map((e4) => e4[i2.value]) : [];
    } };
  })(e, i, t), v = computed(() => i.query.length > 0 && d.value.length === 0), m = computed(() => i.query.length > 0 && i.inputHover ? "circle-close" : "search"), f = computed(() => !!l.default()[0].children.length), { checked: g, allChecked: b, query: y, inputHover: k, checkChangeByUser: x } = toRefs(i);
  return { labelProp: r, keyProp: s, disabledProp: u, filteredData: d, checkedSummary: c, isIndeterminate: p, handleAllCheckedChange: h2, checked: g, allChecked: b, query: y, inputHover: k, checkChangeByUser: x, hasNoMatch: v, inputIcon: m, hasFooter: f, clearQuery: () => {
    m.value === "circle-close" && (i.query = "");
  }, t: Ca };
} });
var ah = { class: "el-transfer-panel" };
var nh = { class: "el-transfer-panel__header" };
var oh = { key: 0, class: "el-transfer-panel__footer" };
lh.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-checkbox"), r = resolveComponent("el-input"), p = resolveComponent("option-content"), y = resolveComponent("el-checkbox-group");
  return openBlock(), createBlock("div", ah, [createVNode("p", nh, [createVNode(i, { modelValue: e.allChecked, "onUpdate:modelValue": t[1] || (t[1] = (t2) => e.allChecked = t2), indeterminate: e.isIndeterminate, onChange: e.handleAllCheckedChange }, { default: withCtx(() => [createTextVNode(toDisplayString(e.title) + " ", 1), createVNode("span", null, toDisplayString(e.checkedSummary), 1)]), _: 1 }, 8, ["modelValue", "indeterminate", "onChange"])]), createVNode("div", { class: ["el-transfer-panel__body", e.hasFooter ? "is-with-footer" : ""] }, [e.filterable ? (openBlock(), createBlock(r, { key: 0, modelValue: e.query, "onUpdate:modelValue": t[3] || (t[3] = (t2) => e.query = t2), class: "el-transfer-panel__filter", size: "small", placeholder: e.placeholder, onMouseenter: t[4] || (t[4] = (t2) => e.inputHover = true), onMouseleave: t[5] || (t[5] = (t2) => e.inputHover = false) }, { prefix: withCtx(() => [createVNode("i", { class: ["el-input__icon", "el-icon-" + e.inputIcon], onClick: t[2] || (t[2] = (...t2) => e.clearQuery && e.clearQuery(...t2)) }, null, 2)]), _: 1 }, 8, ["modelValue", "placeholder"])) : createCommentVNode("v-if", true), withDirectives(createVNode(y, { modelValue: e.checked, "onUpdate:modelValue": t[6] || (t[6] = (t2) => e.checked = t2), class: [{ "is-filterable": e.filterable }, "el-transfer-panel__list"] }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.filteredData, (t2) => (openBlock(), createBlock(i, { key: t2[e.keyProp], class: "el-transfer-panel__item", label: t2[e.keyProp], disabled: t2[e.disabledProp] }, { default: withCtx(() => [createVNode(p, { option: e.optionRender(t2) }, null, 8, ["option"])]), _: 2 }, 1032, ["label", "disabled"]))), 128))]), _: 1 }, 8, ["modelValue", "class"]), [[vShow, !e.hasNoMatch && e.data.length > 0]]), withDirectives(createVNode("p", { class: "el-transfer-panel__empty" }, toDisplayString(e.hasNoMatch ? e.t("el.transfer.noMatch") : e.t("el.transfer.noData")), 513), [[vShow, e.hasNoMatch || e.data.length === 0]])], 2), e.hasFooter ? (openBlock(), createBlock("p", oh, [renderSlot(e.$slots, "default")])) : createCommentVNode("v-if", true)]);
}, lh.__file = "packages/transfer/src/transfer-panel.vue";
var ih = "change";
var rh = defineComponent({ name: "ElTransfer", components: { TransferPanel: lh, ElButton: ma }, props: { data: { type: Array, default: () => [] }, titles: { type: Array, default: () => [] }, buttonTexts: { type: Array, default: () => [] }, filterPlaceholder: { type: String, default: "" }, filterMethod: Function, leftDefaultChecked: { type: Array, default: () => [] }, rightDefaultChecked: { type: Array, default: () => [] }, renderContent: Function, modelValue: { type: Array, default: () => [] }, format: { type: Object, default: () => ({}) }, filterable: { type: Boolean, default: false }, props: { type: Object, default: () => ({ label: "label", key: "key", disabled: "disabled" }) }, targetOrder: { type: String, default: "original", validator: (e) => ["original", "push", "unshift"].includes(e) } }, emits: [Gt, ih, "left-check-change", "right-check-change"], setup(e, { emit: t, slots: i }) {
  const r = inject("elFormItem", {}), s = reactive({ leftChecked: [], rightChecked: [] }), { propsKey: u, sourceData: d, targetData: c } = ((e2) => {
    const t2 = computed(() => e2.props.key), l = computed(() => e2.data.reduce((e3, l2) => (e3[l2[t2.value]] = l2) && e3, {})), a = computed(() => e2.data.filter((l2) => !e2.modelValue.includes(l2[t2.value]))), o = computed(() => e2.targetOrder === "original" ? e2.data.filter((l2) => e2.modelValue.includes(l2[t2.value])) : e2.modelValue.reduce((e3, t3) => {
      const a2 = l.value[t3];
      return a2 && e3.push(a2), e3;
    }, []));
    return { propsKey: t2, sourceData: a, targetData: o };
  })(e), { onSourceCheckedChange: p, onTargetCheckedChange: h2 } = ((e2, t2) => ({ onSourceCheckedChange: (l, a) => {
    e2.leftChecked = l, a !== void 0 && t2("left-check-change", l, a);
  }, onTargetCheckedChange: (l, a) => {
    e2.rightChecked = l, a !== void 0 && t2("right-check-change", l, a);
  } }))(s, t), { addToLeft: v, addToRight: m } = ((e2, t2, l, a) => {
    const n = (e3, t3, l2) => {
      a(Gt, e3), a(ih, e3, t3, l2);
    };
    return { addToLeft: () => {
      const l2 = e2.modelValue.slice();
      t2.rightChecked.forEach((e3) => {
        const t3 = l2.indexOf(e3);
        t3 > -1 && l2.splice(t3, 1);
      }), n(l2, "left", t2.rightChecked);
    }, addToRight: () => {
      let a2 = e2.modelValue.slice();
      const o = e2.data.filter((a3) => {
        const n2 = a3[l.value];
        return t2.leftChecked.includes(n2) && !e2.modelValue.includes(n2);
      }).map((e3) => e3[l.value]);
      a2 = e2.targetOrder === "unshift" ? o.concat(a2) : a2.concat(o), n(a2, "right", t2.leftChecked);
    } };
  })(e, s, u, t), f = ref(null), g = ref(null), b = computed(() => e.buttonTexts.length === 2), y = computed(() => e.titles[0] || Ca("el.transfer.titles.0")), k = computed(() => e.titles[1] || Ca("el.transfer.titles.1")), x = computed(() => e.filterPlaceholder || Ca("el.transfer.filterPlaceholder"));
  watch(() => e.modelValue, (e2) => {
    var t2;
    (t2 = r.formItemMitt) === null || t2 === void 0 || t2.emit("el.form.change", e2);
  });
  const C = computed(() => (t2) => e.renderContent ? e.renderContent(h, t2) : i.default ? i.default({ option: t2 }) : h("span", t2[e.props.label] || t2[e.props.key]));
  return Object.assign(Object.assign({ sourceData: d, targetData: c, onSourceCheckedChange: p, onTargetCheckedChange: h2, addToLeft: v, addToRight: m }, toRefs(s)), { hasButtonTexts: b, leftPanelTitle: y, rightPanelTitle: k, panelFilterPlaceholder: x, clearQuery: (e2) => {
    e2 === "left" ? f.value.query = "" : e2 === "right" && (g.value.query = "");
  }, optionRender: C });
} });
var sh = { class: "el-transfer" };
var uh = { class: "el-transfer__buttons" };
var dh = createVNode("i", { class: "el-icon-arrow-left" }, null, -1);
var ch = { key: 0 };
var ph = { key: 0 };
var hh = createVNode("i", { class: "el-icon-arrow-right" }, null, -1);
rh.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("transfer-panel"), r = resolveComponent("el-button");
  return openBlock(), createBlock("div", sh, [createVNode(i, { ref: "leftPanel", data: e.sourceData, "option-render": e.optionRender, placeholder: e.panelFilterPlaceholder, title: e.leftPanelTitle, filterable: e.filterable, format: e.format, "filter-method": e.filterMethod, "default-checked": e.leftDefaultChecked, props: e.props, onCheckedChange: e.onSourceCheckedChange }, { default: withCtx(() => [renderSlot(e.$slots, "left-footer")]), _: 3 }, 8, ["data", "option-render", "placeholder", "title", "filterable", "format", "filter-method", "default-checked", "props", "onCheckedChange"]), createVNode("div", uh, [createVNode(r, { type: "primary", class: ["el-transfer__button", e.hasButtonTexts ? "is-with-texts" : ""], disabled: e.rightChecked.length === 0, onClick: e.addToLeft }, { default: withCtx(() => [dh, e.buttonTexts[0] !== void 0 ? (openBlock(), createBlock("span", ch, toDisplayString(e.buttonTexts[0]), 1)) : createCommentVNode("v-if", true)]), _: 1 }, 8, ["class", "disabled", "onClick"]), createVNode(r, { type: "primary", class: ["el-transfer__button", e.hasButtonTexts ? "is-with-texts" : ""], disabled: e.leftChecked.length === 0, onClick: e.addToRight }, { default: withCtx(() => [e.buttonTexts[1] !== void 0 ? (openBlock(), createBlock("span", ph, toDisplayString(e.buttonTexts[1]), 1)) : createCommentVNode("v-if", true), hh]), _: 1 }, 8, ["class", "disabled", "onClick"])]), createVNode(i, { ref: "rightPanel", data: e.targetData, "option-render": e.optionRender, placeholder: e.panelFilterPlaceholder, filterable: e.filterable, format: e.format, "filter-method": e.filterMethod, title: e.rightPanelTitle, "default-checked": e.rightDefaultChecked, props: e.props, onCheckedChange: e.onTargetCheckedChange }, { default: withCtx(() => [renderSlot(e.$slots, "right-footer")]), _: 3 }, 8, ["data", "option-render", "placeholder", "filterable", "format", "filter-method", "title", "default-checked", "props", "onCheckedChange"])]);
}, rh.__file = "packages/transfer/src/index.vue", rh.install = (e) => {
  e.component(rh.name, rh);
};
var vh = rh;
var mh = "$treeNodeId";
var fh = function(e, t) {
  t && !t[mh] && Object.defineProperty(t, mh, { value: e.id, enumerable: false, configurable: false, writable: false });
};
var gh = function(e, t) {
  return e ? t[e] : t[mh];
};
var bh = (e) => {
  let t = true, l = true, a = true;
  for (let n = 0, o = e.length; n < o; n++) {
    const o2 = e[n];
    (o2.checked !== true || o2.indeterminate) && (t = false, o2.disabled || (a = false)), (o2.checked !== false || o2.indeterminate) && (l = false);
  }
  return { all: t, none: l, allWithoutDisable: a, half: !t && !l };
};
var yh = function(e) {
  if (e.childNodes.length === 0)
    return;
  const { all: t, none: l, half: a } = bh(e.childNodes);
  t ? (e.checked = true, e.indeterminate = false) : a ? (e.checked = false, e.indeterminate = true) : l && (e.checked = false, e.indeterminate = false);
  const n = e.parent;
  n && n.level !== 0 && (e.store.checkStrictly || yh(n));
};
var kh = function(e, t) {
  const l = e.store.props, a = e.data || {}, n = l[t];
  if (typeof n == "function")
    return n(a, e);
  if (typeof n == "string")
    return a[n];
  if (n === void 0) {
    const e2 = a[t];
    return e2 === void 0 ? "" : e2;
  }
};
var xh = 0;
var Ch = class {
  constructor(e) {
    this.id = xh++, this.text = null, this.checked = false, this.indeterminate = false, this.data = null, this.expanded = false, this.parent = null, this.visible = true, this.isCurrent = false, this.canFocus = false;
    for (const t in e)
      Se(e, t) && (this[t] = e[t]);
    this.level = 0, this.loaded = false, this.childNodes = [], this.loading = false, this.parent && (this.level = this.parent.level + 1);
  }
  initialize() {
    const e = this.store;
    if (!e)
      throw new Error("[Node]store is required!");
    e.registerNode(this);
    const t = e.props;
    if (t && t.isLeaf !== void 0) {
      const e2 = kh(this, "isLeaf");
      typeof e2 == "boolean" && (this.isLeafByUser = e2);
    }
    if (e.lazy !== true && this.data ? (this.setData(this.data), e.defaultExpandAll && (this.expanded = true, this.canFocus = true)) : this.level > 0 && e.lazy && e.defaultExpandAll && this.expand(), Array.isArray(this.data) || fh(this, this.data), !this.data)
      return;
    const l = e.defaultExpandedKeys, a = e.key;
    a && l && l.indexOf(this.key) !== -1 && this.expand(null, e.autoExpandParent), a && e.currentNodeKey !== void 0 && this.key === e.currentNodeKey && (e.currentNode = this, e.currentNode.isCurrent = true), e.lazy && e._initDefaultCheckedNode(this), this.updateLeafState(), !this.parent || this.level !== 1 && this.parent.expanded !== true || (this.canFocus = true);
  }
  setData(e) {
    let t;
    Array.isArray(e) || fh(this, e), this.data = e, this.childNodes = [], t = this.level === 0 && this.data instanceof Array ? this.data : kh(this, "children") || [];
    for (let e2 = 0, l = t.length; e2 < l; e2++)
      this.insertChild({ data: t[e2] });
  }
  get label() {
    return kh(this, "label");
  }
  get key() {
    const e = this.store.key;
    return this.data ? this.data[e] : null;
  }
  get disabled() {
    return kh(this, "disabled");
  }
  get nextSibling() {
    const e = this.parent;
    if (e) {
      const t = e.childNodes.indexOf(this);
      if (t > -1)
        return e.childNodes[t + 1];
    }
    return null;
  }
  get previousSibling() {
    const e = this.parent;
    if (e) {
      const t = e.childNodes.indexOf(this);
      if (t > -1)
        return t > 0 ? e.childNodes[t - 1] : null;
    }
    return null;
  }
  contains(e, t = true) {
    return (this.childNodes || []).some((l) => l === e || t && l.contains(e));
  }
  remove() {
    const e = this.parent;
    e && e.removeChild(this);
  }
  insertChild(e, t, l) {
    if (!e)
      throw new Error("insertChild error: child is required.");
    if (!(e instanceof Ch)) {
      if (!l) {
        const l2 = this.getChildren(true);
        l2.indexOf(e.data) === -1 && (t === void 0 || t < 0 ? l2.push(e.data) : l2.splice(t, 0, e.data));
      }
      Object.assign(e, { parent: this, store: this.store }), (e = reactive(new Ch(e))) instanceof Ch && e.initialize();
    }
    e.level = this.level + 1, t === void 0 || t < 0 ? this.childNodes.push(e) : this.childNodes.splice(t, 0, e), this.updateLeafState();
  }
  insertBefore(e, t) {
    let l;
    t && (l = this.childNodes.indexOf(t)), this.insertChild(e, l);
  }
  insertAfter(e, t) {
    let l;
    t && (l = this.childNodes.indexOf(t), l !== -1 && (l += 1)), this.insertChild(e, l);
  }
  removeChild(e) {
    const t = this.getChildren() || [], l = t.indexOf(e.data);
    l > -1 && t.splice(l, 1);
    const a = this.childNodes.indexOf(e);
    a > -1 && (this.store && this.store.deregisterNode(e), e.parent = null, this.childNodes.splice(a, 1)), this.updateLeafState();
  }
  removeChildByData(e) {
    let t = null;
    for (let l = 0; l < this.childNodes.length; l++)
      if (this.childNodes[l].data === e) {
        t = this.childNodes[l];
        break;
      }
    t && this.removeChild(t);
  }
  expand(e, t) {
    const l = () => {
      if (t) {
        let e2 = this.parent;
        for (; e2.level > 0; )
          e2.expanded = true, e2 = e2.parent;
      }
      this.expanded = true, e && e(), this.childNodes.forEach((e2) => {
        e2.canFocus = true;
      });
    };
    this.shouldLoadData() ? this.loadData((e2) => {
      Array.isArray(e2) && (this.checked ? this.setChecked(true, true) : this.store.checkStrictly || yh(this), l());
    }) : l();
  }
  doCreateChildren(e, t = {}) {
    e.forEach((e2) => {
      this.insertChild(Object.assign({ data: e2 }, t), void 0, true);
    });
  }
  collapse() {
    this.expanded = false, this.childNodes.forEach((e) => {
      e.canFocus = false;
    });
  }
  shouldLoadData() {
    return this.store.lazy === true && this.store.load && !this.loaded;
  }
  updateLeafState() {
    if (this.store.lazy === true && this.loaded !== true && this.isLeafByUser !== void 0)
      return void (this.isLeaf = this.isLeafByUser);
    const e = this.childNodes;
    !this.store.lazy || this.store.lazy === true && this.loaded === true ? this.isLeaf = !e || e.length === 0 : this.isLeaf = false;
  }
  setChecked(e, t, l, a) {
    if (this.indeterminate = e === "half", this.checked = e === true, this.store.checkStrictly)
      return;
    if (!this.shouldLoadData() || this.store.checkDescendants) {
      const { all: l2, allWithoutDisable: n2 } = bh(this.childNodes);
      this.isLeaf || l2 || !n2 || (this.checked = false, e = false);
      const o = () => {
        if (t) {
          const l3 = this.childNodes;
          for (let n4 = 0, o3 = l3.length; n4 < o3; n4++) {
            const o4 = l3[n4];
            a = a || e !== false;
            const i = o4.disabled ? o4.checked : a;
            o4.setChecked(i, t, true, a);
          }
          const { half: n3, all: o2 } = bh(l3);
          o2 || (this.checked = o2, this.indeterminate = n3);
        }
      };
      if (this.shouldLoadData())
        return void this.loadData(() => {
          o(), yh(this);
        }, { checked: e !== false });
      o();
    }
    const n = this.parent;
    n && n.level !== 0 && (l || yh(n));
  }
  getChildren(e = false) {
    if (this.level === 0)
      return this.data;
    const t = this.data;
    if (!t)
      return null;
    const l = this.store.props;
    let a = "children";
    return l && (a = l.children || "children"), t[a] === void 0 && (t[a] = null), e && !t[a] && (t[a] = []), t[a];
  }
  updateChildren() {
    const e = this.getChildren() || [], t = this.childNodes.map((e2) => e2.data), l = {}, a = [];
    e.forEach((e2, n) => {
      const o = e2[mh];
      !!o && t.findIndex((e3) => e3[mh] === o) >= 0 ? l[o] = { index: n, data: e2 } : a.push({ index: n, data: e2 });
    }), this.store.lazy || t.forEach((e2) => {
      l[e2[mh]] || this.removeChildByData(e2);
    }), a.forEach(({ index: e2, data: t2 }) => {
      this.insertChild({ data: t2 }, e2);
    }), this.updateLeafState();
  }
  loadData(e, t = {}) {
    if (this.store.lazy !== true || !this.store.load || this.loaded || this.loading && !Object.keys(t).length)
      e && e.call(this);
    else {
      this.loading = true;
      const l = (l2) => {
        this.loaded = true, this.loading = false, this.childNodes = [], this.doCreateChildren(l2, t), this.updateLeafState(), e && e.call(this, l2);
      };
      this.store.load(this, l);
    }
  }
};
var wh = class {
  constructor(e) {
    this.currentNode = null, this.currentNodeKey = null;
    for (const t in e)
      Se(e, t) && (this[t] = e[t]);
    this.nodesMap = {};
  }
  initialize() {
    if (this.root = new Ch({ data: this.data, store: this }), this.root.initialize(), this.lazy && this.load) {
      (0, this.load)(this.root, (e) => {
        this.root.doCreateChildren(e), this._initDefaultCheckedNodes();
      });
    } else
      this._initDefaultCheckedNodes();
  }
  filter(e) {
    const t = this.filterNodeMethod, l = this.lazy, a = function(n) {
      const o = n.root ? n.root.childNodes : n.childNodes;
      if (o.forEach((l2) => {
        l2.visible = t.call(l2, e, l2.data, l2), a(l2);
      }), !n.visible && o.length) {
        let e2 = true;
        e2 = !o.some((e3) => e3.visible), n.root ? n.root.visible = e2 === false : n.visible = e2 === false;
      }
      e && (!n.visible || n.isLeaf || l || n.expand());
    };
    a(this);
  }
  setData(e) {
    e !== this.root.data ? (this.root.setData(e), this._initDefaultCheckedNodes()) : this.root.updateChildren();
  }
  getNode(e) {
    if (e instanceof Ch)
      return e;
    const t = typeof e != "object" ? e : gh(this.key, e);
    return this.nodesMap[t] || null;
  }
  insertBefore(e, t) {
    const l = this.getNode(t);
    l.parent.insertBefore({ data: e }, l);
  }
  insertAfter(e, t) {
    const l = this.getNode(t);
    l.parent.insertAfter({ data: e }, l);
  }
  remove(e) {
    const t = this.getNode(e);
    t && t.parent && (t === this.currentNode && (this.currentNode = null), t.parent.removeChild(t));
  }
  append(e, t) {
    const l = t ? this.getNode(t) : this.root;
    l && l.insertChild({ data: e });
  }
  _initDefaultCheckedNodes() {
    const e = this.defaultCheckedKeys || [], t = this.nodesMap;
    e.forEach((e2) => {
      const l = t[e2];
      l && l.setChecked(true, !this.checkStrictly);
    });
  }
  _initDefaultCheckedNode(e) {
    (this.defaultCheckedKeys || []).indexOf(e.key) !== -1 && e.setChecked(true, !this.checkStrictly);
  }
  setDefaultCheckedKey(e) {
    e !== this.defaultCheckedKeys && (this.defaultCheckedKeys = e, this._initDefaultCheckedNodes());
  }
  registerNode(e) {
    const t = this.key;
    if (e && e.data)
      if (t) {
        e.key !== void 0 && (this.nodesMap[e.key] = e);
      } else
        this.nodesMap[e.id] = e;
  }
  deregisterNode(e) {
    this.key && e && e.data && (e.childNodes.forEach((e2) => {
      this.deregisterNode(e2);
    }), delete this.nodesMap[e.key]);
  }
  getCheckedNodes(e = false, t = false) {
    const l = [], a = function(n) {
      (n.root ? n.root.childNodes : n.childNodes).forEach((n2) => {
        (n2.checked || t && n2.indeterminate) && (!e || e && n2.isLeaf) && l.push(n2.data), a(n2);
      });
    };
    return a(this), l;
  }
  getCheckedKeys(e = false) {
    return this.getCheckedNodes(e).map((e2) => (e2 || {})[this.key]);
  }
  getHalfCheckedNodes() {
    const e = [], t = function(l) {
      (l.root ? l.root.childNodes : l.childNodes).forEach((l2) => {
        l2.indeterminate && e.push(l2.data), t(l2);
      });
    };
    return t(this), e;
  }
  getHalfCheckedKeys() {
    return this.getHalfCheckedNodes().map((e) => (e || {})[this.key]);
  }
  _getAllNodes() {
    const e = [], t = this.nodesMap;
    for (const l in t)
      Se(t, l) && e.push(t[l]);
    return e;
  }
  updateChildren(e, t) {
    const l = this.nodesMap[e];
    if (!l)
      return;
    const a = l.childNodes;
    for (let e2 = a.length - 1; e2 >= 0; e2--) {
      const t2 = a[e2];
      this.remove(t2.data);
    }
    for (let e2 = 0, a2 = t.length; e2 < a2; e2++) {
      const a3 = t[e2];
      this.append(a3, l.data);
    }
  }
  _setCheckedKeys(e, t = false, l) {
    const a = this._getAllNodes().sort((e2, t2) => t2.level - e2.level), n = Object.create(null), o = Object.keys(l);
    a.forEach((e2) => e2.setChecked(false, false));
    for (let l2 = 0, i = a.length; l2 < i; l2++) {
      const i2 = a[l2], r = i2.data[e].toString();
      if (!(o.indexOf(r) > -1)) {
        i2.checked && !n[r] && i2.setChecked(false, false);
        continue;
      }
      let s = i2.parent;
      for (; s && s.level > 0; )
        n[s.data[e]] = true, s = s.parent;
      if (i2.isLeaf || this.checkStrictly)
        i2.setChecked(true, false);
      else if (i2.setChecked(true, true), t) {
        i2.setChecked(false, false);
        const e2 = function(t2) {
          t2.childNodes.forEach((t3) => {
            t3.isLeaf || t3.setChecked(false, false), e2(t3);
          });
        };
        e2(i2);
      }
    }
  }
  setCheckedNodes(e, t = false) {
    const l = this.key, a = {};
    e.forEach((e2) => {
      a[(e2 || {})[l]] = true;
    }), this._setCheckedKeys(l, t, a);
  }
  setCheckedKeys(e, t = false) {
    this.defaultCheckedKeys = e;
    const l = this.key, a = {};
    e.forEach((e2) => {
      a[e2] = true;
    }), this._setCheckedKeys(l, t, a);
  }
  setDefaultExpandedKeys(e) {
    e = e || [], this.defaultExpandedKeys = e, e.forEach((e2) => {
      const t = this.getNode(e2);
      t && t.expand(null, this.autoExpandParent);
    });
  }
  setChecked(e, t, l) {
    const a = this.getNode(e);
    a && a.setChecked(!!t, l);
  }
  getCurrentNode() {
    return this.currentNode;
  }
  setCurrentNode(e) {
    const t = this.currentNode;
    t && (t.isCurrent = false), this.currentNode = e, this.currentNode.isCurrent = true;
  }
  setUserCurrentNode(e, t = true) {
    const l = e[this.key], a = this.nodesMap[l];
    this.setCurrentNode(a), t && this.currentNode.level > 1 && this.currentNode.parent.expand(null, true);
  }
  setCurrentNodeKey(e, t = true) {
    if (e == null)
      return this.currentNode && (this.currentNode.isCurrent = false), void (this.currentNode = null);
    const l = this.getNode(e);
    l && (this.setCurrentNode(l), t && this.currentNode.level > 1 && this.currentNode.parent.expand(null, true));
  }
};
var Sh = defineComponent({ name: "ElTreeNodeContent", props: { node: { type: Object, required: true }, renderContent: Function }, setup(e) {
  const t = inject("NodeInstance"), l = inject("RootTree");
  return () => {
    const a = e.node, { data: n, store: o } = a;
    return e.renderContent ? e.renderContent(h, { _self: t, node: a, data: n, store: o }) : l.ctx.slots.default ? l.ctx.slots.default({ node: a, data: n }) : h("span", { class: "el-tree-node__label" }, [a.label]);
  };
} });
function _h(e) {
  const t = inject("TreeNodeMap", null), l = { treeNodeExpand: (t2) => {
    e.node !== t2 && e.node.collapse();
  }, children: [] };
  return t && t.children.push(l), provide("TreeNodeMap", l), { broadcastExpanded: (t2) => {
    if (e.accordion)
      for (const e2 of l.children)
        e2.treeNodeExpand(t2);
  } };
}
Sh.__file = "packages/tree/src/tree-node-content.vue";
var Eh = defineComponent({ name: "ElTreeNode", components: { ElCollapseTransition: Eo, ElCheckbox: Dn, NodeContent: Sh }, props: { node: { type: Ch, default: () => ({}) }, props: { type: Object, default: () => ({}) }, renderContent: Function, renderAfterExpand: Boolean, showCheckbox: { type: Boolean, default: false } }, emits: ["node-expand"], setup(t, a) {
  const { broadcastExpanded: n } = _h(t), i = inject("RootTree"), r = ref(false), s = ref(false), u = ref(null), d = ref(null), c = ref(null), { emitter: p } = { emitter: inject("DragNodeEmitter") }, h2 = getCurrentInstance();
  provide("NodeInstance", h2), i || console.warn("Can not find node's tree."), t.node.expanded && (r.value = true, s.value = true);
  const v = i.props.children || "children";
  watch(() => {
    const e = t.node.data[v];
    return e && [...e];
  }, () => {
    t.node.updateChildren();
  }), watch(() => t.node.indeterminate, (e) => {
    m(t.node.checked, e);
  }), watch(() => t.node.checked, (e) => {
    m(e, t.node.indeterminate);
  }), watch(() => t.node.expanded, (e) => {
    nextTick(() => r.value = e), e && (s.value = true);
  });
  const m = (e, l) => {
    u.value === e && d.value === l || i.ctx.emit("check-change", t.node.data, e, l), u.value = e, d.value = l;
  }, f = () => {
    t.node.isLeaf || (r.value ? (i.ctx.emit("node-collapse", t.node.data, t.node, h2), t.node.collapse()) : (t.node.expand(), a.emit("node-expand", t.node.data, t.node, h2)));
  }, g = (e, l) => {
    t.node.setChecked(l.target.checked, !i.props.checkStrictly), nextTick(() => {
      const e2 = i.store.value;
      i.ctx.emit("check", t.node.data, { checkedNodes: e2.getCheckedNodes(), checkedKeys: e2.getCheckedKeys(), halfCheckedNodes: e2.getHalfCheckedNodes(), halfCheckedKeys: e2.getHalfCheckedKeys() });
    });
  };
  return { node$: c, tree: i, expanded: r, childNodeRendered: s, oldChecked: u, oldIndeterminate: d, emitter: p, parent, getNodeKey: (e) => gh(i.props.nodeKey, e.data), handleSelectChange: m, handleClick: () => {
    const e = i.store.value;
    e.setCurrentNode(t.node), i.ctx.emit("current-change", e.currentNode ? e.currentNode.data : null, e.currentNode), i.currentNode.value = t.node, i.props.expandOnClickNode && f(), i.props.checkOnClickNode && !t.node.disabled && g(null, { target: { checked: !t.node.checked } }), i.ctx.emit("node-click", t.node.data, t.node, h2);
  }, handleContextMenu: (e) => {
    i.instance.vnode.props.onNodeContextmenu && (e.stopPropagation(), e.preventDefault()), i.ctx.emit("node-contextmenu", e, t.node.data, t.node, h2);
  }, handleExpandIconClick: f, handleCheckChange: g, handleChildNodeExpand: (e, t2, l) => {
    n(t2), i.ctx.emit("node-expand", e, t2, l);
  }, handleDragStart: (e) => {
    i.props.draggable && p.emit("tree-node-drag-start", { event: e, treeNode: t });
  }, handleDragOver: (e) => {
    i.props.draggable && (p.emit("tree-node-drag-over", { event: e, treeNode: { $el: c.value, node: t.node } }), e.preventDefault());
  }, handleDrop: (e) => {
    e.preventDefault();
  }, handleDragEnd: (e) => {
    i.props.draggable && p.emit("tree-node-drag-end", e);
  } };
} });
var Mh = { key: 1, class: "el-tree-node__loading-icon el-icon-loading" };
Eh.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-checkbox"), r = resolveComponent("node-content"), c = resolveComponent("el-tree-node"), p = resolveComponent("el-collapse-transition");
  return withDirectives((openBlock(), createBlock("div", { ref: "node$", class: ["el-tree-node", { "is-expanded": e.expanded, "is-current": e.node.isCurrent, "is-hidden": !e.node.visible, "is-focusable": !e.node.disabled, "is-checked": !e.node.disabled && e.node.checked }], role: "treeitem", tabindex: "-1", "aria-expanded": e.expanded, "aria-disabled": e.node.disabled, "aria-checked": e.node.checked, draggable: e.tree.props.draggable, "data-key": e.getNodeKey(e.node), onClick: t[3] || (t[3] = withModifiers((...t2) => e.handleClick && e.handleClick(...t2), ["stop"])), onContextmenu: t[4] || (t[4] = (...t2) => e.handleContextMenu && e.handleContextMenu(...t2)), onDragstart: t[5] || (t[5] = withModifiers((...t2) => e.handleDragStart && e.handleDragStart(...t2), ["stop"])), onDragover: t[6] || (t[6] = withModifiers((...t2) => e.handleDragOver && e.handleDragOver(...t2), ["stop"])), onDragend: t[7] || (t[7] = withModifiers((...t2) => e.handleDragEnd && e.handleDragEnd(...t2), ["stop"])), onDrop: t[8] || (t[8] = withModifiers((...t2) => e.handleDrop && e.handleDrop(...t2), ["stop"])) }, [createVNode("div", { class: "el-tree-node__content", style: { "padding-left": (e.node.level - 1) * e.tree.props.indent + "px" } }, [createVNode("span", { class: [{ "is-leaf": e.node.isLeaf, expanded: !e.node.isLeaf && e.expanded }, "el-tree-node__expand-icon", e.tree.props.iconClass ? e.tree.props.iconClass : "el-icon-caret-right"], onClick: t[1] || (t[1] = withModifiers((...t2) => e.handleExpandIconClick && e.handleExpandIconClick(...t2), ["stop"])) }, null, 2), e.showCheckbox ? (openBlock(), createBlock(i, { key: 0, "model-value": e.node.checked, indeterminate: e.node.indeterminate, disabled: !!e.node.disabled, onClick: t[2] || (t[2] = withModifiers(() => {
  }, ["stop"])), onChange: e.handleCheckChange }, null, 8, ["model-value", "indeterminate", "disabled", "onChange"])) : createCommentVNode("v-if", true), e.node.loading ? (openBlock(), createBlock("span", Mh)) : createCommentVNode("v-if", true), createVNode(r, { node: e.node, "render-content": e.renderContent }, null, 8, ["node", "render-content"])], 4), createVNode(p, null, { default: withCtx(() => [!e.renderAfterExpand || e.childNodeRendered ? withDirectives((openBlock(), createBlock("div", { key: 0, class: "el-tree-node__children", role: "group", "aria-expanded": e.expanded }, [(openBlock(true), createBlock(Fragment, null, renderList(e.node.childNodes, (t2) => (openBlock(), createBlock(c, { key: e.getNodeKey(t2), "render-content": e.renderContent, "render-after-expand": e.renderAfterExpand, "show-checkbox": e.showCheckbox, node: t2, onNodeExpand: e.handleChildNodeExpand }, null, 8, ["render-content", "render-after-expand", "show-checkbox", "node", "onNodeExpand"]))), 128))], 8, ["aria-expanded"])), [[vShow, e.expanded]]) : createCommentVNode("v-if", true)]), _: 1 })], 42, ["aria-expanded", "aria-disabled", "aria-checked", "draggable", "data-key"])), [[vShow, e.node.visible]]);
}, Eh.__file = "packages/tree/src/tree-node.vue";
var Th = defineComponent({ name: "ElTree", components: { ElTreeNode: Eh }, props: { data: { type: Array }, emptyText: { type: String, default: () => Ca("el.tree.emptyText") }, renderAfterExpand: { type: Boolean, default: true }, nodeKey: String, checkStrictly: Boolean, defaultExpandAll: Boolean, expandOnClickNode: { type: Boolean, default: true }, checkOnClickNode: Boolean, checkDescendants: { type: Boolean, default: false }, autoExpandParent: { type: Boolean, default: true }, defaultCheckedKeys: Array, defaultExpandedKeys: Array, currentNodeKey: [String, Number], renderContent: Function, showCheckbox: { type: Boolean, default: false }, draggable: { type: Boolean, default: false }, allowDrag: Function, allowDrop: Function, props: { type: Object, default: () => ({ children: "children", label: "label", disabled: "disabled" }) }, lazy: { type: Boolean, default: false }, highlightCurrent: Boolean, load: Function, filterNodeMethod: Function, accordion: Boolean, indent: { type: Number, default: 18 }, iconClass: String }, emits: ["check-change", "current-change", "node-click", "node-contextmenu", "node-collapse", "node-expand", "check", "node-drag-start", "node-drag-end", "node-drop", "node-drag-leave", "node-drag-enter", "node-drag-over"], setup(t, a) {
  const s = ref(new wh({ key: t.nodeKey, data: t.data, lazy: t.lazy, props: t.props, load: t.load, currentNodeKey: t.currentNodeKey, checkStrictly: t.checkStrictly, checkDescendants: t.checkDescendants, defaultCheckedKeys: t.defaultCheckedKeys, defaultExpandedKeys: t.defaultExpandedKeys, autoExpandParent: t.autoExpandParent, defaultExpandAll: t.defaultExpandAll, filterNodeMethod: t.filterNodeMethod }));
  s.value.initialize();
  const u = ref(s.value.root), d = ref(null), c = ref(null), p = ref(null), { broadcastExpanded: h2 } = _h(t), { dragState: v } = function({ props: e, ctx: t2, el$: a2, dropIndicator$: n, store: o }) {
    const i = mitt_es_default();
    provide("DragNodeEmitter", i);
    const r = ref({ showDropIndicator: false, draggingNode: null, dropNode: null, allowDrop: true, dropType: null });
    return i.on("tree-node-drag-start", ({ event: l, treeNode: a3 }) => {
      if (typeof e.allowDrag == "function" && !e.allowDrag(a3.node))
        return l.preventDefault(), false;
      l.dataTransfer.effectAllowed = "move";
      try {
        l.dataTransfer.setData("text/plain", "");
      } catch (e2) {
      }
      r.value.draggingNode = a3, t2.emit("node-drag-start", a3.node, l);
    }), i.on("tree-node-drag-over", ({ event: l, treeNode: o2 }) => {
      const i2 = o2, s2 = r.value.dropNode;
      s2 && s2 !== i2 && rt(s2.$el, "is-drop-inner");
      const u2 = r.value.draggingNode;
      if (!u2 || !i2)
        return;
      let d2 = true, c2 = true, p2 = true, h3 = true;
      typeof e.allowDrop == "function" && (d2 = e.allowDrop(u2.node, i2.node, "prev"), h3 = c2 = e.allowDrop(u2.node, i2.node, "inner"), p2 = e.allowDrop(u2.node, i2.node, "next")), l.dataTransfer.dropEffect = c2 ? "move" : "none", (d2 || c2 || p2) && s2 !== i2 && (s2 && t2.emit("node-drag-leave", u2.node, s2.node, l), t2.emit("node-drag-enter", u2.node, i2.node, l)), (d2 || c2 || p2) && (r.value.dropNode = i2), i2.node.nextSibling === u2.node && (p2 = false), i2.node.previousSibling === u2.node && (d2 = false), i2.node.contains(u2.node, false) && (c2 = false), (u2.node === i2.node || u2.node.contains(i2.node)) && (d2 = false, c2 = false, p2 = false);
      const v2 = i2.$el.getBoundingClientRect(), m2 = a2.value.getBoundingClientRect();
      let f2;
      const g = d2 ? c2 ? 0.25 : p2 ? 0.45 : 1 : -1, b = p2 ? c2 ? 0.75 : d2 ? 0.55 : 0 : 1;
      let y = -9999;
      const k = l.clientY - v2.top;
      f2 = k < v2.height * g ? "before" : k > v2.height * b ? "after" : c2 ? "inner" : "none";
      const x = i2.$el.querySelector(".el-tree-node__expand-icon").getBoundingClientRect(), C = n.value;
      f2 === "before" ? y = x.top - m2.top : f2 === "after" && (y = x.bottom - m2.top), C.style.top = y + "px", C.style.left = x.right - m2.left + "px", f2 === "inner" ? it(i2.$el, "is-drop-inner") : rt(i2.$el, "is-drop-inner"), r.value.showDropIndicator = f2 === "before" || f2 === "after", r.value.allowDrop = r.value.showDropIndicator || h3, r.value.dropType = f2, t2.emit("node-drag-over", u2.node, i2.node, l);
    }), i.on("tree-node-drag-end", (e2) => {
      const { draggingNode: l, dropType: a3, dropNode: n2 } = r.value;
      if (e2.preventDefault(), e2.dataTransfer.dropEffect = "move", l && n2) {
        const i2 = { data: l.node.data };
        a3 !== "none" && l.node.remove(), a3 === "before" ? n2.node.parent.insertBefore(i2, n2.node) : a3 === "after" ? n2.node.parent.insertAfter(i2, n2.node) : a3 === "inner" && n2.node.insertChild(i2), a3 !== "none" && o.value.registerNode(i2), rt(n2.$el, "is-drop-inner"), t2.emit("node-drag-end", l.node, n2.node, a3, e2), a3 !== "none" && t2.emit("node-drop", l.node, n2.node, a3, e2);
      }
      l && !n2 && t2.emit("node-drag-end", l.node, null, a3, e2), r.value.showDropIndicator = false, r.value.draggingNode = null, r.value.dropNode = null, r.value.allowDrop = true;
    }), { dragState: r };
  }({ props: t, ctx: a, el$: c, dropIndicator$: p, store: s });
  !function({ el$: e }, t2) {
    const a2 = ref([]), n = ref([]);
    onMounted(() => {
      u2(), at(e.value, "keydown", s2);
    }), onBeforeUnmount(() => {
      nt(e.value, "keydown", s2);
    }), onUpdated(() => {
      a2.value = Array.from(e.value.querySelectorAll("[role=treeitem]")), n.value = Array.from(e.value.querySelectorAll("input[type=checkbox]"));
    }), watch(n, (e2) => {
      e2.forEach((e3) => {
        e3.setAttribute("tabindex", "-1");
      });
    });
    const s2 = (l) => {
      const n2 = l.target;
      if (n2.className.indexOf("el-tree-node") === -1)
        return;
      const o = l.code;
      a2.value = Array.from(e.value.querySelectorAll(".is-focusable[role=treeitem]"));
      const i = a2.value.indexOf(n2);
      let r;
      if ([Dt.up, Dt.down].indexOf(o) > -1) {
        if (l.preventDefault(), o === Dt.up) {
          r = i === -1 ? 0 : i !== 0 ? i - 1 : a2.value.length - 1;
          const e2 = r;
          for (; !t2.value.getNode(a2.value[r].dataset.key).canFocus; ) {
            if (r--, r === e2) {
              r = -1;
              break;
            }
            r < 0 && (r = a2.value.length - 1);
          }
        } else {
          r = i === -1 ? 0 : i < a2.value.length - 1 ? i + 1 : 0;
          const e2 = r;
          for (; !t2.value.getNode(a2.value[r].dataset.key).canFocus; ) {
            if (r++, r === e2) {
              r = -1;
              break;
            }
            r >= a2.value.length && (r = 0);
          }
        }
        r !== -1 && a2.value[r].focus();
      }
      [Dt.left, Dt.right].indexOf(o) > -1 && (l.preventDefault(), n2.click());
      const s3 = n2.querySelector('[type="checkbox"]');
      [Dt.enter, Dt.space].indexOf(o) > -1 && s3 && (l.preventDefault(), s3.click());
    }, u2 = () => {
      var t3;
      a2.value = Array.from(e.value.querySelectorAll(".is-focusable[role=treeitem]")), n.value = Array.from(e.value.querySelectorAll("input[type=checkbox]"));
      const l = e.value.querySelectorAll(".is-checked[role=treeitem]");
      l.length ? l[0].setAttribute("tabindex", "0") : (t3 = a2.value[0]) === null || t3 === void 0 || t3.setAttribute("tabindex", "0");
    };
  }({ el$: c }, s);
  const m = computed(() => {
    const { childNodes: e } = u.value;
    return !e || e.length === 0 || e.every(({ visible: e2 }) => !e2);
  });
  watch(() => t.defaultCheckedKeys, (e) => {
    s.value.setDefaultCheckedKey(e);
  }), watch(() => t.defaultExpandedKeys, (e) => {
    s.value.defaultExpandedKeys = e, s.value.setDefaultExpandedKeys(e);
  }), watch(() => t.data, (e) => {
    s.value.setData(e);
  }, { deep: true }), watch(() => t.checkStrictly, (e) => {
    s.value.checkStrictly = e;
  });
  const f = () => {
    const e = s.value.getCurrentNode();
    return e ? e.data : null;
  };
  return provide("RootTree", { ctx: a, props: t, store: s, root: u, currentNode: d, instance: getCurrentInstance() }), { store: s, root: u, currentNode: d, dragState: v, el$: c, dropIndicator$: p, isEmpty: m, filter: (e) => {
    if (!t.filterNodeMethod)
      throw new Error("[Tree] filterNodeMethod is required when filter");
    s.value.filter(e);
  }, getNodeKey: (e) => gh(t.nodeKey, e.data), getNodePath: (e) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in getNodePath");
    const l = s.value.getNode(e);
    if (!l)
      return [];
    const a2 = [l.data];
    let n = l.parent;
    for (; n && n !== u.value; )
      a2.push(n.data), n = n.parent;
    return a2.reverse();
  }, getCheckedNodes: (e, t2) => s.value.getCheckedNodes(e, t2), getCheckedKeys: (e) => s.value.getCheckedKeys(e), getCurrentNode: f, getCurrentKey: () => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in getCurrentKey");
    const e = f();
    return e ? e[t.nodeKey] : null;
  }, setCheckedNodes: (e, l) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in setCheckedNodes");
    s.value.setCheckedNodes(e, l);
  }, setCheckedKeys: (e, l) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in setCheckedKeys");
    s.value.setCheckedKeys(e, l);
  }, setChecked: (e, t2, l) => {
    s.value.setChecked(e, t2, l);
  }, getHalfCheckedNodes: () => s.value.getHalfCheckedNodes(), getHalfCheckedKeys: () => s.value.getHalfCheckedKeys(), setCurrentNode: (e, l = true) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in setCurrentNode");
    s.value.setUserCurrentNode(e, l);
  }, setCurrentKey: (e, l = true) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in setCurrentKey");
    s.value.setCurrentNodeKey(e, l);
  }, getNode: (e) => s.value.getNode(e), remove: (e) => {
    s.value.remove(e);
  }, append: (e, t2) => {
    s.value.append(e, t2);
  }, insertBefore: (e, t2) => {
    s.value.insertBefore(e, t2);
  }, insertAfter: (e, t2) => {
    s.value.insertAfter(e, t2);
  }, handleNodeExpand: (e, t2, l) => {
    h2(t2), a.emit("node-expand", e, t2, l);
  }, updateKeyChildren: (e, l) => {
    if (!t.nodeKey)
      throw new Error("[Tree] nodeKey is required in updateKeyChild");
    s.value.updateChildren(e, l);
  } };
} });
var Ih = { key: 0, class: "el-tree__empty-block" };
var Oh = { class: "el-tree__empty-text" };
var Nh = { ref: "dropIndicator$", class: "el-tree__drop-indicator" };
Th.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-tree-node");
  return openBlock(), createBlock("div", { ref: "el$", class: ["el-tree", { "el-tree--highlight-current": e.highlightCurrent, "is-dragging": !!e.dragState.draggingNode, "is-drop-not-allow": !e.dragState.allowDrop, "is-drop-inner": e.dragState.dropType === "inner" }], role: "tree" }, [(openBlock(true), createBlock(Fragment, null, renderList(e.root.childNodes, (t2) => (openBlock(), createBlock(i, { key: e.getNodeKey(t2), node: t2, props: e.props, "render-after-expand": e.renderAfterExpand, "show-checkbox": e.showCheckbox, "render-content": e.renderContent, onNodeExpand: e.handleNodeExpand }, null, 8, ["node", "props", "render-after-expand", "show-checkbox", "render-content", "onNodeExpand"]))), 128)), e.isEmpty ? (openBlock(), createBlock("div", Ih, [createVNode("span", Oh, toDisplayString(e.emptyText), 1)])) : createCommentVNode("v-if", true), withDirectives(createVNode("div", Nh, null, 512), [[vShow, e.dragState.showDropIndicator]])], 2);
}, Th.__file = "packages/tree/src/tree.vue", Th.install = (e) => {
  e.component(Th.name, Th);
};
var Dh = Th;
function Vh(e, t, l) {
  let a;
  a = l.response ? "" + (l.response.error || l.response) : l.responseText ? "" + l.responseText : `fail to post ${e} ${l.status}`;
  const n = new Error(a);
  return n.status = l.status, n.method = "post", n.url = e, n;
}
function Bh(e) {
  if (typeof XMLHttpRequest == "undefined")
    return;
  const t = new XMLHttpRequest(), l = e.action;
  t.upload && (t.upload.onprogress = function(t2) {
    t2.total > 0 && (t2.percent = t2.loaded / t2.total * 100), e.onProgress(t2);
  });
  const a = new FormData();
  e.data && Object.keys(e.data).forEach((t2) => {
    a.append(t2, e.data[t2]);
  }), a.append(e.filename, e.file, e.file.name), t.onerror = function() {
    e.onError(Vh(l, 0, t));
  }, t.onload = function() {
    if (t.status < 200 || t.status >= 300)
      return e.onError(Vh(l, 0, t));
    e.onSuccess(function(e2) {
      const t2 = e2.responseText || e2.response;
      if (!t2)
        return t2;
      try {
        return JSON.parse(t2);
      } catch (e3) {
        return t2;
      }
    }(t));
  }, t.open("post", l, true), e.withCredentials && "withCredentials" in t && (t.withCredentials = true);
  const n = e.headers || {};
  for (const e2 in n)
    Se(n, e2) && n[e2] !== null && t.setRequestHeader(e2, n[e2]);
  return t.send(a), t;
}
var Ph = defineComponent({ name: "ElUploadList", components: { ElProgress: Gd }, props: { files: { type: Array, default: () => [] }, disabled: { type: Boolean, default: false }, handlePreview: { type: Function, default: () => xe }, listType: { type: String, default: "text" } }, emits: ["remove"], setup: (e, { emit: t }) => ({ focusing: ref(false), parsePercentage: (e2) => parseInt(e2, 10), handleClick: (t2) => {
  e.handlePreview(t2);
}, handleRemove: (e2, l) => {
  t("remove", l);
}, onFileClicked: (e2) => {
  e2.target.focus();
}, t: Ca }) });
var Ah = createVNode("i", { class: "el-icon-document" }, null, -1);
var zh = { class: "el-upload-list__item-status-label" };
var Lh = { key: 2, class: "el-icon-close-tip" };
var Fh = { key: 4, class: "el-upload-list__item-actions" };
var Rh = createVNode("i", { class: "el-icon-zoom-in" }, null, -1);
var $h = createVNode("i", { class: "el-icon-delete" }, null, -1);
Ph.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-progress");
  return openBlock(), createBlock(TransitionGroup, { tag: "ul", class: ["el-upload-list", "el-upload-list--" + e.listType, { "is-disabled": e.disabled }], name: "el-list" }, { default: withCtx(() => [(openBlock(true), createBlock(Fragment, null, renderList(e.files, (l2) => (openBlock(), createBlock("li", { key: l2, class: ["el-upload-list__item", "is-" + l2.status, e.focusing ? "focusing" : ""], tabindex: "0", onKeydown: withKeys((t2) => !e.disabled && e.handleRemove(t2, l2), ["delete"]), onFocus: t[1] || (t[1] = (t2) => e.focusing = true), onBlur: t[2] || (t[2] = (t2) => e.focusing = false), onClick: t[3] || (t[3] = (...t2) => e.onFileClicked && e.onFileClicked(...t2)) }, [renderSlot(e.$slots, "default", { file: l2 }, () => [l2.status !== "uploading" && ["picture-card", "picture"].includes(e.listType) ? (openBlock(), createBlock("img", { key: 0, class: "el-upload-list__item-thumbnail", src: l2.url, alt: "" }, null, 8, ["src"])) : createCommentVNode("v-if", true), createVNode("a", { class: "el-upload-list__item-name", onClick: (t2) => e.handleClick(l2) }, [Ah, createTextVNode(toDisplayString(l2.name), 1)], 8, ["onClick"]), createVNode("label", zh, [createVNode("i", { class: { "el-icon-upload-success": true, "el-icon-circle-check": e.listType === "text", "el-icon-check": ["picture-card", "picture"].includes(e.listType) } }, null, 2)]), e.disabled ? createCommentVNode("v-if", true) : (openBlock(), createBlock("i", { key: 1, class: "el-icon-close", onClick: (t2) => e.handleRemove(t2, l2) }, null, 8, ["onClick"])), createCommentVNode(" Due to close btn only appears when li gets focused disappears after li gets blurred, thus keyboard navigation can never reach close btn"), createCommentVNode(" This is a bug which needs to be fixed "), createCommentVNode(" TODO: Fix the incorrect navigation interaction "), e.disabled ? createCommentVNode("v-if", true) : (openBlock(), createBlock("i", Lh, toDisplayString(e.t("el.upload.deleteTip")), 1)), l2.status === "uploading" ? (openBlock(), createBlock(i, { key: 3, type: e.listType === "picture-card" ? "circle" : "line", "stroke-width": e.listType === "picture-card" ? 6 : 2, percentage: e.parsePercentage(l2.percentage) }, null, 8, ["type", "stroke-width", "percentage"])) : createCommentVNode("v-if", true), e.listType === "picture-card" ? (openBlock(), createBlock("span", Fh, [createVNode("span", { class: "el-upload-list__item-preview", onClick: (t2) => e.handlePreview(l2) }, [Rh], 8, ["onClick"]), e.disabled ? createCommentVNode("v-if", true) : (openBlock(), createBlock("span", { key: 0, class: "el-upload-list__item-delete", onClick: (t2) => e.handleRemove(t2, l2) }, [$h], 8, ["onClick"]))])) : createCommentVNode("v-if", true)])], 42, ["onKeydown"]))), 128))]), _: 3 }, 8, ["class"]);
}, Ph.__file = "packages/upload/src/upload-list.vue";
var Hh = defineComponent({ name: "ElUploadDrag", props: { disabled: { type: Boolean, default: false } }, emits: ["file"], setup(e, { emit: t }) {
  const a = inject("uploader", {}), n = ref(false);
  return { dragover: n, onDrop: function(l) {
    if (e.disabled || !a)
      return;
    const o = a.accept;
    n.value = false, t("file", o ? Array.from(l.dataTransfer.files).filter((e2) => {
      const { type: t2, name: l2 } = e2, a2 = l2.indexOf(".") > -1 ? "." + l2.split(".").pop() : "", n2 = t2.replace(/\/.*$/, "");
      return o.split(",").map((e3) => e3.trim()).filter((e3) => e3).some((e3) => e3.startsWith(".") ? a2 === e3 : /\/\*$/.test(e3) ? n2 === e3.replace(/\/\*$/, "") : !!/^[^\/]+\/[^\/]+$/.test(e3) && t2 === e3);
    }) : l.dataTransfer.files);
  }, onDragover: function() {
    e.disabled || (n.value = true);
  } };
} });
Hh.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: { "el-upload-dragger": true, "is-dragover": e.dragover }, onDrop: t[1] || (t[1] = withModifiers((...t2) => e.onDrop && e.onDrop(...t2), ["prevent"])), onDragover: t[2] || (t[2] = withModifiers((...t2) => e.onDragover && e.onDragover(...t2), ["prevent"])), onDragleave: t[3] || (t[3] = withModifiers((t2) => e.dragover = false, ["prevent"])) }, [renderSlot(e.$slots, "default")], 34);
}, Hh.__file = "packages/upload/src/upload-dragger.vue";
var Wh = defineComponent({ components: { UploadDragger: Hh }, props: { type: { type: String, default: "" }, action: { type: String, required: true }, name: { type: String, default: "file" }, data: { type: Object, default: () => null }, headers: { type: Object, default: () => null }, withCredentials: { type: Boolean, default: false }, multiple: { type: Boolean, default: null }, accept: { type: String, default: "" }, onStart: { type: Function, default: xe }, onProgress: { type: Function, default: xe }, onSuccess: { type: Function, default: xe }, onError: { type: Function, default: xe }, beforeUpload: { type: Function, default: xe }, drag: { type: Boolean, default: false }, onPreview: { type: Function, default: xe }, onRemove: { type: Function, default: xe }, fileList: { type: Array, default: () => [] }, autoUpload: { type: Boolean, default: true }, listType: { type: String, default: "text" }, httpRequest: { type: Function, default: () => Bh }, disabled: Boolean, limit: { type: Number, default: null }, onExceed: { type: Function, default: xe } }, setup(e) {
  const t = ref({}), a = ref(false), n = ref(null);
  function o(t2) {
    if (e.limit && e.fileList.length + t2.length > e.limit)
      return void e.onExceed(t2, e.fileList);
    let l = Array.from(t2);
    e.multiple || (l = l.slice(0, 1)), l.length !== 0 && l.forEach((t3) => {
      e.onStart(t3), e.autoUpload && i(t3);
    });
  }
  function i(t2) {
    if (n.value.value = null, !e.beforeUpload)
      return r(t2);
    const l = e.beforeUpload(t2);
    l instanceof Promise ? l.then((e2) => {
      const l2 = Object.prototype.toString.call(e2);
      if (l2 === "[object File]" || l2 === "[object Blob]") {
        l2 === "[object Blob]" && (e2 = new File([e2], t2.name, { type: t2.type }));
        for (const l3 in t2)
          Se(t2, l3) && (e2[l3] = t2[l3]);
        r(e2);
      } else
        r(t2);
    }).catch(() => {
      e.onRemove(null, t2);
    }) : l !== false ? r(t2) : e.onRemove(null, t2);
  }
  function r(l) {
    const { uid: a2 } = l, n2 = { headers: e.headers, withCredentials: e.withCredentials, file: l, data: e.data, filename: e.name, action: e.action, onProgress: (t2) => {
      e.onProgress(t2, l);
    }, onSuccess: (n3) => {
      e.onSuccess(n3, l), delete t.value[a2];
    }, onError: (n3) => {
      e.onError(n3, l), delete t.value[a2];
    } }, o2 = e.httpRequest(n2);
    t.value[a2] = o2, o2 instanceof Promise && o2.then(n2.onSuccess, n2.onError);
  }
  function s() {
    e.disabled || (n.value.value = null, n.value.click());
  }
  return { reqs: t, mouseover: a, inputRef: n, abort: function(e2) {
    const l = t.value;
    if (e2) {
      let t2 = e2;
      e2.uid && (t2 = e2.uid), l[t2] && l[t2].abort();
    } else
      Object.keys(l).forEach((e3) => {
        l[e3] && l[e3].abort(), delete l[e3];
      });
  }, post: r, handleChange: function(e2) {
    const t2 = e2.target.files;
    t2 && o(t2);
  }, handleClick: s, handleKeydown: function() {
    s();
  }, upload: i, uploadFiles: o };
} });
function jh(e, t) {
  return t.find((t2) => t2.uid === e.uid);
}
function Kh(e) {
  return Date.now() + e;
}
Wh.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("upload-dragger");
  return openBlock(), createBlock("div", { class: ["el-upload", "el-upload--" + e.listType], tabindex: "0", onClick: t[2] || (t[2] = (...t2) => e.handleClick && e.handleClick(...t2)), onKeydown: t[3] || (t[3] = withKeys(withModifiers((...t2) => e.handleKeydown && e.handleKeydown(...t2), ["self"]), ["enter", "space"])) }, [e.drag ? (openBlock(), createBlock(i, { key: 0, disabled: e.disabled, onFile: e.uploadFiles }, { default: withCtx(() => [renderSlot(e.$slots, "default")]), _: 3 }, 8, ["disabled", "onFile"])) : renderSlot(e.$slots, "default", { key: 1 }), createVNode("input", { ref: "inputRef", class: "el-upload__input", type: "file", name: e.name, multiple: e.multiple, accept: e.accept, onChange: t[1] || (t[1] = (...t2) => e.handleChange && e.handleChange(...t2)) }, null, 40, ["name", "multiple", "accept"])], 34);
}, Wh.__file = "packages/upload/src/upload.vue";
var Yh = defineComponent({ name: "ElUpload", components: { Upload: Wh, UploadList: Ph }, props: { action: { type: String, required: true }, headers: { type: Object, default: () => ({}) }, data: { type: Object, default: () => ({}) }, multiple: { type: Boolean, default: false }, name: { type: String, default: "file" }, drag: { type: Boolean, default: false }, withCredentials: Boolean, showFileList: { type: Boolean, default: true }, accept: { type: String, default: "" }, type: { type: String, default: "select" }, beforeUpload: { type: Function, default: xe }, beforeRemove: { type: Function, default: xe }, onRemove: { type: Function, default: xe }, onChange: { type: Function, default: xe }, onPreview: { type: Function, default: xe }, onSuccess: { type: Function, default: xe }, onProgress: { type: Function, default: xe }, onError: { type: Function, default: xe }, fileList: { type: Array, default: () => [] }, autoUpload: { type: Boolean, default: true }, listType: { type: String, default: "text" }, httpRequest: { type: Function, default: Bh }, disabled: Boolean, limit: { type: Number, default: null }, onExceed: { type: Function, default: () => xe } }, setup(t) {
  const a = inject("elForm", {}), i = computed(() => t.disabled || a.disabled), { abort: s, clearFiles: u, handleError: d, handleProgress: c, handleStart: p, handleSuccess: h2, handleRemove: v, submit: m, uploadRef: f, uploadFiles: g } = ((e) => {
    let t2 = [];
    const a2 = ref([]), n = ref(null);
    let i2 = 1;
    function r(e2) {
      n.value.abort(e2);
    }
    return watch(() => e.listType, (t3) => {
      t3 !== "picture-card" && t3 !== "picture" || (a2.value = a2.value.map((t4) => {
        if (!t4.url && t4.raw)
          try {
            t4.url = URL.createObjectURL(t4.raw);
          } catch (l) {
            e.onError(l, t4, a2.value);
          }
        return t4;
      }));
    }), watch(() => e.fileList, (e2) => {
      (0, import_isEqual.default)(t2, e2) || (t2 = [], a2.value = e2.map((e3) => {
        const l = (0, import_cloneDeep.default)(e3);
        return t2.push(l), Object.assign(Object.assign({}, l), { uid: e3.uid || Kh(i2++), status: e3.status || "success" });
      }));
    }, { immediate: true, deep: true }), { abort: r, clearFiles: function() {
      a2.value = [];
    }, handleError: function(t3, l) {
      const n2 = jh(l, a2.value);
      n2.status = "fail", a2.value.splice(a2.value.indexOf(n2), 1), e.onError(t3, n2, a2.value), e.onChange(n2, a2.value);
    }, handleProgress: function(t3, l) {
      const n2 = jh(l, a2.value);
      e.onProgress(t3, n2, a2.value), n2.status = "uploading", n2.percentage = t3.percent || 0;
    }, handleStart: function(t3) {
      const l = Kh(i2++);
      t3.uid = l;
      const n2 = { name: t3.name, percentage: 0, status: "ready", size: t3.size, raw: t3, uid: l };
      if (e.listType === "picture-card" || e.listType === "picture")
        try {
          n2.url = URL.createObjectURL(t3);
        } catch (t4) {
          console.error("[Element Error][Upload]", t4), e.onError(t4, n2, a2.value);
        }
      a2.value.push(n2), e.onChange(n2, a2.value);
    }, handleSuccess: function(t3, l) {
      const n2 = jh(l, a2.value);
      n2 && (n2.status = "success", n2.response = t3, e.onSuccess(t3, n2, a2.value), e.onChange(n2, a2.value));
    }, handleRemove: function(t3, l) {
      l && (t3 = jh(l, a2.value));
      const n2 = () => {
        r(t3);
        const l2 = a2.value;
        l2.splice(l2.indexOf(t3), 1), e.onRemove(t3, l2);
      };
      if (e.beforeRemove) {
        if (typeof e.beforeRemove == "function") {
          const l2 = e.beforeRemove(t3, a2.value);
          l2 instanceof Promise ? l2.then(() => {
            n2();
          }).catch(xe) : l2 !== false && n2();
        }
      } else
        n2();
    }, submit: function() {
      a2.value.filter((e2) => e2.status === "ready").forEach((e2) => {
        n.value.upload(e2.raw);
      });
    }, uploadFiles: a2, uploadRef: n };
  })(t);
  return provide("uploader", getCurrentInstance()), onBeforeUnmount(() => {
    g.value.forEach((e) => {
      e.url && e.url.indexOf("blob:") === 0 && URL.revokeObjectURL(e.url);
    });
  }), { abort: s, dragOver: ref(false), draging: ref(false), handleError: d, handleProgress: c, handleRemove: v, handleStart: p, handleSuccess: h2, uploadDisabled: i, uploadFiles: g, uploadRef: f, submit: m, clearFiles: u };
}, render() {
  var e, t;
  let l;
  l = this.showFileList ? h(Ph, { disabled: this.uploadDisabled, listType: this.listType, files: this.uploadFiles, onRemove: this.handleRemove, handlePreview: this.onPreview }, this.$slots.file ? { default: (e2) => this.$slots.file({ file: e2.file }) } : null) : null;
  const a = { type: this.type, drag: this.drag, action: this.action, multiple: this.multiple, "before-upload": this.beforeUpload, "with-credentials": this.withCredentials, headers: this.headers, name: this.name, data: this.data, accept: this.accept, fileList: this.uploadFiles, autoUpload: this.autoUpload, listType: this.listType, disabled: this.uploadDisabled, limit: this.limit, "on-exceed": this.onExceed, "on-start": this.handleStart, "on-progress": this.handleProgress, "on-success": this.handleSuccess, "on-error": this.handleError, "on-preview": this.onPreview, "on-remove": this.handleRemove, "http-request": this.httpRequest, ref: "uploadRef" }, n = this.$slots.trigger || this.$slots.default, o = h(Wh, a, { default: () => n == null ? void 0 : n() });
  return h("div", [this.listType === "picture-card" ? l : null, this.$slots.trigger ? [o, this.$slots.default()] : o, (t = (e = this.$slots).tip) === null || t === void 0 ? void 0 : t.call(e), this.listType !== "picture-card" ? l : null]);
} });
Yh.__file = "packages/upload/src/index.vue", Yh.install = (e) => {
  e.component(Yh.name, Yh);
};
var qh = Yh;
var Uh = defineComponent({ props: { prefixCls: { type: String, default: "el-space" } }, setup: (e) => ({ classes: computed(() => e.prefixCls + "__item") }) });
Uh.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", { class: e.classes }, [renderSlot(e.$slots, "default")], 2);
}, Uh.__file = "packages/space/src/item.vue";
var Gh = { mini: 4, small: 8, medium: 12, large: 16 };
var Xh = { direction: { type: String, default: "horizontal" }, class: { type: [String, Object, Array], default: "" }, style: { type: [String, Array, Object] }, alignment: { type: String, default: "center" }, prefixCls: { type: String }, spacer: { type: [Object, String, Number], default: null, validator: (e) => isVNode(e) || Ke(e) || Me(e) }, wrap: { type: Boolean, default: false }, size: { type: [String, Array, Number], validator: (e) => Qt(e) || Ke(e) || _e(e) } };
var Zh = defineComponent({ name: "ElSpace", props: Xh, setup: (e) => function(e2) {
  const t = computed(() => ["el-space", "el-space--" + e2.direction, e2.class]), a = ref(0), i = ref(0);
  return watch(() => [e2.size, e2.wrap, e2.direction], ([e3 = "small", t2, l]) => {
    if (_e(e3)) {
      const [t3 = 0, l2 = 0] = e3;
      a.value = t3, i.value = l2;
    } else {
      let n;
      n = Ke(e3) ? e3 : Gh[e3] || Gh.small, t2 && l === "horizontal" ? a.value = i.value = n : l === "horizontal" ? (a.value = n, i.value = 0) : (i.value = n, a.value = 0);
    }
  }, { immediate: true }), { classes: t, containerStyle: computed(() => [e2.wrap ? { flexWrap: "wrap", marginBottom: `-${i.value}px` } : null, { alignItems: e2.alignment }, e2.style]), itemStyle: computed(() => ({ paddingBottom: i.value + "px", marginRight: a.value + "px" })) };
}(e), render(e) {
  const { classes: t, $slots: l, containerStyle: a, itemStyle: n, spacer: o, prefixCls: i, direction: r } = e, s = renderSlot(l, "default", { key: 0 }, () => []);
  if (s.children.length === 0)
    return null;
  if (_e(s.children)) {
    let e2 = [];
    if (s.children.forEach((t2, l2) => {
      var a2;
      zl(t2) ? _e(t2.children) && t2.children.forEach((t3, l3) => {
        e2.push(createVNode(Uh, { style: n, prefixCls: i, key: "nested-" + l3 }, { default: () => [t3] }, Al.PROPS | Al.STYLE, ["style", "prefixCls"]));
      }) : zl(a2 = t2) || Ll(a2) || e2.push(createVNode(Uh, { style: n, prefixCls: i, key: "LoopKey" + l2 }, { default: () => [t2] }, Al.PROPS | Al.STYLE, ["style", "prefixCls"]));
    }), o) {
      const t2 = e2.length - 1;
      e2 = e2.reduce((e3, l2, a2) => a2 === t2 ? [...e3, l2] : [...e3, l2, createVNode("span", { style: [n, r === "vertical" ? "width: 100%" : null], key: a2 }, [isVNode(o) ? o : createTextVNode(o, Al.TEXT)], Al.STYLE)], []);
    }
    return createVNode("div", { class: t, style: a }, e2, Al.STYLE | Al.CLASS);
  }
  return s.children;
} });
Zh.install = (e) => {
  e.component(Zh.name, Zh);
};
var Qh = defineComponent({ name: "ImgPlaceholder" });
var Jh = { viewBox: "0 0 1024 1024", xmlns: "http://www.w3.org/2000/svg" };
var ev = createVNode("path", { d: "M64 896V128h896v768H64z m64-128l192-192 116.352 116.352L640 448l256 307.2V192H128v576z m224-480a96 96 0 1 1-0.064 192.064A96 96 0 0 1 352 288z" }, null, -1);
Qh.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", Jh, [ev]);
}, Qh.__file = "packages/skeleton-item/src/img-placeholder.vue";
var tv = defineComponent({ name: "ElSkeletonItem", components: { [Qh.name]: Qh }, props: { variant: { type: String, default: "text" } } });
tv.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("img-placeholder");
  return openBlock(), createBlock("div", { class: ["el-skeleton__item", "el-skeleton__" + e.variant] }, [e.variant === "image" ? (openBlock(), createBlock(i, { key: 0 })) : createCommentVNode("v-if", true)], 2);
}, tv.__file = "packages/skeleton-item/src/index.vue", tv.install = (e) => {
  e.component(tv.name, tv);
};
var lv = tv;
var av = defineComponent({ name: "ElSkeleton", components: { [lv.name]: lv }, props: { animated: { type: Boolean, default: false }, count: { type: Number, default: 1 }, rows: { type: Number, default: 3 }, loading: { type: Boolean, default: true }, throttle: { type: Number } }, setup: (e) => ({ uiLoading: function(e2, t = 0) {
  if (t === 0)
    return e2;
  const a = ref(false);
  let n = 0;
  const r = () => {
    n && clearTimeout(n), n = window.setTimeout(() => {
      a.value = e2.value;
    }, t);
  };
  return onMounted(r), watch(() => e2.value, (e3) => {
    e3 ? r() : a.value = e3;
  }), a;
}(computed(() => e.loading), e.throttle) }) });
av.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-skeleton-item");
  return e.uiLoading ? (openBlock(), createBlock("div", mergeProps({ key: 0, class: ["el-skeleton", e.animated ? "is-animated" : ""] }, e.$attrs), [(openBlock(true), createBlock(Fragment, null, renderList(e.count, (t2) => (openBlock(), createBlock(Fragment, { key: t2 }, [e.loading ? renderSlot(e.$slots, "template", { key: 0 }, () => [createVNode(i, { class: "is-first", variant: "p" }), (openBlock(true), createBlock(Fragment, null, renderList(e.rows, (t3) => (openBlock(), createBlock(i, { key: t3, class: { "el-skeleton__paragraph": true, "is-last": t3 === e.rows && e.rows > 1 }, variant: "p" }, null, 8, ["class"]))), 128))]) : createCommentVNode("v-if", true)], 64))), 128))], 16)) : renderSlot(e.$slots, "default", mergeProps({ key: 1 }, e.$attrs));
}, av.__file = "packages/skeleton/src/index.vue", av.install = (e) => {
  e.component(av.name, av);
};
var nv = av;
var ov = defineComponent({ name: "ElCheckTag", props: { checked: Boolean }, emits: ["change"], setup: (e, { emit: t }) => ({ onChange: () => {
  t("change", !e.checked);
} }) });
ov.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("span", { class: { "el-check-tag": true, "is-checked": e.checked }, onClick: t[1] || (t[1] = (...t2) => e.onChange && e.onChange(...t2)) }, [renderSlot(e.$slots, "default")], 2);
}, ov.__file = "packages/check-tag/src/index.vue", ov.install = (e) => {
  e.component(ov.name, ov);
};
var iv = ov;
var rv = defineComponent({ name: "ElDescriptionsItem" });
rv.install = (e) => {
  e.component(rv.name, rv);
};
var sv = rv;
var uv = defineComponent({ name: "ElDescriptionsCell", props: { cell: { type: Object }, tag: { type: String }, type: { type: String } }, setup: (e) => ({ descriptions: inject("elDescriptions", {}), label: computed(() => {
  var t, l, a, n, o;
  return ((a = (l = (t = e.cell) === null || t === void 0 ? void 0 : t.children) === null || l === void 0 ? void 0 : l.label) === null || a === void 0 ? void 0 : a.call(l)) || ((o = (n = e.cell) === null || n === void 0 ? void 0 : n.props) === null || o === void 0 ? void 0 : o.label);
}), content: computed(() => {
  var t, l, a;
  return (a = (l = (t = e.cell) === null || t === void 0 ? void 0 : t.children) === null || l === void 0 ? void 0 : l.default) === null || a === void 0 ? void 0 : a.call(l);
}), span: computed(() => {
  var t, l;
  return ((l = (t = e.cell) === null || t === void 0 ? void 0 : t.props) === null || l === void 0 ? void 0 : l.span) || 1;
}) }), render() {
  switch (this.type) {
    case "label":
      return h(this.tag, { class: ["el-descriptions__label", { "is-bordered-label": this.descriptions.border }], colSpan: this.descriptions.direction === "vertical" ? this.span : 1 }, this.label);
    case "content":
      return h(this.tag, { class: "el-descriptions__content", colSpan: this.descriptions.direction === "vertical" ? this.span : 2 * this.span - 1 }, this.content);
    default:
      return h("td", { colSpan: this.span }, [h("span", { class: ["el-descriptions__label", { "is-bordered-label": this.descriptions.border }] }, this.label), h("span", { class: "el-descriptions__content" }, this.content)]);
  }
} });
var dv = defineComponent({ name: "ElDescriptionsRow", components: { [uv.name]: uv }, props: { row: { type: Array } }, setup: () => ({ descriptions: inject("elDescriptions", {}) }) });
var cv = { key: 1 };
dv.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-descriptions-cell");
  return e.descriptions.direction === "vertical" ? (openBlock(), createBlock(Fragment, { key: 0 }, [createVNode("tr", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.row, (e2, t2) => (openBlock(), createBlock(i, { key: "tr1-" + t2, cell: e2, tag: "th", type: "label" }, null, 8, ["cell"]))), 128))]), createVNode("tr", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.row, (e2, t2) => (openBlock(), createBlock(i, { key: "tr2-" + t2, cell: e2, tag: "td", type: "content" }, null, 8, ["cell"]))), 128))])], 64)) : (openBlock(), createBlock("tr", cv, [(openBlock(true), createBlock(Fragment, null, renderList(e.row, (t2, l2) => (openBlock(), createBlock(Fragment, { key: "tr3-" + l2 }, [e.descriptions.border ? (openBlock(), createBlock(Fragment, { key: 0 }, [createVNode(i, { cell: t2, tag: "td", type: "label" }, null, 8, ["cell"]), createVNode(i, { cell: t2, tag: "td", type: "content" }, null, 8, ["cell"])], 64)) : (openBlock(), createBlock(i, { key: 1, cell: t2, tag: "td", type: "both" }, null, 8, ["cell"]))], 64))), 128))]));
}, dv.__file = "packages/descriptions/src/descriptions-row.vue";
var pv = defineComponent({ name: "ElDescriptions", components: { [sv.name]: sv, [dv.name]: dv }, props: { border: { type: Boolean, default: false }, column: { type: Number, default: 3 }, direction: { type: String, default: "horizontal" }, size: { type: String, validator: Qt }, title: { type: String, default: "" }, extra: { type: String, default: "" } }, setup(e, { slots: t }) {
  provide("elDescriptions", e);
  const l = Xe(), a = computed(() => e.size || l.size), o = (e2) => {
    const t2 = Array.isArray(e2) ? e2 : [e2], l2 = [];
    return t2.forEach((e3) => {
      Array.isArray(e3.children) ? l2.push(...o(e3.children)) : l2.push(e3);
    }), l2;
  }, i = (t2, l2, a2, n = false) => (t2.props || (t2.props = {}), l2 > a2 && (t2.props.span = a2), n && (t2.props.span = e.column), t2);
  return { descriptionsSize: a, getRows: () => {
    var l2;
    const a2 = o((l2 = t.default) === null || l2 === void 0 ? void 0 : l2.call(t)).filter((e2) => {
      var t2;
      return ((t2 = e2 == null ? void 0 : e2.type) === null || t2 === void 0 ? void 0 : t2.name) === "ElDescriptionsItem";
    }), n = [];
    let r = [], s = e.column;
    return a2.forEach((t2, l3) => {
      var o2;
      const u = ((o2 = t2.props) === null || o2 === void 0 ? void 0 : o2.span) || 1;
      if (l3 === a2.length - 1)
        return r.push(i(t2, u, s, true)), void n.push(r);
      u < s ? (s -= u, r.push(t2)) : (r.push(i(t2, u, s)), n.push(r), s = e.column, r = []);
    }), n;
  } };
} });
var hv = { class: "el-descriptions" };
var vv = { key: 0, class: "el-descriptions__header" };
var mv = { class: "el-descriptions__title" };
var fv = { class: "el-descriptions__extra" };
var gv = { class: "el-descriptions__body" };
pv.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-descriptions-row");
  return openBlock(), createBlock("div", hv, [e.title || e.extra || e.$slots.title || e.$slots.extra ? (openBlock(), createBlock("div", vv, [createVNode("div", mv, [renderSlot(e.$slots, "title", {}, () => [createTextVNode(toDisplayString(e.title), 1)])]), createVNode("div", fv, [renderSlot(e.$slots, "extra", {}, () => [createTextVNode(toDisplayString(e.extra), 1)])])])) : createCommentVNode("v-if", true), createVNode("div", gv, [createVNode("table", { class: [{ "is-bordered": e.border }, e.descriptionsSize ? "el-descriptions--" + e.descriptionsSize : ""] }, [createVNode("tbody", null, [(openBlock(true), createBlock(Fragment, null, renderList(e.getRows(), (e2, t2) => (openBlock(), createBlock(i, { key: t2, row: e2 }, null, 8, ["row"]))), 128))])], 2)])]);
}, pv.__file = "packages/descriptions/src/index.vue", pv.install = (e) => {
  e.component(pv.name, pv);
};
var bv = pv;
var yv = defineComponent({ name: "IconSuccess" });
var kv = { viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg" };
var xv = createVNode("path", { d: "M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M34.5548098,16.4485711 C33.9612228,15.8504763 32.9988282,15.8504763 32.4052412,16.4485711 L32.4052412,16.4485711 L21.413757,27.5805811 L21.413757,27.5805811 L21.4034642,27.590855 C21.0097542,27.9781674 20.3766105,27.9729811 19.9892981,27.5792711 L19.9892981,27.5792711 L15.5947588,23.1121428 C15.0011718,22.514048 14.0387772,22.514048 13.4451902,23.1121428 C12.8516033,23.7102376 12.8516033,24.6799409 13.4451902,25.2780357 L13.4451902,25.2780357 L19.6260786,31.5514289 C20.2196656,32.1495237 21.1820602,32.1495237 21.7756472,31.5514289 L21.7756472,31.5514289 L34.5548098,18.614464 C35.1483967,18.0163692 35.1483967,17.0466659 34.5548098,16.4485711 Z" }, null, -1);
yv.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", kv, [xv]);
}, yv.__file = "packages/result/src/icon-success.vue";
var Cv = defineComponent({ name: "IconError" });
var wv = { viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg" };
var Sv = createVNode("path", { d: "M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M32.57818,15.42182 C32.0157534,14.8593933 31.1038797,14.8593933 30.541453,15.42182 L30.541453,15.42182 L24.0006789,21.9625941 L17.458547,15.42182 C16.8961203,14.8593933 15.9842466,14.8593933 15.42182,15.42182 C14.8593933,15.9842466 14.8593933,16.8961203 15.42182,17.458547 L15.42182,17.458547 L21.9639519,23.9993211 L15.42182,30.541453 C14.8593933,31.1038797 14.8593933,32.0157534 15.42182,32.57818 C15.9842466,33.1406067 16.8961203,33.1406067 17.458547,32.57818 L17.458547,32.57818 L24.0006789,26.0360481 L30.541453,32.57818 C31.1038797,33.1406067 32.0157534,33.1406067 32.57818,32.57818 C33.1406067,32.0157534 33.1406067,31.1038797 32.57818,30.541453 L32.57818,30.541453 L26.0374059,23.9993211 L32.57818,17.458547 C33.1406067,16.8961203 33.1406067,15.9842466 32.57818,15.42182 Z" }, null, -1);
Cv.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", wv, [Sv]);
}, Cv.__file = "packages/result/src/icon-error.vue";
var _v = defineComponent({ name: "IconWarning" });
var Ev = { viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg" };
var Mv = createVNode("path", { d: "M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M24,31 C22.8954305,31 22,31.8954305 22,33 C22,34.1045695 22.8954305,35 24,35 C25.1045695,35 26,34.1045695 26,33 C26,31.8954305 25.1045695,31 24,31 Z M24,14 C23.1715729,14 22.5,14.6715729 22.5,15.5 L22.5,15.5 L22.5,27.5 C22.5,28.3284271 23.1715729,29 24,29 C24.8284271,29 25.5,28.3284271 25.5,27.5 L25.5,27.5 L25.5,15.5 C25.5,14.6715729 24.8284271,14 24,14 Z" }, null, -1);
_v.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", Ev, [Mv]);
}, _v.__file = "packages/result/src/icon-warning.vue";
var Tv = defineComponent({ name: "IconInfo" });
var Iv = { viewBox: "0 0 48 48", xmlns: "http://www.w3.org/2000/svg" };
var Ov = createVNode("path", { d: "M24,4 C35.045695,4 44,12.954305 44,24 C44,35.045695 35.045695,44 24,44 C12.954305,44 4,35.045695 4,24 C4,12.954305 12.954305,4 24,4 Z M24,19 L21,19 C20.1715729,19 19.5,19.6715729 19.5,20.5 C19.5,21.3284271 20.1715729,22 21,22 L21,22 L22.5,22 L22.5,31 L21,31 C20.1715729,31 19.5,31.6715729 19.5,32.5 C19.5,33.3284271 20.1715729,34 21,34 L21,34 L27,34 C27.8284271,34 28.5,33.3284271 28.5,32.5 C28.5,31.6715729 27.8284271,31 27,31 L27,31 L25.5,31 L25.5,20.5 C25.5,19.6715729 24.8284271,19 24,19 L24,19 Z M24,13 C22.8954305,13 22,13.8954305 22,15 C22,16.1045695 22.8954305,17 24,17 C25.1045695,17 26,16.1045695 26,15 C26,13.8954305 25.1045695,13 24,13 Z" }, null, -1);
Tv.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("svg", Iv, [Ov]);
}, Tv.__file = "packages/result/src/icon-info.vue";
var Nv = { success: "icon-success", warning: "icon-warning", error: "icon-error", info: "icon-info" };
var Dv = defineComponent({ name: "ElResult", components: { [yv.name]: yv, [Cv.name]: Cv, [_v.name]: _v, [Tv.name]: Tv }, props: { title: { type: String, default: "" }, subTitle: { type: String, default: "" }, icon: { type: String, default: "info" } }, setup: (e) => ({ iconElement: computed(() => {
  const t = e.icon;
  return t && Nv[t] ? Nv[t] : "icon-info";
}) }) });
var Vv = { class: "el-result" };
var Bv = { class: "el-result__icon" };
var Pv = { key: 0, class: "el-result__title" };
var Av = { key: 1, class: "el-result__subtitle" };
var zv = { key: 2, class: "el-result__extra" };
Dv.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("div", Vv, [createVNode("div", Bv, [renderSlot(e.$slots, "icon", {}, () => [(openBlock(), createBlock(resolveDynamicComponent(e.iconElement), { class: e.iconElement }, null, 8, ["class"]))])]), e.title || e.$slots.title ? (openBlock(), createBlock("div", Pv, [renderSlot(e.$slots, "title", {}, () => [createVNode("p", null, toDisplayString(e.title), 1)])])) : createCommentVNode("v-if", true), e.subTitle || e.$slots.subTitle ? (openBlock(), createBlock("div", Av, [renderSlot(e.$slots, "subTitle", {}, () => [createVNode("p", null, toDisplayString(e.subTitle), 1)])])) : createCommentVNode("v-if", true), e.$slots.extra ? (openBlock(), createBlock("div", zv, [renderSlot(e.$slots, "extra")])) : createCommentVNode("v-if", true)]);
}, Dv.__file = "packages/result/src/index.vue", Dv.install = (e) => {
  e.component(Dv.name, Dv);
};
var Lv = Dv;
var Fv = (e) => setTimeout(e, 16);
var Rv = (e) => clearTimeout(e);
ke || (Fv = (e) => window.requestAnimationFrame(e), Rv = (e) => window.cancelAnimationFrame(e));
var $v = "rtl";
var Hv = { cache: { type: Number, default: 2 }, className: { type: String, default: "" }, containerElement: { type: [String, Object], default: "div" }, data: { type: [Array], default: () => [] }, direction: { type: String, default: "ltr", validator: (e) => e === "ltr" || e === $v }, estimatedItemSize: { type: [Number] }, height: { type: [String, Number], required: true }, layout: { type: String, default: "vertical" }, initScrollOffset: { type: Number, default: 0 }, innerElement: { type: [String, Object], default: "div" }, total: { type: Number, required: true }, itemSize: { type: [Number, Function], required: true }, style: { type: [Object, String, Array], default: () => ({}) }, useIsScrolling: { type: Boolean, default: false }, width: { type: [Number, String], required: true } };
var Wv = { className: Hv.className, columnCache: Hv.cache, columnWidth: Hv.itemSize, containerElement: Hv.containerElement, data: Hv.data, direction: Hv.direction, estimatedColumnWidth: Hv.estimatedItemSize, estimatedRowHeight: Hv.estimatedItemSize, height: Object.assign(Object.assign({}, Hv.height), { validator: (e) => Ke(e) }), initScrollLeft: Hv.initScrollOffset, initScrollTop: Hv.initScrollOffset, innerElement: Hv.innerElement, rowCache: Hv.cache, rowHeight: Hv.itemSize, style: Hv.style, useIsScrolling: Hv.useIsScrolling, width: Object.assign(Object.assign({}, Hv.width), { validator: (e) => Ke(e) }), totalColumn: Hv.total, totalRow: Hv.total };
var jv = { layout: Hv.layout, total: Number, ratio: Number, clientSize: Number, scrollFrom: Number, visible: Boolean };
var Kv = { horizontal: "height", vertical: "width" };
var Yv = { horizontal: "left", vertical: "top" };
var qv = (e, t) => e < t ? "forward" : "backward";
var Uv = (e) => e === "ltr" || e === $v || e === "horizontal";
var Gv = (e) => e === $v;
var Xv = null;
function Zv(e = false) {
  if (Xv === null || e) {
    const e2 = document.createElement("div"), t = e2.style;
    t.width = "50px", t.height = "50px", t.overflow = "scroll", t.direction = "rtl";
    const l = document.createElement("div"), a = l.style;
    return a.width = "100px", a.height = "100px", e2.appendChild(l), document.body.appendChild(e2), e2.scrollLeft > 0 ? Xv = "positive-descending" : (e2.scrollLeft = 1, Xv = e2.scrollLeft === 0 ? "negative" : "positive-ascending"), document.body.removeChild(e2), Xv;
  }
  return Xv;
}
var Qv = typeof navigator != "undefined" && Te(navigator) && /Firefox/i.test(navigator.userAgent);
var Jv = { horizontal: "deltaX", vertical: "deltaY" };
var em = defineComponent({ name: "ElVirtualScrollBar", props: jv, emits: ["scroll", "start-move", "stop-move"], setup(e, { emit: t }) {
  const s = ref(null), u = ref(null);
  let d = null, c = null;
  const p = reactive({ isDragging: false, traveled: 0 }), h2 = computed(() => bl[e.layout]), v = computed(() => ({ display: e.visible ? null : "none", position: "absolute", [Kv[e.layout]]: "6px", [Yv[e.layout]]: "2px", right: "2px", bottom: "2px", height: "100%", borderRadius: "4px" })), m = computed(() => {
    if (e.ratio >= 100)
      return Number.POSITIVE_INFINITY;
    if (e.ratio >= 50)
      return e.ratio * e.clientSize / 100;
    const t2 = e.clientSize / 3;
    return Math.floor(Math.min(Math.max(e.ratio * e.clientSize, 20), t2));
  }), f = computed(() => {
    if (!Number.isFinite(m.value))
      return { display: "none" };
    const t2 = m.value + "px";
    return function({ move: e2, size: t3, bar: l }, a) {
      const n = {}, o = `translate${l.axis}(${e2}px)`;
      return n[l.size] = t3, n.transform = o, n.msTransform = o, n.webkitTransform = o, a === "horizontal" ? n.height = "100%" : n.width = "100%", n;
    }({ bar: h2.value, size: t2, move: p.traveled }, e.layout);
  }), g = computed(() => Math.floor(e.clientSize - m.value - 4)), b = () => {
    nt(window, "mousemove", x), nt(window, "mouseup", k), document.onselectstart = c, c = null;
    const e2 = u.value;
    nt(e2, "touchmove", x), nt(e2, "touchend", k);
  }, y = (e2) => {
    e2.stopImmediatePropagation(), e2.ctrlKey || [1, 2].includes(e2.button) || (p.isDragging = true, p[h2.value.axis] = e2.currentTarget[h2.value.offset] - (e2[h2.value.client] - e2.currentTarget.getBoundingClientRect()[h2.value.direction]), t("start-move"), (() => {
      at(window, "mousemove", x), at(window, "mouseup", k);
      const e3 = u.value;
      c = document.onselectstart, document.onselectstart = () => false, at(e3, "touchmove", x), at(e3, "touchend", k);
    })());
  }, k = () => {
    p.isDragging = false, p[h2.value.axis] = 0, t("stop-move"), b();
  }, x = (e2) => {
    const { isDragging: l } = p;
    if (!l)
      return;
    const a = p[h2.value.axis];
    if (!a)
      return;
    Rv(d);
    const n = -1 * (s.value.getBoundingClientRect()[h2.value.direction] - e2[h2.value.client]) - (u.value[h2.value.offset] - a);
    d = Fv(() => {
      p.traveled = Math.max(2, Math.min(n, g.value)), t("scroll", n, g.value);
    });
  }, C = (e2) => e2.preventDefault();
  return watch(() => e.scrollFrom, (t2) => {
    p.isDragging || (p.traveled = Math.ceil(t2 * e.clientSize / (e.clientSize / g.value)));
  }), onMounted(() => {
    ke || (at(s.value, "touchstart", C), at(u.value, "touchstart", y));
  }), onBeforeUnmount(() => {
    nt(s.value, "touchstart", C), b();
  }), { state: p, trackRef: s, trackStyle: v, thumbRef: u, thumbStyle: f, onThumbMouseDown: y, onMouseUp: k };
}, template: '\n    <div\n      role="presentation"\n      ref="trackRef"\n      class="el-virtual-scrollbar"\n      :style="trackStyle"\n      @mousedown.stop.prevent=""\n    >\n      <div\n        ref="thumbRef"\n        class="el-scrollbar__thumb"\n        :style="thumbStyle"\n        @mousedown="onThumbMouseDown"\n      >\n      </div>\n    </div>\n  ' });
var tm = ({ name: a, getOffset: o, getItemSize: r, getItemOffset: s, getEstimatedTotalSize: u, getStartIndexForOffset: d, getStopIndexForStartIndex: c, initCache: p, clearCache: h2, validateProps: v }) => defineComponent({ name: a != null ? a : "ElVirtualList", props: Hv, emits: ["item-rendered", "scroll"], setup(t, { emit: a2, expose: m }) {
  v(t);
  const f = getCurrentInstance(), g = ref(p(t, f)), b = ref(null), y = ref(null), k = ref(null), x = ref({ isScrolling: false, scrollDir: "forward", scrollOffset: Ke(t.initScrollOffset) ? t.initScrollOffset : 0, updateRequested: false, isScrollbarDragging: false }), C = computed(() => {
    const { total: e, cache: l } = t, { isScrolling: a3, scrollDir: n, scrollOffset: o2 } = tt(x);
    if (e === 0)
      return [0, 0, 0, 0];
    const i = d(t, o2, tt(g)), r2 = c(t, i, o2, tt(g)), s2 = a3 && n !== "backward" ? 1 : Math.max(1, l), u2 = a3 && n !== "forward" ? 1 : Math.max(1, l);
    return [Math.max(0, i - s2), Math.max(0, Math.min(e - 1, r2 + u2)), i, r2];
  }), S = computed(() => u(t, tt(g))), _ = computed(() => Uv(t.layout)), E = computed(() => [{ position: "relative", overflow: "hidden", WebkitOverflowScrolling: "touch", willChange: "transform" }, Object.assign({ direction: t.direction, height: Ke(t.height) ? t.height + "px" : t.height, width: Ke(t.width) ? t.width + "px" : t.width }, t.style)]), T = computed(() => {
    const e = tt(S), t2 = tt(_);
    return { height: t2 ? "100%" : e + "px", pointerEvents: tt(x).isScrolling ? "none" : void 0, width: t2 ? e + "px" : "100%" };
  }), I = computed(() => _.value ? t.width : t.height), { onWheel: O } = (({ atEndEdge: e, atStartEdge: t2, layout: l }, a3) => {
    let n = null, o2 = 0;
    const i = (l2) => l2 < 0 && t2.value || l2 > 0 && e.value;
    return { hasReachedEdge: i, onWheel: (e2) => {
      Rv(n);
      const t3 = e2[Jv[l.value]];
      i(o2) && i(o2 + t3) || (o2 += t3, Qv || e2.preventDefault(), n = Fv(() => {
        a3(o2), o2 = 0;
      }));
    } };
  })({ atStartEdge: computed(() => x.value.scrollOffset <= 0), atEndEdge: computed(() => x.value.scrollOffset >= S.value), layout: computed(() => t.layout) }, (e) => {
    var t2, l;
    (l = (t2 = k.value).onMouseUp) === null || l === void 0 || l.call(t2), V(Math.min(x.value.scrollOffset + e, S.value - I.value));
  }), N = () => {
    const { total: e } = t;
    if (e > 0) {
      const [e2, t2, l2, n2] = tt(C);
      a2("item-rendered", e2, t2, l2, n2);
    }
    const { scrollDir: l, scrollOffset: n, updateRequested: o2 } = tt(x);
    a2("scroll", l, n, o2);
  }, D = (0, import_memoize.default)((e, t2, l) => ({})), V = (e) => {
    (e = Math.max(e, 0)) !== tt(x).scrollOffset && (x.value = Object.assign(Object.assign({}, tt(x)), { scrollOffset: e, scrollDir: qv(tt(x).scrollOffset, e), updateRequested: true }), nextTick(P));
  }, B = (e, l = "auto") => {
    const { scrollOffset: a3 } = tt(x);
    e = Math.max(0, Math.min(e, t.total - 1)), V(o(t, e, l, a3, tt(g)));
  }, P = () => {
    x.value.isScrolling = false, nextTick(() => {
      D(-1, null, null);
    });
  };
  onMounted(() => {
    if (ke)
      return;
    const { initScrollOffset: e } = t, l = tt(b);
    Ke(e) && l !== null && (tt(_) ? l.scrollLeft = e : l.scrollTop = e), N();
  }), onUpdated(() => {
    const { direction: e, layout: l } = t, { scrollOffset: a3, updateRequested: n } = tt(x);
    if (n && tt(b) !== null) {
      const t2 = tt(b);
      if (l === "horizontal")
        if (e === $v)
          switch (Zv()) {
            case "negative":
              t2.scrollLeft = -a3;
              break;
            case "positive-ascending":
              t2.scrollLeft = a3;
              break;
            default: {
              const { clientWidth: e2, scrollWidth: l2 } = t2;
              t2.scrollLeft = l2 - e2 - a3;
              break;
            }
          }
        else
          t2.scrollLeft = a3;
      else
        t2.scrollTop = a3;
    }
  });
  const A = { clientSize: I, estimatedTotalSize: S, windowStyle: E, windowRef: b, innerRef: y, innerStyle: T, itemsToRender: C, scrollbarRef: k, states: x, getItemStyle: (e) => {
    const { direction: l, itemSize: a3, layout: n } = t, o2 = D(h2 && a3, h2 && n, h2 && l);
    let i;
    if (Se(o2, String(e)))
      i = o2[e];
    else {
      const a4 = s(t, e, tt(g)), n2 = r(t, e, tt(g)), u2 = tt(_), d2 = l === $v, c2 = u2 ? a4 : 0;
      o2[e] = i = { position: "absolute", left: d2 ? void 0 : c2 + "px", right: d2 ? c2 + "px" : void 0, top: u2 ? 0 : a4 + "px", height: u2 ? "100%" : n2 + "px", width: u2 ? n2 + "px" : "100%" };
    }
    return i;
  }, onScroll: (e) => {
    tt(_) ? ((e2) => {
      const { clientWidth: l, scrollLeft: a3, scrollWidth: n } = e2.currentTarget, o2 = tt(x);
      if (o2.scrollOffset === a3)
        return;
      const { direction: i } = t;
      let r2 = a3;
      if (i === $v)
        switch (Zv()) {
          case "negative":
            r2 = -a3;
            break;
          case "positive-descending":
            r2 = n - l - a3;
        }
      r2 = Math.max(0, Math.min(r2, n - l)), x.value = Object.assign(Object.assign({}, o2), { isScrolling: true, scrollDir: qv(o2.scrollOffset, r2), scrollOffset: r2, updateRequested: false }), nextTick(P);
    })(e) : ((e2) => {
      const { clientHeight: t2, scrollHeight: l, scrollTop: a3 } = e2.currentTarget, n = tt(x);
      if (n.scrollOffset === a3)
        return;
      const o2 = Math.max(0, Math.min(a3, l - t2));
      x.value = Object.assign(Object.assign({}, n), { isScrolling: true, scrollDir: qv(n.scrollOffset, o2), scrollOffset: o2, updateRequested: false }), nextTick(P);
    })(e), N();
  }, onScrollbarScroll: (e, t2) => {
    const l = (S.value - I.value) / t2 * e;
    V(Math.min(S.value - I.value, l));
  }, onWheel: O, scrollTo: V, scrollToItem: B };
  return m({ windowRef: b, innerRef: y, getItemStyleCache: D, scrollTo: V, scrollToItem: B, states: x }), A;
}, render(e) {
  var t;
  const { $slots: l, className: a2, clientSize: n, containerElement: o2, data: i, getItemStyle: r2, innerElement: s2, itemsToRender: u2, innerStyle: d2, layout: c2, total: p2, onScroll: h3, onScrollbarScroll: v2, onWheel: m, states: f, useIsScrolling: g, windowStyle: b } = e, [y, k] = u2, x = resolveDynamicComponent(o2), C = resolveDynamicComponent(s2), w = [];
  if (p2 > 0)
    for (let e2 = y; e2 <= k; e2++)
      w.push((t = l.default) === null || t === void 0 ? void 0 : t.call(l, { data: i, key: e2, index: e2, isScrolling: g ? f.isScrolling : void 0, style: r2(e2) }));
  const S = [h(C, { style: d2, ref: "innerRef" }, Me(C) ? w : { default: () => w })], _ = h(em, { ref: "scrollbarRef", clientSize: n, layout: c2, onScroll: v2, ratio: 100 * n / this.estimatedTotalSize, scrollFrom: f.scrollOffset / (this.estimatedTotalSize - n), total: p2, visible: true }), E = h(x, { class: a2, style: b, onScroll: h3, onWheel: m, ref: "windowRef", key: 0 }, Me(x) ? [S] : { default: () => [S] });
  return h("div", { key: 0, class: "el-vl__wrapper" }, [E, _]);
} });
var lm = tm({ name: "ElFixedSizeList", getItemOffset: ({ itemSize: e }, t) => t * e, getItemSize: ({ itemSize: e }) => e, getEstimatedTotalSize: ({ total: e, itemSize: t }) => t * e, getOffset: ({ height: e, total: t, itemSize: l, layout: a, width: n }, o, i, r) => {
  const s = Uv(a) ? n : e;
  process.env.ENV !== "production" && Me(s) && Le("[ElVirtualList]", "\n        You should set\n          width/height\n        to number when your layout is\n          horizontal/vertical\n      ");
  const u = Math.max(0, t * l - s), d = Math.min(u, o * l), c = Math.max(0, (o + 1) * l - s);
  switch (i === "smart" && (i = r >= c - s && r <= d + s ? "auto" : "center"), i) {
    case "start":
      return d;
    case "end":
      return c;
    case "center": {
      const e2 = Math.round(c + (d - c) / 2);
      return e2 < Math.ceil(s / 2) ? 0 : e2 > u + Math.floor(s / 2) ? u : e2;
    }
    case "auto":
    default:
      return r >= c && r <= d ? r : r < c ? c : d;
  }
}, getStartIndexForOffset: ({ total: e, itemSize: t }, l) => Math.max(0, Math.min(e - 1, Math.floor(l / t))), getStopIndexForStartIndex: ({ height: e, total: t, itemSize: l, layout: a, width: n }, o, i) => {
  const r = o * l, s = Uv(a) ? n : e, u = Math.ceil((s + i - r) / l);
  return Math.max(0, Math.min(t - 1, o + u - 1));
}, initCache() {
}, clearCache: true, validateProps() {
} });
var am = (e, t, l) => {
  const { itemSize: a } = e, { items: n, lastVisitedIndex: o } = l;
  if (t > o) {
    let e2 = 0;
    if (o >= 0) {
      const t2 = n[o];
      e2 = t2.offset + t2.size;
    }
    for (let l2 = o + 1; l2 <= t; l2++) {
      const t2 = a(l2);
      n[l2] = { offset: e2, size: t2 }, e2 += t2;
    }
    l.lastVisitedIndex = t;
  }
  return n[t];
};
var nm = (e, t, l, a, n) => {
  for (; l <= a; ) {
    const o = l + Math.floor((a - l) / 2), i = am(e, o, t).offset;
    if (i === n)
      return o;
    i < n ? l = o + 1 : i > n && (a = o - 1);
  }
  return Math.max(0, l - 1);
};
var om = (e, t, l, a) => {
  const { total: n } = e;
  let o = 1;
  for (; l < n && am(e, l, t).offset < a; )
    l += o, o *= 2;
  return nm(e, t, Math.floor(l / 2), Math.min(l, n - 1), a);
};
var im = ({ total: e }, { items: t, estimatedItemSize: l, lastVisitedIndex: a }) => {
  let n = 0;
  if (a >= e && (a = e - 1), a >= 0) {
    const e2 = t[a];
    n = e2.offset + e2.size;
  }
  return n + (e - a - 1) * l;
};
var rm = tm({ name: "ElDynamicSizeList", getItemOffset: (e, t, l) => am(e, t, l).offset, getItemSize: (e, t, { items: l }) => l[t].size, getEstimatedTotalSize: im, getOffset: (e, t, l, a, n) => {
  const { height: o, layout: i, width: r } = e, s = Uv(i) ? r : o, u = am(e, t, n), d = im(e, n), c = Math.max(0, Math.min(d - s, u.offset)), p = Math.max(0, u.offset - s + u.size);
  switch (l === "smart" && (l = a >= p - s && a <= c + s ? "auto" : "center"), l) {
    case "start":
      return c;
    case "end":
      return p;
    case "center":
      return Math.round(p + (c - p) / 2);
    case "auto":
    default:
      return a >= p && a <= c ? a : a < p ? p : c;
  }
}, getStartIndexForOffset: (e, t, l) => ((e2, t2, l2) => {
  const { items: a, lastVisitedIndex: n } = t2;
  return (n > 0 ? a[n].offset : 0) >= l2 ? nm(e2, t2, 0, n, l2) : om(e2, t2, Math.max(0, n), l2);
})(e, l, t), getStopIndexForStartIndex: (e, t, l, a) => {
  const { height: n, total: o, layout: i, width: r } = e, s = Uv(i) ? r : n, u = am(e, t, a), d = l + s;
  let c = u.offset + u.size, p = t;
  for (; p < o - 1 && c < d; )
    p++, c += am(e, p, a).size;
  return p;
}, initCache({ estimatedItemSize: e = 50 }, t) {
  const l = { items: {}, estimatedItemSize: e, lastVisitedIndex: -1, clearCacheAfterIndex: (e2, a = true) => {
    l.lastVisitedIndex = Math.min(l.lastVisitedIndex, e2 - 1), t.exposed.getItemStyleCache(-1), a && t.proxy.$forceUpdate();
  } };
  return l;
}, clearCache: false, validateProps: ({ itemSize: e }) => {
  typeof e != "function" && Le("ElDynamicSizeList", `
          itemSize is required as function, but the given value was ${typeof e}
        `);
} });
var sm = ({ name: a, clearCache: o, getColumnPosition: r, getColumnStartIndexForOffset: s, getColumnStopIndexForStartIndex: u, getEstimatedTotalHeight: d, getEstimatedTotalWidth: c, getColumnOffset: p, getRowOffset: h2, getRowPosition: v, getRowStartIndexForOffset: m, getRowStopIndexForStartIndex: f, initCache: g, validateProps: b }) => defineComponent({ name: a != null ? a : "ElVirtualList", props: Wv, emits: ["item-rendered", "scroll"], setup(t, { emit: a2, expose: y }) {
  b(t);
  const k = getCurrentInstance(), x = ref(g(t, k)), C = ref(null), S = ref(null), _ = ref({ isScrolling: false, scrollLeft: Ke(t.initScrollLeft) ? t.initScrollLeft : 0, scrollTop: Ke(t.initScrollTop) ? t.initScrollTop : 0, updateRequested: false, xAxisScrollDir: "forward", yAxisScrollDir: "forward" }), E = computed(() => {
    const { totalColumn: e, totalRow: l, columnCache: a3 } = t, { isScrolling: n, xAxisScrollDir: o2, scrollLeft: i } = tt(_);
    if (e === 0 || l === 0)
      return [0, 0, 0, 0];
    const r2 = s(t, i, tt(x)), d2 = u(t, r2, i, tt(x)), c2 = n && o2 !== "backward" ? 1 : Math.max(1, a3), p2 = n && o2 !== "forward" ? 1 : Math.max(1, a3);
    return [Math.max(0, r2 - c2), Math.max(0, Math.min(e - 1, d2 + p2)), r2, d2];
  }), T = computed(() => {
    const { totalColumn: e, totalRow: l, rowCache: a3 } = t, { isScrolling: n, yAxisScrollDir: o2, scrollTop: i } = tt(_);
    if (e === 0 || l === 0)
      return [0, 0, 0, 0];
    const r2 = m(t, i, tt(x)), s2 = f(t, r2, i, tt(x)), u2 = n && o2 !== "backward" ? 1 : Math.max(1, a3), d2 = n && o2 !== "forward" ? 1 : Math.max(1, a3);
    return [Math.max(0, r2 - u2), Math.max(0, Math.min(l - 1, s2 + d2)), r2, s2];
  }), I = computed(() => d(t, tt(x))), O = computed(() => c(t, tt(x))), N = computed(() => [{ position: "relative", overflow: "auto", WebkitOverflowScrolling: "touch", willChange: "transform" }, Object.assign({ direction: t.direction, height: Ke(t.height) ? t.height + "px" : t.height, width: Ke(t.width) ? t.width + "px" : t.width }, t.style)]), D = computed(() => {
    const e = tt(O) + "px";
    return { height: tt(I) + "px", pointerEvents: tt(_).isScrolling ? "none" : void 0, width: e };
  }), V = () => {
    const { totalColumn: e, totalRow: l } = t;
    if (e > 0 && l > 0) {
      const [e2, t2, l2, n2] = tt(E), [o3, i2, r3, s3] = tt(T);
      a2("item-rendered", e2, t2, o3, i2, l2, n2, r3, s3);
    }
    const { scrollLeft: n, scrollTop: o2, updateRequested: i, xAxisScrollDir: r2, yAxisScrollDir: s2 } = tt(_);
    a2("scroll", r2, n, s2, o2, i);
  }, B = (0, import_memoize.default)((e, t2, l) => ({})), P = ({ scrollLeft: e, scrollTop: t2 }) => {
    e = Math.max(e, 0), t2 = Math.max(t2, 0);
    const l = tt(_);
    t2 === l.scrollTop && e === l.scrollLeft || (_.value = Object.assign(Object.assign({}, l), { xAxisScrollDir: qv(l.scrollLeft, e), yAxisScrollDir: qv(l.scrollTop, t2), scrollLeft: e, scrollTop: t2, updateRequested: true }), nextTick(z));
  }, A = (e = 0, l = 0, a3 = "auto") => {
    const n = tt(_);
    l = Math.max(0, Math.min(l, t.totalColumn - 1)), e = Math.max(0, Math.min(e, t.totalRow - 1));
    const o2 = It(), i = tt(x), r2 = d(t, i), s2 = c(t, i);
    P({ scrollLeft: p(t, l, a3, n.scrollLeft, i, s2 > t.width ? o2 : 0), scrollTop: h2(t, e, a3, n.scrollTop, i, r2 > t.height ? o2 : 0) });
  }, z = () => {
    _.value.isScrolling = false, nextTick(() => {
      B(-1, null, null);
    });
  };
  onMounted(() => {
    if (ke)
      return;
    const { initScrollLeft: e, initScrollTop: l } = t, a3 = tt(C);
    a3 !== null && (Ke(e) && (a3.scrollLeft = e), Ke(l) && (a3.scrollTop = l)), V();
  }), onUpdated(() => {
    const { direction: e } = t, { scrollLeft: l, scrollTop: a3, updateRequested: n } = tt(_);
    if (n && tt(C) !== null) {
      const t2 = tt(C);
      if (e === $v)
        switch (Zv()) {
          case "negative":
            t2.scrollLeft = -l;
            break;
          case "positive-ascending":
            t2.scrollLeft = l;
            break;
          default: {
            const { clientWidth: e2, scrollWidth: a4 } = t2;
            t2.scrollLeft = a4 - e2 - l;
            break;
          }
        }
      else
        t2.scrollLeft = Math.max(0, l);
      t2.scrollTop = Math.max(0, a3);
    }
  });
  const L = { windowStyle: N, windowRef: C, columnsToRender: E, innerRef: S, innerStyle: D, states: _, rowsToRender: T, getItemStyle: (e, l) => {
    const { columnWidth: a3, direction: n, rowHeight: i } = t, s2 = B(o && a3, o && i, o && n), u2 = `${e},${l}`;
    if (Se(s2, u2))
      return s2[u2];
    {
      const [, a4] = r(t, l, tt(x)), o2 = tt(x), i2 = Gv(n), [d2, c2] = v(t, e, o2), [p2] = r(t, l, o2);
      return s2[u2] = { position: "absolute", left: i2 ? void 0 : a4 + "px", right: i2 ? a4 + "px" : void 0, top: c2 + "px", height: d2 + "px", width: p2 + "px" }, s2[u2];
    }
  }, onScroll: (e) => {
    const { clientHeight: l, clientWidth: a3, scrollHeight: n, scrollLeft: o2, scrollTop: i, scrollWidth: r2 } = e.currentTarget, s2 = tt(_);
    if (s2.scrollTop === i && s2.scrollLeft === o2)
      return;
    let u2 = o2;
    if (Gv(t.direction))
      switch (Zv()) {
        case "negative":
          u2 = -o2;
          break;
        case "positive-descending":
          u2 = r2 - a3 - o2;
      }
    _.value = Object.assign(Object.assign({}, s2), { isScrolling: true, scrollLeft: u2, scrollTop: Math.max(0, Math.min(i, n - l)), updateRequested: false, xAxisScrollDir: qv(s2.scrollLeft, u2), yAxisScrollDir: qv(s2.scrollTop, i) }), nextTick(z), V();
  }, scrollTo: P, scrollToItem: A };
  return y({ windowRef: C, innerRef: S, getItemStyleCache: B, scrollTo: P, scrollToItem: A, states: _ }), L;
}, render(e) {
  var t;
  const { $slots: l, className: a2, containerElement: n, columnsToRender: o2, data: i, getItemStyle: r2, innerElement: s2, innerStyle: u2, rowsToRender: d2, onScroll: c2, states: p2, useIsScrolling: h3, windowStyle: v2, totalColumn: m2, totalRow: f2 } = e, [g2, b2] = o2, [y, k] = d2, x = resolveDynamicComponent(n), C = resolveDynamicComponent(s2), w = [];
  if (f2 > 0 && m2 > 0)
    for (let e2 = y; e2 <= k; e2++)
      for (let a3 = g2; a3 <= b2; a3++)
        w.push((t = l.default) === null || t === void 0 ? void 0 : t.call(l, { columnIndex: a3, data: i, key: a3, isScrolling: h3 ? p2.isScrolling : void 0, style: r2(e2, a3), rowIndex: e2 }));
  const S = [h(C, { style: u2, ref: "innerRef" }, Me(C) ? w : { default: () => w })];
  return h(x, { class: a2, style: v2, onScroll: c2, ref: "windowRef" }, Me(x) ? S : { default: () => S });
} });
var { max: um, min: dm, floor: cm } = (sm({ name: "ElFixedSizeGrid", getColumnPosition: ({ columnWidth: e }, t) => [e, t * e], getRowPosition: ({ rowHeight: e }, t) => [e, t * e], getEstimatedTotalHeight: ({ totalRow: e, rowHeight: t }) => t * e, getEstimatedTotalWidth: ({ totalColumn: e, columnWidth: t }) => t * e, getColumnOffset: ({ totalColumn: e, columnWidth: t, width: l }, a, n, o, i, r) => {
  l = Number(l);
  const s = Math.max(0, e * t - l), u = Math.min(s, a * t), d = Math.max(0, a * t - l + r + t);
  switch (n === "smart" && (n = o >= d - l && o <= u + l ? "auto" : "center"), n) {
    case "start":
      return u;
    case "end":
      return d;
    case "center":
      const e2 = Math.round(d + (u - d) / 2);
      return e2 < Math.ceil(l / 2) ? 0 : e2 > s + Math.floor(l / 2) ? s : e2;
    case "auto":
    default:
      return o >= d && o <= u ? o : d > u || o < d ? d : u;
  }
}, getRowOffset: ({ rowHeight: e, height: t, totalRow: l }, a, n, o, i, r) => {
  t = Number(t);
  const s = Math.max(0, l * e - t), u = Math.min(s, a * e), d = Math.max(0, a * e - t + r + e);
  switch (n === "smart" && (n = o >= d - t && o <= u + t ? "auto" : "center"), n) {
    case "start":
      return u;
    case "end":
      return d;
    case "center":
      const e2 = Math.round(d + (u - d) / 2);
      return e2 < Math.ceil(t / 2) ? 0 : e2 > s + Math.floor(t / 2) ? s : e2;
    case "auto":
    default:
      return o >= d && o <= u ? o : d > u || o < d ? d : u;
  }
}, getColumnStartIndexForOffset: ({ columnWidth: e, totalColumn: t }, l) => Math.max(0, Math.min(t - 1, Math.floor(l / e))), getColumnStopIndexForStartIndex: ({ columnWidth: e, totalColumn: t, width: l }, a, n) => {
  const o = a * e, i = Math.ceil((l + n - o) / e);
  return Math.max(0, Math.min(t - 1, a + i - 1));
}, getRowStartIndexForOffset: ({ rowHeight: e, totalRow: t }, l) => Math.max(0, Math.min(t - 1, Math.floor(l / e))), getRowStopIndexForStartIndex: ({ rowHeight: e, totalRow: t, height: l }, a, n) => {
  const o = a * e, i = Math.ceil((l + n - o) / e);
  return Math.max(0, Math.min(t - 1, a + i - 1));
}, initCache: () => {
}, clearCache: true, validateProps: ({ columnWidth: e, rowHeight: t }) => {
  Ke(e) || Le("ElFixedSizeGrid", `
            "columnWidth" must be passed as number,
              instead ${typeof e} was given.
          `), Ke(t) || Le("ElFixedSizeGrid", `
            "columnWidth" must be passed as number,
              instead ${typeof t} was given.
          `);
} }), Math);
var pm = { column: "columnWidth", row: "rowHeight" };
var hm = { column: "lastVisitedColumnIndex", row: "lastVisitedRowIndex" };
var vm = (e, t, l, a) => {
  const [n, o, i] = [l[a], e[pm[a]], l[hm[a]]];
  if (t > i) {
    let e2 = 0;
    if (i >= 0) {
      const t2 = n[i];
      e2 = t2.offset + t2.size;
    }
    for (let l2 = i + 1; l2 <= t; l2++) {
      const t2 = o(l2);
      n[l2] = { offset: e2, size: t2 }, e2 += t2;
    }
    l[hm[a]] = t;
  }
  return n[t];
};
var mm = (e, t, l, a, n, o) => {
  for (; l <= a; ) {
    const i = l + cm((a - l) / 2), r = vm(e, i, t, o).offset;
    if (r === n)
      return i;
    r < n ? l = i + 1 : a = i - 1;
  }
  return um(0, l - 1);
};
var fm = (e, t, l, a) => {
  const [n, o] = [t[a], t[hm[a]]];
  return (o > 0 ? n[o].offset : 0) >= l ? mm(e, t, 0, o, l, a) : ((e2, t2, l2, a2, n2) => {
    const o2 = n2 === "column" ? e2.totalColumn : e2.totalRow;
    let i = 1;
    for (; l2 < o2 && vm(e2, l2, t2, n2).offset < a2; )
      l2 += i, i *= 2;
    return mm(e2, t2, cm(l2 / 2), dm(l2, o2 - 1), a2, n2);
  })(e, t, um(0, o), l, a);
};
var gm = ({ totalRow: e }, { estimatedRowHeight: t, lastVisitedRowIndex: l, row: a }) => {
  let n = 0;
  if (l >= e && (l = e - 1), l >= 0) {
    const e2 = a[l];
    n = e2.offset + e2.size;
  }
  return n + (e - l - 1) * t;
};
var bm = ({ totalColumn: e }, { column: t, estimatedColumnWidth: l, lastVisitedColumnIndex: a }) => {
  let n = 0;
  if (a > e && (a = e - 1), a >= 0) {
    const e2 = t[a];
    n = e2.offset + e2.size;
  }
  return n + (e - a - 1) * l;
};
var ym = { column: bm, row: gm };
var km = (e, t, l, a, n, o, i) => {
  const [r, s] = [o === "row" ? e.height : e.width, ym[o]], u = vm(e, t, n, o), d = s(e, n), c = um(0, dm(d - r, u.offset)), p = um(0, u.offset - r + i + u.size);
  switch (l === "smart" && (l = a >= p - r && a <= c + r ? "auto" : "center"), l) {
    case "start":
      return c;
    case "end":
      return p;
    case "center":
      return Math.round(p + (c - p) / 2);
    case "auto":
    default:
      return a >= p && a <= c ? a : p > c || a < p ? p : c;
  }
};
sm({ name: "ElDynamicSizeGrid", getColumnPosition: (e, t, l) => {
  const a = vm(e, t, l, "column");
  return [a.size, a.offset];
}, getRowPosition: (e, t, l) => {
  const a = vm(e, t, l, "row");
  return [a.size, a.offset];
}, getColumnOffset: (e, t, l, a, n, o) => km(e, t, l, a, n, "column", o), getRowOffset: (e, t, l, a, n, o) => km(e, t, l, a, n, "row", o), getColumnStartIndexForOffset: (e, t, l) => fm(e, l, t, "column"), getColumnStopIndexForStartIndex: (e, t, l, a) => {
  const n = vm(e, t, a, "column"), o = l + e.width;
  let i = n.offset + n.size, r = t;
  for (; r < e.totalColumn - 1 && i < o; )
    r++, i += vm(e, t, a, "column").size;
  return r;
}, getEstimatedTotalHeight: gm, getEstimatedTotalWidth: bm, getRowStartIndexForOffset: (e, t, l) => fm(e, l, t, "row"), getRowStopIndexForStartIndex: (e, t, l, a) => {
  const { totalRow: n, height: o } = e, i = vm(e, t, a, "row"), r = l + o;
  let s = i.size + i.offset, u = t;
  for (; u < n - 1 && s < r; )
    u++, s += vm(e, u, a, "row").size;
  return u;
}, initCache: ({ estimatedColumnWidth: e = 50, estimatedRowHeight: t = 50 }) => ({ column: {}, estimatedColumnWidth: e, estimatedRowHeight: t, lastVisitedColumnIndex: -1, lastVisitedRowIndex: -1, row: {} }), clearCache: true, validateProps: ({ columnWidth: e, rowHeight: t }) => {
  Ee(e) || Le("ElDynamicSizeGrid", `
          "columnWidth" must be passed as function,
            instead ${typeof e} was given.
        `), Ee(t) || Le("ElDynamicSizeGrid", `
          "columnWidth" must be passed as function,
            instead ${typeof t} was given.
        `);
} });
var xm = defineComponent({ props: { item: { type: Object, required: true }, style: Object, height: Number } });
xm.render = function(e, t, l, a, n, o) {
  return e.item.isTitle ? (openBlock(), createBlock("div", { key: 0, class: "el-select-group__title", style: [e.style, { lineHeight: e.height + "px" }] }, toDisplayString(e.item.label), 5)) : (openBlock(), createBlock("div", { key: 1, class: "el-select-group__split", style: e.style }, [createVNode("span", { class: "el-select-group__split-dash", style: { top: e.height / 2 + "px" } }, null, 4)], 4));
}, xm.__file = "packages/select-v2/src/group-item.vue";
var Cm = defineComponent({ props: { data: Array, disabled: Boolean, hovering: Boolean, item: Object, index: Number, style: Object, selected: Boolean }, emits: ["select", "hover"], setup: (e, { emit: t }) => ({ hoverItem: () => {
  t("hover", e.index);
}, selectOptionClick: () => {
  e.disabled || t("select", e.item, e.index);
} }) });
Cm.render = function(e, t, l, a, n, o) {
  return openBlock(), createBlock("li", { "aria-selected": e.selected, style: e.style, class: { "el-select-dropdown__option-item": true, "is-selected": e.selected, "is-disabled": e.disabled, hover: e.hovering }, onMouseenter: t[1] || (t[1] = (...t2) => e.hoverItem && e.hoverItem(...t2)), onClick: t[2] || (t[2] = withModifiers((...t2) => e.selectOptionClick && e.selectOptionClick(...t2), ["stop"])) }, [renderSlot(e.$slots, "default", { item: e.item, index: e.index, disabled: e.disabled }, () => [createVNode("span", null, toDisplayString(e.item.label), 1)])], 46, ["aria-selected"]);
}, Cm.__file = "packages/select-v2/src/option-item.vue";
var wm = defineComponent({ name: "ElSelectDropdown", props: { data: Array, hoveringIndex: Number, width: Number }, setup(e) {
  const t = inject("ElSelect"), a = ref([]), o = ref(null), i = computed(() => Ge(t.props.estimatedOptionHeight)), r = computed(() => i.value ? { itemSize: t.props.itemHeight } : { estimatedSize: t.props.estimatedOptionHeight, itemSize: (e2) => a.value[e2] });
  return { select: t, listProps: r, listRef: o, isSized: i, isItemDisabled: (e2, l) => {
    const { disabled: a2, multiple: n, multipleLimit: o2 } = t.props;
    return a2 || !l && !!n && o2 > 0 && e2.length < o2;
  }, isItemHovering: (t2) => e.hoveringIndex === t2, isItemSelected: (e2, l) => t.props.multiple ? ((e3 = [], l2) => {
    const { props: { valueKey: a2 } } = t;
    return Te(l2) ? e3 && e3.some((e4) => Re(e4, a2) === Re(l2, a2)) : e3.includes(l2);
  })(e2, l.value) : ((e3, l2) => {
    if (Te(l2)) {
      const { valueKey: a2 } = t.props;
      return Re(e3, a2) === Re(l2, a2);
    }
    return e3 === l2;
  })(e2, l.value), scrollToItem: (e2) => {
    o.value.scrollToItem(e2);
  } };
}, render(e, t) {
  var l;
  const { $slots: a, data: n, listProps: o, select: i, isSized: r, width: s, isItemDisabled: u, isItemHovering: d, isItemSelected: p } = e, v = r ? lm : rm, { props: m, onSelect: f, onKeyboardNavigate: g, onKeyboardSelect: b } = i, { height: y, modelValue: k, multiple: x } = m;
  if (n.length === 0)
    return h("div", { class: "el-select-dropdown", style: { width: s + "px" } }, (l = a.empty) === null || l === void 0 ? void 0 : l.call(a));
  const C = withCtx((e2) => {
    const { index: t2, data: l2 } = e2, n2 = l2[t2];
    if (l2[t2].type === "Group")
      return h(xm, { item: n2, style: e2.style, height: r ? o.itemSize : o.estimatedSize });
    const i2 = p(k, n2), s2 = u(k, i2);
    return h(Cm, Object.assign(Object.assign({}, e2), { selected: i2, disabled: n2.disabled || s2, hovering: d(t2), item: n2, onSelect: f }), { default: withCtx((e3) => renderSlot(a, "default", e3, () => [h("span", n2.label)])) });
  }), w = h(v, Object.assign({ ref: "listRef", className: "el-select-dropdown__list", data: n, height: y, width: s, total: n.length, onKeydown: [t[1] || (t[1] = withKeys(withModifiers(() => g("forward"), ["stop", "prevent"]), ["down"])), t[2] || (t[2] = withKeys(withModifiers(() => g("backward"), ["stop", "prevent"]), ["up"])), t[3] || (t[3] = withKeys(withModifiers(b, ["stop", "prevent"]), ["enter"])), t[4] || (t[4] = withKeys(withModifiers(() => i.expanded = false, ["stop", "prevent"]), ["esc"])), t[5] || (t[5] = withKeys(() => i.expanded = false, ["tab"]))] }, o), { default: C });
  return h("div", { class: { "is-multiple": x, "el-select-dropdown": true } }, [w]);
} });
wm.__file = "packages/select-v2/src/select-dropdown.vue";
var Sm = (e, t) => {
  const r = inject("elForm", {}), s = inject("elFormItem", {}), u = Xe(), d = reactive({ inputValue: "", displayInputValue: "", calculatedWidth: 0, cachedPlaceholder: "", cachedOptions: [], createdOptions: [], createdLabel: "", createdSelected: false, currentPlaceholder: "", hoveringIndex: -1, comboBoxHovering: false, isOnComposition: false, isSilentBlur: false, isComposing: false, inputLength: 20, inputWidth: 240, initialInputHeight: 0, previousQuery: null, query: "", selectedLabel: "", softFocus: false, tagInMultiLine: false }), c = ref(-1), p = ref(null), h2 = ref(null), v = ref(null), m = ref(null), f = ref(null), g = ref(null), b = ref(null), y = ref(false), k = computed(() => e.disabled || r.disabled), x = computed(() => {
    const t2 = 34 * T.value.length;
    return t2 > e.height ? e.height : t2;
  }), C = computed(() => {
    const t2 = e.multiple ? Array.isArray(e.modelValue) && e.modelValue.length > 0 : e.modelValue !== void 0 && e.modelValue !== null && e.modelValue !== "";
    return e.clearable && !k.value && d.comboBoxHovering && t2;
  }), S = computed(() => e.remote && e.filterable ? "" : y.value ? "arrow-up is-reverse" : "arrow-up"), _ = computed(() => e.remote ? 300 : 0), M = computed(() => {
    const t2 = T.value;
    return e.loading ? e.loadingText || Ca("el.select.loading") : (!e.remote || d.query !== "" || t2.length !== 0) && (e.filterable && d.query && t2.length > 0 ? e.noMatchText || Ca("el.select.noMatch") : t2.length === 0 ? e.noDataText || Ca("el.select.noData") : null);
  }), T = computed(() => {
    const t2 = (e2) => {
      const t3 = d.inputValue;
      return !t3 || e2.label.includes(t3);
    };
    return ((e2) => {
      const t3 = [];
      return e2.map((e3) => {
        _e(e3.options) ? (t3.push({ label: e3.label, isTitle: true, type: "Group" }), e3.options.forEach((e4) => {
          t3.push(e4);
        }), t3.push({ type: "Group" })) : t3.push(e3);
      }), t3;
    })(e.options.concat(d.createdOptions).map((e2) => {
      if (_e(e2.options)) {
        const l = e2.options.filter(t2);
        if (l.length > 0)
          return Object.assign(Object.assign({}, e2), { options: l });
      } else if (t2(e2))
        return e2;
      return null;
    }).filter((e2) => e2 !== null));
  }), I = computed(() => e.size || s.size || u.size), O = computed(() => I.value), N = computed(() => {
    var e2, t2, l;
    return ((l = (t2 = (e2 = f.value) === null || e2 === void 0 ? void 0 : e2.getBoundingClientRect) === null || t2 === void 0 ? void 0 : t2.call(e2)) === null || l === void 0 ? void 0 : l.width) || 200;
  }), D = computed(() => ({ width: (d.calculatedWidth === 0 ? 4 : Math.ceil(d.calculatedWidth) + 4) + "px" })), V = computed(() => _e(e.modelValue) ? e.modelValue.length === 0 && !d.displayInputValue : !e.filterable || d.displayInputValue.length === 0), B = computed(() => e.multiple ? e.placeholder : d.selectedLabel || e.placeholder), P = computed(() => {
    var e2;
    return (e2 = m.value) === null || e2 === void 0 ? void 0 : e2.popperRef;
  }), A = () => {
    var e2, t2, l, a;
    (t2 = (e2 = h2.value).focus) === null || t2 === void 0 || t2.call(e2), (a = (l = m.value).update) === null || a === void 0 || a.call(l);
  }, z = () => {
    var t2, l;
    e.automaticDropdown || k.value || (y.value = !y.value, d.softFocus = true, (l = (t2 = h2.value) === null || t2 === void 0 ? void 0 : t2.focus) === null || l === void 0 || l.call(t2));
  }, L = (t2) => {
    d.previousQuery === t2 || d.isOnComposition || (d.previousQuery !== null || !Ee(e.filterMethod) && !Ee(e.remoteMethod) ? (d.previousQuery = t2, nextTick(() => {
      var e2, t3;
      y.value && ((t3 = (e2 = m.value) === null || e2 === void 0 ? void 0 : e2.update) === null || t3 === void 0 || t3.call(e2));
    }), d.hoveringIndex = -1, e.multiple && e.filterable && nextTick(() => {
      const t3 = 15 * h2.value.value.length + 20;
      d.inputLength = e.collapseTags ? Math.min(50, t3) : t3, W();
    }), e.remote && Ee(e.remoteMethod) ? (d.hoveringIndex = -1, e.remoteMethod(t2)) : Ee(e.filterMethod) && e.filterMethod(t2), e.defaultFirstOption && (e.filterable || e.remote)) : d.previousQuery = t2);
  }, F = (0, import_debounce2.default)(() => {
    e.filterable && d.inputValue !== d.selectedLabel && (d.query = d.selectedLabel, L(d.query));
  }, _.value), R = (0, import_debounce2.default)((e2) => {
    L(e2.target.value);
  }, _.value), $ = (l) => {
    (0, import_isEqual.default)(e.modelValue, l) || t("change", l);
  }, H = (e2) => {
    t(Gt, e2), $(e2);
  }, W = () => {
    e.collapseTags && !e.filterable || nextTick(() => {
      var e2, t2;
      if (!h2.value)
        return;
      const l = g.value;
      f.value.height = l.offsetHeight, y.value && M.value !== false && ((t2 = (e2 = m.value) === null || e2 === void 0 ? void 0 : e2.update) === null || t2 === void 0 || t2.call(e2));
    });
  }, j = () => {
    var t2, l;
    K(), (l = (t2 = m.value) === null || t2 === void 0 ? void 0 : t2.update) === null || l === void 0 || l.call(t2), e.multiple && W();
  }, K = () => {
    h2.value && (d.inputWidth = h2.value.getBoundingClientRect().width);
  }, Y = (t2, l, a = true) => {
    var n, o;
    if (e.multiple) {
      let l2 = e.modelValue.slice();
      const a2 = ((t3 = [], l3) => {
        if (!Te(l3))
          return t3.indexOf(l3);
        const a3 = e.valueKey;
        let n2 = -1;
        return t3.some((e2, t4) => Re(e2, a3) === Re(l3, a3) && (n2 = t4, true)), n2;
      })(l2, t2.value);
      a2 > -1 ? (l2 = [...l2.slice(0, a2), ...l2.slice(a2 + 1)], d.cachedOptions.splice(a2, 1)) : (e.multipleLimit <= 0 || l2.length < e.multipleLimit) && (l2 = [...l2, t2.value], d.cachedOptions.push(t2)), H(l2), t2.created && (d.query = "", L(""), d.inputLength = 20), e.filterable && ((o = (n = h2.value).focus) === null || o === void 0 || o.call(n), U("")), e.filterable && (d.calculatedWidth = b.value.getBoundingClientRect().width), W();
    } else
      c.value = l, d.selectedLabel = t2.label, H(t2.value), y.value = false;
    d.isComposing = false, d.isSilentBlur = a, y.value || nextTick(() => {
    });
  }, q = () => {
    e.filterable && e.allowCreate, d.isComposing = false, d.softFocus = false, nextTick(() => {
      var e2, l;
      (l = (e2 = h2.value) === null || e2 === void 0 ? void 0 : e2.blur) === null || l === void 0 || l.call(e2), b.value && (d.calculatedWidth = b.value.getBoundingClientRect().width), d.isSilentBlur ? d.isSilentBlur = false : d.isComposing && t("blur");
    });
  }, U = (e2) => {
    d.displayInputValue = e2, d.inputValue = e2;
  }, G = (l) => {
    if (k.value)
      return;
    if (e.multiple)
      return void (y.value = true);
    let a;
    if (e.options.length !== 0 && T.value.length !== 0 && T.value.length > 0) {
      l === "forward" ? (a = c.value + 1, a > T.value.length - 1 && (a = 0)) : (a = c.value - 1, a < 0 && (a = T.value.length - 1)), c.value = a;
      const e2 = T.value[a];
      if (e2.disabled || e2.type === "Group")
        return void G(l);
      t(Gt, T.value[a]), $(T.value[a]);
    }
  }, X = () => {
    d.displayInputValue.length > 0 && !y.value && (y.value = true), d.calculatedWidth = b.value.getBoundingClientRect().width, e.multiple && W(), F();
  };
  return watch(y, (e2) => {
    var l, a;
    t("visible-change", e2), e2 ? (a = (l = m.value).update) === null || a === void 0 || a.call(l) : d.displayInputValue = "";
  }), onMounted(() => {
    if (e.multiple)
      e.modelValue.length > 0 && e.modelValue.map((t2) => {
        const l = e.options.find((e2) => e2.value === t2);
        l && d.cachedOptions.push(l);
      });
    else if (e.modelValue) {
      const t2 = e.options.find((t3) => t3.value === e.modelValue);
      t2 && (d.selectedLabel = t2.label);
    }
    vt(f.value, j);
  }), onBeforeMount(() => {
    mt(f.value, j);
  }), { collapseTagSize: O, currentPlaceholder: B, expanded: y, emptyText: M, popupHeight: x, debounce: _, filteredOptions: T, iconClass: S, inputWrapperStyle: D, popperSize: N, shouldShowPlaceholder: V, selectDisabled: k, selectSize: I, showClearBtn: C, states: d, calculatorRef: b, controlRef: p, inputRef: h2, menuRef: v, popper: m, selectRef: f, selectionRef: g, popperRef: P, debouncedOnInputChange: F, debouncedQueryChange: R, deleteTag: (l, a) => {
    const n = e.modelValue.indexOf(a.value);
    if (n > -1 && !k.value) {
      const l2 = [...e.modelValue.slice(0, n), ...e.modelValue.slice(n + 1)];
      d.cachedOptions.splice(n, 1), H(l2), t("remove-tag", a.value), d.softFocus = true, nextTick(A);
    }
    l.stopPropagation();
  }, getLabel: (e2) => Te(e2) ? e2.label : e2, getValueKey: (t2) => Te(t2) ? Re(t2, e.valueKey) : t2, handleBlur: q, handleClear: () => {
    let l;
    l = _e(e.modelValue) ? [] : "", d.softFocus = true, e.multiple ? d.cachedOptions = [] : d.selectedLabel = "", y.value = false, H(l), t("clear"), nextTick(A);
  }, handleClickOutside: () => {
    y.value = false, q();
  }, handleDel: (t2) => {
    if (d.displayInputValue.length === 0) {
      t2.preventDefault();
      const l = e.modelValue.slice();
      l.pop(), d.cachedOptions.pop(), H(l);
    }
  }, handleEsc: () => {
    d.displayInputValue.length > 0 ? U("") : y.value = false;
  }, handleFocus: (l) => {
    d.isComposing = true, d.softFocus ? d.softFocus = false : ((e.automaticDropdown || e.filterable) && (y.value = true), t("focus", l));
  }, handleInputBoxClick: () => {
    d.displayInputValue.length === 0 && y.value && (y.value = false);
  }, toggleMenu: z, onCompositionUpdate: (e2) => {
    U(d.displayInputValue += e2.data), X();
  }, onInput: X, onKeyboardNavigate: G, onKeyboardSelect: () => {
    y.value ? Y(T.value[d.hoveringIndex], d.hoveringIndex, false) : z();
  }, onSelect: Y, onUpdateInputValue: U };
};
var _m = { allowCreate: Boolean, autocomplete: { type: String, default: "none" }, automaticDropdown: Boolean, clearable: Boolean, clearIcon: { type: String, default: "el-icon-circle-close" }, collapseTags: Boolean, defaultFirstOption: Boolean, disabled: Boolean, estimatedOptionHeight: { type: Number, default: void 0 }, filterable: Boolean, filterMethod: Function, height: { type: Number, default: 170 }, itemHeight: { type: Number, default: 34 }, id: String, loading: Boolean, loadingText: String, label: String, modelValue: [Array, String, Number, Boolean, Object], multiple: Boolean, multipleLimit: { type: Number, default: 0 }, name: String, noDataText: String, noMatchText: String, remoteMethod: Function, reserveKeyword: Boolean, options: { type: Array, required: true }, placeholder: { type: String }, popperAppendToBody: { type: Boolean, default: true }, popperClass: { type: String, default: "" }, popperOptions: { type: Object, default: () => ({}) }, remote: Boolean, size: { type: String, validator: Qt }, valueKey: { type: String, default: "value" } };
var Em = defineComponent({ name: "ElSelectV2", components: { ElSelectMenu: wm, ElTag: ro, ElPopper: Kl }, directives: { ClickOutside: Ht, ModelText: vModelText }, props: _m, emits: [Gt, "change", "remove-tag", "clear", "visible-change", "focus", "blur"], setup(e, { emit: t }) {
  const l = Sm(e, t);
  return provide("ElSelect", { props: reactive(Object.assign(Object.assign({}, toRefs(e)), { height: l.popupHeight })), onSelect: l.onSelect, onKeyboardNavigate: l.onKeyboardNavigate, onKeyboardSelect: l.onKeyboardSelect }), l;
} });
var Mm = { key: 0 };
var Tm = { key: 1, class: "el-select-v2__selection" };
var Im = { key: 0, class: "el-select-v2__selected-item" };
var Om = { class: "el-select-v2__tags-text" };
var Nm = { class: "el-select-v2__selected-item el-select-v2__input-wrapper" };
var Dm = { class: "el-select-v2__suffix" };
var Vm = { class: "el-select-v2__empty" };
Em.render = function(e, t, l, a, n, o) {
  const i = resolveComponent("el-tag"), r = resolveComponent("el-select-menu"), p = resolveComponent("el-popper"), y = resolveDirective("model-text"), k = resolveDirective("click-outside");
  return withDirectives((openBlock(), createBlock("div", { ref: "selectRef", class: [[e.selectSize ? "el-select-v2--" + e.selectSize : ""], "el-select-v2"], onClick: t[21] || (t[21] = withModifiers((...t2) => e.toggleMenu && e.toggleMenu(...t2), ["stop"])), onMouseenter: t[22] || (t[22] = (t2) => e.states.comboBoxHovering = true), onMouseleave: t[23] || (t[23] = (t2) => e.states.comboBoxHovering = false) }, [createVNode(p, { ref: "popper", visible: e.expanded, "onUpdate:visible": t[18] || (t[18] = (t2) => e.expanded = t2), "append-to-body": e.popperAppendToBody, "popper-class": "el-select-v2__popper " + e.popperClass, "gpu-acceleration": false, "stop-popper-mouse-event": false, "popper-options": e.popperOptions, "fallback-placements": ["bottom-start", "top-start", "right", "left"], effect: "light", "manual-mode": "", placement: "bottom-start", pure: "", transition: "el-zoom-in-top", trigger: "click", onBeforeEnter: t[19] || (t[19] = (t2) => e.states.inputValue = e.states.displayInputValue), onAfterLeave: t[20] || (t[20] = (t2) => e.states.inputValue = e.states.displayInputValue) }, { trigger: withCtx(() => [createVNode("div", { ref: "selectionRef", class: ["el-select-v2__wrapper", { "is-focused": e.states.isComposing, "is-hovering": e.states.comboBoxHovering, "is-filterable": e.filterable, "is-disabled": e.disabled }] }, [e.$slots.prefix ? (openBlock(), createBlock("div", Mm, [renderSlot(e.$slots, "prefix")])) : createCommentVNode("v-if", true), e.multiple ? (openBlock(), createBlock("div", Tm, [e.collapseTags && e.modelValue.length > 0 ? (openBlock(), createBlock("div", Im, [createVNode(i, { closable: !e.selectDisabled && !e.states.cachedOptions[0].disable, size: e.collapseTagSize, type: "info", "disable-transitions": "", onClose: t[1] || (t[1] = (t2) => e.deleteTag(t2, e.states.cachedOptions[0])) }, { default: withCtx(() => [createVNode("span", { class: "el-select-v2__tags-text", style: { maxWidth: e.inputWidth - 123 + "px" } }, toDisplayString(e.states.cachedOptions[0].label), 5)]), _: 1 }, 8, ["closable", "size"]), e.modelValue.length > 1 ? (openBlock(), createBlock(i, { key: 0, closable: false, size: e.collapseTagSize, type: "info", "disable-transitions": "" }, { default: withCtx(() => [createVNode("span", Om, "+ " + toDisplayString(e.modelValue.length - 1), 1)]), _: 1 }, 8, ["size"])) : createCommentVNode("v-if", true)])) : (openBlock(true), createBlock(Fragment, { key: 1 }, renderList(e.states.cachedOptions, (t2, l2) => (openBlock(), createBlock("div", { key: l2, class: "el-select-v2__selected-item" }, [createVNode(i, { key: e.getValueKey(t2), closable: !e.selectDisabled && !t2.disabled, size: e.collapseTagSize, type: "info", "disable-transitions": "", onClose: (l3) => e.deleteTag(l3, t2) }, { default: withCtx(() => [createTextVNode(toDisplayString(e.getLabel(t2)), 1)]), _: 2 }, 1032, ["closable", "size", "onClose"])]))), 128)), createVNode("div", { class: "el-select-v2__selected-item el-select-v2__input-wrapper", style: e.inputWrapperStyle }, [withDirectives(createVNode("input", { id: e.id, ref: "inputRef", autocomplete: e.autocomplete, "aria-autocomplete": "list", "aria-haspopup": "listbox", autocapitalize: "off", "aria-expanded": e.expanded, "aria-labelledby": e.label, class: "el-select-v2__combobox-input", disabled: e.disabled, role: "combobox", readonly: !e.filterable, spellcheck: "false", type: "text", name: e.name, unselectable: e.expanded ? "on" : void 0, "onUpdate:modelValue": t[2] || (t[2] = (...t2) => e.onUpdateInputValue && e.onUpdateInputValue(...t2)), onClick: t[3] || (t[3] = withModifiers((...t2) => e.handleInputBoxClick && e.handleInputBoxClick(...t2), ["stop", "prevent"])), onFocus: t[4] || (t[4] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onInput: t[5] || (t[5] = (...t2) => e.onInput && e.onInput(...t2)), onCompositionupdate: t[6] || (t[6] = (...t2) => e.onCompositionUpdate && e.onCompositionUpdate(...t2)), onCompositionend: t[7] || (t[7] = (...t2) => e.onInput && e.onInput(...t2)), onKeydown: [t[8] || (t[8] = withKeys(withModifiers((...t2) => e.handleEsc && e.handleEsc(...t2), ["stop", "prevent"]), ["esc"])), t[9] || (t[9] = withKeys(withModifiers((...t2) => e.handleDel && e.handleDel(...t2), ["stop"]), ["delete"]))] }, null, 40, ["id", "autocomplete", "aria-expanded", "aria-labelledby", "disabled", "readonly", "name", "unselectable"]), [[y, e.states.displayInputValue]]), e.filterable ? (openBlock(), createBlock("span", { key: 0, ref: "calculatorRef", "aria-hidden": "true", class: "el-select-v2__input-calculator", textContent: toDisplayString(e.states.displayInputValue) }, null, 8, ["textContent"])) : createCommentVNode("v-if", true)], 4)])) : (openBlock(), createBlock(Fragment, { key: 2 }, [createVNode("div", Nm, [withDirectives(createVNode("input", { id: e.id, ref: "inputRef", "aria-autocomplete": "list", "aria-haspopup": "listbox", "aria-labelledby": e.label, "aria-expanded": e.expanded, autocapitalize: "off", autocomplete: e.autocomplete, class: "el-select-v2__combobox-input", disabled: e.disabled, name: e.name, role: "combobox", readonly: !e.filterable, spellcheck: "false", type: "text", unselectable: e.expanded ? "on" : void 0, onClick: t[10] || (t[10] = withModifiers((...t2) => e.handleInputBoxClick && e.handleInputBoxClick(...t2), ["stop", "prevent"])), onCompositionend: t[11] || (t[11] = (...t2) => e.onInput && e.onInput(...t2)), onCompositionupdate: t[12] || (t[12] = (...t2) => e.onCompositionUpdate && e.onCompositionUpdate(...t2)), onFocus: t[13] || (t[13] = (...t2) => e.handleFocus && e.handleFocus(...t2)), onInput: t[14] || (t[14] = (...t2) => e.onInput && e.onInput(...t2)), onKeydown: t[15] || (t[15] = withKeys(withModifiers((...t2) => e.handleEsc && e.handleEsc(...t2), ["stop", "prevent"]), ["esc"])), "onUpdate:modelValue": t[16] || (t[16] = (...t2) => e.onUpdateInputValue && e.onUpdateInputValue(...t2)) }, null, 40, ["id", "aria-labelledby", "aria-expanded", "autocomplete", "disabled", "name", "readonly", "unselectable"]), [[y, e.states.displayInputValue]])]), e.filterable ? (openBlock(), createBlock("span", { key: 0, ref: "calculatorRef", "aria-hidden": "true", class: "el-select-v2__selected-item el-select-v2__input-calculator", textContent: toDisplayString(e.states.displayInputValue) }, null, 8, ["textContent"])) : createCommentVNode("v-if", true)], 64)), e.shouldShowPlaceholder ? (openBlock(), createBlock("span", { key: 3, class: { "el-select-v2__placeholder": true, "is-transparent": e.states.isComposing || (e.placeholder && e.multiple ? e.modelValue.length === 0 : !e.modelValue) } }, toDisplayString(e.currentPlaceholder), 3)) : createCommentVNode("v-if", true), createVNode("span", Dm, [withDirectives(createVNode("i", { class: ["el-select-v2__caret", "el-input__icon", "el-icon-" + e.iconClass] }, null, 2), [[vShow, !e.showClearBtn]]), e.showClearBtn ? (openBlock(), createBlock("i", { key: 0, class: "el-select-v2__caret el-input__icon " + e.clearIcon, onClick: t[17] || (t[17] = withModifiers((...t2) => e.handleClear && e.handleClear(...t2), ["prevent", "stop"])) }, null, 2)) : createCommentVNode("v-if", true)])], 2)]), default: withCtx(() => [createVNode(r, { ref: "menuRef", data: e.filteredOptions, width: e.popperSize, "hovering-index": e.states.hoveringIndex }, { default: withCtx((t2) => [renderSlot(e.$slots, "default", t2)]), empty: withCtx(() => [renderSlot(e.$slots, "empty", {}, () => [createVNode("p", Vm, toDisplayString(e.emptyText), 1)])]), _: 1 }, 8, ["data", "width", "hovering-index"])]), _: 1 }, 8, ["visible", "append-to-body", "popper-class", "popper-options"])], 34)), [[k, e.handleClickOutside, e.popperRef]]);
}, Em.__file = "packages/select-v2/src/select.vue", Em.install = (e) => {
  e.component(Em.name, Em);
};
if (!ke) {
  const e = window;
  e.dayjs || (e.dayjs = import_dayjs.default);
}
var Bm = "1.0.2-beta.52";
var Pm = (e) => {
  ya = e || ya, ya.name && import_dayjs.default.locale(ya.name);
};
var Am = { size: "", zIndex: 2e3 };
var zm = [gt, Ct, St, Gl, Zl, ta, na, ra, ca, ma, ba, vn, gn, wn, En, mo, oo, Dn, go, ko, iv, xo, So, Io, Eo, ni, ii, nr, hr, mr, kr, _r, Mr, Ir, Jr, ts, al, ns, is, ss, Ns, ks, gl, $s, js, eu, ru, hu, fu, od, dd, fd, Dd, zd, Wd, Kl, Gd, zn, Zd, Jd, tc, lc, Cl, nd, cc, gc, yc, xc, _c, Mc, Tp, Pp, Fp, ro, ln, jp, Yp, th, du, vh, Dh, qh, Zh, nv, lv, bv, sv, Lv, Em];
var Lm = [Fs, Zs, wu, Lu, Ku];
var Fm = (e, t) => {
  const l = Object.assign(Am, t);
  var a;
  Pm(l.locale), l.i18n && (a = l.i18n, ka = a), e.config.globalProperties.$ELEMENT = l, ((e2) => {
    wl = e2;
  })(l), zm.forEach((t2) => {
    e.component(t2.name, t2);
  }), Lm.forEach((t2) => {
    e.use(t2);
  });
};
var Rm = { version: "1.0.2-beta.52", install: Fm };
var index_esm_default = Rm;

// dep:element-plus
var element_plus_default = index_esm_default;
export {
  gt as ElAffix,
  Ct as ElAlert,
  St as ElAside,
  Gl as ElAutocomplete,
  Zl as ElAvatar,
  ta as ElBacktop,
  na as ElBadge,
  ra as ElBreadcrumb,
  ca as ElBreadcrumbItem,
  ma as ElButton,
  ba as ElButtonGroup,
  vn as ElCalendar,
  gn as ElCard,
  wn as ElCarousel,
  En as ElCarouselItem,
  mo as ElCascader,
  oo as ElCascaderPanel,
  iv as ElCheckTag,
  Dn as ElCheckbox,
  go as ElCheckboxButton,
  ko as ElCheckboxGroup,
  xo as ElCol,
  So as ElCollapse,
  Io as ElCollapseItem,
  Eo as ElCollapseTransition,
  ni as ElColorPicker,
  ii as ElContainer,
  nr as ElDatePicker,
  bv as ElDescriptions,
  sv as ElDescriptionsItem,
  hr as ElDialog,
  mr as ElDivider,
  kr as ElDrawer,
  _r as ElDropdown,
  Mr as ElDropdownItem,
  Ir as ElDropdownMenu,
  Jr as ElEmpty,
  ts as ElFooter,
  al as ElForm,
  ns as ElFormItem,
  is as ElHeader,
  ss as ElIcon,
  Ns as ElImage,
  ks as ElImageViewer,
  Fs as ElInfiniteScroll,
  gl as ElInput,
  $s as ElInputNumber,
  js as ElLink,
  Zs as ElLoading,
  eu as ElMain,
  ru as ElMenu,
  hu as ElMenuItem,
  fu as ElMenuItemGroup,
  wu as ElMessage,
  Lu as ElMessageBox,
  Ku as ElNotification,
  od as ElOption,
  dd as ElOptionGroup,
  fd as ElPageHeader,
  Dd as ElPagination,
  zd as ElPopconfirm,
  Wd as ElPopover,
  Kl as ElPopper,
  Gd as ElProgress,
  zn as ElRadio,
  Zd as ElRadioButton,
  Jd as ElRadioGroup,
  tc as ElRate,
  Lv as ElResult,
  lc as ElRow,
  Cl as ElScrollbar,
  nd as ElSelect,
  Em as ElSelectV2,
  nv as ElSkeleton,
  lv as ElSkeletonItem,
  cc as ElSlider,
  Zh as ElSpace,
  gc as ElStep,
  yc as ElSteps,
  xc as ElSubmenu,
  _c as ElSwitch,
  Mc as ElTabPane,
  Tp as ElTable,
  Pp as ElTableColumn,
  Fp as ElTabs,
  ro as ElTag,
  ln as ElTimePicker,
  jp as ElTimeSelect,
  Yp as ElTimeline,
  th as ElTimelineItem,
  du as ElTooltip,
  vh as ElTransfer,
  Dh as ElTree,
  qh as ElUpload,
  element_plus_default as default,
  Fm as install,
  Pm as locale,
  Bm as version
};
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/**
 * Checks if an event is supported in the current execution environment.
 *
 * NOTE: This will not work correctly for non-generic events such as `change`,
 * `reset`, `load`, `error`, and `select`.
 *
 * Borrows from Modernizr.
 *
 * @param {string} eventNameSuffix Event name, e.g. "click".
 * @param {?boolean} capture Check if the capture phase is supported.
 * @return {boolean} True if the event is supported.
 * @internal
 * @license Modernizr 3.0.0pre (Custom Build) | MIT
 */
//# sourceMappingURL=element-plus.js.map
